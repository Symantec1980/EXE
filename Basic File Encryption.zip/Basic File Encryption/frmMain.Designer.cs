﻿namespace Basic_File_Encryption
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.gboEncrypt = new System.Windows.Forms.GroupBox();
            this.btnSaveEncryptionFile = new System.Windows.Forms.Button();
            this.txtSaveEncryptionFile = new System.Windows.Forms.TextBox();
            this.lblSaveAs = new System.Windows.Forms.Label();
            this.btnSelectEncryptionFile = new System.Windows.Forms.Button();
            this.txtEncryptFile = new System.Windows.Forms.TextBox();
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.lblFile = new System.Windows.Forms.Label();
            this.lblInfo = new System.Windows.Forms.Label();
            this.gboDecryption = new System.Windows.Forms.GroupBox();
            this.btnSaveDecryptionFile = new System.Windows.Forms.Button();
            this.txtSaveDecryptionFile = new System.Windows.Forms.TextBox();
            this.lblSaveAs2 = new System.Windows.Forms.Label();
            this.btnSelectDecryptionFile = new System.Windows.Forms.Button();
            this.txtDecryptionFile = new System.Windows.Forms.TextBox();
            this.btnDecrypt = new System.Windows.Forms.Button();
            this.lblFile2 = new System.Windows.Forms.Label();
            this.ofdEncryptionFile = new System.Windows.Forms.OpenFileDialog();
            this.ofdDecryptionFile = new System.Windows.Forms.OpenFileDialog();
            this.sfdEncryptionFile = new System.Windows.Forms.SaveFileDialog();
            this.sfdDecryptionFile = new System.Windows.Forms.SaveFileDialog();
            this.gboEncrypt.SuspendLayout();
            this.gboDecryption.SuspendLayout();
            this.SuspendLayout();
            // 
            // gboEncrypt
            // 
            this.gboEncrypt.Controls.Add(this.btnSaveEncryptionFile);
            this.gboEncrypt.Controls.Add(this.txtSaveEncryptionFile);
            this.gboEncrypt.Controls.Add(this.lblSaveAs);
            this.gboEncrypt.Controls.Add(this.btnSelectEncryptionFile);
            this.gboEncrypt.Controls.Add(this.txtEncryptFile);
            this.gboEncrypt.Controls.Add(this.btnEncrypt);
            this.gboEncrypt.Controls.Add(this.lblFile);
            this.gboEncrypt.Location = new System.Drawing.Point(12, 12);
            this.gboEncrypt.Name = "gboEncrypt";
            this.gboEncrypt.Size = new System.Drawing.Size(318, 98);
            this.gboEncrypt.TabIndex = 0;
            this.gboEncrypt.TabStop = false;
            this.gboEncrypt.Text = "Encryption";
            // 
            // btnSaveEncryptionFile
            // 
            this.btnSaveEncryptionFile.Location = new System.Drawing.Point(276, 43);
            this.btnSaveEncryptionFile.Name = "btnSaveEncryptionFile";
            this.btnSaveEncryptionFile.Size = new System.Drawing.Size(36, 20);
            this.btnSaveEncryptionFile.TabIndex = 3;
            this.btnSaveEncryptionFile.Text = "...";
            this.btnSaveEncryptionFile.UseVisualStyleBackColor = true;
            this.btnSaveEncryptionFile.Click += new System.EventHandler(this.btnSaveEncryptionFile_Click);
            // 
            // txtSaveEncryptionFile
            // 
            this.txtSaveEncryptionFile.Location = new System.Drawing.Point(61, 43);
            this.txtSaveEncryptionFile.Multiline = true;
            this.txtSaveEncryptionFile.Name = "txtSaveEncryptionFile";
            this.txtSaveEncryptionFile.ReadOnly = true;
            this.txtSaveEncryptionFile.Size = new System.Drawing.Size(209, 20);
            this.txtSaveEncryptionFile.TabIndex = 4;
            // 
            // lblSaveAs
            // 
            this.lblSaveAs.AutoSize = true;
            this.lblSaveAs.Location = new System.Drawing.Point(6, 46);
            this.lblSaveAs.Name = "lblSaveAs";
            this.lblSaveAs.Size = new System.Drawing.Size(49, 13);
            this.lblSaveAs.TabIndex = 2;
            this.lblSaveAs.Text = "Save as:";
            // 
            // btnSelectEncryptionFile
            // 
            this.btnSelectEncryptionFile.Location = new System.Drawing.Point(276, 17);
            this.btnSelectEncryptionFile.Name = "btnSelectEncryptionFile";
            this.btnSelectEncryptionFile.Size = new System.Drawing.Size(36, 20);
            this.btnSelectEncryptionFile.TabIndex = 1;
            this.btnSelectEncryptionFile.Text = "...";
            this.btnSelectEncryptionFile.UseVisualStyleBackColor = true;
            this.btnSelectEncryptionFile.Click += new System.EventHandler(this.btnSelectEncryptionFile_Click);
            // 
            // txtEncryptFile
            // 
            this.txtEncryptFile.Location = new System.Drawing.Point(61, 17);
            this.txtEncryptFile.Multiline = true;
            this.txtEncryptFile.Name = "txtEncryptFile";
            this.txtEncryptFile.ReadOnly = true;
            this.txtEncryptFile.Size = new System.Drawing.Size(209, 20);
            this.txtEncryptFile.TabIndex = 1;
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.Location = new System.Drawing.Point(237, 69);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(75, 23);
            this.btnEncrypt.TabIndex = 1;
            this.btnEncrypt.Text = "Encrypt";
            this.btnEncrypt.UseVisualStyleBackColor = true;
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // lblFile
            // 
            this.lblFile.AutoSize = true;
            this.lblFile.Location = new System.Drawing.Point(6, 22);
            this.lblFile.Name = "lblFile";
            this.lblFile.Size = new System.Drawing.Size(26, 13);
            this.lblFile.TabIndex = 0;
            this.lblFile.Text = "File:";
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(184, 220);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(155, 13);
            this.lblInfo.TabIndex = 2;
            this.lblInfo.Text = "Copyright © Prince_Aamir 2011";
            this.lblInfo.Click += new System.EventHandler(this.lblInfo_Click);
            // 
            // gboDecryption
            // 
            this.gboDecryption.Controls.Add(this.btnSaveDecryptionFile);
            this.gboDecryption.Controls.Add(this.txtSaveDecryptionFile);
            this.gboDecryption.Controls.Add(this.lblSaveAs2);
            this.gboDecryption.Controls.Add(this.btnSelectDecryptionFile);
            this.gboDecryption.Controls.Add(this.txtDecryptionFile);
            this.gboDecryption.Controls.Add(this.btnDecrypt);
            this.gboDecryption.Controls.Add(this.lblFile2);
            this.gboDecryption.Location = new System.Drawing.Point(12, 116);
            this.gboDecryption.Name = "gboDecryption";
            this.gboDecryption.Size = new System.Drawing.Size(318, 98);
            this.gboDecryption.TabIndex = 3;
            this.gboDecryption.TabStop = false;
            this.gboDecryption.Text = "Decryption";
            // 
            // btnSaveDecryptionFile
            // 
            this.btnSaveDecryptionFile.Location = new System.Drawing.Point(276, 43);
            this.btnSaveDecryptionFile.Name = "btnSaveDecryptionFile";
            this.btnSaveDecryptionFile.Size = new System.Drawing.Size(36, 20);
            this.btnSaveDecryptionFile.TabIndex = 3;
            this.btnSaveDecryptionFile.Text = "...";
            this.btnSaveDecryptionFile.UseVisualStyleBackColor = true;
            this.btnSaveDecryptionFile.Click += new System.EventHandler(this.btnSaveDecryptionFile_Click);
            // 
            // txtSaveDecryptionFile
            // 
            this.txtSaveDecryptionFile.Location = new System.Drawing.Point(61, 43);
            this.txtSaveDecryptionFile.Multiline = true;
            this.txtSaveDecryptionFile.Name = "txtSaveDecryptionFile";
            this.txtSaveDecryptionFile.ReadOnly = true;
            this.txtSaveDecryptionFile.Size = new System.Drawing.Size(209, 20);
            this.txtSaveDecryptionFile.TabIndex = 4;
            // 
            // lblSaveAs2
            // 
            this.lblSaveAs2.AutoSize = true;
            this.lblSaveAs2.Location = new System.Drawing.Point(6, 46);
            this.lblSaveAs2.Name = "lblSaveAs2";
            this.lblSaveAs2.Size = new System.Drawing.Size(49, 13);
            this.lblSaveAs2.TabIndex = 2;
            this.lblSaveAs2.Text = "Save as:";
            // 
            // btnSelectDecryptionFile
            // 
            this.btnSelectDecryptionFile.Location = new System.Drawing.Point(276, 17);
            this.btnSelectDecryptionFile.Name = "btnSelectDecryptionFile";
            this.btnSelectDecryptionFile.Size = new System.Drawing.Size(36, 20);
            this.btnSelectDecryptionFile.TabIndex = 1;
            this.btnSelectDecryptionFile.Text = "...";
            this.btnSelectDecryptionFile.UseVisualStyleBackColor = true;
            this.btnSelectDecryptionFile.Click += new System.EventHandler(this.btnSelectDecryptionFile_Click);
            // 
            // txtDecryptionFile
            // 
            this.txtDecryptionFile.Location = new System.Drawing.Point(61, 17);
            this.txtDecryptionFile.Multiline = true;
            this.txtDecryptionFile.Name = "txtDecryptionFile";
            this.txtDecryptionFile.ReadOnly = true;
            this.txtDecryptionFile.Size = new System.Drawing.Size(209, 20);
            this.txtDecryptionFile.TabIndex = 1;
            // 
            // btnDecrypt
            // 
            this.btnDecrypt.Location = new System.Drawing.Point(237, 69);
            this.btnDecrypt.Name = "btnDecrypt";
            this.btnDecrypt.Size = new System.Drawing.Size(75, 23);
            this.btnDecrypt.TabIndex = 1;
            this.btnDecrypt.Text = "Decrypt";
            this.btnDecrypt.UseVisualStyleBackColor = true;
            this.btnDecrypt.Click += new System.EventHandler(this.btnDecrypt_Click);
            // 
            // lblFile2
            // 
            this.lblFile2.AutoSize = true;
            this.lblFile2.Location = new System.Drawing.Point(6, 22);
            this.lblFile2.Name = "lblFile2";
            this.lblFile2.Size = new System.Drawing.Size(26, 13);
            this.lblFile2.TabIndex = 0;
            this.lblFile2.Text = "File:";
            // 
            // ofdEncryptionFile
            // 
            this.ofdEncryptionFile.Filter = "All files(*.*)|*.*";
            this.ofdEncryptionFile.Title = "Open file...";
            this.ofdEncryptionFile.FileOk += new System.ComponentModel.CancelEventHandler(this.ofdEncryptionFile_FileOk);
            // 
            // ofdDecryptionFile
            // 
            this.ofdDecryptionFile.Filter = "All files(*.*)|*.*";
            this.ofdDecryptionFile.Title = "Open file...";
            this.ofdDecryptionFile.FileOk += new System.ComponentModel.CancelEventHandler(this.ofdDecryptionFile_FileOk);
            // 
            // sfdEncryptionFile
            // 
            this.sfdEncryptionFile.Filter = "All files(*.*)|*.*";
            this.sfdEncryptionFile.Title = "Save file...";
            this.sfdEncryptionFile.FileOk += new System.ComponentModel.CancelEventHandler(this.sfdEncryptionFile_FileOk);
            // 
            // sfdDecryptionFile
            // 
            this.sfdDecryptionFile.Filter = "All files(*.*)|*.*";
            this.sfdDecryptionFile.Title = "Save file...";
            this.sfdDecryptionFile.FileOk += new System.ComponentModel.CancelEventHandler(this.sfdDecryptionFile_FileOk);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 239);
            this.Controls.Add(this.gboDecryption);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.gboEncrypt);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Basic File Encryption";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.gboEncrypt.ResumeLayout(false);
            this.gboEncrypt.PerformLayout();
            this.gboDecryption.ResumeLayout(false);
            this.gboDecryption.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gboEncrypt;
        private System.Windows.Forms.Button btnSelectEncryptionFile;
        private System.Windows.Forms.TextBox txtEncryptFile;
        private System.Windows.Forms.Button btnEncrypt;
        private System.Windows.Forms.Label lblFile;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Button btnSaveEncryptionFile;
        private System.Windows.Forms.TextBox txtSaveEncryptionFile;
        private System.Windows.Forms.Label lblSaveAs;
        private System.Windows.Forms.GroupBox gboDecryption;
        private System.Windows.Forms.Button btnSaveDecryptionFile;
        private System.Windows.Forms.TextBox txtSaveDecryptionFile;
        private System.Windows.Forms.Label lblSaveAs2;
        private System.Windows.Forms.Button btnSelectDecryptionFile;
        private System.Windows.Forms.TextBox txtDecryptionFile;
        private System.Windows.Forms.Button btnDecrypt;
        private System.Windows.Forms.Label lblFile2;
        private System.Windows.Forms.OpenFileDialog ofdEncryptionFile;
        private System.Windows.Forms.OpenFileDialog ofdDecryptionFile;
        private System.Windows.Forms.SaveFileDialog sfdEncryptionFile;
        private System.Windows.Forms.SaveFileDialog sfdDecryptionFile;
    }
}

