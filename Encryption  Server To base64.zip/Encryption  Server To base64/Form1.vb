﻿Public Class Form1

    Dim SaveFileDialog1 As Object
    Dim txtEncoded As Object
    Dim txtDecoded As Object

    Private Sub BlackShadesNetButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackShadesNetButton1.Click
        Dim ofd As New OpenFileDialog With
            {
                .Filter = "ExE Files (*.exe) | *.exe"
                }
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            BlackShadesNetTextBox1.Text = ofd.FileName
        End If
    End Sub

    Private Sub BlackShadesNetButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackShadesNetButton2.Click
        Dim Brow1 As New FolderBrowserDialog
        Dim Brow2 As FolderBrowserDialog = Brow1
        If Brow2.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Dim a As String = NumericUpDown1.Value
            Dim b As String = Convert.ToBase64String(IO.File.ReadAllBytes(BlackShadesNetTextBox1.Text))
            Dim c As String = b.Length
            Dim d As String = c / a
            Dim lll As String = 1
            For i As Integer = 1 To a
                Dim split As String = Mid(b, lll, d)
                IO.File.WriteAllText(Brow2.SelectedPath & "\part" & i & ".txt", split)
                lll += a
            Next
        End If
        MsgBox("Encryption has been ^ _ ^")
    End Sub

    Private Sub BlackShadesNetButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackShadesNetButton4.Click
        Dim s As New Form3
        s.Show()
    End Sub

    Private Sub BlackShadesNetButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackShadesNetButton3.Click
        Dim s As New Form2
        s.Show()
    End Sub

    Private Sub BlackShadesNetButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlackShadesNetButton5.Click
        Process.Start("http://pastebin.com/") ' vb.net
    End Sub
End Class
