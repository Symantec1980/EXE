﻿Imports System.Security.Cryptography
Imports System.IO
Imports System.Text.Encoding


Public Class Form1


    Private Sub ButtonENCRIPTAR_Click(sender As Object, e As EventArgs) Handles ButtonENCRIPTAR.Click
        If TextBoxPASSWORD.Text <> "" Then

            If TextBoxIN.Text <> "" Then


                File.WriteAllText(Application.StartupPath & "\ORIGINAL.TXT", TextBoxIN.Text, UTF7)
                File.WriteAllText(Application.StartupPath & "\ENCRIPTADO.TXT", TextBoxOUT.Text, UTF7)


                PROCESAR(TextBoxPASSWORD.Text, Application.StartupPath & "\ORIGINAL.TXT", Application.StartupPath & "\ENCRIPTADO.TXT", True)
                TextBoxOUT.Text = File.ReadAllText(Application.StartupPath & "\ENCRIPTADO.TXT", UTF7)
            Else
                MsgBox("NO HAS ESCRITO NADA")
            End If

        Else
            MsgBox("NO HAS PUESTO CONTRASEÑA")
        End If
    End Sub

    Private Sub ButtonDESENCRIPTAR_Click(sender As Object, e As EventArgs) Handles ButtonDESENCRIPTAR.Click
        TextBoxIN.Text = ""
        TextBoxOUT.Text = ""
        If TextBoxPASSWORD.Text <> "" Then

            File.WriteAllText(Application.StartupPath & "\DESENCRIPTADO.TXT", TextBoxIN.Text, UTF7)
            If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then

                TextBoxIN.Text = File.ReadAllText(OpenFileDialog1.FileName, UTF7)

                PROCESAR(TextBoxPASSWORD.Text, OpenFileDialog1.FileName, Application.StartupPath & "\DESENCRIPTADO.TXT", False)


                TextBoxOUT.Text = File.ReadAllText(Application.StartupPath & "\DESENCRIPTADO.TXT", UTF7)
                If TextBoxOUT.Text = "" Then
                    MsgBox("CONTRASEÑA INCORRECTA")
                End If

            End If
        Else
            MsgBox("NO HAS PUESTO CONTRASEÑA")
        End If

    End Sub

    Private Sub ButtonARCHIVO_Click(sender As Object, e As EventArgs) Handles ButtonARCHIVO.Click
        If OpenFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBoxIN.Text = File.ReadAllText(OpenFileDialog1.FileName, UTF7)
        End If
    End Sub
    Private Sub ButtonGUARDAR_Click(sender As Object, e As EventArgs) Handles ButtonGUARDAR.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            File.Copy(Application.StartupPath & "\ENCRIPTADO.TXT", SaveFileDialog1.FileName & ".txt")
        End If
    End Sub
    Private Sub ButtonGUARDARDES_Click(sender As Object, e As EventArgs) Handles ButtonGUARDARDES.Click
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            File.Copy(Application.StartupPath & "\DESENCRIPTADO.TXT", SaveFileDialog1.FileName & ".txt")
        End If
    End Sub
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        File.Delete(Application.StartupPath & "\ORIGINAL.TXT")
        File.Delete(Application.StartupPath & "\ENCRIPTADO.TXT")
        File.Delete(Application.StartupPath & "\DESENCRIPTADO.TXT")
    End Sub
    Private Sub PROCESAR(ByVal PASSWORDTEXT As String, ByVal INTEXT As String, ByVal OUTTEXT As String, ByVal ENCRIPTA As Boolean)

        Using INstream As New FileStream(INTEXT, FileMode.Open, FileAccess.Read)
            Using OUTstream As New FileStream(OUTTEXT, FileMode.Create, FileAccess.Write)


                Dim MIAES As New DESCryptoServiceProvider()

                ' OBTIENE EL TAMAÑO VALIDO DE KEY
                Dim KEYSIZE As Integer = 0
                For i As Integer = 1024 To 1 Step -1
                    If MIAES.ValidKeySize(i) Then
                        KEYSIZE = i
                        Exit For
                    End If
                Next i
                Debug.Assert(KEYSIZE > 0)

                ' OBTIENE EL TAMAÑO VALIDO DE BLOCK
                Dim BLOCKSIZE As Integer = MIAES.BlockSize

                ' KEY , IV
                Dim KEY As Byte() = Nothing
                Dim IV As Byte() = Nothing


                Dim salt As Byte() = {&HA9, &HE3, &HF1, &H0, &HB5, &HA4, &HC5, &HD6, &HD1, &HF3, &HFE, &H1F, &HDD, &HAA}
                Dim DERIVADOS As New Rfc2898DeriveBytes(PASSWORDTEXT, salt, 1000)

                KEY = DERIVADOS.GetBytes(KEYSIZE \ 8)
                IV = DERIVADOS.GetBytes(BLOCKSIZE \ 8)


                'ENCRIPTADOR/DESENCRIPTADOR.
                Dim ENCRIPTADOR As ICryptoTransform
                If ENCRIPTA = True Then
                    ENCRIPTADOR = MIAES.CreateEncryptor(KEY, IV)
                Else
                    ENCRIPTADOR = MIAES.CreateDecryptor(KEY, IV)
                End If

                Try
                    Using CRYPTOstream As New CryptoStream(OUTstream, ENCRIPTADOR, CryptoStreamMode.Write)

                        Const BLOCK_SIZE As Integer = 1024
                        Dim BUFFER(BLOCK_SIZE) As Byte
                        Dim LEER As Integer
                        Do
                            LEER = INstream.Read(BUFFER, 0, BLOCK_SIZE)
                            If LEER = 0 Then Exit Do
                            CRYPTOstream.Write(BUFFER, 0, LEER)
                        Loop
                        CRYPTOstream.Flush()
                        CRYPTOstream.Close()
                    End Using
                    Catch ex As Exception
                    End Try

                    ENCRIPTADOR.Dispose()
                    INstream.Close()
                    OUTstream.Close()
            End Using
        End Using
    End Sub

End Class
