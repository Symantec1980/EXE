﻿Public Class Form2

    Private Sub DevButton1_Click(sender As Object, e As EventArgs) Handles DevButton1.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class