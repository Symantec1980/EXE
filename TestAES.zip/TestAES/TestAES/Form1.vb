﻿Imports System.IO, System.Text, System.Security.Cryptography
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim OpenFile As New OpenFileDialog()
        If OpenFile.ShowDialog = DialogResult.OK Then
            txtFile.Text = OpenFile.FileName
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim SaveFile As New SaveFileDialog()
        If SaveFile.ShowDialog = DialogResult.OK Then
            File.WriteAllBytes(SaveFile.FileName, AESEncryption(File.ReadAllBytes(txtFile.Text), txtKey.Text))
        End If
    End Sub

    Public Function AESEncryption(ByVal Data As Byte(), ByVal sKey As String) As Byte()
        'Encryption Function
        Dim AES As New AesCryptoServiceProvider()
        Dim Buffer() As Byte = Nothing
        If Data.Length <> 0 Then
            Dim bKey() As Byte = Encoding.UTF8.GetBytes(sKey)
            Dim Key() As Byte = New MD5CryptoServiceProvider().ComputeHash(bKey, 0, bKey.Length)
            AES.Key = Key
            AES.Mode = CipherMode.ECB
            AES.Padding = PaddingMode.None
            Buffer = AES.CreateEncryptor().TransformFinalBlock(Data, 0, Data.Length)
        End If
        Return Buffer
    End Function
    '=============================================================================================
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim SaveFile As New SaveFileDialog()
        If SaveFile.ShowDialog = DialogResult.OK Then
            File.WriteAllBytes(SaveFile.FileName, AESDecryption(File.ReadAllBytes(txtFile.Text), txtKey.Text))
        End If
    End Sub
    Public Function AESDecryption(ByVal Data As Byte(), ByVal sKey As String) As Byte()
        'Decryption Function
        Dim AES As New AesCryptoServiceProvider()
        Dim Buffer() As Byte = Nothing
        If Data.Length <> 0 Then
            Dim bKey() As Byte = Encoding.UTF8.GetBytes(sKey)
            Dim Key() As Byte = New MD5CryptoServiceProvider().ComputeHash(bKey, 0, bKey.Length)
            AES.Key = Key
            AES.Mode = CipherMode.ECB
            AES.Padding = PaddingMode.None
            Buffer = AES.CreateDecryptor().TransformFinalBlock(Data, 0, Data.Length)
        End If
        Return Buffer
    End Function


End Class
