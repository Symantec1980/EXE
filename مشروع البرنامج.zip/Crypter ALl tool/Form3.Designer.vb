﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Generating_Algorithm = New Crypter_ALl_tool.FormSkin()
        Me.FlatCheckBox1 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox2 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatButton1 = New Crypter_ALl_tool.FlatButton()
        Me.r2 = New System.Windows.Forms.RichTextBox()
        Me.r1 = New System.Windows.Forms.RichTextBox()
        Me.t41 = New Crypter_ALl_tool.FlatTextBox()
        Me.t52 = New Crypter_ALl_tool.FlatTextBox()
        Me.t51 = New Crypter_ALl_tool.FlatTextBox()
        Me.t50 = New Crypter_ALl_tool.FlatTextBox()
        Me.t49 = New Crypter_ALl_tool.FlatTextBox()
        Me.t48 = New Crypter_ALl_tool.FlatTextBox()
        Me.t47 = New Crypter_ALl_tool.FlatTextBox()
        Me.t46 = New Crypter_ALl_tool.FlatTextBox()
        Me.t45 = New Crypter_ALl_tool.FlatTextBox()
        Me.t44 = New Crypter_ALl_tool.FlatTextBox()
        Me.t43 = New Crypter_ALl_tool.FlatTextBox()
        Me.t42 = New Crypter_ALl_tool.FlatTextBox()
        Me.t40 = New Crypter_ALl_tool.FlatTextBox()
        Me.t39 = New Crypter_ALl_tool.FlatTextBox()
        Me.t38 = New Crypter_ALl_tool.FlatTextBox()
        Me.t37 = New Crypter_ALl_tool.FlatTextBox()
        Me.t36 = New Crypter_ALl_tool.FlatTextBox()
        Me.t35 = New Crypter_ALl_tool.FlatTextBox()
        Me.t34 = New Crypter_ALl_tool.FlatTextBox()
        Me.t33 = New Crypter_ALl_tool.FlatTextBox()
        Me.t32 = New Crypter_ALl_tool.FlatTextBox()
        Me.t31 = New Crypter_ALl_tool.FlatTextBox()
        Me.t30 = New Crypter_ALl_tool.FlatTextBox()
        Me.t29 = New Crypter_ALl_tool.FlatTextBox()
        Me.t28 = New Crypter_ALl_tool.FlatTextBox()
        Me.t27 = New Crypter_ALl_tool.FlatTextBox()
        Me.t26 = New Crypter_ALl_tool.FlatTextBox()
        Me.t25 = New Crypter_ALl_tool.FlatTextBox()
        Me.t24 = New Crypter_ALl_tool.FlatTextBox()
        Me.t23 = New Crypter_ALl_tool.FlatTextBox()
        Me.t22 = New Crypter_ALl_tool.FlatTextBox()
        Me.t21 = New Crypter_ALl_tool.FlatTextBox()
        Me.t20 = New Crypter_ALl_tool.FlatTextBox()
        Me.t19 = New Crypter_ALl_tool.FlatTextBox()
        Me.t18 = New Crypter_ALl_tool.FlatTextBox()
        Me.t17 = New Crypter_ALl_tool.FlatTextBox()
        Me.t16 = New Crypter_ALl_tool.FlatTextBox()
        Me.t15 = New Crypter_ALl_tool.FlatTextBox()
        Me.t14 = New Crypter_ALl_tool.FlatTextBox()
        Me.t13 = New Crypter_ALl_tool.FlatTextBox()
        Me.t12 = New Crypter_ALl_tool.FlatTextBox()
        Me.t11 = New Crypter_ALl_tool.FlatTextBox()
        Me.t10 = New Crypter_ALl_tool.FlatTextBox()
        Me.t9 = New Crypter_ALl_tool.FlatTextBox()
        Me.t8 = New Crypter_ALl_tool.FlatTextBox()
        Me.t7 = New Crypter_ALl_tool.FlatTextBox()
        Me.t6 = New Crypter_ALl_tool.FlatTextBox()
        Me.t5 = New Crypter_ALl_tool.FlatTextBox()
        Me.t4 = New Crypter_ALl_tool.FlatTextBox()
        Me.t3 = New Crypter_ALl_tool.FlatTextBox()
        Me.t2 = New Crypter_ALl_tool.FlatTextBox()
        Me.t1 = New Crypter_ALl_tool.FlatTextBox()
        Me.FlatButton2 = New Crypter_ALl_tool.FlatButton()
        Me.Generating_Algorithm.SuspendLayout()
        Me.SuspendLayout()
        '
        'Generating_Algorithm
        '
        Me.Generating_Algorithm.BackColor = System.Drawing.Color.White
        Me.Generating_Algorithm.BaseColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.Generating_Algorithm.BorderColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.Generating_Algorithm.Controls.Add(Me.FlatButton2)
        Me.Generating_Algorithm.Controls.Add(Me.FlatCheckBox1)
        Me.Generating_Algorithm.Controls.Add(Me.FlatCheckBox2)
        Me.Generating_Algorithm.Controls.Add(Me.FlatButton1)
        Me.Generating_Algorithm.Controls.Add(Me.r2)
        Me.Generating_Algorithm.Controls.Add(Me.r1)
        Me.Generating_Algorithm.Controls.Add(Me.t41)
        Me.Generating_Algorithm.Controls.Add(Me.t52)
        Me.Generating_Algorithm.Controls.Add(Me.t51)
        Me.Generating_Algorithm.Controls.Add(Me.t50)
        Me.Generating_Algorithm.Controls.Add(Me.t49)
        Me.Generating_Algorithm.Controls.Add(Me.t48)
        Me.Generating_Algorithm.Controls.Add(Me.t47)
        Me.Generating_Algorithm.Controls.Add(Me.t46)
        Me.Generating_Algorithm.Controls.Add(Me.t45)
        Me.Generating_Algorithm.Controls.Add(Me.t44)
        Me.Generating_Algorithm.Controls.Add(Me.t43)
        Me.Generating_Algorithm.Controls.Add(Me.t42)
        Me.Generating_Algorithm.Controls.Add(Me.t40)
        Me.Generating_Algorithm.Controls.Add(Me.t39)
        Me.Generating_Algorithm.Controls.Add(Me.t38)
        Me.Generating_Algorithm.Controls.Add(Me.t37)
        Me.Generating_Algorithm.Controls.Add(Me.t36)
        Me.Generating_Algorithm.Controls.Add(Me.t35)
        Me.Generating_Algorithm.Controls.Add(Me.t34)
        Me.Generating_Algorithm.Controls.Add(Me.t33)
        Me.Generating_Algorithm.Controls.Add(Me.t32)
        Me.Generating_Algorithm.Controls.Add(Me.t31)
        Me.Generating_Algorithm.Controls.Add(Me.t30)
        Me.Generating_Algorithm.Controls.Add(Me.t29)
        Me.Generating_Algorithm.Controls.Add(Me.t28)
        Me.Generating_Algorithm.Controls.Add(Me.t27)
        Me.Generating_Algorithm.Controls.Add(Me.t26)
        Me.Generating_Algorithm.Controls.Add(Me.t25)
        Me.Generating_Algorithm.Controls.Add(Me.t24)
        Me.Generating_Algorithm.Controls.Add(Me.t23)
        Me.Generating_Algorithm.Controls.Add(Me.t22)
        Me.Generating_Algorithm.Controls.Add(Me.t21)
        Me.Generating_Algorithm.Controls.Add(Me.t20)
        Me.Generating_Algorithm.Controls.Add(Me.t19)
        Me.Generating_Algorithm.Controls.Add(Me.t18)
        Me.Generating_Algorithm.Controls.Add(Me.t17)
        Me.Generating_Algorithm.Controls.Add(Me.t16)
        Me.Generating_Algorithm.Controls.Add(Me.t15)
        Me.Generating_Algorithm.Controls.Add(Me.t14)
        Me.Generating_Algorithm.Controls.Add(Me.t13)
        Me.Generating_Algorithm.Controls.Add(Me.t12)
        Me.Generating_Algorithm.Controls.Add(Me.t11)
        Me.Generating_Algorithm.Controls.Add(Me.t10)
        Me.Generating_Algorithm.Controls.Add(Me.t9)
        Me.Generating_Algorithm.Controls.Add(Me.t8)
        Me.Generating_Algorithm.Controls.Add(Me.t7)
        Me.Generating_Algorithm.Controls.Add(Me.t6)
        Me.Generating_Algorithm.Controls.Add(Me.t5)
        Me.Generating_Algorithm.Controls.Add(Me.t4)
        Me.Generating_Algorithm.Controls.Add(Me.t3)
        Me.Generating_Algorithm.Controls.Add(Me.t2)
        Me.Generating_Algorithm.Controls.Add(Me.t1)
        Me.Generating_Algorithm.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Generating_Algorithm.FlatColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.Generating_Algorithm.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Generating_Algorithm.HeaderColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Generating_Algorithm.HeaderMaximize = False
        Me.Generating_Algorithm.Location = New System.Drawing.Point(0, 0)
        Me.Generating_Algorithm.Name = "Generating_Algorithm"
        Me.Generating_Algorithm.Size = New System.Drawing.Size(746, 500)
        Me.Generating_Algorithm.TabIndex = 0
        Me.Generating_Algorithm.Text = "FormSkin1"
        '
        'FlatCheckBox1
        '
        Me.FlatCheckBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox1.Checked = False
        Me.FlatCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox1.Location = New System.Drawing.Point(12, 245)
        Me.FlatCheckBox1.Name = "FlatCheckBox1"
        Me.FlatCheckBox1.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox1.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox1.TabIndex = 1
        Me.FlatCheckBox1.Text = "Copy ENC"
        '
        'FlatCheckBox2
        '
        Me.FlatCheckBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox2.Checked = False
        Me.FlatCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox2.Location = New System.Drawing.Point(12, 461)
        Me.FlatCheckBox2.Name = "FlatCheckBox2"
        Me.FlatCheckBox2.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox2.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox2.TabIndex = 2
        Me.FlatCheckBox2.Text = "Copy DEC"
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton1.BaseColor = System.Drawing.Color.Maroon
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton1.Font = New System.Drawing.Font("Freestyle Script", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton1.Location = New System.Drawing.Point(316, 413)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(237, 29)
        Me.FlatButton1.TabIndex = 64
        Me.FlatButton1.Text = "Gn"
        Me.FlatButton1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'r2
        '
        Me.r2.BackColor = System.Drawing.SystemColors.InfoText
        Me.r2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.r2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.r2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.r2.Location = New System.Drawing.Point(12, 273)
        Me.r2.Name = "r2"
        Me.r2.Size = New System.Drawing.Size(286, 182)
        Me.r2.TabIndex = 63
        Me.r2.Text = ""
        '
        'r1
        '
        Me.r1.BackColor = System.Drawing.SystemColors.InfoText
        Me.r1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.r1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.r1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.r1.Location = New System.Drawing.Point(12, 63)
        Me.r1.Name = "r1"
        Me.r1.Size = New System.Drawing.Size(286, 175)
        Me.r1.TabIndex = 62
        Me.r1.Text = ""
        '
        't41
        '
        Me.t41.BackColor = System.Drawing.Color.Transparent
        Me.t41.Location = New System.Drawing.Point(559, 413)
        Me.t41.MaxLength = 32767
        Me.t41.Multiline = False
        Me.t41.Name = "t41"
        Me.t41.ReadOnly = False
        Me.t41.Size = New System.Drawing.Size(75, 29)
        Me.t41.TabIndex = 61
        Me.t41.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t41.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t41.UseSystemPasswordChar = False
        '
        't52
        '
        Me.t52.BackColor = System.Drawing.Color.Transparent
        Me.t52.Location = New System.Drawing.Point(640, 413)
        Me.t52.MaxLength = 32767
        Me.t52.Multiline = False
        Me.t52.Name = "t52"
        Me.t52.ReadOnly = False
        Me.t52.Size = New System.Drawing.Size(75, 29)
        Me.t52.TabIndex = 60
        Me.t52.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t52.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t52.UseSystemPasswordChar = False
        '
        't51
        '
        Me.t51.BackColor = System.Drawing.Color.Transparent
        Me.t51.Location = New System.Drawing.Point(640, 378)
        Me.t51.MaxLength = 32767
        Me.t51.Multiline = False
        Me.t51.Name = "t51"
        Me.t51.ReadOnly = False
        Me.t51.Size = New System.Drawing.Size(75, 29)
        Me.t51.TabIndex = 59
        Me.t51.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t51.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t51.UseSystemPasswordChar = False
        '
        't50
        '
        Me.t50.BackColor = System.Drawing.Color.Transparent
        Me.t50.Location = New System.Drawing.Point(640, 343)
        Me.t50.MaxLength = 32767
        Me.t50.Multiline = False
        Me.t50.Name = "t50"
        Me.t50.ReadOnly = False
        Me.t50.Size = New System.Drawing.Size(75, 29)
        Me.t50.TabIndex = 58
        Me.t50.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t50.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t50.UseSystemPasswordChar = False
        '
        't49
        '
        Me.t49.BackColor = System.Drawing.Color.Transparent
        Me.t49.Location = New System.Drawing.Point(640, 308)
        Me.t49.MaxLength = 32767
        Me.t49.Multiline = False
        Me.t49.Name = "t49"
        Me.t49.ReadOnly = False
        Me.t49.Size = New System.Drawing.Size(75, 29)
        Me.t49.TabIndex = 57
        Me.t49.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t49.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t49.UseSystemPasswordChar = False
        '
        't48
        '
        Me.t48.BackColor = System.Drawing.Color.Transparent
        Me.t48.Location = New System.Drawing.Point(640, 273)
        Me.t48.MaxLength = 32767
        Me.t48.Multiline = False
        Me.t48.Name = "t48"
        Me.t48.ReadOnly = False
        Me.t48.Size = New System.Drawing.Size(75, 29)
        Me.t48.TabIndex = 56
        Me.t48.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t48.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t48.UseSystemPasswordChar = False
        '
        't47
        '
        Me.t47.BackColor = System.Drawing.Color.Transparent
        Me.t47.Location = New System.Drawing.Point(640, 238)
        Me.t47.MaxLength = 32767
        Me.t47.Multiline = False
        Me.t47.Name = "t47"
        Me.t47.ReadOnly = False
        Me.t47.Size = New System.Drawing.Size(75, 29)
        Me.t47.TabIndex = 55
        Me.t47.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t47.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t47.UseSystemPasswordChar = False
        '
        't46
        '
        Me.t46.BackColor = System.Drawing.Color.Transparent
        Me.t46.Location = New System.Drawing.Point(640, 203)
        Me.t46.MaxLength = 32767
        Me.t46.Multiline = False
        Me.t46.Name = "t46"
        Me.t46.ReadOnly = False
        Me.t46.Size = New System.Drawing.Size(75, 29)
        Me.t46.TabIndex = 54
        Me.t46.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t46.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t46.UseSystemPasswordChar = False
        '
        't45
        '
        Me.t45.BackColor = System.Drawing.Color.Transparent
        Me.t45.Location = New System.Drawing.Point(640, 168)
        Me.t45.MaxLength = 32767
        Me.t45.Multiline = False
        Me.t45.Name = "t45"
        Me.t45.ReadOnly = False
        Me.t45.Size = New System.Drawing.Size(75, 29)
        Me.t45.TabIndex = 53
        Me.t45.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t45.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t45.UseSystemPasswordChar = False
        '
        't44
        '
        Me.t44.BackColor = System.Drawing.Color.Transparent
        Me.t44.Location = New System.Drawing.Point(640, 133)
        Me.t44.MaxLength = 32767
        Me.t44.Multiline = False
        Me.t44.Name = "t44"
        Me.t44.ReadOnly = False
        Me.t44.Size = New System.Drawing.Size(75, 29)
        Me.t44.TabIndex = 52
        Me.t44.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t44.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t44.UseSystemPasswordChar = False
        '
        't43
        '
        Me.t43.BackColor = System.Drawing.Color.Transparent
        Me.t43.Location = New System.Drawing.Point(640, 98)
        Me.t43.MaxLength = 32767
        Me.t43.Multiline = False
        Me.t43.Name = "t43"
        Me.t43.ReadOnly = False
        Me.t43.Size = New System.Drawing.Size(75, 29)
        Me.t43.TabIndex = 51
        Me.t43.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t43.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t43.UseSystemPasswordChar = False
        '
        't42
        '
        Me.t42.BackColor = System.Drawing.Color.Transparent
        Me.t42.Location = New System.Drawing.Point(640, 63)
        Me.t42.MaxLength = 32767
        Me.t42.Multiline = False
        Me.t42.Name = "t42"
        Me.t42.ReadOnly = False
        Me.t42.Size = New System.Drawing.Size(75, 29)
        Me.t42.TabIndex = 50
        Me.t42.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t42.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t42.UseSystemPasswordChar = False
        '
        't40
        '
        Me.t40.BackColor = System.Drawing.Color.Transparent
        Me.t40.Location = New System.Drawing.Point(559, 378)
        Me.t40.MaxLength = 32767
        Me.t40.Multiline = False
        Me.t40.Name = "t40"
        Me.t40.ReadOnly = False
        Me.t40.Size = New System.Drawing.Size(75, 29)
        Me.t40.TabIndex = 49
        Me.t40.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t40.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t40.UseSystemPasswordChar = False
        '
        't39
        '
        Me.t39.BackColor = System.Drawing.Color.Transparent
        Me.t39.Location = New System.Drawing.Point(559, 343)
        Me.t39.MaxLength = 32767
        Me.t39.Multiline = False
        Me.t39.Name = "t39"
        Me.t39.ReadOnly = False
        Me.t39.Size = New System.Drawing.Size(75, 29)
        Me.t39.TabIndex = 48
        Me.t39.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t39.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t39.UseSystemPasswordChar = False
        '
        't38
        '
        Me.t38.BackColor = System.Drawing.Color.Transparent
        Me.t38.Location = New System.Drawing.Point(559, 308)
        Me.t38.MaxLength = 32767
        Me.t38.Multiline = False
        Me.t38.Name = "t38"
        Me.t38.ReadOnly = False
        Me.t38.Size = New System.Drawing.Size(75, 29)
        Me.t38.TabIndex = 47
        Me.t38.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t38.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t38.UseSystemPasswordChar = False
        '
        't37
        '
        Me.t37.BackColor = System.Drawing.Color.Transparent
        Me.t37.Location = New System.Drawing.Point(559, 273)
        Me.t37.MaxLength = 32767
        Me.t37.Multiline = False
        Me.t37.Name = "t37"
        Me.t37.ReadOnly = False
        Me.t37.Size = New System.Drawing.Size(75, 29)
        Me.t37.TabIndex = 46
        Me.t37.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t37.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t37.UseSystemPasswordChar = False
        '
        't36
        '
        Me.t36.BackColor = System.Drawing.Color.Transparent
        Me.t36.Location = New System.Drawing.Point(559, 238)
        Me.t36.MaxLength = 32767
        Me.t36.Multiline = False
        Me.t36.Name = "t36"
        Me.t36.ReadOnly = False
        Me.t36.Size = New System.Drawing.Size(75, 29)
        Me.t36.TabIndex = 45
        Me.t36.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t36.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t36.UseSystemPasswordChar = False
        '
        't35
        '
        Me.t35.BackColor = System.Drawing.Color.Transparent
        Me.t35.Location = New System.Drawing.Point(559, 203)
        Me.t35.MaxLength = 32767
        Me.t35.Multiline = False
        Me.t35.Name = "t35"
        Me.t35.ReadOnly = False
        Me.t35.Size = New System.Drawing.Size(75, 29)
        Me.t35.TabIndex = 44
        Me.t35.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t35.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t35.UseSystemPasswordChar = False
        '
        't34
        '
        Me.t34.BackColor = System.Drawing.Color.Transparent
        Me.t34.Location = New System.Drawing.Point(559, 168)
        Me.t34.MaxLength = 32767
        Me.t34.Multiline = False
        Me.t34.Name = "t34"
        Me.t34.ReadOnly = False
        Me.t34.Size = New System.Drawing.Size(75, 29)
        Me.t34.TabIndex = 43
        Me.t34.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t34.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t34.UseSystemPasswordChar = False
        '
        't33
        '
        Me.t33.BackColor = System.Drawing.Color.Transparent
        Me.t33.Location = New System.Drawing.Point(559, 133)
        Me.t33.MaxLength = 32767
        Me.t33.Multiline = False
        Me.t33.Name = "t33"
        Me.t33.ReadOnly = False
        Me.t33.Size = New System.Drawing.Size(75, 29)
        Me.t33.TabIndex = 42
        Me.t33.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t33.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t33.UseSystemPasswordChar = False
        '
        't32
        '
        Me.t32.BackColor = System.Drawing.Color.Transparent
        Me.t32.Location = New System.Drawing.Point(559, 98)
        Me.t32.MaxLength = 32767
        Me.t32.Multiline = False
        Me.t32.Name = "t32"
        Me.t32.ReadOnly = False
        Me.t32.Size = New System.Drawing.Size(75, 29)
        Me.t32.TabIndex = 41
        Me.t32.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t32.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t32.UseSystemPasswordChar = False
        '
        't31
        '
        Me.t31.BackColor = System.Drawing.Color.Transparent
        Me.t31.Location = New System.Drawing.Point(559, 63)
        Me.t31.MaxLength = 32767
        Me.t31.Multiline = False
        Me.t31.Name = "t31"
        Me.t31.ReadOnly = False
        Me.t31.Size = New System.Drawing.Size(75, 29)
        Me.t31.TabIndex = 40
        Me.t31.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t31.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t31.UseSystemPasswordChar = False
        '
        't30
        '
        Me.t30.BackColor = System.Drawing.Color.Transparent
        Me.t30.Location = New System.Drawing.Point(478, 378)
        Me.t30.MaxLength = 32767
        Me.t30.Multiline = False
        Me.t30.Name = "t30"
        Me.t30.ReadOnly = False
        Me.t30.Size = New System.Drawing.Size(75, 29)
        Me.t30.TabIndex = 39
        Me.t30.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t30.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t30.UseSystemPasswordChar = False
        '
        't29
        '
        Me.t29.BackColor = System.Drawing.Color.Transparent
        Me.t29.Location = New System.Drawing.Point(478, 343)
        Me.t29.MaxLength = 32767
        Me.t29.Multiline = False
        Me.t29.Name = "t29"
        Me.t29.ReadOnly = False
        Me.t29.Size = New System.Drawing.Size(75, 29)
        Me.t29.TabIndex = 38
        Me.t29.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t29.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t29.UseSystemPasswordChar = False
        '
        't28
        '
        Me.t28.BackColor = System.Drawing.Color.Transparent
        Me.t28.Location = New System.Drawing.Point(478, 308)
        Me.t28.MaxLength = 32767
        Me.t28.Multiline = False
        Me.t28.Name = "t28"
        Me.t28.ReadOnly = False
        Me.t28.Size = New System.Drawing.Size(75, 29)
        Me.t28.TabIndex = 37
        Me.t28.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t28.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t28.UseSystemPasswordChar = False
        '
        't27
        '
        Me.t27.BackColor = System.Drawing.Color.Transparent
        Me.t27.Location = New System.Drawing.Point(478, 273)
        Me.t27.MaxLength = 32767
        Me.t27.Multiline = False
        Me.t27.Name = "t27"
        Me.t27.ReadOnly = False
        Me.t27.Size = New System.Drawing.Size(75, 29)
        Me.t27.TabIndex = 36
        Me.t27.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t27.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t27.UseSystemPasswordChar = False
        '
        't26
        '
        Me.t26.BackColor = System.Drawing.Color.Transparent
        Me.t26.Location = New System.Drawing.Point(478, 238)
        Me.t26.MaxLength = 32767
        Me.t26.Multiline = False
        Me.t26.Name = "t26"
        Me.t26.ReadOnly = False
        Me.t26.Size = New System.Drawing.Size(75, 29)
        Me.t26.TabIndex = 35
        Me.t26.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t26.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t26.UseSystemPasswordChar = False
        '
        't25
        '
        Me.t25.BackColor = System.Drawing.Color.Transparent
        Me.t25.Location = New System.Drawing.Point(478, 203)
        Me.t25.MaxLength = 32767
        Me.t25.Multiline = False
        Me.t25.Name = "t25"
        Me.t25.ReadOnly = False
        Me.t25.Size = New System.Drawing.Size(75, 29)
        Me.t25.TabIndex = 34
        Me.t25.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t25.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t25.UseSystemPasswordChar = False
        '
        't24
        '
        Me.t24.BackColor = System.Drawing.Color.Transparent
        Me.t24.Location = New System.Drawing.Point(478, 168)
        Me.t24.MaxLength = 32767
        Me.t24.Multiline = False
        Me.t24.Name = "t24"
        Me.t24.ReadOnly = False
        Me.t24.Size = New System.Drawing.Size(75, 29)
        Me.t24.TabIndex = 33
        Me.t24.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t24.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t24.UseSystemPasswordChar = False
        '
        't23
        '
        Me.t23.BackColor = System.Drawing.Color.Transparent
        Me.t23.Location = New System.Drawing.Point(478, 133)
        Me.t23.MaxLength = 32767
        Me.t23.Multiline = False
        Me.t23.Name = "t23"
        Me.t23.ReadOnly = False
        Me.t23.Size = New System.Drawing.Size(75, 29)
        Me.t23.TabIndex = 32
        Me.t23.Text = " "
        Me.t23.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t23.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t23.UseSystemPasswordChar = False
        '
        't22
        '
        Me.t22.BackColor = System.Drawing.Color.Transparent
        Me.t22.Location = New System.Drawing.Point(478, 98)
        Me.t22.MaxLength = 32767
        Me.t22.Multiline = False
        Me.t22.Name = "t22"
        Me.t22.ReadOnly = False
        Me.t22.Size = New System.Drawing.Size(75, 29)
        Me.t22.TabIndex = 31
        Me.t22.Text = " "
        Me.t22.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t22.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t22.UseSystemPasswordChar = False
        '
        't21
        '
        Me.t21.BackColor = System.Drawing.Color.Transparent
        Me.t21.Location = New System.Drawing.Point(478, 63)
        Me.t21.MaxLength = 32767
        Me.t21.Multiline = False
        Me.t21.Name = "t21"
        Me.t21.ReadOnly = False
        Me.t21.Size = New System.Drawing.Size(75, 29)
        Me.t21.TabIndex = 30
        Me.t21.Text = " "
        Me.t21.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t21.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t21.UseSystemPasswordChar = False
        '
        't20
        '
        Me.t20.BackColor = System.Drawing.Color.Transparent
        Me.t20.Location = New System.Drawing.Point(397, 378)
        Me.t20.MaxLength = 32767
        Me.t20.Multiline = False
        Me.t20.Name = "t20"
        Me.t20.ReadOnly = False
        Me.t20.Size = New System.Drawing.Size(75, 29)
        Me.t20.TabIndex = 29
        Me.t20.Text = " "
        Me.t20.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t20.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t20.UseSystemPasswordChar = False
        '
        't19
        '
        Me.t19.BackColor = System.Drawing.Color.Transparent
        Me.t19.Location = New System.Drawing.Point(397, 343)
        Me.t19.MaxLength = 32767
        Me.t19.Multiline = False
        Me.t19.Name = "t19"
        Me.t19.ReadOnly = False
        Me.t19.Size = New System.Drawing.Size(75, 29)
        Me.t19.TabIndex = 28
        Me.t19.Text = " "
        Me.t19.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t19.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t19.UseSystemPasswordChar = False
        '
        't18
        '
        Me.t18.BackColor = System.Drawing.Color.Transparent
        Me.t18.Location = New System.Drawing.Point(397, 308)
        Me.t18.MaxLength = 32767
        Me.t18.Multiline = False
        Me.t18.Name = "t18"
        Me.t18.ReadOnly = False
        Me.t18.Size = New System.Drawing.Size(75, 29)
        Me.t18.TabIndex = 27
        Me.t18.Text = " "
        Me.t18.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t18.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t18.UseSystemPasswordChar = False
        '
        't17
        '
        Me.t17.BackColor = System.Drawing.Color.Transparent
        Me.t17.Location = New System.Drawing.Point(397, 273)
        Me.t17.MaxLength = 32767
        Me.t17.Multiline = False
        Me.t17.Name = "t17"
        Me.t17.ReadOnly = False
        Me.t17.Size = New System.Drawing.Size(75, 29)
        Me.t17.TabIndex = 26
        Me.t17.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t17.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t17.UseSystemPasswordChar = False
        '
        't16
        '
        Me.t16.BackColor = System.Drawing.Color.Transparent
        Me.t16.Location = New System.Drawing.Point(397, 238)
        Me.t16.MaxLength = 32767
        Me.t16.Multiline = False
        Me.t16.Name = "t16"
        Me.t16.ReadOnly = False
        Me.t16.Size = New System.Drawing.Size(75, 29)
        Me.t16.TabIndex = 25
        Me.t16.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t16.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t16.UseSystemPasswordChar = False
        '
        't15
        '
        Me.t15.BackColor = System.Drawing.Color.Transparent
        Me.t15.Location = New System.Drawing.Point(397, 203)
        Me.t15.MaxLength = 32767
        Me.t15.Multiline = False
        Me.t15.Name = "t15"
        Me.t15.ReadOnly = False
        Me.t15.Size = New System.Drawing.Size(75, 29)
        Me.t15.TabIndex = 24
        Me.t15.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t15.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t15.UseSystemPasswordChar = False
        '
        't14
        '
        Me.t14.BackColor = System.Drawing.Color.Transparent
        Me.t14.Location = New System.Drawing.Point(397, 168)
        Me.t14.MaxLength = 32767
        Me.t14.Multiline = False
        Me.t14.Name = "t14"
        Me.t14.ReadOnly = False
        Me.t14.Size = New System.Drawing.Size(75, 29)
        Me.t14.TabIndex = 23
        Me.t14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t14.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t14.UseSystemPasswordChar = False
        '
        't13
        '
        Me.t13.BackColor = System.Drawing.Color.Transparent
        Me.t13.Location = New System.Drawing.Point(397, 133)
        Me.t13.MaxLength = 32767
        Me.t13.Multiline = False
        Me.t13.Name = "t13"
        Me.t13.ReadOnly = False
        Me.t13.Size = New System.Drawing.Size(75, 29)
        Me.t13.TabIndex = 22
        Me.t13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t13.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t13.UseSystemPasswordChar = False
        '
        't12
        '
        Me.t12.BackColor = System.Drawing.Color.Transparent
        Me.t12.Location = New System.Drawing.Point(397, 98)
        Me.t12.MaxLength = 32767
        Me.t12.Multiline = False
        Me.t12.Name = "t12"
        Me.t12.ReadOnly = False
        Me.t12.Size = New System.Drawing.Size(75, 29)
        Me.t12.TabIndex = 21
        Me.t12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t12.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t12.UseSystemPasswordChar = False
        '
        't11
        '
        Me.t11.BackColor = System.Drawing.Color.Transparent
        Me.t11.Location = New System.Drawing.Point(397, 63)
        Me.t11.MaxLength = 32767
        Me.t11.Multiline = False
        Me.t11.Name = "t11"
        Me.t11.ReadOnly = False
        Me.t11.Size = New System.Drawing.Size(75, 29)
        Me.t11.TabIndex = 20
        Me.t11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t11.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t11.UseSystemPasswordChar = False
        '
        't10
        '
        Me.t10.BackColor = System.Drawing.Color.Transparent
        Me.t10.Location = New System.Drawing.Point(316, 378)
        Me.t10.MaxLength = 32767
        Me.t10.Multiline = False
        Me.t10.Name = "t10"
        Me.t10.ReadOnly = False
        Me.t10.Size = New System.Drawing.Size(75, 29)
        Me.t10.TabIndex = 19
        Me.t10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t10.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t10.UseSystemPasswordChar = False
        '
        't9
        '
        Me.t9.BackColor = System.Drawing.Color.Transparent
        Me.t9.Location = New System.Drawing.Point(316, 343)
        Me.t9.MaxLength = 32767
        Me.t9.Multiline = False
        Me.t9.Name = "t9"
        Me.t9.ReadOnly = False
        Me.t9.Size = New System.Drawing.Size(75, 29)
        Me.t9.TabIndex = 18
        Me.t9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t9.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t9.UseSystemPasswordChar = False
        '
        't8
        '
        Me.t8.BackColor = System.Drawing.Color.Transparent
        Me.t8.Location = New System.Drawing.Point(316, 308)
        Me.t8.MaxLength = 32767
        Me.t8.Multiline = False
        Me.t8.Name = "t8"
        Me.t8.ReadOnly = False
        Me.t8.Size = New System.Drawing.Size(75, 29)
        Me.t8.TabIndex = 17
        Me.t8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t8.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t8.UseSystemPasswordChar = False
        '
        't7
        '
        Me.t7.BackColor = System.Drawing.Color.Transparent
        Me.t7.Location = New System.Drawing.Point(316, 273)
        Me.t7.MaxLength = 32767
        Me.t7.Multiline = False
        Me.t7.Name = "t7"
        Me.t7.ReadOnly = False
        Me.t7.Size = New System.Drawing.Size(75, 29)
        Me.t7.TabIndex = 16
        Me.t7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t7.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t7.UseSystemPasswordChar = False
        '
        't6
        '
        Me.t6.BackColor = System.Drawing.Color.Transparent
        Me.t6.Location = New System.Drawing.Point(316, 238)
        Me.t6.MaxLength = 32767
        Me.t6.Multiline = False
        Me.t6.Name = "t6"
        Me.t6.ReadOnly = False
        Me.t6.Size = New System.Drawing.Size(75, 29)
        Me.t6.TabIndex = 15
        Me.t6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t6.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t6.UseSystemPasswordChar = False
        '
        't5
        '
        Me.t5.BackColor = System.Drawing.Color.Transparent
        Me.t5.Location = New System.Drawing.Point(316, 203)
        Me.t5.MaxLength = 32767
        Me.t5.Multiline = False
        Me.t5.Name = "t5"
        Me.t5.ReadOnly = False
        Me.t5.Size = New System.Drawing.Size(75, 29)
        Me.t5.TabIndex = 14
        Me.t5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t5.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t5.UseSystemPasswordChar = False
        '
        't4
        '
        Me.t4.BackColor = System.Drawing.Color.Transparent
        Me.t4.Location = New System.Drawing.Point(316, 168)
        Me.t4.MaxLength = 32767
        Me.t4.Multiline = False
        Me.t4.Name = "t4"
        Me.t4.ReadOnly = False
        Me.t4.Size = New System.Drawing.Size(75, 29)
        Me.t4.TabIndex = 13
        Me.t4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t4.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t4.UseSystemPasswordChar = False
        '
        't3
        '
        Me.t3.BackColor = System.Drawing.Color.Transparent
        Me.t3.Location = New System.Drawing.Point(316, 133)
        Me.t3.MaxLength = 32767
        Me.t3.Multiline = False
        Me.t3.Name = "t3"
        Me.t3.ReadOnly = False
        Me.t3.Size = New System.Drawing.Size(75, 29)
        Me.t3.TabIndex = 12
        Me.t3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t3.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t3.UseSystemPasswordChar = False
        '
        't2
        '
        Me.t2.BackColor = System.Drawing.Color.Transparent
        Me.t2.Location = New System.Drawing.Point(316, 98)
        Me.t2.MaxLength = 32767
        Me.t2.Multiline = False
        Me.t2.Name = "t2"
        Me.t2.ReadOnly = False
        Me.t2.Size = New System.Drawing.Size(75, 29)
        Me.t2.TabIndex = 11
        Me.t2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t2.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t2.UseSystemPasswordChar = False
        '
        't1
        '
        Me.t1.BackColor = System.Drawing.Color.Transparent
        Me.t1.Location = New System.Drawing.Point(316, 63)
        Me.t1.MaxLength = 32767
        Me.t1.Multiline = False
        Me.t1.Name = "t1"
        Me.t1.ReadOnly = False
        Me.t1.Size = New System.Drawing.Size(75, 29)
        Me.t1.TabIndex = 10
        Me.t1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t1.UseSystemPasswordChar = False
        '
        'FlatButton2
        '
        Me.FlatButton2.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton2.BaseColor = System.Drawing.Color.Black
        Me.FlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton2.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton2.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.FlatButton2.Location = New System.Drawing.Point(609, 456)
        Me.FlatButton2.Name = "FlatButton2"
        Me.FlatButton2.Rounded = False
        Me.FlatButton2.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton2.TabIndex = 65
        Me.FlatButton2.Text = "Back"
        Me.FlatButton2.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(746, 500)
        Me.Controls.Add(Me.Generating_Algorithm)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form3"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.Generating_Algorithm.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Generating_Algorithm As Crypter_ALl_tool.FormSkin
    Friend WithEvents r2 As System.Windows.Forms.RichTextBox
    Friend WithEvents r1 As System.Windows.Forms.RichTextBox
    Friend WithEvents t41 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t52 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t51 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t50 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t49 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t48 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t47 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t46 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t45 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t44 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t43 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t42 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t40 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t39 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t38 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t37 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t36 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t35 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t34 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t33 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t32 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t31 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t30 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t29 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t28 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t27 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t26 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t25 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t24 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t23 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t22 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t21 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t20 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t19 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t18 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t17 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t16 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t15 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t14 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t13 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t12 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t11 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t10 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t9 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t8 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t7 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t6 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t5 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t4 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t3 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t2 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t1 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents FlatButton1 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatCheckBox1 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox2 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatButton2 As Crypter_ALl_tool.FlatButton
End Class
