﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cliente
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Cliente))
        Me.ETheme1 = New Crypter.ETheme()
        Me.EButton4 = New Crypter.EButton()
        Me.EButton3 = New Crypter.EButton()
        Me.EButton2 = New Crypter.EButton()
        Me.EButton1 = New Crypter.EButton()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ETheme1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ETheme1
        '
        Me.ETheme1.BackColor = System.Drawing.Color.White
        Me.ETheme1.Controls.Add(Me.EButton4)
        Me.ETheme1.Controls.Add(Me.EButton3)
        Me.ETheme1.Controls.Add(Me.EButton2)
        Me.ETheme1.Controls.Add(Me.EButton1)
        Me.ETheme1.Controls.Add(Me.TextBox3)
        Me.ETheme1.Controls.Add(Me.Button4)
        Me.ETheme1.Controls.Add(Me.TextBox2)
        Me.ETheme1.Controls.Add(Me.TextBox1)
        Me.ETheme1.Controls.Add(Me.PictureBox1)
        Me.ETheme1.Cursor = System.Windows.Forms.Cursors.HSplit
        Me.ETheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ETheme1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        Me.ETheme1.ForeColor = System.Drawing.Color.Black
        Me.ETheme1.Image = Nothing
        Me.ETheme1.Location = New System.Drawing.Point(0, 0)
        Me.ETheme1.MoveHeight = 20
        Me.ETheme1.Name = "ETheme1"
        Me.ETheme1.Resizable = False
        Me.ETheme1.Size = New System.Drawing.Size(483, 297)
        Me.ETheme1.TabIndex = 0
        Me.ETheme1.Text = "Crypter By LOBO"
        Me.ETheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        '
        'EButton4
        '
        Me.EButton4.Image = Nothing
        Me.EButton4.Location = New System.Drawing.Point(396, 201)
        Me.EButton4.Name = "EButton4"
        Me.EButton4.NoRounding = False
        Me.EButton4.Size = New System.Drawing.Size(75, 23)
        Me.EButton4.TabIndex = 18
        Me.EButton4.Text = "Scam"
        '
        'EButton3
        '
        Me.EButton3.Image = Nothing
        Me.EButton3.Location = New System.Drawing.Point(396, 230)
        Me.EButton3.Name = "EButton3"
        Me.EButton3.NoRounding = False
        Me.EButton3.Size = New System.Drawing.Size(75, 39)
        Me.EButton3.TabIndex = 17
        Me.EButton3.Text = "Cryptar"
        '
        'EButton2
        '
        Me.EButton2.Image = Nothing
        Me.EButton2.Location = New System.Drawing.Point(12, 239)
        Me.EButton2.Name = "EButton2"
        Me.EButton2.NoRounding = False
        Me.EButton2.Size = New System.Drawing.Size(75, 23)
        Me.EButton2.TabIndex = 16
        Me.EButton2.Text = "ADD Stub"
        '
        'EButton1
        '
        Me.EButton1.Image = Nothing
        Me.EButton1.Location = New System.Drawing.Point(12, 201)
        Me.EButton1.Name = "EButton1"
        Me.EButton1.NoRounding = False
        Me.EButton1.Size = New System.Drawing.Size(75, 23)
        Me.EButton1.TabIndex = 15
        Me.EButton1.Text = "ADD .EXE"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(12, 84)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(15, 21)
        Me.TextBox3.TabIndex = 11
        Me.TextBox3.Text = "еПOллереееаенлиесцнввъарвOвнПонъзнзаиIевоеаеиееиво"
        Me.TextBox3.Visible = False
        '
        'Button4
        '
        Me.Button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button4.BackColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(457, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(23, 11)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "...."
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(12, 57)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(15, 21)
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(12, 28)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(15, 21)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(477, 257)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Cliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(483, 297)
        Me.Controls.Add(Me.ETheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Cliente"
        Me.Opacity = 0.7R
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Crypter LOBO"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ETheme1.ResumeLayout(False)
        Me.ETheme1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ETheme1 As Crypter.ETheme
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents EButton4 As Crypter.EButton
    Friend WithEvents EButton3 As Crypter.EButton
    Friend WithEvents EButton2 As Crypter.EButton
    Friend WithEvents EButton1 As Crypter.EButton

End Class
