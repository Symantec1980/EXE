﻿Imports System.IO
Imports System.IO.Compression
Imports System.Security.Cryptography

Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim OpenFileDialog As New OpenFileDialog
        With OpenFileDialog
            .Title = "Select EXE File"
            .Filter = "Exe Files (*.exe)|*.exe"
            .ShowDialog()
        End With
        TextBox1.Text = OpenFileDialog.FileName
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Me.CheckBox1.Checked Then
            RichTextBox1.Text = Convert.ToBase64String(IO.File.ReadAllBytes(TextBox1.Text))
        End If
        If Me.CheckBox2.Checked Then
            RichTextBox1.Text = Convert.ToBase64String(Form1.GZip(IO.File.ReadAllBytes(TextBox1.Text)))
        End If
        If Me.CheckBox3.Checked Then
            RichTextBox1.Text = Convert.ToBase64String(Form1.RNG(IO.File.ReadAllBytes(TextBox1.Text)))
        End If
    End Sub
    Public Shared Function GZip(ByVal byte_0 As Byte()) As Byte()
        Using stream As MemoryStream = New MemoryStream
            Using stream2 As GZipStream = New GZipStream(stream, CompressionMode.Compress)
                stream2.Write(byte_0, 0, byte_0.Length)
                stream2.Close()
                byte_0 = New Byte(((((stream.ToArray.Length - 1) + 1) - 1) + 1) - 1) {}
                byte_0 = stream.ToArray
            End Using
            stream.Close()
        End Using
        Return byte_0
    End Function

    Public Shared Function RNG(ByVal byte_0 As Byte()) As Byte()
        Dim provider As New RNGCryptoServiceProvider
        Dim data As Byte() = New Byte(&H20 - 1) {}
        Dim dst As Byte() = New Byte(((((&H20 + (byte_0.Length - 1)) + 1) - 1) + 1) - 1) {}
        provider.GetBytes(data)
        Buffer.BlockCopy(data, 0, dst, 0, &H20)
        Buffer.BlockCopy(byte_0, 0, dst, &H20, byte_0.Length)
        Dim num2 As Integer = (dst.Length - 1)
        Dim i As Integer = &H20
        Do While (i <= num2)
            dst(i) = CByte((dst(i) Xor data((i Mod data.Length))))
            i += 1
        Loop
        Return dst
    End Function

    Private Sub CheckBox2_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox2.CheckedChanged

    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged

    End Sub
End Class
