﻿namespace Cryptex1
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            Cryptex1.Control16.Class1 class11 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class12 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class13 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class14 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class15 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class16 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class17 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class18 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class19 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class110 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class111 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class112 = new Cryptex1.Control16.Class1();
            Cryptex1.Control16.Class1 class113 = new Cryptex1.Control16.Class1();
            Cryptex1.Class0 class010 = new Cryptex1.Class0();
            Cryptex1.Class0 class011 = new Cryptex1.Class0();
            Cryptex1.Class0 class012 = new Cryptex1.Class0();
            Cryptex1.Class0 class013 = new Cryptex1.Class0();
            Cryptex1.Class0 class014 = new Cryptex1.Class0();
            Cryptex1.Class0 class015 = new Cryptex1.Class0();
            Cryptex1.Class0 class016 = new Cryptex1.Class0();
            Cryptex1.Class0 class017 = new Cryptex1.Class0();
            Cryptex1.Class0 class018 = new Cryptex1.Class0();
            Cryptex1.Class0 class019 = new Cryptex1.Class0();
            Cryptex1.Class0 class020 = new Cryptex1.Class0();
            Cryptex1.Class0 class021 = new Cryptex1.Class0();
            Cryptex1.Class0 class022 = new Cryptex1.Class0();
            Cryptex1.Class0 class023 = new Cryptex1.Class0();
            Cryptex1.Class0 class024 = new Cryptex1.Class0();
            Cryptex1.Class0 class025 = new Cryptex1.Class0();
            Cryptex1.Class0 class026 = new Cryptex1.Class0();
            Cryptex1.Class0 class027 = new Cryptex1.Class0();
            Cryptex1.Class0 class028 = new Cryptex1.Class0();
            Cryptex1.Class0 class029 = new Cryptex1.Class0();
            Cryptex1.Class0 class030 = new Cryptex1.Class0();
            Cryptex1.Class0 class031 = new Cryptex1.Class0();
            Cryptex1.Class0 class032 = new Cryptex1.Class0();
            Cryptex1.Class0 class033 = new Cryptex1.Class0();
            Cryptex1.Class0 class034 = new Cryptex1.Class0();
            Cryptex1.Class0 class035 = new Cryptex1.Class0();
            Cryptex1.Class0 class036 = new Cryptex1.Class0();
            Cryptex1.Class0 class037 = new Cryptex1.Class0();
            Cryptex1.Class0 class038 = new Cryptex1.Class0();
            Cryptex1.Class0 class039 = new Cryptex1.Class0();
            Cryptex1.Class0 class040 = new Cryptex1.Class0();
            Cryptex1.Class0 class041 = new Cryptex1.Class0();
            Cryptex1.Class0 class042 = new Cryptex1.Class0();
            Cryptex1.Class0 class043 = new Cryptex1.Class0();
            Cryptex1.Class0 class044 = new Cryptex1.Class0();
            Cryptex1.Class0 class045 = new Cryptex1.Class0();
            Cryptex1.Class0 class046 = new Cryptex1.Class0();
            Cryptex1.Class0 class047 = new Cryptex1.Class0();
            Cryptex1.Class0 class048 = new Cryptex1.Class0();
            Cryptex1.Class0 class049 = new Cryptex1.Class0();
            Cryptex1.Class0 class050 = new Cryptex1.Class0();
            Cryptex1.Class0 class051 = new Cryptex1.Class0();
            Cryptex1.Class0 class052 = new Cryptex1.Class0();
            Cryptex1.Class0 class053 = new Cryptex1.Class0();
            Cryptex1.Class0 class054 = new Cryptex1.Class0();
            Cryptex1.Class0 class055 = new Cryptex1.Class0();
            Cryptex1.Class0 class056 = new Cryptex1.Class0();
            Cryptex1.Class0 class057 = new Cryptex1.Class0();
            Cryptex1.Class0 class058 = new Cryptex1.Class0();
            Cryptex1.Class0 class059 = new Cryptex1.Class0();
            Cryptex1.Class0 class060 = new Cryptex1.Class0();
            Cryptex1.Class0 class061 = new Cryptex1.Class0();
            Cryptex1.Class0 class062 = new Cryptex1.Class0();
            Cryptex1.Class0 class063 = new Cryptex1.Class0();
            Cryptex1.Class0 class064 = new Cryptex1.Class0();
            Cryptex1.Class0 class065 = new Cryptex1.Class0();
            Cryptex1.Class0 class066 = new Cryptex1.Class0();
            Cryptex1.Class0 class067 = new Cryptex1.Class0();
            Cryptex1.Class0 class068 = new Cryptex1.Class0();
            Cryptex1.Class0 class069 = new Cryptex1.Class0();
            Cryptex1.Class0 class070 = new Cryptex1.Class0();
            Cryptex1.Class0 class071 = new Cryptex1.Class0();
            Cryptex1.Class0 class072 = new Cryptex1.Class0();
            Cryptex1.Class0 class073 = new Cryptex1.Class0();
            Cryptex1.Class0 class074 = new Cryptex1.Class0();
            Cryptex1.Class0 class075 = new Cryptex1.Class0();
            Cryptex1.Class0 class076 = new Cryptex1.Class0();
            Cryptex1.Class0 class077 = new Cryptex1.Class0();
            Cryptex1.Class0 class078 = new Cryptex1.Class0();
            Cryptex1.Class0 class079 = new Cryptex1.Class0();
            Cryptex1.Class0 class080 = new Cryptex1.Class0();
            Cryptex1.Class0 class081 = new Cryptex1.Class0();
            Cryptex1.Class0 class082 = new Cryptex1.Class0();
            Cryptex1.Class0 class083 = new Cryptex1.Class0();
            Cryptex1.Class0 class084 = new Cryptex1.Class0();
            Cryptex1.Class0 class085 = new Cryptex1.Class0();
            Cryptex1.Class0 class086 = new Cryptex1.Class0();
            Cryptex1.Class0 class087 = new Cryptex1.Class0();
            Cryptex1.Class0 class088 = new Cryptex1.Class0();
            Cryptex1.Class0 class089 = new Cryptex1.Class0();
            Cryptex1.Class0 class090 = new Cryptex1.Class0();
            Cryptex1.Class0 class091 = new Cryptex1.Class0();
            Cryptex1.Class0 class092 = new Cryptex1.Class0();
            Cryptex1.Class0 class093 = new Cryptex1.Class0();
            Cryptex1.Class0 class094 = new Cryptex1.Class0();
            Cryptex1.Class0 class095 = new Cryptex1.Class0();
            Cryptex1.Class0 class096 = new Cryptex1.Class0();
            Cryptex1.Class0 class097 = new Cryptex1.Class0();
            Cryptex1.Class0 class098 = new Cryptex1.Class0();
            Cryptex1.Class0 class099 = new Cryptex1.Class0();
            Cryptex1.Class0 class0100 = new Cryptex1.Class0();
            Cryptex1.Class0 class0101 = new Cryptex1.Class0();
            Cryptex1.Class0 class0102 = new Cryptex1.Class0();
            Cryptex1.Class0 class0103 = new Cryptex1.Class0();
            Cryptex1.Class0 class0104 = new Cryptex1.Class0();
            Cryptex1.Class0 class0105 = new Cryptex1.Class0();
            Cryptex1.Class0 class0106 = new Cryptex1.Class0();
            Cryptex1.Class0 class0107 = new Cryptex1.Class0();
            Cryptex1.Class0 class0108 = new Cryptex1.Class0();
            Cryptex1.Class0 class0109 = new Cryptex1.Class0();
            Cryptex1.Class0 class0110 = new Cryptex1.Class0();
            Cryptex1.Class0 class0111 = new Cryptex1.Class0();
            Cryptex1.Class0 class0112 = new Cryptex1.Class0();
            Cryptex1.Class0 class0113 = new Cryptex1.Class0();
            Cryptex1.Class0 class0114 = new Cryptex1.Class0();
            Cryptex1.Class0 class0115 = new Cryptex1.Class0();
            Cryptex1.Class0 class0116 = new Cryptex1.Class0();
            Cryptex1.Class0 class0117 = new Cryptex1.Class0();
            Cryptex1.Class0 class0118 = new Cryptex1.Class0();
            Cryptex1.Class0 class0119 = new Cryptex1.Class0();
            Cryptex1.Class0 class0120 = new Cryptex1.Class0();
            Cryptex1.Class0 class0121 = new Cryptex1.Class0();
            Cryptex1.Class0 class0122 = new Cryptex1.Class0();
            Cryptex1.Class0 class0123 = new Cryptex1.Class0();
            Cryptex1.Class0 class0124 = new Cryptex1.Class0();
            Cryptex1.Class0 class0125 = new Cryptex1.Class0();
            Cryptex1.Class0 class0126 = new Cryptex1.Class0();
            Cryptex1.Class0 class0127 = new Cryptex1.Class0();
            Cryptex1.Class0 class0128 = new Cryptex1.Class0();
            Cryptex1.Class0 class0129 = new Cryptex1.Class0();
            Cryptex1.Class0 class0130 = new Cryptex1.Class0();
            Cryptex1.Class0 class0131 = new Cryptex1.Class0();
            Cryptex1.Class0 class0132 = new Cryptex1.Class0();
            Cryptex1.Class0 class0133 = new Cryptex1.Class0();
            Cryptex1.Class0 class0134 = new Cryptex1.Class0();
            Cryptex1.Class0 class0135 = new Cryptex1.Class0();
            Cryptex1.Class0 class0136 = new Cryptex1.Class0();
            Cryptex1.Class0 class0137 = new Cryptex1.Class0();
            Cryptex1.Class0 class0138 = new Cryptex1.Class0();
            Cryptex1.Class0 class0139 = new Cryptex1.Class0();
            Cryptex1.Class0 class0140 = new Cryptex1.Class0();
            Cryptex1.Class0 class0141 = new Cryptex1.Class0();
            Cryptex1.Class0 class0142 = new Cryptex1.Class0();
            Cryptex1.Class0 class0143 = new Cryptex1.Class0();
            Cryptex1.Class0 class0144 = new Cryptex1.Class0();
            Cryptex1.Class0 class0145 = new Cryptex1.Class0();
            Cryptex1.Class0 class0146 = new Cryptex1.Class0();
            Cryptex1.Class0 class0147 = new Cryptex1.Class0();
            Cryptex1.Class0 class0148 = new Cryptex1.Class0();
            Cryptex1.Class0 class0149 = new Cryptex1.Class0();
            Cryptex1.Class0 class0150 = new Cryptex1.Class0();
            Cryptex1.Class0 class0151 = new Cryptex1.Class0();
            Cryptex1.Class0 class0152 = new Cryptex1.Class0();
            Cryptex1.Class0 class0153 = new Cryptex1.Class0();
            Cryptex1.Class0 class0154 = new Cryptex1.Class0();
            Cryptex1.Class0 class0155 = new Cryptex1.Class0();
            Cryptex1.Class0 class0156 = new Cryptex1.Class0();
            Cryptex1.Class0 class0157 = new Cryptex1.Class0();
            Cryptex1.Class0 class0158 = new Cryptex1.Class0();
            Cryptex1.Class0 class0159 = new Cryptex1.Class0();
            Cryptex1.Class0 class0160 = new Cryptex1.Class0();
            Cryptex1.Class0 class0161 = new Cryptex1.Class0();
            Cryptex1.Class0 class0162 = new Cryptex1.Class0();
            Cryptex1.Class0 class0163 = new Cryptex1.Class0();
            Cryptex1.Class0 class0164 = new Cryptex1.Class0();
            Cryptex1.Class0 class0165 = new Cryptex1.Class0();
            Cryptex1.Class0 class0166 = new Cryptex1.Class0();
            Cryptex1.Class0 class0167 = new Cryptex1.Class0();
            Cryptex1.Class0 class0168 = new Cryptex1.Class0();
            Cryptex1.Class0 class0169 = new Cryptex1.Class0();
            Cryptex1.Class0 class0170 = new Cryptex1.Class0();
            Cryptex1.Class0 class0171 = new Cryptex1.Class0();
            Cryptex1.Class0 class0172 = new Cryptex1.Class0();
            Cryptex1.Class0 class0173 = new Cryptex1.Class0();
            Cryptex1.Class0 class0174 = new Cryptex1.Class0();
            Cryptex1.Class0 class0175 = new Cryptex1.Class0();
            Cryptex1.Class0 class0176 = new Cryptex1.Class0();
            Cryptex1.Class0 class0177 = new Cryptex1.Class0();
            Cryptex1.Class0 class0178 = new Cryptex1.Class0();
            Cryptex1.Class0 class0179 = new Cryptex1.Class0();
            Cryptex1.Class0 class0180 = new Cryptex1.Class0();
            Cryptex1.Class0 class0181 = new Cryptex1.Class0();
            Cryptex1.Class0 class0182 = new Cryptex1.Class0();
            Cryptex1.Class0 class0183 = new Cryptex1.Class0();
            Cryptex1.Class0 class0184 = new Cryptex1.Class0();
            Cryptex1.Class0 class0185 = new Cryptex1.Class0();
            Cryptex1.Class0 class0186 = new Cryptex1.Class0();
            Cryptex1.Class0 class0187 = new Cryptex1.Class0();
            Cryptex1.Class0 class0188 = new Cryptex1.Class0();
            Cryptex1.Class0 class0189 = new Cryptex1.Class0();
            Cryptex1.Class0 class0190 = new Cryptex1.Class0();
            Cryptex1.Class0 class0191 = new Cryptex1.Class0();
            Cryptex1.Class0 class0192 = new Cryptex1.Class0();
            Cryptex1.Class0 class0193 = new Cryptex1.Class0();
            Cryptex1.Class0 class0194 = new Cryptex1.Class0();
            Cryptex1.Class0 class0195 = new Cryptex1.Class0();
            Cryptex1.Class0 class0196 = new Cryptex1.Class0();
            Cryptex1.Class0 class0197 = new Cryptex1.Class0();
            Cryptex1.Class0 class0198 = new Cryptex1.Class0();
            Cryptex1.Class0 class0199 = new Cryptex1.Class0();
            Cryptex1.Class0 class0200 = new Cryptex1.Class0();
            Cryptex1.Class0 class0201 = new Cryptex1.Class0();
            Cryptex1.Class0 class0202 = new Cryptex1.Class0();
            Cryptex1.Class0 class0203 = new Cryptex1.Class0();
            Cryptex1.Class0 class0204 = new Cryptex1.Class0();
            Cryptex1.Class0 class0205 = new Cryptex1.Class0();
            Cryptex1.Class0 class0206 = new Cryptex1.Class0();
            Cryptex1.Class0 class0207 = new Cryptex1.Class0();
            Cryptex1.Class0 class0208 = new Cryptex1.Class0();
            Cryptex1.Class0 class0209 = new Cryptex1.Class0();
            Cryptex1.Class0 class0210 = new Cryptex1.Class0();
            Cryptex1.Class0 class0211 = new Cryptex1.Class0();
            Cryptex1.Class0 class0212 = new Cryptex1.Class0();
            Cryptex1.Class0 class0213 = new Cryptex1.Class0();
            Cryptex1.Class0 class0214 = new Cryptex1.Class0();
            Cryptex1.Class0 class0215 = new Cryptex1.Class0();
            Cryptex1.Class0 class0216 = new Cryptex1.Class0();
            Cryptex1.Class0 class0217 = new Cryptex1.Class0();
            Cryptex1.Class0 class0218 = new Cryptex1.Class0();
            Cryptex1.Class0 class0219 = new Cryptex1.Class0();
            Cryptex1.Class0 class0220 = new Cryptex1.Class0();
            Cryptex1.Class0 class0221 = new Cryptex1.Class0();
            Cryptex1.Class0 class0222 = new Cryptex1.Class0();
            Cryptex1.Class0 class0223 = new Cryptex1.Class0();
            Cryptex1.Class0 class0224 = new Cryptex1.Class0();
            Cryptex1.Class0 class0225 = new Cryptex1.Class0();
            Cryptex1.Class0 class0226 = new Cryptex1.Class0();
            Cryptex1.Class0 class0227 = new Cryptex1.Class0();
            Cryptex1.Class0 class0228 = new Cryptex1.Class0();
            Cryptex1.Class0 class0229 = new Cryptex1.Class0();
            Cryptex1.Class0 class0230 = new Cryptex1.Class0();
            Cryptex1.Class0 class0231 = new Cryptex1.Class0();
            Cryptex1.Class0 class0232 = new Cryptex1.Class0();
            Cryptex1.Class0 class0233 = new Cryptex1.Class0();
            Cryptex1.Class0 class0234 = new Cryptex1.Class0();
            Cryptex1.Class0 class0235 = new Cryptex1.Class0();
            Cryptex1.Class0 class0236 = new Cryptex1.Class0();
            Cryptex1.Class0 class0237 = new Cryptex1.Class0();
            Cryptex1.Class0 class0238 = new Cryptex1.Class0();
            Cryptex1.Class0 class0239 = new Cryptex1.Class0();
            Cryptex1.Class0 class0240 = new Cryptex1.Class0();
            Cryptex1.Class0 class0241 = new Cryptex1.Class0();
            Cryptex1.Class0 class0242 = new Cryptex1.Class0();
            Cryptex1.Class0 class0243 = new Cryptex1.Class0();
            Cryptex1.Class0 class0244 = new Cryptex1.Class0();
            Cryptex1.Class0 class0245 = new Cryptex1.Class0();
            Cryptex1.Class0 class0246 = new Cryptex1.Class0();
            Cryptex1.Class0 class0247 = new Cryptex1.Class0();
            Cryptex1.Class0 class0248 = new Cryptex1.Class0();
            Cryptex1.Class0 class0249 = new Cryptex1.Class0();
            Cryptex1.Class0 class0250 = new Cryptex1.Class0();
            Cryptex1.Class0 class0251 = new Cryptex1.Class0();
            Cryptex1.Class0 class0252 = new Cryptex1.Class0();
            Cryptex1.Class0 class0253 = new Cryptex1.Class0();
            Cryptex1.Class0 class0254 = new Cryptex1.Class0();
            Cryptex1.Class0 class01 = new Cryptex1.Class0();
            Cryptex1.Class0 class02 = new Cryptex1.Class0();
            Cryptex1.Class0 class03 = new Cryptex1.Class0();
            Cryptex1.Class0 class04 = new Cryptex1.Class0();
            Cryptex1.Class0 class05 = new Cryptex1.Class0();
            Cryptex1.Class0 class06 = new Cryptex1.Class0();
            Cryptex1.Class0 class07 = new Cryptex1.Class0();
            Cryptex1.Class0 class08 = new Cryptex1.Class0();
            Cryptex1.Class0 class09 = new Cryptex1.Class0();
            this.control161 = new Cryptex1.Control16();
            this.rdbNETfile = new System.Windows.Forms.RadioButton();
            this.pan5 = new System.Windows.Forms.Panel();
            this.deumosGroupBox8 = new Cryptex1.Control9();
            this.b12232324 = new System.Windows.Forms.Button();
            this.b555 = new System.Windows.Forms.Button();
            this.muButton1 = new Cryptex1.Control12();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.chckExeFusion = new System.Windows.Forms.CheckBox();
            this.chckMelt = new System.Windows.Forms.CheckBox();
            this.chckUAC = new System.Windows.Forms.CheckBox();
            this.chckTASK = new System.Windows.Forms.CheckBox();
            this.chckProtect = new System.Windows.Forms.CheckBox();
            this.Regedit = new System.Windows.Forms.CheckBox();
            this.chckReadOnly = new System.Windows.Forms.CheckBox();
            this.chckReflect = new System.Windows.Forms.CheckBox();
            this.chckCMD = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.chckReAlign = new System.Windows.Forms.CheckBox();
            this.deumosSeperator4 = new Cryptex1.Control3();
            this.deumosSeperator3 = new Cryptex1.Control3();
            this.control31 = new Cryptex1.Control3();
            this.deumosSeperator1 = new Cryptex1.Control3();
            this.deumosGroupBox12 = new Cryptex1.Control9();
            this.btnLoad = new Cryptex1.Control12();
            this.deumosGroupBox14 = new Cryptex1.Control9();
            this.label16 = new System.Windows.Forms.Label();
            this.rdbLoad3 = new System.Windows.Forms.RadioButton();
            this.rdbLoad2 = new System.Windows.Forms.RadioButton();
            this.rdbLoad1 = new System.Windows.Forms.RadioButton();
            this.rdbLoadCustom = new System.Windows.Forms.RadioButton();
            this.deumosGroupBox15 = new Cryptex1.Control9();
            this.label17 = new System.Windows.Forms.Label();
            this.rdbSave1 = new System.Windows.Forms.RadioButton();
            this.rdbSave2 = new System.Windows.Forms.RadioButton();
            this.rdbSave3 = new System.Windows.Forms.RadioButton();
            this.rdbSaveCustom = new System.Windows.Forms.RadioButton();
            this.muButton16 = new Cryptex1.Control12();
            this.pan7 = new System.Windows.Forms.Panel();
            this.deumosGroupBox9 = new Cryptex1.Control9();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rdbMyDocuments = new System.Windows.Forms.RadioButton();
            this.rdbDesktop = new System.Windows.Forms.RadioButton();
            this.rdbResources = new System.Windows.Forms.RadioButton();
            this.rdbProgramFiles = new System.Windows.Forms.RadioButton();
            this.rdbWindows = new System.Windows.Forms.RadioButton();
            this.rdbFavourites = new System.Windows.Forms.RadioButton();
            this.rdbCookies = new System.Windows.Forms.RadioButton();
            this.rdbSystem = new System.Windows.Forms.RadioButton();
            this.rdbHistory = new System.Windows.Forms.RadioButton();
            this.rdbAppData = new System.Windows.Forms.RadioButton();
            this.rdbMyMusic = new System.Windows.Forms.RadioButton();
            this.rdbSendTo = new System.Windows.Forms.RadioButton();
            this.rdbStartMenu = new System.Windows.Forms.RadioButton();
            this.rdbMyPrictures = new System.Windows.Forms.RadioButton();
            this.rdbRecent = new System.Windows.Forms.RadioButton();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtActiveXKey = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RandActiveX = new Cryptex1.Control4();
            this.deumosButton2 = new Cryptex1.Control4();
            this.textBoxStartup2 = new Cryptex1.Control2();
            this.txtFileNameSU = new Cryptex1.Control2();
            this.txtSubFolder = new Cryptex1.Control2();
            this.chckActiveX = new System.Windows.Forms.CheckBox();
            this.chckSubFolder = new System.Windows.Forms.CheckBox();
            this.rdbStart1 = new System.Windows.Forms.RadioButton();
            this.rdbStart2 = new System.Windows.Forms.RadioButton();
            this.chckSUp2 = new System.Windows.Forms.CheckBox();
            this.txtBindFile = new System.Windows.Forms.TextBox();
            this.rdbVBC = new System.Windows.Forms.RadioButton();
            this.radioCSC = new System.Windows.Forms.RadioButton();
            this.radioBtnCustom = new System.Windows.Forms.RadioButton();
            this.chckHideFile = new System.Windows.Forms.CheckBox();
            this.rdbMeth1 = new System.Windows.Forms.RadioButton();
            this.btnCrypt = new Cryptex1.Control12();
            this.txt111 = new Cryptex1.Control2();
            this.txtInformation = new Cryptex1.Control2();
            this.txtIcon = new System.Windows.Forms.TextBox();
            this.b12 = new Cryptex1.Control12();
            this.b11 = new Cryptex1.Control12();
            this.b10 = new Cryptex1.Control12();
            this.b2 = new Cryptex1.Control12();
            this.b6 = new Cryptex1.Control12();
            this.b3 = new Cryptex1.Control12();
            this.b4 = new Cryptex1.Control12();
            this.b7 = new Cryptex1.Control12();
            this.b8 = new Cryptex1.Control12();
            this.b9 = new Cryptex1.Control12();
            this.b1 = new Cryptex1.Control12();
            this.pan6 = new System.Windows.Forms.Panel();
            this.deumosGroupBox6 = new Cryptex1.Control9();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.intRevision = new System.Windows.Forms.NumericUpDown();
            this.intBuild = new System.Windows.Forms.NumericUpDown();
            this.intMinor = new System.Windows.Forms.NumericUpDown();
            this.intMajor = new System.Windows.Forms.NumericUpDown();
            this.AssemblyLenght = new System.Windows.Forms.NumericUpDown();
            this.muButton14 = new Cryptex1.Control12();
            this.muButton11 = new Cryptex1.Control12();
            this.txtAssemblyTitle = new Cryptex1.Control2();
            this.textAssemblyDescription = new Cryptex1.Control2();
            this.textAssemblyCompany = new Cryptex1.Control2();
            this.textAssemblyProduct = new Cryptex1.Control2();
            this.textAssemblyCopyRight = new Cryptex1.Control2();
            this.chckAssembly = new System.Windows.Forms.CheckBox();
            this.pan2 = new System.Windows.Forms.Panel();
            this.deumosGroupBox2 = new Cryptex1.Control9();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.muButton5 = new Cryptex1.Control12();
            this.muButton4 = new Cryptex1.Control12();
            this.lstBind = new System.Windows.Forms.ListBox();
            this.muButton15 = new Cryptex1.Control12();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.rdbBindStart = new System.Windows.Forms.RadioButton();
            this.radioButton93 = new System.Windows.Forms.RadioButton();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.pan10 = new System.Windows.Forms.Panel();
            this.deumosGroupBox10 = new Cryptex1.Control9();
            this.txtKey2 = new Cryptex1.Control2();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.rdbLetterKey2 = new System.Windows.Forms.RadioButton();
            this.rdbUnicodeKey2 = new System.Windows.Forms.RadioButton();
            this.rdbChinKey2 = new System.Windows.Forms.RadioButton();
            this.randomPool2 = new Cryptex1.Control14();
            this.groupEnc2 = new System.Windows.Forms.GroupBox();
            this.rdbPolyRijn2 = new System.Windows.Forms.RadioButton();
            this.rdbRC22 = new System.Windows.Forms.RadioButton();
            this.rdb3DES2 = new System.Windows.Forms.RadioButton();
            this.radioButton42 = new System.Windows.Forms.RadioButton();
            this.rdbPolyRev2 = new System.Windows.Forms.RadioButton();
            this.rdbPolyStairs2 = new System.Windows.Forms.RadioButton();
            this.rdbPolyAES2 = new System.Windows.Forms.RadioButton();
            this.rdbRC42 = new System.Windows.Forms.RadioButton();
            this.rdbRSM2 = new System.Windows.Forms.RadioButton();
            this.rdbPoly3DES2 = new System.Windows.Forms.RadioButton();
            this.rdbPolyCloud2 = new System.Windows.Forms.RadioButton();
            this.rdbAES2 = new System.Windows.Forms.RadioButton();
            this.rdbRijndael2 = new System.Windows.Forms.RadioButton();
            this.rdbPolyBaby2 = new System.Windows.Forms.RadioButton();
            this.rdbPolyDex2 = new System.Windows.Forms.RadioButton();
            this.rdbStairs2 = new System.Windows.Forms.RadioButton();
            this.rdbPolyRC22 = new System.Windows.Forms.RadioButton();
            this.rdbXOR2 = new System.Windows.Forms.RadioButton();
            this.radioButton57 = new System.Windows.Forms.RadioButton();
            this.rdbCloud2 = new System.Windows.Forms.RadioButton();
            this.rdbDex2 = new System.Windows.Forms.RadioButton();
            this.rdbPolyDES2 = new System.Windows.Forms.RadioButton();
            this.rdbSymetric2 = new System.Windows.Forms.RadioButton();
            this.rdbPolySym2 = new System.Windows.Forms.RadioButton();
            this.pan3 = new System.Windows.Forms.Panel();
            this.deumosGroupBox5 = new Cryptex1.Control9();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.numVariableLength = new System.Windows.Forms.NumericUpDown();
            this.rdbUnicode = new System.Windows.Forms.RadioButton();
            this.rdbLetter = new System.Windows.Forms.RadioButton();
            this.muButton13kk = new System.Windows.Forms.GroupBox();
            this.numRandomStringLength = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.lblApiAmount = new System.Windows.Forms.Label();
            this.trkFakeApi = new Cryptex1.Control1();
            this.chkFakeAPI = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblJunkAmount = new System.Windows.Forms.Label();
            this.chkArrayVariables = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.trkJunkCode = new Cryptex1.Control1();
            this.chkJunkCode = new System.Windows.Forms.CheckBox();
            this.pan8 = new System.Windows.Forms.Panel();
            this.deumosGroupBox3 = new Cryptex1.Control9();
            this.txtKey = new Cryptex1.Control2();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.rdbLettersKey = new System.Windows.Forms.RadioButton();
            this.rdbUnicodeKey = new System.Windows.Forms.RadioButton();
            this.rdbChinKey = new System.Windows.Forms.RadioButton();
            this.randomPool1 = new Cryptex1.Control14();
            this.grpEncryption = new System.Windows.Forms.GroupBox();
            this.rdbPolyRijn = new System.Windows.Forms.RadioButton();
            this.rdbRC2 = new System.Windows.Forms.RadioButton();
            this.rdbTripleDES = new System.Windows.Forms.RadioButton();
            this.radioButton34 = new System.Windows.Forms.RadioButton();
            this.rdbPolyRev = new System.Windows.Forms.RadioButton();
            this.rdbPolyStairs = new System.Windows.Forms.RadioButton();
            this.rdbPolyAES = new System.Windows.Forms.RadioButton();
            this.rdbRC4 = new System.Windows.Forms.RadioButton();
            this.rdbRSM = new System.Windows.Forms.RadioButton();
            this.rdbPoly3DES = new System.Windows.Forms.RadioButton();
            this.rdbPolyCloud = new System.Windows.Forms.RadioButton();
            this.rdbAES = new System.Windows.Forms.RadioButton();
            this.rdbRijndael = new System.Windows.Forms.RadioButton();
            this.rdbPolyBaby = new System.Windows.Forms.RadioButton();
            this.rdbPolyDex = new System.Windows.Forms.RadioButton();
            this.rdbStairs = new System.Windows.Forms.RadioButton();
            this.rdbPolyRC2 = new System.Windows.Forms.RadioButton();
            this.rdbXOR = new System.Windows.Forms.RadioButton();
            this.radioButton19 = new System.Windows.Forms.RadioButton();
            this.rdbBind1 = new System.Windows.Forms.RadioButton();
            this.rdbDex = new System.Windows.Forms.RadioButton();
            this.rdbPolyDES = new System.Windows.Forms.RadioButton();
            this.rdbSymetric = new System.Windows.Forms.RadioButton();
            this.rdbPolySym = new System.Windows.Forms.RadioButton();
            this.pan12 = new System.Windows.Forms.Panel();
            this.deumosGroupBox13 = new Cryptex1.Control9();
            this.grpPic = new System.Windows.Forms.GroupBox();
            this.pic1 = new System.Windows.Forms.PictureBox();
            this.pic2 = new System.Windows.Forms.PictureBox();
            this.pic3 = new System.Windows.Forms.PictureBox();
            this.pic4 = new System.Windows.Forms.PictureBox();
            this.picMn = new System.Windows.Forms.PictureBox();
            this.picEnc = new System.Windows.Forms.PictureBox();
            this.picRunPE = new System.Windows.Forms.PictureBox();
            this.picRest = new System.Windows.Forms.PictureBox();
            this.btnClearPic = new Cryptex1.Control12();
            this.grpPicBtn = new System.Windows.Forms.GroupBox();
            this.rdbCustomPic = new System.Windows.Forms.RadioButton();
            this.rdbRndPic = new System.Windows.Forms.RadioButton();
            this.pan9 = new System.Windows.Forms.Panel();
            this.DeumosGroupBo = new Cryptex1.Control9();
            this.groupBox21m = new System.Windows.Forms.GroupBox();
            this.numUpDownDelay = new System.Windows.Forms.NumericUpDown();
            this.chckDelay = new System.Windows.Forms.CheckBox();
            this.groupBox22b = new System.Windows.Forms.GroupBox();
            this.rdbMinutes = new System.Windows.Forms.RadioButton();
            this.rdbSeconds = new System.Windows.Forms.RadioButton();
            this.txtDownloa = new System.Windows.Forms.GroupBox();
            this.txtBatch2 = new System.Windows.Forms.RichTextBox();
            this.chckBatch = new System.Windows.Forms.CheckBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.chckNETfile = new System.Windows.Forms.CheckBox();
            this.chckEOF = new System.Windows.Forms.CheckBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.txtMutex = new Cryptex1.Control2();
            this.label8 = new System.Windows.Forms.Label();
            this.deumosButton1 = new Cryptex1.Control12();
            this.rdbmutletters = new System.Windows.Forms.RadioButton();
            this.rdbmutuni = new System.Windows.Forms.RadioButton();
            this.pan4 = new System.Windows.Forms.Panel();
            this.deumosGroupBox7 = new Cryptex1.Control9();
            this.groupBox6b = new System.Windows.Forms.GroupBox();
            this.rdbCrypt2x = new System.Windows.Forms.RadioButton();
            this.rdbCryptNormal = new System.Windows.Forms.RadioButton();
            this.grpStorage = new System.Windows.Forms.GroupBox();
            this.rdbStorBytes = new System.Windows.Forms.RadioButton();
            this.rdbStorString = new System.Windows.Forms.RadioButton();
            this.rdbStorBase = new System.Windows.Forms.RadioButton();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtInjectInto = new Cryptex1.Control2();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.muButton3 = new Cryptex1.Control12();
            this.muButton2 = new Cryptex1.Control12();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.rdbRunPE7 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE6 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE5 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE4 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE3 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE2 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE1 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.muButton10 = new Cryptex1.Control12();
            this.muButton9 = new Cryptex1.Control12();
            this.txtCryptFile = new Cryptex1.Control2();
            this.pan11 = new System.Windows.Forms.Panel();
            this.grpAntis = new Cryptex1.Control9();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.lstProc = new System.Windows.Forms.ListBox();
            this.txtProcess = new System.Windows.Forms.TextBox();
            this.muButton12 = new Cryptex1.Control12();
            this.muButton13 = new Cryptex1.Control12();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.rdbKill = new System.Windows.Forms.RadioButton();
            this.rdbExit = new System.Windows.Forms.RadioButton();
            this.rdbKillExit = new System.Windows.Forms.RadioButton();
            this.chckAnties = new System.Windows.Forms.CheckBox();
            this.pan1 = new System.Windows.Forms.Panel();
            this.deumosGroupBox1 = new Cryptex1.Control9();
            this.muButton6 = new Cryptex1.Control12();
            this.muButton7 = new Cryptex1.Control12();
            this.muButton8 = new Cryptex1.Control12();
            this.rdbDLapp = new System.Windows.Forms.RadioButton();
            this.rdbDLTemp = new System.Windows.Forms.RadioButton();
            this.rdbDLsystem = new System.Windows.Forms.RadioButton();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.rdbStart = new System.Windows.Forms.RadioButton();
            this.rdbEnd = new System.Windows.Forms.RadioButton();
            this.chckProxy = new System.Windows.Forms.CheckBox();
            this.txtDownloadLink = new Cryptex1.Control2();
            this.lstDownloadLinks = new System.Windows.Forms.ListBox();
            this.control91 = new Cryptex1.Control9();
            this.control161.SuspendLayout();
            this.pan5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.deumosGroupBox12.SuspendLayout();
            this.deumosGroupBox14.SuspendLayout();
            this.deumosGroupBox15.SuspendLayout();
            this.pan7.SuspendLayout();
            this.deumosGroupBox9.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.pan6.SuspendLayout();
            this.deumosGroupBox6.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.intRevision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.intBuild)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.intMinor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.intMajor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AssemblyLenght)).BeginInit();
            this.pan2.SuspendLayout();
            this.deumosGroupBox2.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.pan10.SuspendLayout();
            this.deumosGroupBox10.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupEnc2.SuspendLayout();
            this.pan3.SuspendLayout();
            this.deumosGroupBox5.SuspendLayout();
            this.groupBox17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numVariableLength)).BeginInit();
            this.muButton13kk.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRandomStringLength)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.pan8.SuspendLayout();
            this.deumosGroupBox3.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.grpEncryption.SuspendLayout();
            this.pan12.SuspendLayout();
            this.deumosGroupBox13.SuspendLayout();
            this.grpPic.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRunPE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRest)).BeginInit();
            this.grpPicBtn.SuspendLayout();
            this.pan9.SuspendLayout();
            this.DeumosGroupBo.SuspendLayout();
            this.groupBox21m.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownDelay)).BeginInit();
            this.groupBox22b.SuspendLayout();
            this.txtDownloa.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.pan4.SuspendLayout();
            this.deumosGroupBox7.SuspendLayout();
            this.groupBox6b.SuspendLayout();
            this.grpStorage.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox33.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pan11.SuspendLayout();
            this.grpAntis.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.pan1.SuspendLayout();
            this.deumosGroupBox1.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.SuspendLayout();
            // 
            // control161
            // 
            this.control161.AllowDrop = true;
            this.control161.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.control161.Boolean_0 = true;
            class11.Name = "BackColor";
            class11.Value = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class12.Name = "CornerGradient1";
            class12.Value = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(48)))), ((int)(((byte)(48)))));
            class13.Name = "CornerGradient2";
            class13.Value = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(4)))), ((int)(((byte)(4)))));
            class14.Name = "TextShadow";
            class14.Value = System.Drawing.Color.Black;
            class15.Name = "TextColor";
            class15.Value = System.Drawing.Color.White;
            class16.Name = "BorderColor";
            class16.Value = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
            class17.Name = "Outline";
            class17.Value = System.Drawing.Color.Black;
            class18.Name = "CornerHighlight";
            class18.Value = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class19.Name = "TitleShine";
            class19.Value = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            class110.Name = "TitleGloss";
            class110.Value = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class111.Name = "CornerGloss";
            class111.Value = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class112.Name = "TitleGradient1";
            class112.Value = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class113.Name = "TitleGradient2";
            class113.Value = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            this.control161.Class1_0 = new Cryptex1.Control16.Class1[] {
        class11,
        class12,
        class13,
        class14,
        class15,
        class16,
        class17,
        class18,
        class19,
        class110,
        class111,
        class112,
        class113};
            this.control161.Color_0 = System.Drawing.Color.Fuchsia;
            this.control161.Controls.Add(this.control91);
            this.control161.Controls.Add(this.rdbNETfile);
            this.control161.Controls.Add(this.pan5);
            this.control161.Controls.Add(this.b12232324);
            this.control161.Controls.Add(this.b555);
            this.control161.Controls.Add(this.muButton1);
            this.control161.Controls.Add(this.pictureBox2);
            this.control161.Controls.Add(this.pictureBox3);
            this.control161.Controls.Add(this.chckExeFusion);
            this.control161.Controls.Add(this.chckMelt);
            this.control161.Controls.Add(this.chckUAC);
            this.control161.Controls.Add(this.chckTASK);
            this.control161.Controls.Add(this.chckProtect);
            this.control161.Controls.Add(this.Regedit);
            this.control161.Controls.Add(this.chckReadOnly);
            this.control161.Controls.Add(this.chckReflect);
            this.control161.Controls.Add(this.chckCMD);
            this.control161.Controls.Add(this.label11);
            this.control161.Controls.Add(this.label15);
            this.control161.Controls.Add(this.chckReAlign);
            this.control161.Controls.Add(this.deumosSeperator4);
            this.control161.Controls.Add(this.deumosSeperator3);
            this.control161.Controls.Add(this.control31);
            this.control161.Controls.Add(this.deumosSeperator1);
            this.control161.Controls.Add(this.deumosGroupBox12);
            this.control161.Controls.Add(this.pan7);
            this.control161.Controls.Add(this.txtBindFile);
            this.control161.Controls.Add(this.rdbVBC);
            this.control161.Controls.Add(this.radioCSC);
            this.control161.Controls.Add(this.radioBtnCustom);
            this.control161.Controls.Add(this.chckHideFile);
            this.control161.Controls.Add(this.rdbMeth1);
            this.control161.Controls.Add(this.btnCrypt);
            this.control161.Controls.Add(this.txt111);
            this.control161.Controls.Add(this.txtInformation);
            this.control161.Controls.Add(this.txtIcon);
            this.control161.Controls.Add(this.b12);
            this.control161.Controls.Add(this.b11);
            this.control161.Controls.Add(this.b10);
            this.control161.Controls.Add(this.b2);
            this.control161.Controls.Add(this.b6);
            this.control161.Controls.Add(this.b3);
            this.control161.Controls.Add(this.b4);
            this.control161.Controls.Add(this.b7);
            this.control161.Controls.Add(this.b8);
            this.control161.Controls.Add(this.b9);
            this.control161.Controls.Add(this.b1);
            this.control161.Controls.Add(this.pan6);
            this.control161.Controls.Add(this.pan2);
            this.control161.Controls.Add(this.pan10);
            this.control161.Controls.Add(this.pan3);
            this.control161.Controls.Add(this.pan8);
            this.control161.Controls.Add(this.pan12);
            this.control161.Controls.Add(this.pan9);
            this.control161.Controls.Add(this.pan4);
            this.control161.Controls.Add(this.pan11);
            this.control161.Controls.Add(this.pan1);
            this.control161.Dock = System.Windows.Forms.DockStyle.Fill;
            this.control161.ForeColor = System.Drawing.Color.DarkOrange;
            this.control161.Image_0 = null;
            this.control161.Int32_0 = 24;
            this.control161.Location = new System.Drawing.Point(0, 0);
            this.control161.MinimumSize = new System.Drawing.Size(120, 80);
            this.control161.Name = "control161";
            this.control161.Size = new System.Drawing.Size(1028, 742);
            this.control161.TabIndex = 0;
            this.control161.Text = "Cryptex 2.5.1.2";
            // 
            // rdbNETfile
            // 
            this.rdbNETfile.AutoSize = true;
            this.rdbNETfile.Location = new System.Drawing.Point(492, 461);
            this.rdbNETfile.Name = "rdbNETfile";
            this.rdbNETfile.Size = new System.Drawing.Size(14, 13);
            this.rdbNETfile.TabIndex = 6;
            this.rdbNETfile.TabStop = true;
            this.rdbNETfile.UseVisualStyleBackColor = true;
            // 
            // pan5
            // 
            this.pan5.Controls.Add(this.deumosGroupBox8);
            this.pan5.Location = new System.Drawing.Point(199, 456);
            this.pan5.Name = "pan5";
            this.pan5.Size = new System.Drawing.Size(74, 44);
            this.pan5.TabIndex = 62;
            // 
            // deumosGroupBox8
            // 
            this.deumosGroupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox8.Boolean_0 = true;
            this.deumosGroupBox8.Boolean_1 = true;
            this.deumosGroupBox8.Boolean_3 = false;
            class010.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class010.String_0 = "Back";
            class011.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class011.String_0 = "MainFill";
            class012.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class012.String_0 = "MainOutline1";
            class013.Color_0 = System.Drawing.Color.Black;
            class013.String_0 = "MainOutline2";
            class014.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class014.String_0 = "TitleShadow";
            class015.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class015.String_0 = "TitleFill";
            class016.Color_0 = System.Drawing.Color.White;
            class016.String_0 = "Text";
            class017.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class017.String_0 = "TitleOutline1";
            class018.Color_0 = System.Drawing.Color.Black;
            class018.String_0 = "TitleOutline2";
            this.deumosGroupBox8.Class0_0 = new Cryptex1.Class0[] {
        class010,
        class011,
        class012,
        class013,
        class014,
        class015,
        class016,
        class017,
        class018};
            this.deumosGroupBox8.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox8.Font = new System.Drawing.Font("Verdana", 8F);
            this.deumosGroupBox8.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox8.Image_0 = null;
            this.deumosGroupBox8.Location = new System.Drawing.Point(3, 169);
            this.deumosGroupBox8.Name = "deumosGroupBox8";
            this.deumosGroupBox8.Size = new System.Drawing.Size(85, 61);
            this.deumosGroupBox8.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox8.TabIndex = 0;
            this.deumosGroupBox8.Text = "Build";
            // 
            // b12232324
            // 
            this.b12232324.Location = new System.Drawing.Point(285, 421);
            this.b12232324.Name = "b12232324";
            this.b12232324.Size = new System.Drawing.Size(75, 23);
            this.b12232324.TabIndex = 61;
            this.b12232324.Text = "Event";
            this.b12232324.UseVisualStyleBackColor = true;
            this.b12232324.Click += new System.EventHandler(this.b12232324_Click);
            // 
            // b555
            // 
            this.b555.Location = new System.Drawing.Point(12, 484);
            this.b555.Name = "b555";
            this.b555.Size = new System.Drawing.Size(75, 23);
            this.b555.TabIndex = 60;
            this.b555.Text = "Build";
            this.b555.UseVisualStyleBackColor = true;
            // 
            // muButton1
            // 
            this.muButton1.Boolean_0 = false;
            this.muButton1.Image_0 = null;
            this.muButton1.Location = new System.Drawing.Point(501, 4);
            this.muButton1.Name = "muButton1";
            this.muButton1.Size = new System.Drawing.Size(19, 19);
            this.muButton1.TabIndex = 59;
            this.muButton1.Text = "X";
            this.muButton1.Click += new System.EventHandler(this.muButton1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(12, 392);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(181, 155);
            this.pictureBox2.TabIndex = 58;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(91, 31);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(10, 10);
            this.pictureBox3.TabIndex = 57;
            this.pictureBox3.TabStop = false;
            // 
            // chckExeFusion
            // 
            this.chckExeFusion.AutoSize = true;
            this.chckExeFusion.Location = new System.Drawing.Point(0, 672);
            this.chckExeFusion.Name = "chckExeFusion";
            this.chckExeFusion.Size = new System.Drawing.Size(57, 17);
            this.chckExeFusion.TabIndex = 56;
            this.chckExeFusion.Text = "exefuz";
            this.chckExeFusion.UseVisualStyleBackColor = true;
            // 
            // chckMelt
            // 
            this.chckMelt.AutoSize = true;
            this.chckMelt.Location = new System.Drawing.Point(9, 630);
            this.chckMelt.Name = "chckMelt";
            this.chckMelt.Size = new System.Drawing.Size(80, 17);
            this.chckMelt.TabIndex = 55;
            this.chckMelt.Text = "checkBox2";
            this.chckMelt.UseVisualStyleBackColor = true;
            // 
            // chckUAC
            // 
            this.chckUAC.AutoSize = true;
            this.chckUAC.Location = new System.Drawing.Point(3, 599);
            this.chckUAC.Name = "chckUAC";
            this.chckUAC.Size = new System.Drawing.Size(46, 17);
            this.chckUAC.TabIndex = 54;
            this.chckUAC.Text = "Uac";
            this.chckUAC.UseVisualStyleBackColor = true;
            // 
            // chckTASK
            // 
            this.chckTASK.AutoSize = true;
            this.chckTASK.Enabled = false;
            this.chckTASK.Location = new System.Drawing.Point(9, 554);
            this.chckTASK.Name = "chckTASK";
            this.chckTASK.Size = new System.Drawing.Size(54, 17);
            this.chckTASK.TabIndex = 53;
            this.chckTASK.Text = "TASK";
            this.chckTASK.UseVisualStyleBackColor = true;
            this.chckTASK.Visible = false;
            // 
            // chckProtect
            // 
            this.chckProtect.AutoSize = true;
            this.chckProtect.Enabled = false;
            this.chckProtect.Location = new System.Drawing.Point(5, 727);
            this.chckProtect.Name = "chckProtect";
            this.chckProtect.Size = new System.Drawing.Size(81, 17);
            this.chckProtect.TabIndex = 52;
            this.chckProtect.Text = "Protectproc";
            this.chckProtect.UseVisualStyleBackColor = true;
            this.chckProtect.Visible = false;
            // 
            // Regedit
            // 
            this.Regedit.AutoSize = true;
            this.Regedit.Enabled = false;
            this.Regedit.Location = new System.Drawing.Point(6, 574);
            this.Regedit.Name = "Regedit";
            this.Regedit.Size = new System.Drawing.Size(63, 17);
            this.Regedit.TabIndex = 51;
            this.Regedit.Text = "Regedit";
            this.Regedit.UseVisualStyleBackColor = true;
            this.Regedit.Visible = false;
            // 
            // chckReadOnly
            // 
            this.chckReadOnly.AutoSize = true;
            this.chckReadOnly.Location = new System.Drawing.Point(5, 708);
            this.chckReadOnly.Name = "chckReadOnly";
            this.chckReadOnly.Size = new System.Drawing.Size(76, 17);
            this.chckReadOnly.TabIndex = 50;
            this.chckReadOnly.Text = "Read Only";
            this.chckReadOnly.UseVisualStyleBackColor = true;
            // 
            // chckReflect
            // 
            this.chckReflect.AutoSize = true;
            this.chckReflect.Location = new System.Drawing.Point(0, 691);
            this.chckReflect.Name = "chckReflect";
            this.chckReflect.Size = new System.Drawing.Size(81, 17);
            this.chckReflect.TabIndex = 49;
            this.chckReflect.Text = "Anti-Reflect";
            this.chckReflect.UseVisualStyleBackColor = true;
            // 
            // chckCMD
            // 
            this.chckCMD.AutoSize = true;
            this.chckCMD.Enabled = false;
            this.chckCMD.Location = new System.Drawing.Point(6, 647);
            this.chckCMD.Name = "chckCMD";
            this.chckCMD.Size = new System.Drawing.Size(50, 17);
            this.chckCMD.TabIndex = 48;
            this.chckCMD.Text = "CMD";
            this.chckCMD.UseVisualStyleBackColor = true;
            this.chckCMD.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(418, 29);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 13);
            this.label11.TabIndex = 47;
            this.label11.Text = "Settings";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(105, 412);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(57, 13);
            this.label15.TabIndex = 46;
            this.label15.Text = "Inject Into:";
            // 
            // chckReAlign
            // 
            this.chckReAlign.AutoSize = true;
            this.chckReAlign.Location = new System.Drawing.Point(19, 356);
            this.chckReAlign.Name = "chckReAlign";
            this.chckReAlign.Size = new System.Drawing.Size(77, 17);
            this.chckReAlign.TabIndex = 45;
            this.chckReAlign.Text = "ReAlignPE";
            this.chckReAlign.UseVisualStyleBackColor = true;
            // 
            // deumosSeperator4
            // 
            this.deumosSeperator4.Boolean_0 = false;
            this.deumosSeperator4.Boolean_1 = false;
            class019.Color_0 = System.Drawing.Color.Black;
            class019.String_0 = "Line1";
            class020.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            class020.String_0 = "Line2";
            this.deumosSeperator4.Class0_0 = new Cryptex1.Class0[] {
        class019,
        class020};
            this.deumosSeperator4.Font = new System.Drawing.Font("Verdana", 8F);
            this.deumosSeperator4.Image_0 = null;
            this.deumosSeperator4.Location = new System.Drawing.Point(515, 30);
            this.deumosSeperator4.Name = "deumosSeperator4";
            this.deumosSeperator4.Orientation_0 = System.Windows.Forms.Orientation.Vertical;
            this.deumosSeperator4.Size = new System.Drawing.Size(14, 308);
            this.deumosSeperator4.String_0 = "AAAA/xYWFv8=";
            this.deumosSeperator4.TabIndex = 44;
            this.deumosSeperator4.Text = "control32";
            // 
            // deumosSeperator3
            // 
            this.deumosSeperator3.Boolean_0 = false;
            this.deumosSeperator3.Boolean_1 = false;
            class021.Color_0 = System.Drawing.Color.Black;
            class021.String_0 = "Line1";
            class022.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            class022.String_0 = "Line2";
            this.deumosSeperator3.Class0_0 = new Cryptex1.Class0[] {
        class021,
        class022};
            this.deumosSeperator3.Font = new System.Drawing.Font("Verdana", 8F);
            this.deumosSeperator3.Image_0 = null;
            this.deumosSeperator3.Location = new System.Drawing.Point(365, 28);
            this.deumosSeperator3.Name = "deumosSeperator3";
            this.deumosSeperator3.Orientation_0 = System.Windows.Forms.Orientation.Vertical;
            this.deumosSeperator3.Size = new System.Drawing.Size(14, 234);
            this.deumosSeperator3.String_0 = "AAAA/xYWFv8=";
            this.deumosSeperator3.TabIndex = 43;
            this.deumosSeperator3.Text = "control32";
            // 
            // control31
            // 
            this.control31.Boolean_0 = false;
            this.control31.Boolean_1 = false;
            class023.Color_0 = System.Drawing.Color.Black;
            class023.String_0 = "Line1";
            class024.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            class024.String_0 = "Line2";
            this.control31.Class0_0 = new Cryptex1.Class0[] {
        class023,
        class024};
            this.control31.Font = new System.Drawing.Font("Verdana", 8F);
            this.control31.Image_0 = null;
            this.control31.Location = new System.Drawing.Point(79, 28);
            this.control31.Name = "control31";
            this.control31.Orientation_0 = System.Windows.Forms.Orientation.Vertical;
            this.control31.Size = new System.Drawing.Size(14, 237);
            this.control31.String_0 = "AAAA/xYWFv8=";
            this.control31.TabIndex = 42;
            this.control31.Text = "control31";
            // 
            // deumosSeperator1
            // 
            this.deumosSeperator1.Boolean_0 = false;
            this.deumosSeperator1.Boolean_1 = false;
            class025.Color_0 = System.Drawing.Color.Black;
            class025.String_0 = "Line1";
            class026.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(22)))), ((int)(((byte)(22)))), ((int)(((byte)(22)))));
            class026.String_0 = "Line2";
            this.deumosSeperator1.Class0_0 = new Cryptex1.Class0[] {
        class025,
        class026};
            this.deumosSeperator1.Font = new System.Drawing.Font("Verdana", 8F);
            this.deumosSeperator1.Image_0 = null;
            this.deumosSeperator1.Location = new System.Drawing.Point(7, 261);
            this.deumosSeperator1.Name = "deumosSeperator1";
            this.deumosSeperator1.Orientation_0 = System.Windows.Forms.Orientation.Horizontal;
            this.deumosSeperator1.Size = new System.Drawing.Size(365, 14);
            this.deumosSeperator1.String_0 = "AAAA/xYWFv8=";
            this.deumosSeperator1.TabIndex = 41;
            this.deumosSeperator1.Text = "control31";
            // 
            // deumosGroupBox12
            // 
            this.deumosGroupBox12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox12.Boolean_0 = true;
            this.deumosGroupBox12.Boolean_1 = true;
            this.deumosGroupBox12.Boolean_3 = false;
            class027.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class027.String_0 = "Back";
            class028.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class028.String_0 = "MainFill";
            class029.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class029.String_0 = "MainOutline1";
            class030.Color_0 = System.Drawing.Color.Black;
            class030.String_0 = "MainOutline2";
            class031.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class031.String_0 = "TitleShadow";
            class032.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class032.String_0 = "TitleFill";
            class033.Color_0 = System.Drawing.Color.White;
            class033.String_0 = "Text";
            class034.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class034.String_0 = "TitleOutline1";
            class035.Color_0 = System.Drawing.Color.Black;
            class035.String_0 = "TitleOutline2";
            this.deumosGroupBox12.Class0_0 = new Cryptex1.Class0[] {
        class027,
        class028,
        class029,
        class030,
        class031,
        class032,
        class033,
        class034,
        class035};
            this.deumosGroupBox12.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox12.Controls.Add(this.btnLoad);
            this.deumosGroupBox12.Controls.Add(this.deumosGroupBox14);
            this.deumosGroupBox12.Controls.Add(this.deumosGroupBox15);
            this.deumosGroupBox12.Controls.Add(this.muButton16);
            this.deumosGroupBox12.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox12.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox12.Image_0 = null;
            this.deumosGroupBox12.Location = new System.Drawing.Point(7, 273);
            this.deumosGroupBox12.Name = "deumosGroupBox12";
            this.deumosGroupBox12.Size = new System.Drawing.Size(310, 65);
            this.deumosGroupBox12.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox12.TabIndex = 40;
            // 
            // btnLoad
            // 
            this.btnLoad.Boolean_0 = false;
            this.btnLoad.Image_0 = null;
            this.btnLoad.Location = new System.Drawing.Point(107, 3);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(35, 51);
            this.btnLoad.TabIndex = 3;
            this.btnLoad.Text = "Load";
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // deumosGroupBox14
            // 
            this.deumosGroupBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox14.Boolean_0 = true;
            this.deumosGroupBox14.Boolean_1 = true;
            this.deumosGroupBox14.Boolean_3 = false;
            class036.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class036.String_0 = "Back";
            class037.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class037.String_0 = "MainFill";
            class038.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class038.String_0 = "MainOutline1";
            class039.Color_0 = System.Drawing.Color.Black;
            class039.String_0 = "MainOutline2";
            class040.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class040.String_0 = "TitleShadow";
            class041.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class041.String_0 = "TitleFill";
            class042.Color_0 = System.Drawing.Color.White;
            class042.String_0 = "Text";
            class043.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class043.String_0 = "TitleOutline1";
            class044.Color_0 = System.Drawing.Color.Black;
            class044.String_0 = "TitleOutline2";
            this.deumosGroupBox14.Class0_0 = new Cryptex1.Class0[] {
        class036,
        class037,
        class038,
        class039,
        class040,
        class041,
        class042,
        class043,
        class044};
            this.deumosGroupBox14.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox14.Controls.Add(this.label16);
            this.deumosGroupBox14.Controls.Add(this.rdbLoad3);
            this.deumosGroupBox14.Controls.Add(this.rdbLoad2);
            this.deumosGroupBox14.Controls.Add(this.rdbLoad1);
            this.deumosGroupBox14.Controls.Add(this.rdbLoadCustom);
            this.deumosGroupBox14.Font = new System.Drawing.Font("Verdana", 8F);
            this.deumosGroupBox14.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox14.Image_0 = null;
            this.deumosGroupBox14.Location = new System.Drawing.Point(4, 4);
            this.deumosGroupBox14.Name = "deumosGroupBox14";
            this.deumosGroupBox14.Size = new System.Drawing.Size(97, 57);
            this.deumosGroupBox14.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox14.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DarkOrange;
            this.label16.Location = new System.Drawing.Point(9, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 14);
            this.label16.TabIndex = 4;
            this.label16.Text = "Load Settings:";
            // 
            // rdbLoad3
            // 
            this.rdbLoad3.AutoSize = true;
            this.rdbLoad3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbLoad3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbLoad3.Location = new System.Drawing.Point(63, 19);
            this.rdbLoad3.Name = "rdbLoad3";
            this.rdbLoad3.Size = new System.Drawing.Size(31, 18);
            this.rdbLoad3.TabIndex = 3;
            this.rdbLoad3.TabStop = true;
            this.rdbLoad3.Text = "3";
            this.rdbLoad3.UseVisualStyleBackColor = true;
            // 
            // rdbLoad2
            // 
            this.rdbLoad2.AutoSize = true;
            this.rdbLoad2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbLoad2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbLoad2.Location = new System.Drawing.Point(35, 19);
            this.rdbLoad2.Name = "rdbLoad2";
            this.rdbLoad2.Size = new System.Drawing.Size(31, 18);
            this.rdbLoad2.TabIndex = 2;
            this.rdbLoad2.TabStop = true;
            this.rdbLoad2.Text = "2";
            this.rdbLoad2.UseVisualStyleBackColor = true;
            // 
            // rdbLoad1
            // 
            this.rdbLoad1.AutoSize = true;
            this.rdbLoad1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbLoad1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbLoad1.Location = new System.Drawing.Point(7, 19);
            this.rdbLoad1.Name = "rdbLoad1";
            this.rdbLoad1.Size = new System.Drawing.Size(31, 18);
            this.rdbLoad1.TabIndex = 1;
            this.rdbLoad1.TabStop = true;
            this.rdbLoad1.Text = "1";
            this.rdbLoad1.UseVisualStyleBackColor = true;
            // 
            // rdbLoadCustom
            // 
            this.rdbLoadCustom.AutoSize = true;
            this.rdbLoadCustom.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbLoadCustom.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbLoadCustom.Location = new System.Drawing.Point(17, 36);
            this.rdbLoadCustom.Name = "rdbLoadCustom";
            this.rdbLoadCustom.Size = new System.Drawing.Size(61, 18);
            this.rdbLoadCustom.TabIndex = 0;
            this.rdbLoadCustom.TabStop = true;
            this.rdbLoadCustom.Text = "Custom";
            this.rdbLoadCustom.UseVisualStyleBackColor = true;
            // 
            // deumosGroupBox15
            // 
            this.deumosGroupBox15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox15.Boolean_0 = true;
            this.deumosGroupBox15.Boolean_1 = true;
            this.deumosGroupBox15.Boolean_3 = false;
            class045.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class045.String_0 = "Back";
            class046.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class046.String_0 = "MainFill";
            class047.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class047.String_0 = "MainOutline1";
            class048.Color_0 = System.Drawing.Color.Black;
            class048.String_0 = "MainOutline2";
            class049.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class049.String_0 = "TitleShadow";
            class050.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class050.String_0 = "TitleFill";
            class051.Color_0 = System.Drawing.Color.White;
            class051.String_0 = "Text";
            class052.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class052.String_0 = "TitleOutline1";
            class053.Color_0 = System.Drawing.Color.Black;
            class053.String_0 = "TitleOutline2";
            this.deumosGroupBox15.Class0_0 = new Cryptex1.Class0[] {
        class045,
        class046,
        class047,
        class048,
        class049,
        class050,
        class051,
        class052,
        class053};
            this.deumosGroupBox15.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox15.Controls.Add(this.label17);
            this.deumosGroupBox15.Controls.Add(this.rdbSave1);
            this.deumosGroupBox15.Controls.Add(this.rdbSave2);
            this.deumosGroupBox15.Controls.Add(this.rdbSave3);
            this.deumosGroupBox15.Controls.Add(this.rdbSaveCustom);
            this.deumosGroupBox15.Font = new System.Drawing.Font("Verdana", 8F);
            this.deumosGroupBox15.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox15.Image_0 = null;
            this.deumosGroupBox15.Location = new System.Drawing.Point(163, 4);
            this.deumosGroupBox15.Name = "deumosGroupBox15";
            this.deumosGroupBox15.Size = new System.Drawing.Size(97, 57);
            this.deumosGroupBox15.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox15.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.DarkOrange;
            this.label17.Location = new System.Drawing.Point(9, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 14);
            this.label17.TabIndex = 4;
            this.label17.Text = "Save Settings:";
            // 
            // rdbSave1
            // 
            this.rdbSave1.AutoSize = true;
            this.rdbSave1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbSave1.Location = new System.Drawing.Point(7, 19);
            this.rdbSave1.Name = "rdbSave1";
            this.rdbSave1.Size = new System.Drawing.Size(32, 17);
            this.rdbSave1.TabIndex = 3;
            this.rdbSave1.TabStop = true;
            this.rdbSave1.Text = "1";
            this.rdbSave1.UseVisualStyleBackColor = true;
            // 
            // rdbSave2
            // 
            this.rdbSave2.AutoSize = true;
            this.rdbSave2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbSave2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbSave2.Location = new System.Drawing.Point(35, 19);
            this.rdbSave2.Name = "rdbSave2";
            this.rdbSave2.Size = new System.Drawing.Size(31, 18);
            this.rdbSave2.TabIndex = 2;
            this.rdbSave2.TabStop = true;
            this.rdbSave2.Text = "2";
            this.rdbSave2.UseVisualStyleBackColor = true;
            // 
            // rdbSave3
            // 
            this.rdbSave3.AutoSize = true;
            this.rdbSave3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbSave3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbSave3.Location = new System.Drawing.Point(63, 19);
            this.rdbSave3.Name = "rdbSave3";
            this.rdbSave3.Size = new System.Drawing.Size(31, 18);
            this.rdbSave3.TabIndex = 1;
            this.rdbSave3.TabStop = true;
            this.rdbSave3.Text = "3";
            this.rdbSave3.UseVisualStyleBackColor = true;
            // 
            // rdbSaveCustom
            // 
            this.rdbSaveCustom.AutoSize = true;
            this.rdbSaveCustom.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbSaveCustom.Location = new System.Drawing.Point(17, 36);
            this.rdbSaveCustom.Name = "rdbSaveCustom";
            this.rdbSaveCustom.Size = new System.Drawing.Size(69, 17);
            this.rdbSaveCustom.TabIndex = 0;
            this.rdbSaveCustom.TabStop = true;
            this.rdbSaveCustom.Text = "Custom";
            this.rdbSaveCustom.UseVisualStyleBackColor = true;
            // 
            // muButton16
            // 
            this.muButton16.Boolean_0 = false;
            this.muButton16.Image_0 = null;
            this.muButton16.Location = new System.Drawing.Point(262, 7);
            this.muButton16.Name = "muButton16";
            this.muButton16.Size = new System.Drawing.Size(35, 51);
            this.muButton16.TabIndex = 0;
            this.muButton16.Text = "Save";
            this.muButton16.Click += new System.EventHandler(this.muButton16_Click);
            // 
            // pan7
            // 
            this.pan7.Controls.Add(this.deumosGroupBox9);
            this.pan7.Location = new System.Drawing.Point(906, 506);
            this.pan7.Name = "pan7";
            this.pan7.Size = new System.Drawing.Size(277, 225);
            this.pan7.TabIndex = 4;
            this.pan7.Visible = false;
            // 
            // deumosGroupBox9
            // 
            this.deumosGroupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox9.Boolean_0 = true;
            this.deumosGroupBox9.Boolean_1 = true;
            this.deumosGroupBox9.Boolean_3 = false;
            class054.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class054.String_0 = "Back";
            class055.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class055.String_0 = "MainFill";
            class056.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class056.String_0 = "MainOutline1";
            class057.Color_0 = System.Drawing.Color.Black;
            class057.String_0 = "MainOutline2";
            class058.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class058.String_0 = "TitleShadow";
            class059.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class059.String_0 = "TitleFill";
            class060.Color_0 = System.Drawing.Color.White;
            class060.String_0 = "Text";
            class061.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class061.String_0 = "TitleOutline1";
            class062.Color_0 = System.Drawing.Color.Black;
            class062.String_0 = "TitleOutline2";
            this.deumosGroupBox9.Class0_0 = new Cryptex1.Class0[] {
        class054,
        class055,
        class056,
        class057,
        class058,
        class059,
        class060,
        class061,
        class062};
            this.deumosGroupBox9.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox9.Controls.Add(this.groupBox3);
            this.deumosGroupBox9.Controls.Add(this.groupBox11);
            this.deumosGroupBox9.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox9.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox9.Image_0 = null;
            this.deumosGroupBox9.Location = new System.Drawing.Point(3, 1);
            this.deumosGroupBox9.Name = "deumosGroupBox9";
            this.deumosGroupBox9.Size = new System.Drawing.Size(274, 224);
            this.deumosGroupBox9.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox9.TabIndex = 0;
            this.deumosGroupBox9.Text = "Start-Up";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rdbMyDocuments);
            this.groupBox3.Controls.Add(this.rdbDesktop);
            this.groupBox3.Controls.Add(this.rdbResources);
            this.groupBox3.Controls.Add(this.rdbProgramFiles);
            this.groupBox3.Controls.Add(this.rdbWindows);
            this.groupBox3.Controls.Add(this.rdbFavourites);
            this.groupBox3.Controls.Add(this.rdbCookies);
            this.groupBox3.Controls.Add(this.rdbSystem);
            this.groupBox3.Controls.Add(this.rdbHistory);
            this.groupBox3.Controls.Add(this.rdbAppData);
            this.groupBox3.Controls.Add(this.rdbMyMusic);
            this.groupBox3.Controls.Add(this.rdbSendTo);
            this.groupBox3.Controls.Add(this.rdbStartMenu);
            this.groupBox3.Controls.Add(this.rdbMyPrictures);
            this.groupBox3.Controls.Add(this.rdbRecent);
            this.groupBox3.Enabled = false;
            this.groupBox3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox3.Location = new System.Drawing.Point(6, 126);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(267, 95);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Location";
            // 
            // rdbMyDocuments
            // 
            this.rdbMyDocuments.AutoSize = true;
            this.rdbMyDocuments.Location = new System.Drawing.Point(78, 73);
            this.rdbMyDocuments.Name = "rdbMyDocuments";
            this.rdbMyDocuments.Size = new System.Drawing.Size(58, 16);
            this.rdbMyDocuments.TabIndex = 14;
            this.rdbMyDocuments.TabStop = true;
            this.rdbMyDocuments.Text = "MyDocs";
            this.rdbMyDocuments.UseVisualStyleBackColor = true;
            // 
            // rdbDesktop
            // 
            this.rdbDesktop.AutoSize = true;
            this.rdbDesktop.Location = new System.Drawing.Point(148, 54);
            this.rdbDesktop.Name = "rdbDesktop";
            this.rdbDesktop.Size = new System.Drawing.Size(58, 16);
            this.rdbDesktop.TabIndex = 13;
            this.rdbDesktop.TabStop = true;
            this.rdbDesktop.Text = "Desktop";
            this.rdbDesktop.UseVisualStyleBackColor = true;
            // 
            // rdbResources
            // 
            this.rdbResources.AutoSize = true;
            this.rdbResources.Location = new System.Drawing.Point(7, 34);
            this.rdbResources.Name = "rdbResources";
            this.rdbResources.Size = new System.Drawing.Size(68, 16);
            this.rdbResources.TabIndex = 12;
            this.rdbResources.TabStop = true;
            this.rdbResources.Text = "Resources";
            this.rdbResources.UseVisualStyleBackColor = true;
            // 
            // rdbProgramFiles
            // 
            this.rdbProgramFiles.AutoSize = true;
            this.rdbProgramFiles.Location = new System.Drawing.Point(148, 73);
            this.rdbProgramFiles.Name = "rdbProgramFiles";
            this.rdbProgramFiles.Size = new System.Drawing.Size(78, 16);
            this.rdbProgramFiles.TabIndex = 11;
            this.rdbProgramFiles.TabStop = true;
            this.rdbProgramFiles.Text = "ProgramFiles";
            this.rdbProgramFiles.UseVisualStyleBackColor = true;
            // 
            // rdbWindows
            // 
            this.rdbWindows.AutoSize = true;
            this.rdbWindows.Location = new System.Drawing.Point(7, 74);
            this.rdbWindows.Name = "rdbWindows";
            this.rdbWindows.Size = new System.Drawing.Size(60, 16);
            this.rdbWindows.TabIndex = 10;
            this.rdbWindows.TabStop = true;
            this.rdbWindows.Text = "Windows";
            this.rdbWindows.UseVisualStyleBackColor = true;
            // 
            // rdbFavourites
            // 
            this.rdbFavourites.AutoSize = true;
            this.rdbFavourites.Location = new System.Drawing.Point(78, 34);
            this.rdbFavourites.Name = "rdbFavourites";
            this.rdbFavourites.Size = new System.Drawing.Size(63, 16);
            this.rdbFavourites.TabIndex = 9;
            this.rdbFavourites.TabStop = true;
            this.rdbFavourites.Text = "Favorites";
            this.rdbFavourites.UseVisualStyleBackColor = true;
            // 
            // rdbCookies
            // 
            this.rdbCookies.AutoSize = true;
            this.rdbCookies.Location = new System.Drawing.Point(148, 34);
            this.rdbCookies.Name = "rdbCookies";
            this.rdbCookies.Size = new System.Drawing.Size(52, 16);
            this.rdbCookies.TabIndex = 8;
            this.rdbCookies.TabStop = true;
            this.rdbCookies.Text = "Cookie";
            this.rdbCookies.UseVisualStyleBackColor = true;
            // 
            // rdbSystem
            // 
            this.rdbSystem.AutoSize = true;
            this.rdbSystem.Location = new System.Drawing.Point(205, 54);
            this.rdbSystem.Name = "rdbSystem";
            this.rdbSystem.Size = new System.Drawing.Size(56, 16);
            this.rdbSystem.TabIndex = 7;
            this.rdbSystem.TabStop = true;
            this.rdbSystem.Text = "System";
            this.rdbSystem.UseVisualStyleBackColor = true;
            // 
            // rdbHistory
            // 
            this.rdbHistory.AutoSize = true;
            this.rdbHistory.Location = new System.Drawing.Point(148, 14);
            this.rdbHistory.Name = "rdbHistory";
            this.rdbHistory.Size = new System.Drawing.Size(54, 16);
            this.rdbHistory.TabIndex = 6;
            this.rdbHistory.TabStop = true;
            this.rdbHistory.Text = "History";
            this.rdbHistory.UseVisualStyleBackColor = true;
            // 
            // rdbAppData
            // 
            this.rdbAppData.AutoSize = true;
            this.rdbAppData.Location = new System.Drawing.Point(6, 14);
            this.rdbAppData.Name = "rdbAppData";
            this.rdbAppData.Size = new System.Drawing.Size(59, 16);
            this.rdbAppData.TabIndex = 5;
            this.rdbAppData.TabStop = true;
            this.rdbAppData.Text = "AppData";
            this.rdbAppData.UseVisualStyleBackColor = true;
            // 
            // rdbMyMusic
            // 
            this.rdbMyMusic.AutoSize = true;
            this.rdbMyMusic.Location = new System.Drawing.Point(78, 14);
            this.rdbMyMusic.Name = "rdbMyMusic";
            this.rdbMyMusic.Size = new System.Drawing.Size(60, 16);
            this.rdbMyMusic.TabIndex = 4;
            this.rdbMyMusic.TabStop = true;
            this.rdbMyMusic.Text = "MyMusic";
            this.rdbMyMusic.UseVisualStyleBackColor = true;
            // 
            // rdbSendTo
            // 
            this.rdbSendTo.AutoSize = true;
            this.rdbSendTo.Location = new System.Drawing.Point(206, 34);
            this.rdbSendTo.Name = "rdbSendTo";
            this.rdbSendTo.Size = new System.Drawing.Size(45, 16);
            this.rdbSendTo.TabIndex = 3;
            this.rdbSendTo.TabStop = true;
            this.rdbSendTo.Text = "Temp";
            this.rdbSendTo.UseVisualStyleBackColor = true;
            // 
            // rdbStartMenu
            // 
            this.rdbStartMenu.AutoSize = true;
            this.rdbStartMenu.Location = new System.Drawing.Point(79, 54);
            this.rdbStartMenu.Name = "rdbStartMenu";
            this.rdbStartMenu.Size = new System.Drawing.Size(65, 16);
            this.rdbStartMenu.TabIndex = 2;
            this.rdbStartMenu.TabStop = true;
            this.rdbStartMenu.Text = "StartMenu";
            this.rdbStartMenu.UseVisualStyleBackColor = true;
            // 
            // rdbMyPrictures
            // 
            this.rdbMyPrictures.AutoSize = true;
            this.rdbMyPrictures.Location = new System.Drawing.Point(7, 54);
            this.rdbMyPrictures.Name = "rdbMyPrictures";
            this.rdbMyPrictures.Size = new System.Drawing.Size(70, 16);
            this.rdbMyPrictures.TabIndex = 1;
            this.rdbMyPrictures.TabStop = true;
            this.rdbMyPrictures.Text = "MyPictures";
            this.rdbMyPrictures.UseVisualStyleBackColor = true;
            // 
            // rdbRecent
            // 
            this.rdbRecent.AutoSize = true;
            this.rdbRecent.Location = new System.Drawing.Point(206, 14);
            this.rdbRecent.Name = "rdbRecent";
            this.rdbRecent.Size = new System.Drawing.Size(53, 16);
            this.rdbRecent.TabIndex = 0;
            this.rdbRecent.TabStop = true;
            this.rdbRecent.Text = "Recent";
            this.rdbRecent.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label4);
            this.groupBox11.Controls.Add(this.label3);
            this.groupBox11.Controls.Add(this.txtActiveXKey);
            this.groupBox11.Controls.Add(this.label2);
            this.groupBox11.Controls.Add(this.RandActiveX);
            this.groupBox11.Controls.Add(this.deumosButton2);
            this.groupBox11.Controls.Add(this.textBoxStartup2);
            this.groupBox11.Controls.Add(this.txtFileNameSU);
            this.groupBox11.Controls.Add(this.txtSubFolder);
            this.groupBox11.Controls.Add(this.chckActiveX);
            this.groupBox11.Controls.Add(this.chckSubFolder);
            this.groupBox11.Controls.Add(this.rdbStart1);
            this.groupBox11.Controls.Add(this.rdbStart2);
            this.groupBox11.Controls.Add(this.chckSUp2);
            this.groupBox11.Location = new System.Drawing.Point(8, 30);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(263, 95);
            this.groupBox11.TabIndex = 0;
            this.groupBox11.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label4.Location = new System.Drawing.Point(134, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "Filename:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label3.Location = new System.Drawing.Point(5, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 12);
            this.label3.TabIndex = 18;
            this.label3.Text = "Key:";
            // 
            // txtActiveXKey
            // 
            this.txtActiveXKey.Location = new System.Drawing.Point(34, 72);
            this.txtActiveXKey.Name = "txtActiveXKey";
            this.txtActiveXKey.Size = new System.Drawing.Size(200, 18);
            this.txtActiveXKey.TabIndex = 17;
            this.txtActiveXKey.Text = "{f66f7f99-f445-569f-4bb3-47b35c6a33b5}";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label2.Location = new System.Drawing.Point(5, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 12);
            this.label2.TabIndex = 16;
            this.label2.Text = "Key:";
            // 
            // RandActiveX
            // 
            this.RandActiveX.Boolean_0 = false;
            this.RandActiveX.Boolean_1 = false;
            class063.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class063.String_0 = "Back";
            class064.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class064.String_0 = "DownGradient1";
            class065.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            class065.String_0 = "DownGradient2";
            class066.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class066.String_0 = "OverShine";
            class067.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class067.String_0 = "GlossGradient1";
            class068.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class068.String_0 = "GlossGradient2";
            class069.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            class069.String_0 = "Highlight1";
            class070.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class070.String_0 = "Highlight2";
            class071.Color_0 = System.Drawing.Color.Black;
            class071.String_0 = "Border";
            class072.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(16)))), ((int)(((byte)(16)))));
            class072.String_0 = "Corners";
            class073.Color_0 = System.Drawing.Color.White;
            class073.String_0 = "Text";
            this.RandActiveX.Class0_0 = new Cryptex1.Class0[] {
        class063,
        class064,
        class065,
        class066,
        class067,
        class068,
        class069,
        class070,
        class071,
        class072,
        class073};
            this.RandActiveX.Font = new System.Drawing.Font("Verdana", 8F);
            this.RandActiveX.Image_0 = null;
            this.RandActiveX.Location = new System.Drawing.Point(236, 72);
            this.RandActiveX.Name = "RandActiveX";
            this.RandActiveX.Size = new System.Drawing.Size(24, 19);
            this.RandActiveX.String_0 = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//////8=";
            this.RandActiveX.TabIndex = 15;
            this.RandActiveX.Text = "RandActiveX";
            this.RandActiveX.Click += new System.EventHandler(this.RandActiveX_Click);
            // 
            // deumosButton2
            // 
            this.deumosButton2.Boolean_0 = false;
            this.deumosButton2.Boolean_1 = false;
            class074.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class074.String_0 = "Back";
            class075.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class075.String_0 = "DownGradient1";
            class076.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(41)))), ((int)(((byte)(41)))));
            class076.String_0 = "DownGradient2";
            class077.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class077.String_0 = "OverShine";
            class078.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class078.String_0 = "GlossGradient1";
            class079.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class079.String_0 = "GlossGradient2";
            class080.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(62)))), ((int)(((byte)(62)))), ((int)(((byte)(62)))));
            class080.String_0 = "Highlight1";
            class081.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(15)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            class081.String_0 = "Highlight2";
            class082.Color_0 = System.Drawing.Color.Black;
            class082.String_0 = "Border";
            class083.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(16)))), ((int)(((byte)(16)))));
            class083.String_0 = "Corners";
            class084.Color_0 = System.Drawing.Color.White;
            class084.String_0 = "Text";
            this.deumosButton2.Class0_0 = new Cryptex1.Class0[] {
        class074,
        class075,
        class076,
        class077,
        class078,
        class079,
        class080,
        class081,
        class082,
        class083,
        class084};
            this.deumosButton2.Font = new System.Drawing.Font("Verdana", 8F);
            this.deumosButton2.Image_0 = null;
            this.deumosButton2.Location = new System.Drawing.Point(235, 13);
            this.deumosButton2.Name = "deumosButton2";
            this.deumosButton2.Size = new System.Drawing.Size(25, 19);
            this.deumosButton2.String_0 = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//////8=";
            this.deumosButton2.TabIndex = 14;
            this.deumosButton2.Text = "Rnd";
            this.deumosButton2.Click += new System.EventHandler(this.deumosButton2_Click);
            // 
            // textBoxStartup2
            // 
            this.textBoxStartup2.Boolean_0 = false;
            this.textBoxStartup2.Boolean_1 = false;
            this.textBoxStartup2.Boolean_2 = false;
            this.textBoxStartup2.Boolean_3 = false;
            this.textBoxStartup2.Boolean_4 = false;
            class085.Color_0 = System.Drawing.Color.White;
            class085.String_0 = "Text";
            class086.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class086.String_0 = "Back";
            class087.Color_0 = System.Drawing.Color.Black;
            class087.String_0 = "Border1";
            class088.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class088.String_0 = "Border2";
            this.textBoxStartup2.Class0_0 = new Cryptex1.Class0[] {
        class085,
        class086,
        class087,
        class088};
            this.textBoxStartup2.Enabled = false;
            this.textBoxStartup2.Font = new System.Drawing.Font("Verdana", 8F);
            this.textBoxStartup2.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.textBoxStartup2.Image_0 = null;
            this.textBoxStartup2.Int32_2 = 32767;
            this.textBoxStartup2.Location = new System.Drawing.Point(30, 35);
            this.textBoxStartup2.Name = "textBoxStartup2";
            this.textBoxStartup2.Size = new System.Drawing.Size(98, 24);
            this.textBoxStartup2.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.textBoxStartup2.TabIndex = 13;
            this.textBoxStartup2.Text = "MSE";
            // 
            // txtFileNameSU
            // 
            this.txtFileNameSU.Boolean_0 = false;
            this.txtFileNameSU.Boolean_1 = false;
            this.txtFileNameSU.Boolean_2 = false;
            this.txtFileNameSU.Boolean_3 = false;
            this.txtFileNameSU.Boolean_4 = false;
            class089.Color_0 = System.Drawing.Color.White;
            class089.String_0 = "Text";
            class090.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class090.String_0 = "Back";
            class091.Color_0 = System.Drawing.Color.Black;
            class091.String_0 = "Border1";
            class092.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class092.String_0 = "Border2";
            this.txtFileNameSU.Class0_0 = new Cryptex1.Class0[] {
        class089,
        class090,
        class091,
        class092};
            this.txtFileNameSU.Enabled = false;
            this.txtFileNameSU.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtFileNameSU.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtFileNameSU.Image_0 = null;
            this.txtFileNameSU.Int32_2 = 32767;
            this.txtFileNameSU.Location = new System.Drawing.Point(188, 33);
            this.txtFileNameSU.Name = "txtFileNameSU";
            this.txtFileNameSU.Size = new System.Drawing.Size(69, 24);
            this.txtFileNameSU.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtFileNameSU.TabIndex = 12;
            this.txtFileNameSU.Text = "javaw.exe";
            // 
            // txtSubFolder
            // 
            this.txtSubFolder.Boolean_0 = false;
            this.txtSubFolder.Boolean_1 = false;
            this.txtSubFolder.Boolean_2 = false;
            this.txtSubFolder.Boolean_3 = false;
            this.txtSubFolder.Boolean_4 = false;
            class093.Color_0 = System.Drawing.Color.White;
            class093.String_0 = "Text";
            class094.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class094.String_0 = "Back";
            class095.Color_0 = System.Drawing.Color.Black;
            class095.String_0 = "Border1";
            class096.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class096.String_0 = "Border2";
            this.txtSubFolder.Class0_0 = new Cryptex1.Class0[] {
        class093,
        class094,
        class095,
        class096};
            this.txtSubFolder.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtSubFolder.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtSubFolder.Image_0 = null;
            this.txtSubFolder.Int32_2 = 32767;
            this.txtSubFolder.Location = new System.Drawing.Point(165, 9);
            this.txtSubFolder.Name = "txtSubFolder";
            this.txtSubFolder.Size = new System.Drawing.Size(69, 24);
            this.txtSubFolder.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtSubFolder.TabIndex = 11;
            // 
            // chckActiveX
            // 
            this.chckActiveX.AutoSize = true;
            this.chckActiveX.Enabled = false;
            this.chckActiveX.Location = new System.Drawing.Point(7, 58);
            this.chckActiveX.Name = "chckActiveX";
            this.chckActiveX.Size = new System.Drawing.Size(76, 16);
            this.chckActiveX.TabIndex = 8;
            this.chckActiveX.Text = "chckActiveX";
            this.chckActiveX.UseVisualStyleBackColor = true;
            // 
            // chckSubFolder
            // 
            this.chckSubFolder.AutoSize = true;
            this.chckSubFolder.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.chckSubFolder.Location = new System.Drawing.Point(93, 14);
            this.chckSubFolder.Name = "chckSubFolder";
            this.chckSubFolder.Size = new System.Drawing.Size(66, 16);
            this.chckSubFolder.TabIndex = 3;
            this.chckSubFolder.Text = "SubFolder";
            this.chckSubFolder.UseVisualStyleBackColor = true;
            this.chckSubFolder.CheckedChanged += new System.EventHandler(this.chckSubFolder_CheckedChanged);
            // 
            // rdbStart1
            // 
            this.rdbStart1.AutoSize = true;
            this.rdbStart1.Enabled = false;
            this.rdbStart1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbStart1.Location = new System.Drawing.Point(6, 15);
            this.rdbStart1.Name = "rdbStart1";
            this.rdbStart1.Size = new System.Drawing.Size(33, 16);
            this.rdbStart1.TabIndex = 2;
            this.rdbStart1.TabStop = true;
            this.rdbStart1.Text = "#1";
            this.rdbStart1.UseVisualStyleBackColor = true;
            // 
            // rdbStart2
            // 
            this.rdbStart2.AutoSize = true;
            this.rdbStart2.Enabled = false;
            this.rdbStart2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbStart2.Location = new System.Drawing.Point(49, 15);
            this.rdbStart2.Name = "rdbStart2";
            this.rdbStart2.Size = new System.Drawing.Size(33, 16);
            this.rdbStart2.TabIndex = 1;
            this.rdbStart2.TabStop = true;
            this.rdbStart2.Text = "#2";
            this.rdbStart2.UseVisualStyleBackColor = true;
            // 
            // chckSUp2
            // 
            this.chckSUp2.AutoSize = true;
            this.chckSUp2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.chckSUp2.Location = new System.Drawing.Point(30, -1);
            this.chckSUp2.Name = "chckSUp2";
            this.chckSUp2.Size = new System.Drawing.Size(54, 16);
            this.chckSUp2.TabIndex = 0;
            this.chckSUp2.Text = "On/Off";
            this.chckSUp2.UseVisualStyleBackColor = true;
            this.chckSUp2.CheckedChanged += new System.EventHandler(this.chckSUp2_CheckedChanged);
            // 
            // txtBindFile
            // 
            this.txtBindFile.Location = new System.Drawing.Point(27, 456);
            this.txtBindFile.Name = "txtBindFile";
            this.txtBindFile.Size = new System.Drawing.Size(22, 20);
            this.txtBindFile.TabIndex = 38;
            this.txtBindFile.Text = "txtBindFile";
            this.txtBindFile.Visible = false;
            // 
            // rdbVBC
            // 
            this.rdbVBC.AutoSize = true;
            this.rdbVBC.Location = new System.Drawing.Point(93, 451);
            this.rdbVBC.Name = "rdbVBC";
            this.rdbVBC.Size = new System.Drawing.Size(46, 17);
            this.rdbVBC.TabIndex = 37;
            this.rdbVBC.TabStop = true;
            this.rdbVBC.Text = "VBC";
            this.rdbVBC.UseVisualStyleBackColor = true;
            // 
            // radioCSC
            // 
            this.radioCSC.AutoSize = true;
            this.radioCSC.Location = new System.Drawing.Point(98, 428);
            this.radioCSC.Name = "radioCSC";
            this.radioCSC.Size = new System.Drawing.Size(69, 17);
            this.radioCSC.TabIndex = 36;
            this.radioCSC.TabStop = true;
            this.radioCSC.Text = "radioCSC";
            this.radioCSC.UseVisualStyleBackColor = true;
            // 
            // radioBtnCustom
            // 
            this.radioBtnCustom.AutoSize = true;
            this.radioBtnCustom.Location = new System.Drawing.Point(98, 474);
            this.radioBtnCustom.Name = "radioBtnCustom";
            this.radioBtnCustom.Size = new System.Drawing.Size(63, 17);
            this.radioBtnCustom.TabIndex = 35;
            this.radioBtnCustom.TabStop = true;
            this.radioBtnCustom.Text = "Custom:";
            this.radioBtnCustom.UseVisualStyleBackColor = true;
            // 
            // chckHideFile
            // 
            this.chckHideFile.AutoSize = true;
            this.chckHideFile.Location = new System.Drawing.Point(19, 372);
            this.chckHideFile.Name = "chckHideFile";
            this.chckHideFile.Size = new System.Drawing.Size(67, 17);
            this.chckHideFile.TabIndex = 34;
            this.chckHideFile.Text = "Hide File";
            this.chckHideFile.UseVisualStyleBackColor = true;
            // 
            // rdbMeth1
            // 
            this.rdbMeth1.AutoSize = true;
            this.rdbMeth1.Location = new System.Drawing.Point(145, 409);
            this.rdbMeth1.Name = "rdbMeth1";
            this.rdbMeth1.Size = new System.Drawing.Size(70, 17);
            this.rdbMeth1.TabIndex = 33;
            this.rdbMeth1.TabStop = true;
            this.rdbMeth1.Text = "rdbMeth1";
            this.rdbMeth1.UseVisualStyleBackColor = true;
            // 
            // btnCrypt
            // 
            this.btnCrypt.Boolean_0 = false;
            this.btnCrypt.Image_0 = null;
            this.btnCrypt.Location = new System.Drawing.Point(323, 273);
            this.btnCrypt.Name = "btnCrypt";
            this.btnCrypt.Size = new System.Drawing.Size(47, 65);
            this.btnCrypt.TabIndex = 32;
            this.btnCrypt.Text = "Crypt";
            this.btnCrypt.Click += new System.EventHandler(this.btnCrypt_Click);
            // 
            // txt111
            // 
            this.txt111.Boolean_0 = false;
            this.txt111.Boolean_1 = false;
            this.txt111.Boolean_2 = false;
            this.txt111.Boolean_3 = false;
            this.txt111.Boolean_4 = false;
            class097.Color_0 = System.Drawing.Color.White;
            class097.String_0 = "Text";
            class098.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class098.String_0 = "Back";
            class099.Color_0 = System.Drawing.Color.Black;
            class099.String_0 = "Border1";
            class0100.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0100.String_0 = "Border2";
            this.txt111.Class0_0 = new Cryptex1.Class0[] {
        class097,
        class098,
        class099,
        class0100};
            this.txt111.Font = new System.Drawing.Font("Verdana", 8F);
            this.txt111.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txt111.Image_0 = null;
            this.txt111.Int32_2 = 32767;
            this.txt111.Location = new System.Drawing.Point(258, 384);
            this.txt111.Name = "txt111";
            this.txt111.Size = new System.Drawing.Size(110, 24);
            this.txt111.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txt111.TabIndex = 31;
            // 
            // txtInformation
            // 
            this.txtInformation.Boolean_0 = false;
            this.txtInformation.Boolean_1 = false;
            this.txtInformation.Boolean_2 = true;
            this.txtInformation.Boolean_3 = false;
            this.txtInformation.Boolean_4 = true;
            class0101.Color_0 = System.Drawing.Color.White;
            class0101.String_0 = "Text";
            class0102.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0102.String_0 = "Back";
            class0103.Color_0 = System.Drawing.Color.Black;
            class0103.String_0 = "Border1";
            class0104.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0104.String_0 = "Border2";
            this.txtInformation.Class0_0 = new Cryptex1.Class0[] {
        class0101,
        class0102,
        class0103,
        class0104};
            this.txtInformation.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInformation.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtInformation.Image_0 = null;
            this.txtInformation.Int32_2 = 32767;
            this.txtInformation.Location = new System.Drawing.Point(373, 46);
            this.txtInformation.Name = "txtInformation";
            this.txtInformation.Size = new System.Drawing.Size(146, 292);
            this.txtInformation.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtInformation.TabIndex = 30;
            // 
            // txtIcon
            // 
            this.txtIcon.Location = new System.Drawing.Point(27, 406);
            this.txtIcon.Name = "txtIcon";
            this.txtIcon.Size = new System.Drawing.Size(22, 20);
            this.txtIcon.TabIndex = 28;
            // 
            // b12
            // 
            this.b12.Boolean_0 = false;
            this.b12.Image_0 = null;
            this.b12.Location = new System.Drawing.Point(7, 115);
            this.b12.Name = "b12";
            this.b12.Size = new System.Drawing.Size(75, 21);
            this.b12.TabIndex = 27;
            this.b12.Text = "Disposition";
            // 
            // b11
            // 
            this.b11.Boolean_0 = false;
            this.b11.Image_0 = null;
            this.b11.Location = new System.Drawing.Point(7, 234);
            this.b11.Name = "b11";
            this.b11.Size = new System.Drawing.Size(75, 21);
            this.b11.TabIndex = 26;
            this.b11.Text = "Anties";
            // 
            // b10
            // 
            this.b10.Boolean_0 = false;
            this.b10.Image_0 = null;
            this.b10.Location = new System.Drawing.Point(7, 75);
            this.b10.Name = "b10";
            this.b10.Size = new System.Drawing.Size(75, 21);
            this.b10.TabIndex = 25;
            this.b10.Text = "Enc.#2";
            // 
            // b2
            // 
            this.b2.Boolean_0 = false;
            this.b2.Image_0 = null;
            this.b2.Location = new System.Drawing.Point(7, 194);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(75, 23);
            this.b2.TabIndex = 24;
            this.b2.Text = "Binder";
            // 
            // b6
            // 
            this.b6.Boolean_0 = false;
            this.b6.Image_0 = null;
            this.b6.Location = new System.Drawing.Point(7, 214);
            this.b6.Name = "b6";
            this.b6.Size = new System.Drawing.Size(75, 21);
            this.b6.TabIndex = 23;
            this.b6.Text = "Assembly";
            // 
            // b3
            // 
            this.b3.Boolean_0 = false;
            this.b3.Image_0 = null;
            this.b3.Location = new System.Drawing.Point(7, 135);
            this.b3.Name = "b3";
            this.b3.Size = new System.Drawing.Size(75, 23);
            this.b3.TabIndex = 22;
            this.b3.Text = "USG";
            // 
            // b4
            // 
            this.b4.Boolean_0 = false;
            this.b4.Image_0 = null;
            this.b4.Location = new System.Drawing.Point(7, 175);
            this.b4.Name = "b4";
            this.b4.Size = new System.Drawing.Size(75, 23);
            this.b4.TabIndex = 21;
            this.b4.Text = "Download";
            // 
            // b7
            // 
            this.b7.Boolean_0 = false;
            this.b7.Image_0 = null;
            this.b7.Location = new System.Drawing.Point(7, 97);
            this.b7.Name = "b7";
            this.b7.Size = new System.Drawing.Size(75, 21);
            this.b7.TabIndex = 20;
            this.b7.Text = "Stratup";
            // 
            // b8
            // 
            this.b8.Boolean_0 = false;
            this.b8.Image_0 = null;
            this.b8.Location = new System.Drawing.Point(7, 55);
            this.b8.Name = "b8";
            this.b8.Size = new System.Drawing.Size(75, 21);
            this.b8.TabIndex = 19;
            this.b8.Text = "Enc.#1";
            // 
            // b9
            // 
            this.b9.Boolean_0 = false;
            this.b9.Image_0 = null;
            this.b9.Location = new System.Drawing.Point(7, 155);
            this.b9.Name = "b9";
            this.b9.Size = new System.Drawing.Size(75, 21);
            this.b9.TabIndex = 18;
            this.b9.Text = "Opt.#2";
            // 
            // b1
            // 
            this.b1.Boolean_0 = false;
            this.b1.Image_0 = null;
            this.b1.Location = new System.Drawing.Point(7, 35);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(75, 23);
            this.b1.TabIndex = 17;
            this.b1.Text = "Main";
            // 
            // pan6
            // 
            this.pan6.Controls.Add(this.deumosGroupBox6);
            this.pan6.Location = new System.Drawing.Point(3, 511);
            this.pan6.Name = "pan6";
            this.pan6.Size = new System.Drawing.Size(281, 233);
            this.pan6.TabIndex = 15;
            this.pan6.Visible = false;
            // 
            // deumosGroupBox6
            // 
            this.deumosGroupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox6.Boolean_0 = true;
            this.deumosGroupBox6.Boolean_1 = true;
            this.deumosGroupBox6.Boolean_3 = false;
            class0105.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0105.String_0 = "Back";
            class0106.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0106.String_0 = "MainFill";
            class0107.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0107.String_0 = "MainOutline1";
            class0108.Color_0 = System.Drawing.Color.Black;
            class0108.String_0 = "MainOutline2";
            class0109.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0109.String_0 = "TitleShadow";
            class0110.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0110.String_0 = "TitleFill";
            class0111.Color_0 = System.Drawing.Color.White;
            class0111.String_0 = "Text";
            class0112.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0112.String_0 = "TitleOutline1";
            class0113.Color_0 = System.Drawing.Color.Black;
            class0113.String_0 = "TitleOutline2";
            this.deumosGroupBox6.Class0_0 = new Cryptex1.Class0[] {
        class0105,
        class0106,
        class0107,
        class0108,
        class0109,
        class0110,
        class0111,
        class0112,
        class0113};
            this.deumosGroupBox6.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox6.Controls.Add(this.groupBox9);
            this.deumosGroupBox6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox6.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox6.Image_0 = null;
            this.deumosGroupBox6.Location = new System.Drawing.Point(3, 3);
            this.deumosGroupBox6.Name = "deumosGroupBox6";
            this.deumosGroupBox6.Size = new System.Drawing.Size(270, 225);
            this.deumosGroupBox6.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox6.TabIndex = 14;
            this.deumosGroupBox6.Text = "Assembly";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.intRevision);
            this.groupBox9.Controls.Add(this.intBuild);
            this.groupBox9.Controls.Add(this.intMinor);
            this.groupBox9.Controls.Add(this.intMajor);
            this.groupBox9.Controls.Add(this.AssemblyLenght);
            this.groupBox9.Controls.Add(this.muButton14);
            this.groupBox9.Controls.Add(this.muButton11);
            this.groupBox9.Controls.Add(this.txtAssemblyTitle);
            this.groupBox9.Controls.Add(this.textAssemblyDescription);
            this.groupBox9.Controls.Add(this.textAssemblyCompany);
            this.groupBox9.Controls.Add(this.textAssemblyProduct);
            this.groupBox9.Controls.Add(this.textAssemblyCopyRight);
            this.groupBox9.Controls.Add(this.chckAssembly);
            this.groupBox9.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox9.Location = new System.Drawing.Point(8, 31);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(262, 192);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "    Custom Assembly";
            // 
            // intRevision
            // 
            this.intRevision.Enabled = false;
            this.intRevision.Location = new System.Drawing.Point(140, 140);
            this.intRevision.Name = "intRevision";
            this.intRevision.Size = new System.Drawing.Size(34, 20);
            this.intRevision.TabIndex = 12;
            // 
            // intBuild
            // 
            this.intBuild.Enabled = false;
            this.intBuild.Location = new System.Drawing.Point(100, 140);
            this.intBuild.Name = "intBuild";
            this.intBuild.Size = new System.Drawing.Size(34, 20);
            this.intBuild.TabIndex = 11;
            // 
            // intMinor
            // 
            this.intMinor.Enabled = false;
            this.intMinor.Location = new System.Drawing.Point(58, 140);
            this.intMinor.Name = "intMinor";
            this.intMinor.Size = new System.Drawing.Size(34, 20);
            this.intMinor.TabIndex = 10;
            // 
            // intMajor
            // 
            this.intMajor.Enabled = false;
            this.intMajor.Location = new System.Drawing.Point(16, 140);
            this.intMajor.Name = "intMajor";
            this.intMajor.Size = new System.Drawing.Size(34, 20);
            this.intMajor.TabIndex = 9;
            // 
            // AssemblyLenght
            // 
            this.AssemblyLenght.Enabled = false;
            this.AssemblyLenght.Location = new System.Drawing.Point(224, 140);
            this.AssemblyLenght.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.AssemblyLenght.Minimum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.AssemblyLenght.Name = "AssemblyLenght";
            this.AssemblyLenght.Size = new System.Drawing.Size(32, 20);
            this.AssemblyLenght.TabIndex = 8;
            this.AssemblyLenght.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // muButton14
            // 
            this.muButton14.Boolean_0 = false;
            this.muButton14.Image_0 = null;
            this.muButton14.Location = new System.Drawing.Point(13, 164);
            this.muButton14.Name = "muButton14";
            this.muButton14.Size = new System.Drawing.Size(112, 25);
            this.muButton14.TabIndex = 7;
            this.muButton14.Text = "Clone";
            this.muButton14.Click += new System.EventHandler(this.muButton14_Click);
            // 
            // muButton11
            // 
            this.muButton11.Boolean_0 = false;
            this.muButton11.Enabled = false;
            this.muButton11.Image_0 = null;
            this.muButton11.Location = new System.Drawing.Point(191, 18);
            this.muButton11.Name = "muButton11";
            this.muButton11.Size = new System.Drawing.Size(62, 116);
            this.muButton11.TabIndex = 6;
            this.muButton11.Text = "Rnd";
            this.muButton11.Click += new System.EventHandler(this.muButton11_Click);
            // 
            // txtAssemblyTitle
            // 
            this.txtAssemblyTitle.Boolean_0 = false;
            this.txtAssemblyTitle.Boolean_1 = false;
            this.txtAssemblyTitle.Boolean_2 = false;
            this.txtAssemblyTitle.Boolean_3 = false;
            this.txtAssemblyTitle.Boolean_4 = false;
            class0114.Color_0 = System.Drawing.Color.White;
            class0114.String_0 = "Text";
            class0115.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0115.String_0 = "Back";
            class0116.Color_0 = System.Drawing.Color.Black;
            class0116.String_0 = "Border1";
            class0117.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0117.String_0 = "Border2";
            this.txtAssemblyTitle.Class0_0 = new Cryptex1.Class0[] {
        class0114,
        class0115,
        class0116,
        class0117};
            this.txtAssemblyTitle.Enabled = false;
            this.txtAssemblyTitle.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtAssemblyTitle.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtAssemblyTitle.Image_0 = null;
            this.txtAssemblyTitle.Int32_2 = 32767;
            this.txtAssemblyTitle.Location = new System.Drawing.Point(16, 18);
            this.txtAssemblyTitle.Name = "txtAssemblyTitle";
            this.txtAssemblyTitle.Size = new System.Drawing.Size(159, 24);
            this.txtAssemblyTitle.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtAssemblyTitle.TabIndex = 5;
            this.txtAssemblyTitle.Text = "Title";
            // 
            // textAssemblyDescription
            // 
            this.textAssemblyDescription.Boolean_0 = false;
            this.textAssemblyDescription.Boolean_1 = false;
            this.textAssemblyDescription.Boolean_2 = false;
            this.textAssemblyDescription.Boolean_3 = false;
            this.textAssemblyDescription.Boolean_4 = false;
            class0118.Color_0 = System.Drawing.Color.White;
            class0118.String_0 = "Text";
            class0119.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0119.String_0 = "Back";
            class0120.Color_0 = System.Drawing.Color.Black;
            class0120.String_0 = "Border1";
            class0121.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0121.String_0 = "Border2";
            this.textAssemblyDescription.Class0_0 = new Cryptex1.Class0[] {
        class0118,
        class0119,
        class0120,
        class0121};
            this.textAssemblyDescription.Enabled = false;
            this.textAssemblyDescription.Font = new System.Drawing.Font("Verdana", 8F);
            this.textAssemblyDescription.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.textAssemblyDescription.Image_0 = null;
            this.textAssemblyDescription.Int32_2 = 32767;
            this.textAssemblyDescription.Location = new System.Drawing.Point(16, 39);
            this.textAssemblyDescription.Name = "textAssemblyDescription";
            this.textAssemblyDescription.Size = new System.Drawing.Size(159, 24);
            this.textAssemblyDescription.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.textAssemblyDescription.TabIndex = 4;
            this.textAssemblyDescription.Text = "Description";
            // 
            // textAssemblyCompany
            // 
            this.textAssemblyCompany.Boolean_0 = false;
            this.textAssemblyCompany.Boolean_1 = false;
            this.textAssemblyCompany.Boolean_2 = false;
            this.textAssemblyCompany.Boolean_3 = false;
            this.textAssemblyCompany.Boolean_4 = false;
            class0122.Color_0 = System.Drawing.Color.White;
            class0122.String_0 = "Text";
            class0123.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0123.String_0 = "Back";
            class0124.Color_0 = System.Drawing.Color.Black;
            class0124.String_0 = "Border1";
            class0125.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0125.String_0 = "Border2";
            this.textAssemblyCompany.Class0_0 = new Cryptex1.Class0[] {
        class0122,
        class0123,
        class0124,
        class0125};
            this.textAssemblyCompany.Enabled = false;
            this.textAssemblyCompany.Font = new System.Drawing.Font("Verdana", 8F);
            this.textAssemblyCompany.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.textAssemblyCompany.Image_0 = null;
            this.textAssemblyCompany.Int32_2 = 32767;
            this.textAssemblyCompany.Location = new System.Drawing.Point(16, 61);
            this.textAssemblyCompany.Name = "textAssemblyCompany";
            this.textAssemblyCompany.Size = new System.Drawing.Size(159, 24);
            this.textAssemblyCompany.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.textAssemblyCompany.TabIndex = 3;
            this.textAssemblyCompany.Text = "Company";
            // 
            // textAssemblyProduct
            // 
            this.textAssemblyProduct.Boolean_0 = false;
            this.textAssemblyProduct.Boolean_1 = false;
            this.textAssemblyProduct.Boolean_2 = false;
            this.textAssemblyProduct.Boolean_3 = false;
            this.textAssemblyProduct.Boolean_4 = false;
            class0126.Color_0 = System.Drawing.Color.White;
            class0126.String_0 = "Text";
            class0127.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0127.String_0 = "Back";
            class0128.Color_0 = System.Drawing.Color.Black;
            class0128.String_0 = "Border1";
            class0129.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0129.String_0 = "Border2";
            this.textAssemblyProduct.Class0_0 = new Cryptex1.Class0[] {
        class0126,
        class0127,
        class0128,
        class0129};
            this.textAssemblyProduct.Enabled = false;
            this.textAssemblyProduct.Font = new System.Drawing.Font("Verdana", 8F);
            this.textAssemblyProduct.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.textAssemblyProduct.Image_0 = null;
            this.textAssemblyProduct.Int32_2 = 32767;
            this.textAssemblyProduct.Location = new System.Drawing.Point(16, 84);
            this.textAssemblyProduct.Name = "textAssemblyProduct";
            this.textAssemblyProduct.Size = new System.Drawing.Size(159, 24);
            this.textAssemblyProduct.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.textAssemblyProduct.TabIndex = 2;
            this.textAssemblyProduct.Text = "Product";
            // 
            // textAssemblyCopyRight
            // 
            this.textAssemblyCopyRight.Boolean_0 = false;
            this.textAssemblyCopyRight.Boolean_1 = false;
            this.textAssemblyCopyRight.Boolean_2 = false;
            this.textAssemblyCopyRight.Boolean_3 = false;
            this.textAssemblyCopyRight.Boolean_4 = false;
            class0130.Color_0 = System.Drawing.Color.White;
            class0130.String_0 = "Text";
            class0131.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0131.String_0 = "Back";
            class0132.Color_0 = System.Drawing.Color.Black;
            class0132.String_0 = "Border1";
            class0133.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0133.String_0 = "Border2";
            this.textAssemblyCopyRight.Class0_0 = new Cryptex1.Class0[] {
        class0130,
        class0131,
        class0132,
        class0133};
            this.textAssemblyCopyRight.Enabled = false;
            this.textAssemblyCopyRight.Font = new System.Drawing.Font("Verdana", 8F);
            this.textAssemblyCopyRight.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.textAssemblyCopyRight.Image_0 = null;
            this.textAssemblyCopyRight.Int32_2 = 32767;
            this.textAssemblyCopyRight.Location = new System.Drawing.Point(16, 107);
            this.textAssemblyCopyRight.Name = "textAssemblyCopyRight";
            this.textAssemblyCopyRight.Size = new System.Drawing.Size(159, 24);
            this.textAssemblyCopyRight.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.textAssemblyCopyRight.TabIndex = 1;
            this.textAssemblyCopyRight.Text = "Copyright";
            // 
            // chckAssembly
            // 
            this.chckAssembly.AutoSize = true;
            this.chckAssembly.Location = new System.Drawing.Point(5, -1);
            this.chckAssembly.Name = "chckAssembly";
            this.chckAssembly.Size = new System.Drawing.Size(15, 14);
            this.chckAssembly.TabIndex = 0;
            this.chckAssembly.UseVisualStyleBackColor = true;
            this.chckAssembly.CheckedChanged += new System.EventHandler(this.chckAssembly_CheckedChanged);
            // 
            // pan2
            // 
            this.pan2.Controls.Add(this.deumosGroupBox2);
            this.pan2.Location = new System.Drawing.Point(531, 33);
            this.pan2.Name = "pan2";
            this.pan2.Size = new System.Drawing.Size(281, 225);
            this.pan2.TabIndex = 13;
            this.pan2.Visible = false;
            // 
            // deumosGroupBox2
            // 
            this.deumosGroupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox2.Boolean_0 = true;
            this.deumosGroupBox2.Boolean_1 = true;
            this.deumosGroupBox2.Boolean_3 = false;
            class0134.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0134.String_0 = "Back";
            class0135.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0135.String_0 = "MainFill";
            class0136.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0136.String_0 = "MainOutline1";
            class0137.Color_0 = System.Drawing.Color.Black;
            class0137.String_0 = "MainOutline2";
            class0138.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0138.String_0 = "TitleShadow";
            class0139.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0139.String_0 = "TitleFill";
            class0140.Color_0 = System.Drawing.Color.White;
            class0140.String_0 = "Text";
            class0141.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0141.String_0 = "TitleOutline1";
            class0142.Color_0 = System.Drawing.Color.Black;
            class0142.String_0 = "TitleOutline2";
            this.deumosGroupBox2.Class0_0 = new Cryptex1.Class0[] {
        class0134,
        class0135,
        class0136,
        class0137,
        class0138,
        class0139,
        class0140,
        class0141,
        class0142};
            this.deumosGroupBox2.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox2.Controls.Add(this.groupBox24);
            this.deumosGroupBox2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox2.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox2.Image_0 = null;
            this.deumosGroupBox2.Location = new System.Drawing.Point(3, 3);
            this.deumosGroupBox2.Name = "deumosGroupBox2";
            this.deumosGroupBox2.Size = new System.Drawing.Size(268, 199);
            this.deumosGroupBox2.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox2.TabIndex = 0;
            this.deumosGroupBox2.Text = "Binder";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.muButton5);
            this.groupBox24.Controls.Add(this.muButton4);
            this.groupBox24.Controls.Add(this.lstBind);
            this.groupBox24.Controls.Add(this.muButton15);
            this.groupBox24.Controls.Add(this.groupBox25);
            this.groupBox24.Controls.Add(this.checkBox13);
            this.groupBox24.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox24.Location = new System.Drawing.Point(12, 32);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(248, 159);
            this.groupBox24.TabIndex = 0;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Binder";
            // 
            // muButton5
            // 
            this.muButton5.Boolean_0 = false;
            this.muButton5.Image_0 = null;
            this.muButton5.Location = new System.Drawing.Point(13, 100);
            this.muButton5.Name = "muButton5";
            this.muButton5.Size = new System.Drawing.Size(65, 23);
            this.muButton5.TabIndex = 5;
            this.muButton5.Text = "Clear";
            this.muButton5.Click += new System.EventHandler(this.muButton5_Click);
            // 
            // muButton4
            // 
            this.muButton4.Boolean_0 = false;
            this.muButton4.Image_0 = null;
            this.muButton4.Location = new System.Drawing.Point(162, 100);
            this.muButton4.Name = "muButton4";
            this.muButton4.Size = new System.Drawing.Size(71, 23);
            this.muButton4.TabIndex = 4;
            this.muButton4.Text = "Add File";
            this.muButton4.Click += new System.EventHandler(this.muButton4_Click);
            // 
            // lstBind
            // 
            this.lstBind.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.lstBind.FormattingEnabled = true;
            this.lstBind.ItemHeight = 14;
            this.lstBind.Location = new System.Drawing.Point(6, 16);
            this.lstBind.Name = "lstBind";
            this.lstBind.Size = new System.Drawing.Size(236, 60);
            this.lstBind.TabIndex = 3;
            // 
            // muButton15
            // 
            this.muButton15.Boolean_0 = false;
            this.muButton15.Image_0 = null;
            this.muButton15.Location = new System.Drawing.Point(89, 100);
            this.muButton15.Name = "muButton15";
            this.muButton15.Size = new System.Drawing.Size(65, 23);
            this.muButton15.TabIndex = 2;
            this.muButton15.Text = "Clear All";
            this.muButton15.Click += new System.EventHandler(this.muButton15_Click);
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.rdbBindStart);
            this.groupBox25.Controls.Add(this.radioButton93);
            this.groupBox25.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox25.Location = new System.Drawing.Point(6, 123);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(107, 30);
            this.groupBox25.TabIndex = 1;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Run On:";
            // 
            // rdbBindStart
            // 
            this.rdbBindStart.AutoSize = true;
            this.rdbBindStart.Location = new System.Drawing.Point(7, 11);
            this.rdbBindStart.Name = "rdbBindStart";
            this.rdbBindStart.Size = new System.Drawing.Size(48, 18);
            this.rdbBindStart.TabIndex = 1;
            this.rdbBindStart.Text = "Start";
            this.rdbBindStart.UseVisualStyleBackColor = true;
            // 
            // radioButton93
            // 
            this.radioButton93.AutoSize = true;
            this.radioButton93.Checked = true;
            this.radioButton93.Location = new System.Drawing.Point(57, 11);
            this.radioButton93.Name = "radioButton93";
            this.radioButton93.Size = new System.Drawing.Size(43, 18);
            this.radioButton93.TabIndex = 0;
            this.radioButton93.TabStop = true;
            this.radioButton93.Text = "End";
            this.radioButton93.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(119, 134);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(122, 18);
            this.checkBox13.TabIndex = 0;
            this.checkBox13.Text = "One-Time Execution";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // pan10
            // 
            this.pan10.Controls.Add(this.deumosGroupBox10);
            this.pan10.Location = new System.Drawing.Point(1113, 27);
            this.pan10.Name = "pan10";
            this.pan10.Size = new System.Drawing.Size(277, 234);
            this.pan10.TabIndex = 12;
            this.pan10.Visible = false;
            // 
            // deumosGroupBox10
            // 
            this.deumosGroupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox10.Boolean_0 = true;
            this.deumosGroupBox10.Boolean_1 = true;
            this.deumosGroupBox10.Boolean_3 = false;
            class0143.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0143.String_0 = "Back";
            class0144.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0144.String_0 = "MainFill";
            class0145.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0145.String_0 = "MainOutline1";
            class0146.Color_0 = System.Drawing.Color.Black;
            class0146.String_0 = "MainOutline2";
            class0147.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0147.String_0 = "TitleShadow";
            class0148.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0148.String_0 = "TitleFill";
            class0149.Color_0 = System.Drawing.Color.White;
            class0149.String_0 = "Text";
            class0150.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0150.String_0 = "TitleOutline1";
            class0151.Color_0 = System.Drawing.Color.Black;
            class0151.String_0 = "TitleOutline2";
            this.deumosGroupBox10.Class0_0 = new Cryptex1.Class0[] {
        class0143,
        class0144,
        class0145,
        class0146,
        class0147,
        class0148,
        class0149,
        class0150,
        class0151};
            this.deumosGroupBox10.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox10.Controls.Add(this.txtKey2);
            this.deumosGroupBox10.Controls.Add(this.groupBox22);
            this.deumosGroupBox10.Controls.Add(this.randomPool2);
            this.deumosGroupBox10.Controls.Add(this.groupEnc2);
            this.deumosGroupBox10.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox10.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox10.Image_0 = null;
            this.deumosGroupBox10.Location = new System.Drawing.Point(3, 3);
            this.deumosGroupBox10.Name = "deumosGroupBox10";
            this.deumosGroupBox10.Size = new System.Drawing.Size(271, 228);
            this.deumosGroupBox10.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox10.TabIndex = 0;
            this.deumosGroupBox10.Text = "2nd Encryption";
            // 
            // txtKey2
            // 
            this.txtKey2.Boolean_0 = false;
            this.txtKey2.Boolean_1 = false;
            this.txtKey2.Boolean_2 = false;
            this.txtKey2.Boolean_3 = false;
            this.txtKey2.Boolean_4 = false;
            class0152.Color_0 = System.Drawing.Color.White;
            class0152.String_0 = "Text";
            class0153.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0153.String_0 = "Back";
            class0154.Color_0 = System.Drawing.Color.Black;
            class0154.String_0 = "Border1";
            class0155.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0155.String_0 = "Border2";
            this.txtKey2.Class0_0 = new Cryptex1.Class0[] {
        class0152,
        class0153,
        class0154,
        class0155};
            this.txtKey2.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtKey2.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtKey2.Image_0 = null;
            this.txtKey2.Int32_2 = 32767;
            this.txtKey2.Location = new System.Drawing.Point(4, 200);
            this.txtKey2.Name = "txtKey2";
            this.txtKey2.Size = new System.Drawing.Size(132, 24);
            this.txtKey2.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtKey2.TabIndex = 4;
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.rdbLetterKey2);
            this.groupBox22.Controls.Add(this.rdbUnicodeKey2);
            this.groupBox22.Controls.Add(this.rdbChinKey2);
            this.groupBox22.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox22.Location = new System.Drawing.Point(139, 195);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(131, 29);
            this.groupBox22.TabIndex = 3;
            this.groupBox22.TabStop = false;
            // 
            // rdbLetterKey2
            // 
            this.rdbLetterKey2.AutoSize = true;
            this.rdbLetterKey2.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbLetterKey2.Location = new System.Drawing.Point(2, 9);
            this.rdbLetterKey2.Name = "rdbLetterKey2";
            this.rdbLetterKey2.Size = new System.Drawing.Size(39, 16);
            this.rdbLetterKey2.TabIndex = 2;
            this.rdbLetterKey2.TabStop = true;
            this.rdbLetterKey2.Text = "Ltrs";
            this.rdbLetterKey2.UseVisualStyleBackColor = true;
            this.rdbLetterKey2.CheckedChanged += new System.EventHandler(this.rdbLetterKey2_CheckedChanged);
            // 
            // rdbUnicodeKey2
            // 
            this.rdbUnicodeKey2.AutoSize = true;
            this.rdbUnicodeKey2.Location = new System.Drawing.Point(40, 9);
            this.rdbUnicodeKey2.Name = "rdbUnicodeKey2";
            this.rdbUnicodeKey2.Size = new System.Drawing.Size(44, 16);
            this.rdbUnicodeKey2.TabIndex = 1;
            this.rdbUnicodeKey2.TabStop = true;
            this.rdbUnicodeKey2.Text = "UniC";
            this.rdbUnicodeKey2.UseVisualStyleBackColor = true;
            this.rdbUnicodeKey2.CheckedChanged += new System.EventHandler(this.rdbUnicodeKey2_CheckedChanged);
            // 
            // rdbChinKey2
            // 
            this.rdbChinKey2.AutoSize = true;
            this.rdbChinKey2.Location = new System.Drawing.Point(84, 9);
            this.rdbChinKey2.Name = "rdbChinKey2";
            this.rdbChinKey2.Size = new System.Drawing.Size(42, 16);
            this.rdbChinKey2.TabIndex = 0;
            this.rdbChinKey2.TabStop = true;
            this.rdbChinKey2.Text = "Chin";
            this.rdbChinKey2.UseVisualStyleBackColor = true;
            this.rdbChinKey2.CheckedChanged += new System.EventHandler(this.rdbChinKey2_CheckedChanged);
            // 
            // randomPool2
            // 
            this.randomPool2.Boolean_0 = false;
            this.randomPool2.ForeColor = System.Drawing.Color.DarkOrange;
            this.randomPool2.Image_0 = null;
            this.randomPool2.Int32_2 = 2;
            this.randomPool2.Location = new System.Drawing.Point(8, 149);
            this.randomPool2.Name = "randomPool2";
            this.randomPool2.Size = new System.Drawing.Size(250, 45);
            this.randomPool2.String_0 = "ƀƁƂƄƅƆƈƉƋƍƎƏƐƑƒƓƔƕƖƗƘƙƜƛơƣƥƪƩƱƲƳƴǍǎǢǣǤǥǭȄȜȞȣȮփռպֆԄӸӂҿҧ";
            this.randomPool2.TabIndex = 1;
            this.randomPool2.Text = "control142";
            // 
            // groupEnc2
            // 
            this.groupEnc2.Controls.Add(this.rdbPolyRijn2);
            this.groupEnc2.Controls.Add(this.rdbRC22);
            this.groupEnc2.Controls.Add(this.rdb3DES2);
            this.groupEnc2.Controls.Add(this.radioButton42);
            this.groupEnc2.Controls.Add(this.rdbPolyRev2);
            this.groupEnc2.Controls.Add(this.rdbPolyStairs2);
            this.groupEnc2.Controls.Add(this.rdbPolyAES2);
            this.groupEnc2.Controls.Add(this.rdbRC42);
            this.groupEnc2.Controls.Add(this.rdbRSM2);
            this.groupEnc2.Controls.Add(this.rdbPoly3DES2);
            this.groupEnc2.Controls.Add(this.rdbPolyCloud2);
            this.groupEnc2.Controls.Add(this.rdbAES2);
            this.groupEnc2.Controls.Add(this.rdbRijndael2);
            this.groupEnc2.Controls.Add(this.rdbPolyBaby2);
            this.groupEnc2.Controls.Add(this.rdbPolyDex2);
            this.groupEnc2.Controls.Add(this.rdbStairs2);
            this.groupEnc2.Controls.Add(this.rdbPolyRC22);
            this.groupEnc2.Controls.Add(this.rdbXOR2);
            this.groupEnc2.Controls.Add(this.radioButton57);
            this.groupEnc2.Controls.Add(this.rdbCloud2);
            this.groupEnc2.Controls.Add(this.rdbDex2);
            this.groupEnc2.Controls.Add(this.rdbPolyDES2);
            this.groupEnc2.Controls.Add(this.rdbSymetric2);
            this.groupEnc2.Controls.Add(this.rdbPolySym2);
            this.groupEnc2.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupEnc2.Location = new System.Drawing.Point(6, 22);
            this.groupEnc2.Name = "groupEnc2";
            this.groupEnc2.Size = new System.Drawing.Size(261, 120);
            this.groupEnc2.TabIndex = 0;
            this.groupEnc2.TabStop = false;
            // 
            // rdbPolyRijn2
            // 
            this.rdbPolyRijn2.AutoSize = true;
            this.rdbPolyRijn2.Location = new System.Drawing.Point(192, 82);
            this.rdbPolyRijn2.Name = "rdbPolyRijn2";
            this.rdbPolyRijn2.Size = new System.Drawing.Size(58, 16);
            this.rdbPolyRijn2.TabIndex = 24;
            this.rdbPolyRijn2.Text = "PolyRijn";
            this.rdbPolyRijn2.UseVisualStyleBackColor = true;
            // 
            // rdbRC22
            // 
            this.rdbRC22.AutoSize = true;
            this.rdbRC22.Location = new System.Drawing.Point(4, 10);
            this.rdbRC22.Name = "rdbRC22";
            this.rdbRC22.Size = new System.Drawing.Size(42, 16);
            this.rdbRC22.TabIndex = 23;
            this.rdbRC22.Text = "RC2";
            this.rdbRC22.UseVisualStyleBackColor = true;
            // 
            // rdb3DES2
            // 
            this.rdb3DES2.AutoSize = true;
            this.rdb3DES2.Location = new System.Drawing.Point(66, 10);
            this.rdb3DES2.Name = "rdb3DES2";
            this.rdb3DES2.Size = new System.Drawing.Size(47, 16);
            this.rdb3DES2.TabIndex = 22;
            this.rdb3DES2.Text = "3DES";
            this.rdb3DES2.UseVisualStyleBackColor = true;
            // 
            // radioButton42
            // 
            this.radioButton42.AutoSize = true;
            this.radioButton42.Location = new System.Drawing.Point(192, 183);
            this.radioButton42.Name = "radioButton42";
            this.radioButton42.Size = new System.Drawing.Size(58, 16);
            this.radioButton42.TabIndex = 21;
            this.radioButton42.Text = "PolyRijn";
            this.radioButton42.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRev2
            // 
            this.rdbPolyRev2.AutoSize = true;
            this.rdbPolyRev2.Location = new System.Drawing.Point(133, 82);
            this.rdbPolyRev2.Name = "rdbPolyRev2";
            this.rdbPolyRev2.Size = new System.Drawing.Size(60, 16);
            this.rdbPolyRev2.TabIndex = 20;
            this.rdbPolyRev2.Text = "PolyRev";
            this.rdbPolyRev2.UseVisualStyleBackColor = true;
            // 
            // rdbPolyStairs2
            // 
            this.rdbPolyStairs2.AutoSize = true;
            this.rdbPolyStairs2.Location = new System.Drawing.Point(66, 82);
            this.rdbPolyStairs2.Name = "rdbPolyStairs2";
            this.rdbPolyStairs2.Size = new System.Drawing.Size(66, 16);
            this.rdbPolyStairs2.TabIndex = 19;
            this.rdbPolyStairs2.Text = "PolyStairs";
            this.rdbPolyStairs2.UseVisualStyleBackColor = true;
            // 
            // rdbPolyAES2
            // 
            this.rdbPolyAES2.AutoSize = true;
            this.rdbPolyAES2.Enabled = false;
            this.rdbPolyAES2.Location = new System.Drawing.Point(4, 84);
            this.rdbPolyAES2.Name = "rdbPolyAES2";
            this.rdbPolyAES2.Size = new System.Drawing.Size(60, 16);
            this.rdbPolyAES2.TabIndex = 18;
            this.rdbPolyAES2.Text = "PolyAES";
            this.rdbPolyAES2.UseVisualStyleBackColor = true;
            // 
            // rdbRC42
            // 
            this.rdbRC42.AutoSize = true;
            this.rdbRC42.Location = new System.Drawing.Point(4, 28);
            this.rdbRC42.Name = "rdbRC42";
            this.rdbRC42.Size = new System.Drawing.Size(42, 16);
            this.rdbRC42.TabIndex = 17;
            this.rdbRC42.Text = "RC4";
            this.rdbRC42.UseVisualStyleBackColor = true;
            // 
            // rdbRSM2
            // 
            this.rdbRSM2.AutoSize = true;
            this.rdbRSM2.Location = new System.Drawing.Point(133, 100);
            this.rdbRSM2.Name = "rdbRSM2";
            this.rdbRSM2.Size = new System.Drawing.Size(93, 16);
            this.rdbRSM2.TabIndex = 16;
            this.rdbRSM2.Text = "RSM (Aeonhack)";
            this.rdbRSM2.UseVisualStyleBackColor = true;
            // 
            // rdbPoly3DES2
            // 
            this.rdbPoly3DES2.AutoSize = true;
            this.rdbPoly3DES2.BackColor = System.Drawing.Color.Transparent;
            this.rdbPoly3DES2.Location = new System.Drawing.Point(65, 46);
            this.rdbPoly3DES2.Name = "rdbPoly3DES2";
            this.rdbPoly3DES2.Size = new System.Drawing.Size(66, 16);
            this.rdbPoly3DES2.TabIndex = 15;
            this.rdbPoly3DES2.Text = "Poly3DES";
            this.rdbPoly3DES2.UseVisualStyleBackColor = false;
            // 
            // rdbPolyCloud2
            // 
            this.rdbPolyCloud2.AutoSize = true;
            this.rdbPolyCloud2.Location = new System.Drawing.Point(4, 101);
            this.rdbPolyCloud2.Name = "rdbPolyCloud2";
            this.rdbPolyCloud2.Size = new System.Drawing.Size(66, 16);
            this.rdbPolyCloud2.TabIndex = 14;
            this.rdbPolyCloud2.Text = "PolyCloud";
            this.rdbPolyCloud2.UseVisualStyleBackColor = true;
            // 
            // rdbAES2
            // 
            this.rdbAES2.AutoSize = true;
            this.rdbAES2.Location = new System.Drawing.Point(66, 28);
            this.rdbAES2.Name = "rdbAES2";
            this.rdbAES2.Size = new System.Drawing.Size(41, 16);
            this.rdbAES2.TabIndex = 13;
            this.rdbAES2.Text = "AES";
            this.rdbAES2.UseVisualStyleBackColor = true;
            // 
            // rdbRijndael2
            // 
            this.rdbRijndael2.AutoSize = true;
            this.rdbRijndael2.BackColor = System.Drawing.Color.Transparent;
            this.rdbRijndael2.Location = new System.Drawing.Point(133, 46);
            this.rdbRijndael2.Name = "rdbRijndael2";
            this.rdbRijndael2.Size = new System.Drawing.Size(56, 16);
            this.rdbRijndael2.TabIndex = 12;
            this.rdbRijndael2.Text = "Rijndael";
            this.rdbRijndael2.UseVisualStyleBackColor = false;
            // 
            // rdbPolyBaby2
            // 
            this.rdbPolyBaby2.AutoSize = true;
            this.rdbPolyBaby2.Location = new System.Drawing.Point(191, 46);
            this.rdbPolyBaby2.Name = "rdbPolyBaby2";
            this.rdbPolyBaby2.Size = new System.Drawing.Size(64, 16);
            this.rdbPolyBaby2.TabIndex = 11;
            this.rdbPolyBaby2.Text = "PolyBaby";
            this.rdbPolyBaby2.UseVisualStyleBackColor = true;
            // 
            // rdbPolyDex2
            // 
            this.rdbPolyDex2.AutoSize = true;
            this.rdbPolyDex2.Checked = true;
            this.rdbPolyDex2.Location = new System.Drawing.Point(4, 46);
            this.rdbPolyDex2.Name = "rdbPolyDex2";
            this.rdbPolyDex2.Size = new System.Drawing.Size(59, 16);
            this.rdbPolyDex2.TabIndex = 10;
            this.rdbPolyDex2.TabStop = true;
            this.rdbPolyDex2.Text = "PolyDex";
            this.rdbPolyDex2.UseVisualStyleBackColor = true;
            // 
            // rdbStairs2
            // 
            this.rdbStairs2.AutoSize = true;
            this.rdbStairs2.Location = new System.Drawing.Point(133, 65);
            this.rdbStairs2.Name = "rdbStairs2";
            this.rdbStairs2.Size = new System.Drawing.Size(47, 16);
            this.rdbStairs2.TabIndex = 9;
            this.rdbStairs2.Text = "Stairs";
            this.rdbStairs2.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRC22
            // 
            this.rdbPolyRC22.AutoSize = true;
            this.rdbPolyRC22.Location = new System.Drawing.Point(66, 64);
            this.rdbPolyRC22.Name = "rdbPolyRC22";
            this.rdbPolyRC22.Size = new System.Drawing.Size(61, 16);
            this.rdbPolyRC22.TabIndex = 8;
            this.rdbPolyRC22.Text = "PolyRC2";
            this.rdbPolyRC22.UseVisualStyleBackColor = true;
            // 
            // rdbXOR2
            // 
            this.rdbXOR2.AutoSize = true;
            this.rdbXOR2.Location = new System.Drawing.Point(133, 10);
            this.rdbXOR2.Name = "rdbXOR2";
            this.rdbXOR2.Size = new System.Drawing.Size(42, 16);
            this.rdbXOR2.TabIndex = 7;
            this.rdbXOR2.Text = "XOR";
            this.rdbXOR2.UseVisualStyleBackColor = true;
            // 
            // radioButton57
            // 
            this.radioButton57.AutoSize = true;
            this.radioButton57.Location = new System.Drawing.Point(66, 64);
            this.radioButton57.Name = "radioButton57";
            this.radioButton57.Size = new System.Drawing.Size(61, 16);
            this.radioButton57.TabIndex = 6;
            this.radioButton57.Text = "PolyRC2";
            this.radioButton57.UseVisualStyleBackColor = true;
            // 
            // rdbCloud2
            // 
            this.rdbCloud2.AutoSize = true;
            this.rdbCloud2.Location = new System.Drawing.Point(192, 28);
            this.rdbCloud2.Name = "rdbCloud2";
            this.rdbCloud2.Size = new System.Drawing.Size(47, 16);
            this.rdbCloud2.TabIndex = 4;
            this.rdbCloud2.Text = "Cloud";
            this.rdbCloud2.UseVisualStyleBackColor = true;
            // 
            // rdbDex2
            // 
            this.rdbDex2.AutoSize = true;
            this.rdbDex2.Location = new System.Drawing.Point(133, 28);
            this.rdbDex2.Name = "rdbDex2";
            this.rdbDex2.Size = new System.Drawing.Size(40, 16);
            this.rdbDex2.TabIndex = 3;
            this.rdbDex2.Text = "Dex";
            this.rdbDex2.UseVisualStyleBackColor = true;
            // 
            // rdbPolyDES2
            // 
            this.rdbPolyDES2.AutoSize = true;
            this.rdbPolyDES2.Location = new System.Drawing.Point(4, 65);
            this.rdbPolyDES2.Name = "rdbPolyDES2";
            this.rdbPolyDES2.Size = new System.Drawing.Size(61, 16);
            this.rdbPolyDES2.TabIndex = 2;
            this.rdbPolyDES2.Text = "PolyDES";
            this.rdbPolyDES2.UseVisualStyleBackColor = true;
            // 
            // rdbSymetric2
            // 
            this.rdbSymetric2.AutoSize = true;
            this.rdbSymetric2.Location = new System.Drawing.Point(192, 10);
            this.rdbSymetric2.Name = "rdbSymetric2";
            this.rdbSymetric2.Size = new System.Drawing.Size(61, 16);
            this.rdbSymetric2.TabIndex = 1;
            this.rdbSymetric2.Text = "Symetric";
            this.rdbSymetric2.UseVisualStyleBackColor = true;
            // 
            // rdbPolySym2
            // 
            this.rdbPolySym2.AutoSize = true;
            this.rdbPolySym2.BackColor = System.Drawing.Color.Transparent;
            this.rdbPolySym2.Location = new System.Drawing.Point(192, 64);
            this.rdbPolySym2.Name = "rdbPolySym2";
            this.rdbPolySym2.Size = new System.Drawing.Size(65, 16);
            this.rdbPolySym2.TabIndex = 0;
            this.rdbPolySym2.Text = "PolySym.";
            this.rdbPolySym2.UseVisualStyleBackColor = false;
            // 
            // pan3
            // 
            this.pan3.Controls.Add(this.deumosGroupBox5);
            this.pan3.Location = new System.Drawing.Point(531, 258);
            this.pan3.Name = "pan3";
            this.pan3.Size = new System.Drawing.Size(277, 225);
            this.pan3.TabIndex = 11;
            this.pan3.Visible = false;
            // 
            // deumosGroupBox5
            // 
            this.deumosGroupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox5.Boolean_0 = true;
            this.deumosGroupBox5.Boolean_1 = true;
            this.deumosGroupBox5.Boolean_3 = false;
            class0156.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0156.String_0 = "Back";
            class0157.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0157.String_0 = "MainFill";
            class0158.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0158.String_0 = "MainOutline1";
            class0159.Color_0 = System.Drawing.Color.Black;
            class0159.String_0 = "MainOutline2";
            class0160.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0160.String_0 = "TitleShadow";
            class0161.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0161.String_0 = "TitleFill";
            class0162.Color_0 = System.Drawing.Color.White;
            class0162.String_0 = "Text";
            class0163.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0163.String_0 = "TitleOutline1";
            class0164.Color_0 = System.Drawing.Color.Black;
            class0164.String_0 = "TitleOutline2";
            this.deumosGroupBox5.Class0_0 = new Cryptex1.Class0[] {
        class0156,
        class0157,
        class0158,
        class0159,
        class0160,
        class0161,
        class0162,
        class0163,
        class0164};
            this.deumosGroupBox5.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox5.Controls.Add(this.groupBox17);
            this.deumosGroupBox5.Controls.Add(this.muButton13kk);
            this.deumosGroupBox5.Controls.Add(this.groupBox2);
            this.deumosGroupBox5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox5.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox5.Image_0 = null;
            this.deumosGroupBox5.Location = new System.Drawing.Point(5, 3);
            this.deumosGroupBox5.Name = "deumosGroupBox5";
            this.deumosGroupBox5.Size = new System.Drawing.Size(265, 214);
            this.deumosGroupBox5.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox5.TabIndex = 0;
            this.deumosGroupBox5.Text = "USG";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.numVariableLength);
            this.groupBox17.Controls.Add(this.rdbUnicode);
            this.groupBox17.Controls.Add(this.rdbLetter);
            this.groupBox17.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox17.Location = new System.Drawing.Point(8, 161);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(249, 46);
            this.groupBox17.TabIndex = 2;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Variables Randmization + Length";
            // 
            // numVariableLength
            // 
            this.numVariableLength.Location = new System.Drawing.Point(196, 19);
            this.numVariableLength.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numVariableLength.Name = "numVariableLength";
            this.numVariableLength.Size = new System.Drawing.Size(40, 20);
            this.numVariableLength.TabIndex = 2;
            this.numVariableLength.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // rdbUnicode
            // 
            this.rdbUnicode.AutoSize = true;
            this.rdbUnicode.Checked = true;
            this.rdbUnicode.Location = new System.Drawing.Point(101, 17);
            this.rdbUnicode.Name = "rdbUnicode";
            this.rdbUnicode.Size = new System.Drawing.Size(64, 18);
            this.rdbUnicode.TabIndex = 1;
            this.rdbUnicode.TabStop = true;
            this.rdbUnicode.Text = "Unicode";
            this.rdbUnicode.UseVisualStyleBackColor = true;
            // 
            // rdbLetter
            // 
            this.rdbLetter.AutoSize = true;
            this.rdbLetter.Location = new System.Drawing.Point(9, 17);
            this.rdbLetter.Name = "rdbLetter";
            this.rdbLetter.Size = new System.Drawing.Size(86, 18);
            this.rdbLetter.TabIndex = 0;
            this.rdbLetter.Text = "Letter+Numb";
            this.rdbLetter.UseVisualStyleBackColor = true;
            // 
            // muButton13kk
            // 
            this.muButton13kk.Controls.Add(this.numRandomStringLength);
            this.muButton13kk.Controls.Add(this.label7);
            this.muButton13kk.Controls.Add(this.lblApiAmount);
            this.muButton13kk.Controls.Add(this.trkFakeApi);
            this.muButton13kk.Controls.Add(this.chkFakeAPI);
            this.muButton13kk.Location = new System.Drawing.Point(146, 33);
            this.muButton13kk.Name = "muButton13kk";
            this.muButton13kk.Size = new System.Drawing.Size(116, 127);
            this.muButton13kk.TabIndex = 1;
            this.muButton13kk.TabStop = false;
            this.muButton13kk.Text = "groupBox16";
            // 
            // numRandomStringLength
            // 
            this.numRandomStringLength.Enabled = false;
            this.numRandomStringLength.Location = new System.Drawing.Point(37, 91);
            this.numRandomStringLength.Maximum = new decimal(new int[] {
            300,
            0,
            0,
            0});
            this.numRandomStringLength.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numRandomStringLength.Name = "numRandomStringLength";
            this.numRandomStringLength.Size = new System.Drawing.Size(41, 20);
            this.numRandomStringLength.TabIndex = 4;
            this.numRandomStringLength.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.DarkOrange;
            this.label7.Location = new System.Drawing.Point(4, 70);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 14);
            this.label7.TabIndex = 3;
            this.label7.Text = "Random String length";
            // 
            // lblApiAmount
            // 
            this.lblApiAmount.AutoSize = true;
            this.lblApiAmount.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblApiAmount.Location = new System.Drawing.Point(17, 19);
            this.lblApiAmount.Name = "lblApiAmount";
            this.lblApiAmount.Size = new System.Drawing.Size(88, 14);
            this.lblApiAmount.TabIndex = 2;
            this.lblApiAmount.Text = "Amount: 10 API\'s";
            // 
            // trkFakeApi
            // 
            this.trkFakeApi.Boolean_0 = false;
            this.trkFakeApi.Boolean_1 = false;
            class0165.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            class0165.String_0 = "Track";
            class0166.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            class0166.String_0 = "Border";
            class0167.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(135)))), ((int)(((byte)(135)))));
            class0167.String_0 = "Line";
            class0168.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(118)))), ((int)(((byte)(118)))));
            class0168.String_0 = "BarBack";
            class0169.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            class0169.String_0 = "BarGloss1";
            class0170.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            class0170.String_0 = "BarGloss2";
            class0171.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(165)))), ((int)(((byte)(165)))));
            class0171.String_0 = "BarShine";
            class0172.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            class0172.String_0 = "BarBorder";
            this.trkFakeApi.Class0_0 = new Cryptex1.Class0[] {
        class0165,
        class0166,
        class0167,
        class0168,
        class0169,
        class0170,
        class0171,
        class0172};
            this.trkFakeApi.Enabled = false;
            this.trkFakeApi.Font = new System.Drawing.Font("Verdana", 8F);
            this.trkFakeApi.Image_0 = null;
            this.trkFakeApi.Int32_2 = 0;
            this.trkFakeApi.Int32_3 = 10;
            this.trkFakeApi.Int32_4 = 0;
            this.trkFakeApi.Location = new System.Drawing.Point(8, 44);
            this.trkFakeApi.Name = "trkFakeApi";
            this.trkFakeApi.Size = new System.Drawing.Size(102, 17);
            this.trkFakeApi.String_0 = "ZGRk/0ZGRv+Hh4f/dnZ2/5aWlv+AgID/paWl/1BQUP8=";
            this.trkFakeApi.TabIndex = 1;
            this.trkFakeApi.Text = "control12";
            // 
            // chkFakeAPI
            // 
            this.chkFakeAPI.AutoSize = true;
            this.chkFakeAPI.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.chkFakeAPI.Location = new System.Drawing.Point(6, -3);
            this.chkFakeAPI.Name = "chkFakeAPI";
            this.chkFakeAPI.Size = new System.Drawing.Size(92, 18);
            this.chkFakeAPI.TabIndex = 0;
            this.chkFakeAPI.Text = "Fake API USG";
            this.chkFakeAPI.UseVisualStyleBackColor = true;
            this.chkFakeAPI.CheckedChanged += new System.EventHandler(this.chkFakeAPI_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblJunkAmount);
            this.groupBox2.Controls.Add(this.chkArrayVariables);
            this.groupBox2.Controls.Add(this.checkBox9);
            this.groupBox2.Controls.Add(this.trkJunkCode);
            this.groupBox2.Controls.Add(this.chkJunkCode);
            this.groupBox2.Location = new System.Drawing.Point(13, 33);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(119, 127);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox15";
            // 
            // lblJunkAmount
            // 
            this.lblJunkAmount.AutoSize = true;
            this.lblJunkAmount.ForeColor = System.Drawing.Color.DarkOrange;
            this.lblJunkAmount.Location = new System.Drawing.Point(7, 21);
            this.lblJunkAmount.Name = "lblJunkAmount";
            this.lblJunkAmount.Size = new System.Drawing.Size(87, 14);
            this.lblJunkAmount.TabIndex = 4;
            this.lblJunkAmount.Text = "Amount: 10 lines";
            // 
            // chkArrayVariables
            // 
            this.chkArrayVariables.AutoSize = true;
            this.chkArrayVariables.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.chkArrayVariables.Location = new System.Drawing.Point(10, 93);
            this.chkArrayVariables.Name = "chkArrayVariables";
            this.chkArrayVariables.Size = new System.Drawing.Size(54, 18);
            this.chkArrayVariables.TabIndex = 3;
            this.chkArrayVariables.Text = "USG2";
            this.chkArrayVariables.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Checked = true;
            this.checkBox9.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox9.Enabled = false;
            this.checkBox9.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.checkBox9.Location = new System.Drawing.Point(10, 73);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(54, 18);
            this.checkBox9.TabIndex = 2;
            this.checkBox9.Text = "USG1";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // trkJunkCode
            // 
            this.trkJunkCode.Boolean_0 = false;
            this.trkJunkCode.Boolean_1 = false;
            class0173.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
            class0173.String_0 = "Track";
            class0174.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            class0174.String_0 = "Border";
            class0175.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(135)))), ((int)(((byte)(135)))));
            class0175.String_0 = "Line";
            class0176.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(118)))), ((int)(((byte)(118)))), ((int)(((byte)(118)))));
            class0176.String_0 = "BarBack";
            class0177.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(150)))), ((int)(((byte)(150)))));
            class0177.String_0 = "BarGloss1";
            class0178.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            class0178.String_0 = "BarGloss2";
            class0179.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(165)))), ((int)(((byte)(165)))));
            class0179.String_0 = "BarShine";
            class0180.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
            class0180.String_0 = "BarBorder";
            this.trkJunkCode.Class0_0 = new Cryptex1.Class0[] {
        class0173,
        class0174,
        class0175,
        class0176,
        class0177,
        class0178,
        class0179,
        class0180};
            this.trkJunkCode.Enabled = false;
            this.trkJunkCode.Font = new System.Drawing.Font("Verdana", 8F);
            this.trkJunkCode.Image_0 = null;
            this.trkJunkCode.Int32_2 = 0;
            this.trkJunkCode.Int32_3 = 10;
            this.trkJunkCode.Int32_4 = 0;
            this.trkJunkCode.Location = new System.Drawing.Point(6, 44);
            this.trkJunkCode.Name = "trkJunkCode";
            this.trkJunkCode.Size = new System.Drawing.Size(102, 17);
            this.trkJunkCode.String_0 = "ZGRk/0ZGRv+Hh4f/dnZ2/5aWlv+AgID/paWl/1BQUP8=";
            this.trkJunkCode.TabIndex = 1;
            this.trkJunkCode.Text = "control11";
            // 
            // chkJunkCode
            // 
            this.chkJunkCode.AutoSize = true;
            this.chkJunkCode.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.chkJunkCode.Location = new System.Drawing.Point(6, -3);
            this.chkJunkCode.Name = "chkJunkCode";
            this.chkJunkCode.Size = new System.Drawing.Size(101, 18);
            this.chkJunkCode.TabIndex = 0;
            this.chkJunkCode.Text = "Junk Code USG";
            this.chkJunkCode.UseVisualStyleBackColor = true;
            this.chkJunkCode.CheckedChanged += new System.EventHandler(this.chkJunkCode_CheckedChanged);
            // 
            // pan8
            // 
            this.pan8.Controls.Add(this.deumosGroupBox3);
            this.pan8.Location = new System.Drawing.Point(810, 28);
            this.pan8.Name = "pan8";
            this.pan8.Size = new System.Drawing.Size(277, 234);
            this.pan8.TabIndex = 2;
            this.pan8.Visible = false;
            // 
            // deumosGroupBox3
            // 
            this.deumosGroupBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox3.Boolean_0 = true;
            this.deumosGroupBox3.Boolean_1 = true;
            this.deumosGroupBox3.Boolean_3 = false;
            class0181.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0181.String_0 = "Back";
            class0182.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0182.String_0 = "MainFill";
            class0183.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0183.String_0 = "MainOutline1";
            class0184.Color_0 = System.Drawing.Color.Black;
            class0184.String_0 = "MainOutline2";
            class0185.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0185.String_0 = "TitleShadow";
            class0186.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0186.String_0 = "TitleFill";
            class0187.Color_0 = System.Drawing.Color.White;
            class0187.String_0 = "Text";
            class0188.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0188.String_0 = "TitleOutline1";
            class0189.Color_0 = System.Drawing.Color.Black;
            class0189.String_0 = "TitleOutline2";
            this.deumosGroupBox3.Class0_0 = new Cryptex1.Class0[] {
        class0181,
        class0182,
        class0183,
        class0184,
        class0185,
        class0186,
        class0187,
        class0188,
        class0189};
            this.deumosGroupBox3.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox3.Controls.Add(this.txtKey);
            this.deumosGroupBox3.Controls.Add(this.groupBox21);
            this.deumosGroupBox3.Controls.Add(this.randomPool1);
            this.deumosGroupBox3.Controls.Add(this.grpEncryption);
            this.deumosGroupBox3.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox3.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox3.Image_0 = null;
            this.deumosGroupBox3.Location = new System.Drawing.Point(3, 3);
            this.deumosGroupBox3.Name = "deumosGroupBox3";
            this.deumosGroupBox3.Size = new System.Drawing.Size(271, 228);
            this.deumosGroupBox3.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox3.TabIndex = 0;
            this.deumosGroupBox3.Text = "1st Encryption";
            // 
            // txtKey
            // 
            this.txtKey.Boolean_0 = false;
            this.txtKey.Boolean_1 = false;
            this.txtKey.Boolean_2 = false;
            this.txtKey.Boolean_3 = false;
            this.txtKey.Boolean_4 = false;
            class0190.Color_0 = System.Drawing.Color.White;
            class0190.String_0 = "Text";
            class0191.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0191.String_0 = "Back";
            class0192.Color_0 = System.Drawing.Color.Black;
            class0192.String_0 = "Border1";
            class0193.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0193.String_0 = "Border2";
            this.txtKey.Class0_0 = new Cryptex1.Class0[] {
        class0190,
        class0191,
        class0192,
        class0193};
            this.txtKey.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtKey.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtKey.Image_0 = null;
            this.txtKey.Int32_2 = 32767;
            this.txtKey.Location = new System.Drawing.Point(4, 200);
            this.txtKey.Name = "txtKey";
            this.txtKey.Size = new System.Drawing.Size(132, 24);
            this.txtKey.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtKey.TabIndex = 4;
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.rdbLettersKey);
            this.groupBox21.Controls.Add(this.rdbUnicodeKey);
            this.groupBox21.Controls.Add(this.rdbChinKey);
            this.groupBox21.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox21.Location = new System.Drawing.Point(139, 195);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(131, 29);
            this.groupBox21.TabIndex = 3;
            this.groupBox21.TabStop = false;
            // 
            // rdbLettersKey
            // 
            this.rdbLettersKey.AutoSize = true;
            this.rdbLettersKey.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbLettersKey.Location = new System.Drawing.Point(2, 9);
            this.rdbLettersKey.Name = "rdbLettersKey";
            this.rdbLettersKey.Size = new System.Drawing.Size(39, 16);
            this.rdbLettersKey.TabIndex = 2;
            this.rdbLettersKey.TabStop = true;
            this.rdbLettersKey.Text = "Ltrs";
            this.rdbLettersKey.UseVisualStyleBackColor = true;
            this.rdbLettersKey.CheckedChanged += new System.EventHandler(this.rdbLettersKey_CheckedChanged);
            // 
            // rdbUnicodeKey
            // 
            this.rdbUnicodeKey.AutoSize = true;
            this.rdbUnicodeKey.Location = new System.Drawing.Point(40, 9);
            this.rdbUnicodeKey.Name = "rdbUnicodeKey";
            this.rdbUnicodeKey.Size = new System.Drawing.Size(44, 16);
            this.rdbUnicodeKey.TabIndex = 1;
            this.rdbUnicodeKey.TabStop = true;
            this.rdbUnicodeKey.Text = "UniC";
            this.rdbUnicodeKey.UseVisualStyleBackColor = true;
            this.rdbUnicodeKey.CheckedChanged += new System.EventHandler(this.rdbUnicodeKey_CheckedChanged);
            // 
            // rdbChinKey
            // 
            this.rdbChinKey.AutoSize = true;
            this.rdbChinKey.Location = new System.Drawing.Point(84, 9);
            this.rdbChinKey.Name = "rdbChinKey";
            this.rdbChinKey.Size = new System.Drawing.Size(42, 16);
            this.rdbChinKey.TabIndex = 0;
            this.rdbChinKey.TabStop = true;
            this.rdbChinKey.Text = "Chin";
            this.rdbChinKey.UseVisualStyleBackColor = true;
            this.rdbChinKey.CheckedChanged += new System.EventHandler(this.rdbChinKey_CheckedChanged);
            // 
            // randomPool1
            // 
            this.randomPool1.Boolean_0 = false;
            this.randomPool1.ForeColor = System.Drawing.Color.DarkOrange;
            this.randomPool1.Image_0 = null;
            this.randomPool1.Int32_2 = 2;
            this.randomPool1.Location = new System.Drawing.Point(8, 149);
            this.randomPool1.Name = "randomPool1";
            this.randomPool1.Size = new System.Drawing.Size(250, 45);
            this.randomPool1.String_0 = "ƀƁƂƄƅƆƈƉƋƍƎƏƐƑƒƓƔƕƖƗƘƙƜƛơƣƥƪƩƱƲƳƴǍǎǢǣǤǥǭȄȜȞȣȮփռպֆԄӸӂҿҧ";
            this.randomPool1.TabIndex = 1;
            this.randomPool1.Text = "control141";
            // 
            // grpEncryption
            // 
            this.grpEncryption.Controls.Add(this.rdbPolyRijn);
            this.grpEncryption.Controls.Add(this.rdbRC2);
            this.grpEncryption.Controls.Add(this.rdbTripleDES);
            this.grpEncryption.Controls.Add(this.radioButton34);
            this.grpEncryption.Controls.Add(this.rdbPolyRev);
            this.grpEncryption.Controls.Add(this.rdbPolyStairs);
            this.grpEncryption.Controls.Add(this.rdbPolyAES);
            this.grpEncryption.Controls.Add(this.rdbRC4);
            this.grpEncryption.Controls.Add(this.rdbRSM);
            this.grpEncryption.Controls.Add(this.rdbPoly3DES);
            this.grpEncryption.Controls.Add(this.rdbPolyCloud);
            this.grpEncryption.Controls.Add(this.rdbAES);
            this.grpEncryption.Controls.Add(this.rdbRijndael);
            this.grpEncryption.Controls.Add(this.rdbPolyBaby);
            this.grpEncryption.Controls.Add(this.rdbPolyDex);
            this.grpEncryption.Controls.Add(this.rdbStairs);
            this.grpEncryption.Controls.Add(this.rdbPolyRC2);
            this.grpEncryption.Controls.Add(this.rdbXOR);
            this.grpEncryption.Controls.Add(this.radioButton19);
            this.grpEncryption.Controls.Add(this.rdbBind1);
            this.grpEncryption.Controls.Add(this.rdbDex);
            this.grpEncryption.Controls.Add(this.rdbPolyDES);
            this.grpEncryption.Controls.Add(this.rdbSymetric);
            this.grpEncryption.Controls.Add(this.rdbPolySym);
            this.grpEncryption.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.grpEncryption.Location = new System.Drawing.Point(6, 22);
            this.grpEncryption.Name = "grpEncryption";
            this.grpEncryption.Size = new System.Drawing.Size(261, 120);
            this.grpEncryption.TabIndex = 0;
            this.grpEncryption.TabStop = false;
            // 
            // rdbPolyRijn
            // 
            this.rdbPolyRijn.AutoSize = true;
            this.rdbPolyRijn.Location = new System.Drawing.Point(191, 80);
            this.rdbPolyRijn.Name = "rdbPolyRijn";
            this.rdbPolyRijn.Size = new System.Drawing.Size(58, 16);
            this.rdbPolyRijn.TabIndex = 24;
            this.rdbPolyRijn.Text = "PolyRijn";
            this.rdbPolyRijn.UseVisualStyleBackColor = true;
            // 
            // rdbRC2
            // 
            this.rdbRC2.AutoSize = true;
            this.rdbRC2.Location = new System.Drawing.Point(4, 10);
            this.rdbRC2.Name = "rdbRC2";
            this.rdbRC2.Size = new System.Drawing.Size(42, 16);
            this.rdbRC2.TabIndex = 23;
            this.rdbRC2.Text = "RC2";
            this.rdbRC2.UseVisualStyleBackColor = true;
            // 
            // rdbTripleDES
            // 
            this.rdbTripleDES.AutoSize = true;
            this.rdbTripleDES.Location = new System.Drawing.Point(66, 10);
            this.rdbTripleDES.Name = "rdbTripleDES";
            this.rdbTripleDES.Size = new System.Drawing.Size(47, 16);
            this.rdbTripleDES.TabIndex = 22;
            this.rdbTripleDES.Text = "3DES";
            this.rdbTripleDES.UseVisualStyleBackColor = true;
            // 
            // radioButton34
            // 
            this.radioButton34.AutoSize = true;
            this.radioButton34.Location = new System.Drawing.Point(192, 183);
            this.radioButton34.Name = "radioButton34";
            this.radioButton34.Size = new System.Drawing.Size(58, 16);
            this.radioButton34.TabIndex = 21;
            this.radioButton34.Text = "PolyRijn";
            this.radioButton34.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRev
            // 
            this.rdbPolyRev.AutoSize = true;
            this.rdbPolyRev.Location = new System.Drawing.Point(133, 82);
            this.rdbPolyRev.Name = "rdbPolyRev";
            this.rdbPolyRev.Size = new System.Drawing.Size(60, 16);
            this.rdbPolyRev.TabIndex = 20;
            this.rdbPolyRev.Text = "PolyRev";
            this.rdbPolyRev.UseVisualStyleBackColor = true;
            // 
            // rdbPolyStairs
            // 
            this.rdbPolyStairs.AutoSize = true;
            this.rdbPolyStairs.Location = new System.Drawing.Point(66, 82);
            this.rdbPolyStairs.Name = "rdbPolyStairs";
            this.rdbPolyStairs.Size = new System.Drawing.Size(66, 16);
            this.rdbPolyStairs.TabIndex = 19;
            this.rdbPolyStairs.Text = "PolyStairs";
            this.rdbPolyStairs.UseVisualStyleBackColor = true;
            // 
            // rdbPolyAES
            // 
            this.rdbPolyAES.AutoSize = true;
            this.rdbPolyAES.Enabled = false;
            this.rdbPolyAES.Location = new System.Drawing.Point(4, 84);
            this.rdbPolyAES.Name = "rdbPolyAES";
            this.rdbPolyAES.Size = new System.Drawing.Size(60, 16);
            this.rdbPolyAES.TabIndex = 18;
            this.rdbPolyAES.Text = "PolyAES";
            this.rdbPolyAES.UseVisualStyleBackColor = true;
            // 
            // rdbRC4
            // 
            this.rdbRC4.AutoSize = true;
            this.rdbRC4.Location = new System.Drawing.Point(4, 28);
            this.rdbRC4.Name = "rdbRC4";
            this.rdbRC4.Size = new System.Drawing.Size(42, 16);
            this.rdbRC4.TabIndex = 17;
            this.rdbRC4.Text = "RC4";
            this.rdbRC4.UseVisualStyleBackColor = true;
            // 
            // rdbRSM
            // 
            this.rdbRSM.AutoSize = true;
            this.rdbRSM.Location = new System.Drawing.Point(133, 100);
            this.rdbRSM.Name = "rdbRSM";
            this.rdbRSM.Size = new System.Drawing.Size(93, 16);
            this.rdbRSM.TabIndex = 16;
            this.rdbRSM.Text = "RSM (Aeonhack)";
            this.rdbRSM.UseVisualStyleBackColor = true;
            // 
            // rdbPoly3DES
            // 
            this.rdbPoly3DES.AutoSize = true;
            this.rdbPoly3DES.BackColor = System.Drawing.Color.Transparent;
            this.rdbPoly3DES.Location = new System.Drawing.Point(65, 46);
            this.rdbPoly3DES.Name = "rdbPoly3DES";
            this.rdbPoly3DES.Size = new System.Drawing.Size(66, 16);
            this.rdbPoly3DES.TabIndex = 15;
            this.rdbPoly3DES.Text = "Poly3DES";
            this.rdbPoly3DES.UseVisualStyleBackColor = false;
            // 
            // rdbPolyCloud
            // 
            this.rdbPolyCloud.AutoSize = true;
            this.rdbPolyCloud.Location = new System.Drawing.Point(4, 101);
            this.rdbPolyCloud.Name = "rdbPolyCloud";
            this.rdbPolyCloud.Size = new System.Drawing.Size(66, 16);
            this.rdbPolyCloud.TabIndex = 14;
            this.rdbPolyCloud.Text = "PolyCloud";
            this.rdbPolyCloud.UseVisualStyleBackColor = true;
            // 
            // rdbAES
            // 
            this.rdbAES.AutoSize = true;
            this.rdbAES.Location = new System.Drawing.Point(66, 28);
            this.rdbAES.Name = "rdbAES";
            this.rdbAES.Size = new System.Drawing.Size(41, 16);
            this.rdbAES.TabIndex = 13;
            this.rdbAES.Text = "AES";
            this.rdbAES.UseVisualStyleBackColor = true;
            // 
            // rdbRijndael
            // 
            this.rdbRijndael.AutoSize = true;
            this.rdbRijndael.BackColor = System.Drawing.Color.Transparent;
            this.rdbRijndael.Location = new System.Drawing.Point(133, 46);
            this.rdbRijndael.Name = "rdbRijndael";
            this.rdbRijndael.Size = new System.Drawing.Size(56, 16);
            this.rdbRijndael.TabIndex = 12;
            this.rdbRijndael.Text = "Rijndael";
            this.rdbRijndael.UseVisualStyleBackColor = false;
            // 
            // rdbPolyBaby
            // 
            this.rdbPolyBaby.AutoSize = true;
            this.rdbPolyBaby.Location = new System.Drawing.Point(191, 46);
            this.rdbPolyBaby.Name = "rdbPolyBaby";
            this.rdbPolyBaby.Size = new System.Drawing.Size(64, 16);
            this.rdbPolyBaby.TabIndex = 11;
            this.rdbPolyBaby.Text = "PolyBaby";
            this.rdbPolyBaby.UseVisualStyleBackColor = true;
            // 
            // rdbPolyDex
            // 
            this.rdbPolyDex.AutoSize = true;
            this.rdbPolyDex.Location = new System.Drawing.Point(4, 46);
            this.rdbPolyDex.Name = "rdbPolyDex";
            this.rdbPolyDex.Size = new System.Drawing.Size(59, 16);
            this.rdbPolyDex.TabIndex = 10;
            this.rdbPolyDex.Text = "PolyDex";
            this.rdbPolyDex.UseVisualStyleBackColor = true;
            // 
            // rdbStairs
            // 
            this.rdbStairs.AutoSize = true;
            this.rdbStairs.Location = new System.Drawing.Point(133, 65);
            this.rdbStairs.Name = "rdbStairs";
            this.rdbStairs.Size = new System.Drawing.Size(47, 16);
            this.rdbStairs.TabIndex = 9;
            this.rdbStairs.Text = "Stairs";
            this.rdbStairs.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRC2
            // 
            this.rdbPolyRC2.AutoSize = true;
            this.rdbPolyRC2.Location = new System.Drawing.Point(66, 64);
            this.rdbPolyRC2.Name = "rdbPolyRC2";
            this.rdbPolyRC2.Size = new System.Drawing.Size(61, 16);
            this.rdbPolyRC2.TabIndex = 8;
            this.rdbPolyRC2.Text = "PolyRC2";
            this.rdbPolyRC2.UseVisualStyleBackColor = true;
            // 
            // rdbXOR
            // 
            this.rdbXOR.AutoSize = true;
            this.rdbXOR.Location = new System.Drawing.Point(133, 10);
            this.rdbXOR.Name = "rdbXOR";
            this.rdbXOR.Size = new System.Drawing.Size(42, 16);
            this.rdbXOR.TabIndex = 7;
            this.rdbXOR.Text = "XOR";
            this.rdbXOR.UseVisualStyleBackColor = true;
            // 
            // radioButton19
            // 
            this.radioButton19.AutoSize = true;
            this.radioButton19.Location = new System.Drawing.Point(66, 64);
            this.radioButton19.Name = "radioButton19";
            this.radioButton19.Size = new System.Drawing.Size(61, 16);
            this.radioButton19.TabIndex = 6;
            this.radioButton19.Text = "PolyRC2";
            this.radioButton19.UseVisualStyleBackColor = true;
            // 
            // rdbBind1
            // 
            this.rdbBind1.AutoSize = true;
            this.rdbBind1.Checked = true;
            this.rdbBind1.Location = new System.Drawing.Point(192, 28);
            this.rdbBind1.Name = "rdbBind1";
            this.rdbBind1.Size = new System.Drawing.Size(47, 16);
            this.rdbBind1.TabIndex = 4;
            this.rdbBind1.TabStop = true;
            this.rdbBind1.Text = "Cloud";
            this.rdbBind1.UseVisualStyleBackColor = true;
            // 
            // rdbDex
            // 
            this.rdbDex.AutoSize = true;
            this.rdbDex.Location = new System.Drawing.Point(133, 28);
            this.rdbDex.Name = "rdbDex";
            this.rdbDex.Size = new System.Drawing.Size(40, 16);
            this.rdbDex.TabIndex = 3;
            this.rdbDex.Text = "Dex";
            this.rdbDex.UseVisualStyleBackColor = true;
            // 
            // rdbPolyDES
            // 
            this.rdbPolyDES.AutoSize = true;
            this.rdbPolyDES.Location = new System.Drawing.Point(4, 65);
            this.rdbPolyDES.Name = "rdbPolyDES";
            this.rdbPolyDES.Size = new System.Drawing.Size(61, 16);
            this.rdbPolyDES.TabIndex = 2;
            this.rdbPolyDES.Text = "PolyDES";
            this.rdbPolyDES.UseVisualStyleBackColor = true;
            // 
            // rdbSymetric
            // 
            this.rdbSymetric.AutoSize = true;
            this.rdbSymetric.Location = new System.Drawing.Point(192, 10);
            this.rdbSymetric.Name = "rdbSymetric";
            this.rdbSymetric.Size = new System.Drawing.Size(61, 16);
            this.rdbSymetric.TabIndex = 1;
            this.rdbSymetric.Text = "Symetric";
            this.rdbSymetric.UseVisualStyleBackColor = true;
            // 
            // rdbPolySym
            // 
            this.rdbPolySym.AutoSize = true;
            this.rdbPolySym.BackColor = System.Drawing.Color.Transparent;
            this.rdbPolySym.Location = new System.Drawing.Point(192, 64);
            this.rdbPolySym.Name = "rdbPolySym";
            this.rdbPolySym.Size = new System.Drawing.Size(65, 16);
            this.rdbPolySym.TabIndex = 0;
            this.rdbPolySym.Text = "PolySym.";
            this.rdbPolySym.UseVisualStyleBackColor = false;
            // 
            // pan12
            // 
            this.pan12.AllowDrop = true;
            this.pan12.Controls.Add(this.deumosGroupBox13);
            this.pan12.Location = new System.Drawing.Point(814, 268);
            this.pan12.Name = "pan12";
            this.pan12.Size = new System.Drawing.Size(277, 225);
            this.pan12.TabIndex = 10;
            this.pan12.Visible = false;
            // 
            // deumosGroupBox13
            // 
            this.deumosGroupBox13.AllowDrop = true;
            this.deumosGroupBox13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox13.Boolean_0 = true;
            this.deumosGroupBox13.Boolean_1 = true;
            this.deumosGroupBox13.Boolean_3 = false;
            class0194.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0194.String_0 = "Back";
            class0195.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0195.String_0 = "MainFill";
            class0196.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0196.String_0 = "MainOutline1";
            class0197.Color_0 = System.Drawing.Color.Black;
            class0197.String_0 = "MainOutline2";
            class0198.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0198.String_0 = "TitleShadow";
            class0199.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0199.String_0 = "TitleFill";
            class0200.Color_0 = System.Drawing.Color.White;
            class0200.String_0 = "Text";
            class0201.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0201.String_0 = "TitleOutline1";
            class0202.Color_0 = System.Drawing.Color.Black;
            class0202.String_0 = "TitleOutline2";
            this.deumosGroupBox13.Class0_0 = new Cryptex1.Class0[] {
        class0194,
        class0195,
        class0196,
        class0197,
        class0198,
        class0199,
        class0200,
        class0201,
        class0202};
            this.deumosGroupBox13.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox13.Controls.Add(this.grpPic);
            this.deumosGroupBox13.Controls.Add(this.picMn);
            this.deumosGroupBox13.Controls.Add(this.picEnc);
            this.deumosGroupBox13.Controls.Add(this.picRunPE);
            this.deumosGroupBox13.Controls.Add(this.picRest);
            this.deumosGroupBox13.Controls.Add(this.btnClearPic);
            this.deumosGroupBox13.Controls.Add(this.grpPicBtn);
            this.deumosGroupBox13.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox13.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox13.Image_0 = null;
            this.deumosGroupBox13.Location = new System.Drawing.Point(3, 3);
            this.deumosGroupBox13.Name = "deumosGroupBox13";
            this.deumosGroupBox13.Size = new System.Drawing.Size(271, 217);
            this.deumosGroupBox13.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox13.TabIndex = 0;
            this.deumosGroupBox13.Text = "Stub Disposition";
            // 
            // grpPic
            // 
            this.grpPic.Controls.Add(this.pic1);
            this.grpPic.Controls.Add(this.pic2);
            this.grpPic.Controls.Add(this.pic3);
            this.grpPic.Controls.Add(this.pic4);
            this.grpPic.Enabled = false;
            this.grpPic.Location = new System.Drawing.Point(11, 53);
            this.grpPic.Name = "grpPic";
            this.grpPic.Size = new System.Drawing.Size(129, 154);
            this.grpPic.TabIndex = 8;
            this.grpPic.TabStop = false;
            this.grpPic.Text = "Custom";
            // 
            // pic1
            // 
            this.pic1.Location = new System.Drawing.Point(6, 14);
            this.pic1.Name = "pic1";
            this.pic1.Size = new System.Drawing.Size(115, 36);
            this.pic1.TabIndex = 3;
            this.pic1.TabStop = false;
            // 
            // pic2
            // 
            this.pic2.Location = new System.Drawing.Point(6, 46);
            this.pic2.Name = "pic2";
            this.pic2.Size = new System.Drawing.Size(115, 36);
            this.pic2.TabIndex = 2;
            this.pic2.TabStop = false;
            // 
            // pic3
            // 
            this.pic3.Location = new System.Drawing.Point(6, 80);
            this.pic3.Name = "pic3";
            this.pic3.Size = new System.Drawing.Size(115, 36);
            this.pic3.TabIndex = 1;
            this.pic3.TabStop = false;
            // 
            // pic4
            // 
            this.pic4.Location = new System.Drawing.Point(6, 113);
            this.pic4.Name = "pic4";
            this.pic4.Size = new System.Drawing.Size(115, 36);
            this.pic4.TabIndex = 0;
            this.pic4.TabStop = false;
            // 
            // picMn
            // 
            this.picMn.Image = global::Cryptex1.Properties.Resources.main;
            this.picMn.InitialImage = null;
            this.picMn.Location = new System.Drawing.Point(148, 67);
            this.picMn.Name = "picMn";
            this.picMn.Size = new System.Drawing.Size(115, 36);
            this.picMn.TabIndex = 7;
            this.picMn.TabStop = false;
            // 
            // picEnc
            // 
            this.picEnc.Image = global::Cryptex1.Properties.Resources.Enc;
            this.picEnc.InitialImage = null;
            this.picEnc.Location = new System.Drawing.Point(148, 100);
            this.picEnc.Name = "picEnc";
            this.picEnc.Size = new System.Drawing.Size(115, 36);
            this.picEnc.TabIndex = 6;
            this.picEnc.TabStop = false;
            // 
            // picRunPE
            // 
            this.picRunPE.ErrorImage = null;
            this.picRunPE.Image = global::Cryptex1.Properties.Resources.runpe;
            this.picRunPE.InitialImage = null;
            this.picRunPE.Location = new System.Drawing.Point(148, 134);
            this.picRunPE.Name = "picRunPE";
            this.picRunPE.Size = new System.Drawing.Size(115, 36);
            this.picRunPE.TabIndex = 5;
            this.picRunPE.TabStop = false;
            // 
            // picRest
            // 
            this.picRest.Image = global::Cryptex1.Properties.Resources.other;
            this.picRest.InitialImage = null;
            this.picRest.Location = new System.Drawing.Point(148, 168);
            this.picRest.Name = "picRest";
            this.picRest.Size = new System.Drawing.Size(115, 35);
            this.picRest.TabIndex = 4;
            this.picRest.TabStop = false;
            this.picRest.Tag = "Other";
            // 
            // btnClearPic
            // 
            this.btnClearPic.Boolean_0 = false;
            this.btnClearPic.Enabled = false;
            this.btnClearPic.Image_0 = null;
            this.btnClearPic.Location = new System.Drawing.Point(18, 30);
            this.btnClearPic.Name = "btnClearPic";
            this.btnClearPic.Size = new System.Drawing.Size(35, 23);
            this.btnClearPic.TabIndex = 3;
            this.btnClearPic.Text = "Clear";
            this.btnClearPic.Click += new System.EventHandler(this.btnClearPic_Click);
            // 
            // grpPicBtn
            // 
            this.grpPicBtn.Controls.Add(this.rdbCustomPic);
            this.grpPicBtn.Controls.Add(this.rdbRndPic);
            this.grpPicBtn.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.grpPicBtn.Location = new System.Drawing.Point(125, 16);
            this.grpPicBtn.Name = "grpPicBtn";
            this.grpPicBtn.Size = new System.Drawing.Size(137, 29);
            this.grpPicBtn.TabIndex = 0;
            this.grpPicBtn.TabStop = false;
            // 
            // rdbCustomPic
            // 
            this.rdbCustomPic.AutoSize = true;
            this.rdbCustomPic.Location = new System.Drawing.Point(68, 9);
            this.rdbCustomPic.Name = "rdbCustomPic";
            this.rdbCustomPic.Size = new System.Drawing.Size(56, 16);
            this.rdbCustomPic.TabIndex = 1;
            this.rdbCustomPic.Text = "Custom";
            this.rdbCustomPic.UseVisualStyleBackColor = true;
            this.rdbCustomPic.CheckedChanged += new System.EventHandler(this.rdbCustomPic_CheckedChanged);
            // 
            // rdbRndPic
            // 
            this.rdbRndPic.AutoSize = true;
            this.rdbRndPic.Checked = true;
            this.rdbRndPic.Location = new System.Drawing.Point(2, 9);
            this.rdbRndPic.Name = "rdbRndPic";
            this.rdbRndPic.Size = new System.Drawing.Size(58, 16);
            this.rdbRndPic.TabIndex = 0;
            this.rdbRndPic.TabStop = true;
            this.rdbRndPic.Text = "Random";
            this.rdbRndPic.UseVisualStyleBackColor = true;
            this.rdbRndPic.CheckedChanged += new System.EventHandler(this.rdbRndPic_CheckedChanged);
            // 
            // pan9
            // 
            this.pan9.Controls.Add(this.DeumosGroupBo);
            this.pan9.Location = new System.Drawing.Point(605, 511);
            this.pan9.Name = "pan9";
            this.pan9.Size = new System.Drawing.Size(283, 225);
            this.pan9.TabIndex = 6;
            this.pan9.Visible = false;
            // 
            // DeumosGroupBo
            // 
            this.DeumosGroupBo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.DeumosGroupBo.Boolean_0 = true;
            this.DeumosGroupBo.Boolean_1 = true;
            this.DeumosGroupBo.Boolean_3 = false;
            class0203.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0203.String_0 = "Back";
            class0204.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0204.String_0 = "MainFill";
            class0205.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0205.String_0 = "MainOutline1";
            class0206.Color_0 = System.Drawing.Color.Black;
            class0206.String_0 = "MainOutline2";
            class0207.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0207.String_0 = "TitleShadow";
            class0208.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0208.String_0 = "TitleFill";
            class0209.Color_0 = System.Drawing.Color.White;
            class0209.String_0 = "Text";
            class0210.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0210.String_0 = "TitleOutline1";
            class0211.Color_0 = System.Drawing.Color.Black;
            class0211.String_0 = "TitleOutline2";
            this.DeumosGroupBo.Class0_0 = new Cryptex1.Class0[] {
        class0203,
        class0204,
        class0205,
        class0206,
        class0207,
        class0208,
        class0209,
        class0210,
        class0211};
            this.DeumosGroupBo.Color_0 = System.Drawing.Color.Empty;
            this.DeumosGroupBo.Controls.Add(this.groupBox21m);
            this.DeumosGroupBo.Controls.Add(this.txtDownloa);
            this.DeumosGroupBo.Controls.Add(this.groupBox19);
            this.DeumosGroupBo.Controls.Add(this.groupBox18);
            this.DeumosGroupBo.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeumosGroupBo.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.DeumosGroupBo.Image_0 = null;
            this.DeumosGroupBo.Location = new System.Drawing.Point(6, 4);
            this.DeumosGroupBo.Name = "DeumosGroupBo";
            this.DeumosGroupBo.Size = new System.Drawing.Size(277, 218);
            this.DeumosGroupBo.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.DeumosGroupBo.TabIndex = 0;
            this.DeumosGroupBo.Text = "Opt.#2";
            // 
            // groupBox21m
            // 
            this.groupBox21m.Controls.Add(this.numUpDownDelay);
            this.groupBox21m.Controls.Add(this.chckDelay);
            this.groupBox21m.Controls.Add(this.groupBox22b);
            this.groupBox21m.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox21m.Location = new System.Drawing.Point(5, 173);
            this.groupBox21m.Name = "groupBox21m";
            this.groupBox21m.Size = new System.Drawing.Size(269, 37);
            this.groupBox21m.TabIndex = 3;
            this.groupBox21m.TabStop = false;
            this.groupBox21m.Text = "Other #2";
            // 
            // numUpDownDelay
            // 
            this.numUpDownDelay.Enabled = false;
            this.numUpDownDelay.Location = new System.Drawing.Point(125, 11);
            this.numUpDownDelay.Name = "numUpDownDelay";
            this.numUpDownDelay.Size = new System.Drawing.Size(36, 20);
            this.numUpDownDelay.TabIndex = 2;
            // 
            // chckDelay
            // 
            this.chckDelay.AutoSize = true;
            this.chckDelay.Location = new System.Drawing.Point(17, 13);
            this.chckDelay.Name = "chckDelay";
            this.chckDelay.Size = new System.Drawing.Size(103, 18);
            this.chckDelay.TabIndex = 1;
            this.chckDelay.Text = "Delay Execution";
            this.chckDelay.UseVisualStyleBackColor = true;
            this.chckDelay.CheckedChanged += new System.EventHandler(this.chckDelay_CheckedChanged);
            // 
            // groupBox22b
            // 
            this.groupBox22b.Controls.Add(this.rdbMinutes);
            this.groupBox22b.Controls.Add(this.rdbSeconds);
            this.groupBox22b.Location = new System.Drawing.Point(166, 4);
            this.groupBox22b.Name = "groupBox22b";
            this.groupBox22b.Size = new System.Drawing.Size(100, 27);
            this.groupBox22b.TabIndex = 0;
            this.groupBox22b.TabStop = false;
            // 
            // rdbMinutes
            // 
            this.rdbMinutes.AutoSize = true;
            this.rdbMinutes.Enabled = false;
            this.rdbMinutes.Location = new System.Drawing.Point(52, 8);
            this.rdbMinutes.Name = "rdbMinutes";
            this.rdbMinutes.Size = new System.Drawing.Size(41, 18);
            this.rdbMinutes.TabIndex = 1;
            this.rdbMinutes.Text = "Min";
            this.rdbMinutes.UseVisualStyleBackColor = true;
            // 
            // rdbSeconds
            // 
            this.rdbSeconds.AutoSize = true;
            this.rdbSeconds.Enabled = false;
            this.rdbSeconds.Location = new System.Drawing.Point(11, 8);
            this.rdbSeconds.Name = "rdbSeconds";
            this.rdbSeconds.Size = new System.Drawing.Size(44, 18);
            this.rdbSeconds.TabIndex = 0;
            this.rdbSeconds.Text = "Sec";
            this.rdbSeconds.UseVisualStyleBackColor = true;
            // 
            // txtDownloa
            // 
            this.txtDownloa.Controls.Add(this.txtBatch2);
            this.txtDownloa.Controls.Add(this.chckBatch);
            this.txtDownloa.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.txtDownloa.Location = new System.Drawing.Point(3, 86);
            this.txtDownloa.Name = "txtDownloa";
            this.txtDownloa.Size = new System.Drawing.Size(263, 89);
            this.txtDownloa.TabIndex = 2;
            this.txtDownloa.TabStop = false;
            this.txtDownloa.Text = "          Run Batch";
            // 
            // txtBatch2
            // 
            this.txtBatch2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.txtBatch2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBatch2.Location = new System.Drawing.Point(5, 17);
            this.txtBatch2.Name = "txtBatch2";
            this.txtBatch2.Size = new System.Drawing.Size(252, 66);
            this.txtBatch2.TabIndex = 1;
            this.txtBatch2.Text = "";
            // 
            // chckBatch
            // 
            this.chckBatch.AutoSize = true;
            this.chckBatch.Location = new System.Drawing.Point(15, 0);
            this.chckBatch.Name = "chckBatch";
            this.chckBatch.Size = new System.Drawing.Size(15, 14);
            this.chckBatch.TabIndex = 0;
            this.chckBatch.UseVisualStyleBackColor = true;
            this.chckBatch.CheckedChanged += new System.EventHandler(this.chckBatch_CheckedChanged);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.chckNETfile);
            this.groupBox19.Controls.Add(this.chckEOF);
            this.groupBox19.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox19.Location = new System.Drawing.Point(194, 26);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(72, 55);
            this.groupBox19.TabIndex = 1;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Other";
            // 
            // chckNETfile
            // 
            this.chckNETfile.AutoSize = true;
            this.chckNETfile.Location = new System.Drawing.Point(10, 31);
            this.chckNETfile.Name = "chckNETfile";
            this.chckNETfile.Size = new System.Drawing.Size(54, 18);
            this.chckNETfile.TabIndex = 1;
            this.chckNETfile.Text = ".Net ?";
            this.chckNETfile.UseVisualStyleBackColor = true;
            this.chckNETfile.CheckedChanged += new System.EventHandler(this.chckNETfile_CheckedChanged);
            // 
            // chckEOF
            // 
            this.chckEOF.AutoSize = true;
            this.chckEOF.Location = new System.Drawing.Point(10, 13);
            this.chckEOF.Name = "chckEOF";
            this.chckEOF.Size = new System.Drawing.Size(55, 18);
            this.chckEOF.TabIndex = 0;
            this.chckEOF.Text = "EOF ?";
            this.chckEOF.UseVisualStyleBackColor = true;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.txtMutex);
            this.groupBox18.Controls.Add(this.label8);
            this.groupBox18.Controls.Add(this.deumosButton1);
            this.groupBox18.Controls.Add(this.rdbmutletters);
            this.groupBox18.Controls.Add(this.rdbmutuni);
            this.groupBox18.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox18.Location = new System.Drawing.Point(4, 26);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(184, 55);
            this.groupBox18.TabIndex = 0;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Mutex";
            // 
            // txtMutex
            // 
            this.txtMutex.Boolean_0 = false;
            this.txtMutex.Boolean_1 = false;
            this.txtMutex.Boolean_2 = false;
            this.txtMutex.Boolean_3 = false;
            this.txtMutex.Boolean_4 = false;
            class0212.Color_0 = System.Drawing.Color.White;
            class0212.String_0 = "Text";
            class0213.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0213.String_0 = "Back";
            class0214.Color_0 = System.Drawing.Color.Black;
            class0214.String_0 = "Border1";
            class0215.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0215.String_0 = "Border2";
            this.txtMutex.Class0_0 = new Cryptex1.Class0[] {
        class0212,
        class0213,
        class0214,
        class0215};
            this.txtMutex.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtMutex.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtMutex.Image_0 = null;
            this.txtMutex.Int32_2 = 32767;
            this.txtMutex.Location = new System.Drawing.Point(40, 10);
            this.txtMutex.Name = "txtMutex";
            this.txtMutex.Size = new System.Drawing.Size(134, 24);
            this.txtMutex.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtMutex.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 14);
            this.label8.TabIndex = 3;
            this.label8.Text = "String:";
            // 
            // deumosButton1
            // 
            this.deumosButton1.Boolean_0 = false;
            this.deumosButton1.Image_0 = null;
            this.deumosButton1.Location = new System.Drawing.Point(145, 35);
            this.deumosButton1.Name = "deumosButton1";
            this.deumosButton1.Size = new System.Drawing.Size(28, 19);
            this.deumosButton1.TabIndex = 2;
            this.deumosButton1.Text = "Rnd";
            this.deumosButton1.Click += new System.EventHandler(this.deumosButton1_Click);
            // 
            // rdbmutletters
            // 
            this.rdbmutletters.AutoSize = true;
            this.rdbmutletters.Location = new System.Drawing.Point(7, 35);
            this.rdbmutletters.Name = "rdbmutletters";
            this.rdbmutletters.Size = new System.Drawing.Size(59, 18);
            this.rdbmutletters.TabIndex = 1;
            this.rdbmutletters.Text = "Letters";
            this.rdbmutletters.UseVisualStyleBackColor = true;
            // 
            // rdbmutuni
            // 
            this.rdbmutuni.AutoSize = true;
            this.rdbmutuni.Checked = true;
            this.rdbmutuni.Location = new System.Drawing.Point(65, 35);
            this.rdbmutuni.Name = "rdbmutuni";
            this.rdbmutuni.Size = new System.Drawing.Size(64, 18);
            this.rdbmutuni.TabIndex = 0;
            this.rdbmutuni.TabStop = true;
            this.rdbmutuni.Text = "Unicode";
            this.rdbmutuni.UseVisualStyleBackColor = true;
            // 
            // pan4
            // 
            this.pan4.Controls.Add(this.deumosGroupBox7);
            this.pan4.Location = new System.Drawing.Point(323, 508);
            this.pan4.Name = "pan4";
            this.pan4.Size = new System.Drawing.Size(277, 224);
            this.pan4.TabIndex = 1;
            // 
            // deumosGroupBox7
            // 
            this.deumosGroupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox7.Boolean_0 = true;
            this.deumosGroupBox7.Boolean_1 = true;
            this.deumosGroupBox7.Boolean_3 = false;
            class0216.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0216.String_0 = "Back";
            class0217.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0217.String_0 = "MainFill";
            class0218.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0218.String_0 = "MainOutline1";
            class0219.Color_0 = System.Drawing.Color.Black;
            class0219.String_0 = "MainOutline2";
            class0220.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0220.String_0 = "TitleShadow";
            class0221.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0221.String_0 = "TitleFill";
            class0222.Color_0 = System.Drawing.Color.White;
            class0222.String_0 = "Text";
            class0223.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0223.String_0 = "TitleOutline1";
            class0224.Color_0 = System.Drawing.Color.Black;
            class0224.String_0 = "TitleOutline2";
            this.deumosGroupBox7.Class0_0 = new Cryptex1.Class0[] {
        class0216,
        class0217,
        class0218,
        class0219,
        class0220,
        class0221,
        class0222,
        class0223,
        class0224};
            this.deumosGroupBox7.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox7.Controls.Add(this.groupBox6b);
            this.deumosGroupBox7.Controls.Add(this.grpStorage);
            this.deumosGroupBox7.Controls.Add(this.groupBox6);
            this.deumosGroupBox7.Controls.Add(this.groupBox33);
            this.deumosGroupBox7.Controls.Add(this.groupBox8);
            this.deumosGroupBox7.Controls.Add(this.groupBox1);
            this.deumosGroupBox7.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deumosGroupBox7.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox7.Image_0 = null;
            this.deumosGroupBox7.Location = new System.Drawing.Point(2, 2);
            this.deumosGroupBox7.Name = "deumosGroupBox7";
            this.deumosGroupBox7.Size = new System.Drawing.Size(273, 213);
            this.deumosGroupBox7.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox7.TabIndex = 0;
            this.deumosGroupBox7.Text = "Main";
            // 
            // groupBox6b
            // 
            this.groupBox6b.Controls.Add(this.rdbCrypt2x);
            this.groupBox6b.Controls.Add(this.rdbCryptNormal);
            this.groupBox6b.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox6b.Location = new System.Drawing.Point(7, 175);
            this.groupBox6b.Name = "groupBox6b";
            this.groupBox6b.Size = new System.Drawing.Size(151, 32);
            this.groupBox6b.TabIndex = 5;
            this.groupBox6b.TabStop = false;
            this.groupBox6b.Text = "Crypting Type";
            // 
            // rdbCrypt2x
            // 
            this.rdbCrypt2x.AutoSize = true;
            this.rdbCrypt2x.Checked = true;
            this.rdbCrypt2x.Location = new System.Drawing.Point(62, 12);
            this.rdbCrypt2x.Name = "rdbCrypt2x";
            this.rdbCrypt2x.Size = new System.Drawing.Size(81, 18);
            this.rdbCrypt2x.TabIndex = 1;
            this.rdbCrypt2x.TabStop = true;
            this.rdbCrypt2x.Text = "2x-Crypting";
            this.rdbCrypt2x.UseVisualStyleBackColor = true;
            // 
            // rdbCryptNormal
            // 
            this.rdbCryptNormal.AutoSize = true;
            this.rdbCryptNormal.Location = new System.Drawing.Point(4, 12);
            this.rdbCryptNormal.Name = "rdbCryptNormal";
            this.rdbCryptNormal.Size = new System.Drawing.Size(58, 18);
            this.rdbCryptNormal.TabIndex = 0;
            this.rdbCryptNormal.Text = "Normal";
            this.rdbCryptNormal.UseVisualStyleBackColor = true;
            this.rdbCryptNormal.CheckedChanged += new System.EventHandler(this.rdbCryptNormal_CheckedChanged);
            // 
            // grpStorage
            // 
            this.grpStorage.Controls.Add(this.rdbStorBytes);
            this.grpStorage.Controls.Add(this.rdbStorString);
            this.grpStorage.Controls.Add(this.rdbStorBase);
            this.grpStorage.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpStorage.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.grpStorage.Location = new System.Drawing.Point(162, 142);
            this.grpStorage.Name = "grpStorage";
            this.grpStorage.Size = new System.Drawing.Size(107, 65);
            this.grpStorage.TabIndex = 4;
            this.grpStorage.TabStop = false;
            this.grpStorage.Text = "Storage Method";
            // 
            // rdbStorBytes
            // 
            this.rdbStorBytes.AutoSize = true;
            this.rdbStorBytes.Location = new System.Drawing.Point(5, 13);
            this.rdbStorBytes.Name = "rdbStorBytes";
            this.rdbStorBytes.Size = new System.Drawing.Size(53, 18);
            this.rdbStorBytes.TabIndex = 2;
            this.rdbStorBytes.Text = "Bytes";
            this.rdbStorBytes.UseVisualStyleBackColor = true;
            // 
            // rdbStorString
            // 
            this.rdbStorString.AutoSize = true;
            this.rdbStorString.Checked = true;
            this.rdbStorString.Location = new System.Drawing.Point(5, 29);
            this.rdbStorString.Name = "rdbStorString";
            this.rdbStorString.Size = new System.Drawing.Size(91, 18);
            this.rdbStorString.TabIndex = 1;
            this.rdbStorString.TabStop = true;
            this.rdbStorString.Text = "Default-String";
            this.rdbStorString.UseVisualStyleBackColor = true;
            // 
            // rdbStorBase
            // 
            this.rdbStorBase.AutoSize = true;
            this.rdbStorBase.Location = new System.Drawing.Point(5, 45);
            this.rdbStorBase.Name = "rdbStorBase";
            this.rdbStorBase.Size = new System.Drawing.Size(94, 18);
            this.rdbStorBase.TabIndex = 0;
            this.rdbStorBase.Text = "Base64-String";
            this.rdbStorBase.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label1);
            this.groupBox6.Controls.Add(this.txtInjectInto);
            this.groupBox6.ForeColor = System.Drawing.Color.DarkOrange;
            this.groupBox6.Location = new System.Drawing.Point(134, 99);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(134, 41);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Inject Into";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.label1.Location = new System.Drawing.Point(84, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 14);
            this.label1.TabIndex = 1;
            this.label1.Text = ".exe";
            // 
            // txtInjectInto
            // 
            this.txtInjectInto.Boolean_0 = false;
            this.txtInjectInto.Boolean_1 = false;
            this.txtInjectInto.Boolean_2 = false;
            this.txtInjectInto.Boolean_3 = false;
            this.txtInjectInto.Boolean_4 = false;
            class0225.Color_0 = System.Drawing.Color.White;
            class0225.String_0 = "Text";
            class0226.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0226.String_0 = "Back";
            class0227.Color_0 = System.Drawing.Color.Black;
            class0227.String_0 = "Border1";
            class0228.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0228.String_0 = "Border2";
            this.txtInjectInto.Class0_0 = new Cryptex1.Class0[] {
        class0225,
        class0226,
        class0227,
        class0228};
            this.txtInjectInto.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtInjectInto.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtInjectInto.Image_0 = null;
            this.txtInjectInto.Int32_2 = 32767;
            this.txtInjectInto.Location = new System.Drawing.Point(6, 11);
            this.txtInjectInto.Name = "txtInjectInto";
            this.txtInjectInto.Size = new System.Drawing.Size(75, 24);
            this.txtInjectInto.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtInjectInto.TabIndex = 0;
            this.txtInjectInto.Text = "svchost";
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.pictureBox1);
            this.groupBox33.Controls.Add(this.muButton3);
            this.groupBox33.Controls.Add(this.muButton2);
            this.groupBox33.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox33.Location = new System.Drawing.Point(6, 99);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(115, 62);
            this.groupBox33.TabIndex = 2;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "Icon";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(7, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(56, 43);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // muButton3
            // 
            this.muButton3.Boolean_0 = false;
            this.muButton3.Image_0 = null;
            this.muButton3.Location = new System.Drawing.Point(67, 34);
            this.muButton3.Name = "muButton3";
            this.muButton3.Size = new System.Drawing.Size(41, 23);
            this.muButton3.TabIndex = 1;
            this.muButton3.Text = "...";
            this.muButton3.Click += new System.EventHandler(this.muButton3_Click);
            // 
            // muButton2
            // 
            this.muButton2.Boolean_0 = false;
            this.muButton2.Image_0 = null;
            this.muButton2.Location = new System.Drawing.Point(67, 11);
            this.muButton2.Name = "muButton2";
            this.muButton2.Size = new System.Drawing.Size(42, 23);
            this.muButton2.TabIndex = 0;
            this.muButton2.Text = "Clear";
            this.muButton2.Click += new System.EventHandler(this.muButton2_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.rdbRunPE7);
            this.groupBox8.Controls.Add(this.rdbRunPE6);
            this.groupBox8.Controls.Add(this.rdbRunPE5);
            this.groupBox8.Controls.Add(this.rdbRunPE4);
            this.groupBox8.Controls.Add(this.rdbRunPE3);
            this.groupBox8.Controls.Add(this.rdbRunPE2);
            this.groupBox8.Controls.Add(this.rdbRunPE1);
            this.groupBox8.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox8.Location = new System.Drawing.Point(8, 68);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(263, 29);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "RunPE";
            // 
            // rdbRunPE7
            // 
            this.rdbRunPE7.AutoSize = true;
            this.rdbRunPE7.Location = new System.Drawing.Point(224, 10);
            this.rdbRunPE7.Name = "rdbRunPE7";
            this.rdbRunPE7.Size = new System.Drawing.Size(37, 18);
            this.rdbRunPE7.TabIndex = 6;
            this.rdbRunPE7.Text = "#7";
            this.rdbRunPE7.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE6
            // 
            this.rdbRunPE6.AutoSize = true;
            this.rdbRunPE6.Checked = true;
            this.rdbRunPE6.Location = new System.Drawing.Point(187, 10);
            this.rdbRunPE6.Name = "rdbRunPE6";
            this.rdbRunPE6.Size = new System.Drawing.Size(37, 18);
            this.rdbRunPE6.TabIndex = 5;
            this.rdbRunPE6.TabStop = true;
            this.rdbRunPE6.Text = "#6";
            this.rdbRunPE6.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE5
            // 
            this.rdbRunPE5.AutoSize = true;
            this.rdbRunPE5.Location = new System.Drawing.Point(151, 9);
            this.rdbRunPE5.Name = "rdbRunPE5";
            this.rdbRunPE5.Size = new System.Drawing.Size(37, 18);
            this.rdbRunPE5.TabIndex = 4;
            this.rdbRunPE5.Text = "#5";
            this.rdbRunPE5.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE4
            // 
            this.rdbRunPE4.AutoSize = true;
            this.rdbRunPE4.Location = new System.Drawing.Point(115, 10);
            this.rdbRunPE4.Name = "rdbRunPE4";
            this.rdbRunPE4.Size = new System.Drawing.Size(37, 18);
            this.rdbRunPE4.TabIndex = 3;
            this.rdbRunPE4.Text = "#4";
            this.rdbRunPE4.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE3
            // 
            this.rdbRunPE3.AutoSize = true;
            this.rdbRunPE3.Location = new System.Drawing.Point(78, 9);
            this.rdbRunPE3.Name = "rdbRunPE3";
            this.rdbRunPE3.Size = new System.Drawing.Size(37, 18);
            this.rdbRunPE3.TabIndex = 2;
            this.rdbRunPE3.Text = "#3";
            this.rdbRunPE3.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE2
            // 
            this.rdbRunPE2.AutoSize = true;
            this.rdbRunPE2.Location = new System.Drawing.Point(41, 10);
            this.rdbRunPE2.Name = "rdbRunPE2";
            this.rdbRunPE2.Size = new System.Drawing.Size(37, 18);
            this.rdbRunPE2.TabIndex = 1;
            this.rdbRunPE2.Text = "#2";
            this.rdbRunPE2.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE1
            // 
            this.rdbRunPE1.AutoSize = true;
            this.rdbRunPE1.Location = new System.Drawing.Point(6, 10);
            this.rdbRunPE1.Name = "rdbRunPE1";
            this.rdbRunPE1.Size = new System.Drawing.Size(37, 18);
            this.rdbRunPE1.TabIndex = 0;
            this.rdbRunPE1.Text = "#1";
            this.rdbRunPE1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.muButton10);
            this.groupBox1.Controls.Add(this.muButton9);
            this.groupBox1.Controls.Add(this.txtCryptFile);
            this.groupBox1.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox1.Location = new System.Drawing.Point(8, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(263, 40);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "File";
            // 
            // muButton10
            // 
            this.muButton10.Boolean_0 = false;
            this.muButton10.Image_0 = null;
            this.muButton10.Location = new System.Drawing.Point(170, 13);
            this.muButton10.Name = "muButton10";
            this.muButton10.Size = new System.Drawing.Size(42, 23);
            this.muButton10.TabIndex = 5;
            this.muButton10.Text = "Clear";
            this.muButton10.Click += new System.EventHandler(this.muButton10_Click);
            // 
            // muButton9
            // 
            this.muButton9.Boolean_0 = false;
            this.muButton9.Image_0 = null;
            this.muButton9.Location = new System.Drawing.Point(213, 13);
            this.muButton9.Name = "muButton9";
            this.muButton9.Size = new System.Drawing.Size(41, 23);
            this.muButton9.TabIndex = 4;
            this.muButton9.Text = "...";
            this.muButton9.Click += new System.EventHandler(this.muButton9_Click);
            // 
            // txtCryptFile
            // 
            this.txtCryptFile.Boolean_0 = false;
            this.txtCryptFile.Boolean_1 = false;
            this.txtCryptFile.Boolean_2 = false;
            this.txtCryptFile.Boolean_3 = false;
            this.txtCryptFile.Boolean_4 = false;
            class0229.Color_0 = System.Drawing.Color.White;
            class0229.String_0 = "Text";
            class0230.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0230.String_0 = "Back";
            class0231.Color_0 = System.Drawing.Color.Black;
            class0231.String_0 = "Border1";
            class0232.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0232.String_0 = "Border2";
            this.txtCryptFile.Class0_0 = new Cryptex1.Class0[] {
        class0229,
        class0230,
        class0231,
        class0232};
            this.txtCryptFile.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtCryptFile.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCryptFile.Image_0 = null;
            this.txtCryptFile.Int32_2 = 32767;
            this.txtCryptFile.Location = new System.Drawing.Point(7, 12);
            this.txtCryptFile.Name = "txtCryptFile";
            this.txtCryptFile.Size = new System.Drawing.Size(157, 24);
            this.txtCryptFile.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtCryptFile.TabIndex = 3;
            // 
            // pan11
            // 
            this.pan11.Controls.Add(this.grpAntis);
            this.pan11.Location = new System.Drawing.Point(1094, 264);
            this.pan11.Name = "pan11";
            this.pan11.Size = new System.Drawing.Size(281, 233);
            this.pan11.TabIndex = 16;
            // 
            // grpAntis
            // 
            this.grpAntis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.grpAntis.Boolean_0 = true;
            this.grpAntis.Boolean_1 = true;
            this.grpAntis.Boolean_3 = false;
            class0233.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0233.String_0 = "Back";
            class0234.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0234.String_0 = "MainFill";
            class0235.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0235.String_0 = "MainOutline1";
            class0236.Color_0 = System.Drawing.Color.Black;
            class0236.String_0 = "MainOutline2";
            class0237.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0237.String_0 = "TitleShadow";
            class0238.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0238.String_0 = "TitleFill";
            class0239.Color_0 = System.Drawing.Color.White;
            class0239.String_0 = "Text";
            class0240.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0240.String_0 = "TitleOutline1";
            class0241.Color_0 = System.Drawing.Color.Black;
            class0241.String_0 = "TitleOutline2";
            this.grpAntis.Class0_0 = new Cryptex1.Class0[] {
        class0233,
        class0234,
        class0235,
        class0236,
        class0237,
        class0238,
        class0239,
        class0240,
        class0241};
            this.grpAntis.Color_0 = System.Drawing.Color.Empty;
            this.grpAntis.Controls.Add(this.groupBox28);
            this.grpAntis.Controls.Add(this.groupBox27);
            this.grpAntis.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpAntis.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.grpAntis.Image_0 = null;
            this.grpAntis.Location = new System.Drawing.Point(3, 3);
            this.grpAntis.Name = "grpAntis";
            this.grpAntis.Size = new System.Drawing.Size(270, 225);
            this.grpAntis.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.grpAntis.TabIndex = 14;
            this.grpAntis.Text = "Anties & Whatnot";
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.lstProc);
            this.groupBox28.Controls.Add(this.txtProcess);
            this.groupBox28.Controls.Add(this.muButton12);
            this.groupBox28.Controls.Add(this.muButton13);
            this.groupBox28.Controls.Add(this.label9);
            this.groupBox28.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox28.Location = new System.Drawing.Point(5, 79);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(263, 122);
            this.groupBox28.TabIndex = 1;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Process Killer";
            // 
            // lstProc
            // 
            this.lstProc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.lstProc.FormattingEnabled = true;
            this.lstProc.ItemHeight = 14;
            this.lstProc.Location = new System.Drawing.Point(10, 24);
            this.lstProc.Name = "lstProc";
            this.lstProc.Size = new System.Drawing.Size(148, 74);
            this.lstProc.TabIndex = 4;
            // 
            // txtProcess
            // 
            this.txtProcess.Location = new System.Drawing.Point(165, 89);
            this.txtProcess.Name = "txtProcess";
            this.txtProcess.Size = new System.Drawing.Size(94, 20);
            this.txtProcess.TabIndex = 3;
            // 
            // muButton12
            // 
            this.muButton12.Boolean_0 = false;
            this.muButton12.Image_0 = null;
            this.muButton12.Location = new System.Drawing.Point(163, 60);
            this.muButton12.Name = "muButton12";
            this.muButton12.Size = new System.Drawing.Size(97, 23);
            this.muButton12.TabIndex = 2;
            this.muButton12.Text = "Add";
            this.muButton12.Click += new System.EventHandler(this.muButton12_Click);
            // 
            // muButton13
            // 
            this.muButton13.Boolean_0 = false;
            this.muButton13.Image_0 = null;
            this.muButton13.Location = new System.Drawing.Point(162, 34);
            this.muButton13.Name = "muButton13";
            this.muButton13.Size = new System.Drawing.Size(97, 23);
            this.muButton13.TabIndex = 1;
            this.muButton13.Text = "Clear";
            this.muButton13.Click += new System.EventHandler(this.muButton13_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(162, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 14);
            this.label9.TabIndex = 0;
            this.label9.Text = "Don\'t use \\\".exe\\\"\"";
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.rdbKill);
            this.groupBox27.Controls.Add(this.rdbExit);
            this.groupBox27.Controls.Add(this.rdbKillExit);
            this.groupBox27.Controls.Add(this.chckAnties);
            this.groupBox27.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox27.Location = new System.Drawing.Point(5, 31);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(263, 42);
            this.groupBox27.TabIndex = 0;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "        Anties";
            // 
            // rdbKill
            // 
            this.rdbKill.AutoSize = true;
            this.rdbKill.Enabled = false;
            this.rdbKill.Location = new System.Drawing.Point(15, 16);
            this.rdbKill.Name = "rdbKill";
            this.rdbKill.Size = new System.Drawing.Size(69, 18);
            this.rdbKill.TabIndex = 3;
            this.rdbKill.TabStop = true;
            this.rdbKill.Text = "Try to Kill";
            this.rdbKill.UseVisualStyleBackColor = true;
            // 
            // rdbExit
            // 
            this.rdbExit.AutoSize = true;
            this.rdbExit.Enabled = false;
            this.rdbExit.Location = new System.Drawing.Point(94, 16);
            this.rdbExit.Name = "rdbExit";
            this.rdbExit.Size = new System.Drawing.Size(64, 18);
            this.rdbExit.TabIndex = 2;
            this.rdbExit.TabStop = true;
            this.rdbExit.Text = "Exit App";
            this.rdbExit.UseVisualStyleBackColor = true;
            // 
            // rdbKillExit
            // 
            this.rdbKillExit.AutoSize = true;
            this.rdbKillExit.Enabled = false;
            this.rdbKillExit.Location = new System.Drawing.Point(168, 16);
            this.rdbKillExit.Name = "rdbKillExit";
            this.rdbKillExit.Size = new System.Drawing.Size(89, 18);
            this.rdbKillExit.TabIndex = 1;
            this.rdbKillExit.TabStop = true;
            this.rdbKillExit.Text = "Kill + Exit App";
            this.rdbKillExit.UseVisualStyleBackColor = true;
            // 
            // chckAnties
            // 
            this.chckAnties.AutoSize = true;
            this.chckAnties.Enabled = false;
            this.chckAnties.Location = new System.Drawing.Point(13, 0);
            this.chckAnties.Name = "chckAnties";
            this.chckAnties.Size = new System.Drawing.Size(15, 14);
            this.chckAnties.TabIndex = 0;
            this.chckAnties.UseVisualStyleBackColor = true;
            this.chckAnties.CheckedChanged += new System.EventHandler(this.chckAnties_CheckedChanged);
            // 
            // pan1
            // 
            this.pan1.Controls.Add(this.deumosGroupBox1);
            this.pan1.Location = new System.Drawing.Point(91, 34);
            this.pan1.Name = "pan1";
            this.pan1.Size = new System.Drawing.Size(281, 225);
            this.pan1.TabIndex = 9;
            this.pan1.Visible = false;
            // 
            // deumosGroupBox1
            // 
            this.deumosGroupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.deumosGroupBox1.Boolean_0 = true;
            this.deumosGroupBox1.Boolean_1 = true;
            this.deumosGroupBox1.Boolean_3 = false;
            class0242.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0242.String_0 = "Back";
            class0243.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0243.String_0 = "MainFill";
            class0244.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0244.String_0 = "MainOutline1";
            class0245.Color_0 = System.Drawing.Color.Black;
            class0245.String_0 = "MainOutline2";
            class0246.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class0246.String_0 = "TitleShadow";
            class0247.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class0247.String_0 = "TitleFill";
            class0248.Color_0 = System.Drawing.Color.White;
            class0248.String_0 = "Text";
            class0249.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class0249.String_0 = "TitleOutline1";
            class0250.Color_0 = System.Drawing.Color.Black;
            class0250.String_0 = "TitleOutline2";
            this.deumosGroupBox1.Class0_0 = new Cryptex1.Class0[] {
        class0242,
        class0243,
        class0244,
        class0245,
        class0246,
        class0247,
        class0248,
        class0249,
        class0250};
            this.deumosGroupBox1.Color_0 = System.Drawing.Color.Empty;
            this.deumosGroupBox1.Controls.Add(this.muButton6);
            this.deumosGroupBox1.Controls.Add(this.muButton7);
            this.deumosGroupBox1.Controls.Add(this.muButton8);
            this.deumosGroupBox1.Controls.Add(this.rdbDLapp);
            this.deumosGroupBox1.Controls.Add(this.rdbDLTemp);
            this.deumosGroupBox1.Controls.Add(this.rdbDLsystem);
            this.deumosGroupBox1.Controls.Add(this.groupBox23);
            this.deumosGroupBox1.Controls.Add(this.chckProxy);
            this.deumosGroupBox1.Controls.Add(this.txtDownloadLink);
            this.deumosGroupBox1.Controls.Add(this.lstDownloadLinks);
            this.deumosGroupBox1.Font = new System.Drawing.Font("Arial", 8F);
            this.deumosGroupBox1.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.deumosGroupBox1.Image_0 = null;
            this.deumosGroupBox1.Location = new System.Drawing.Point(6, 4);
            this.deumosGroupBox1.Name = "deumosGroupBox1";
            this.deumosGroupBox1.Size = new System.Drawing.Size(270, 214);
            this.deumosGroupBox1.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.deumosGroupBox1.TabIndex = 0;
            this.deumosGroupBox1.Text = "Downloader";
            // 
            // muButton6
            // 
            this.muButton6.Boolean_0 = false;
            this.muButton6.Image_0 = null;
            this.muButton6.Location = new System.Drawing.Point(14, 131);
            this.muButton6.Name = "muButton6";
            this.muButton6.Size = new System.Drawing.Size(52, 23);
            this.muButton6.TabIndex = 10;
            this.muButton6.Text = "Add";
            this.muButton6.Click += new System.EventHandler(this.muButton6_Click);
            // 
            // muButton7
            // 
            this.muButton7.Boolean_0 = false;
            this.muButton7.Image_0 = null;
            this.muButton7.Location = new System.Drawing.Point(93, 131);
            this.muButton7.Name = "muButton7";
            this.muButton7.Size = new System.Drawing.Size(90, 23);
            this.muButton7.TabIndex = 9;
            this.muButton7.Text = "Del Selected";
            this.muButton7.Click += new System.EventHandler(this.muButton7_Click);
            // 
            // muButton8
            // 
            this.muButton8.Boolean_0 = false;
            this.muButton8.Image_0 = null;
            this.muButton8.Location = new System.Drawing.Point(208, 131);
            this.muButton8.Name = "muButton8";
            this.muButton8.Size = new System.Drawing.Size(55, 23);
            this.muButton8.TabIndex = 8;
            this.muButton8.Text = "Clear All";
            this.muButton8.Click += new System.EventHandler(this.muButton8_Click);
            // 
            // rdbDLapp
            // 
            this.rdbDLapp.AutoSize = true;
            this.rdbDLapp.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbDLapp.Location = new System.Drawing.Point(12, 151);
            this.rdbDLapp.Name = "rdbDLapp";
            this.rdbDLapp.Size = new System.Drawing.Size(67, 18);
            this.rdbDLapp.TabIndex = 7;
            this.rdbDLapp.TabStop = true;
            this.rdbDLapp.Text = "AppData";
            this.rdbDLapp.UseVisualStyleBackColor = true;
            // 
            // rdbDLTemp
            // 
            this.rdbDLTemp.AutoSize = true;
            this.rdbDLTemp.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbDLTemp.Location = new System.Drawing.Point(113, 156);
            this.rdbDLTemp.Name = "rdbDLTemp";
            this.rdbDLTemp.Size = new System.Drawing.Size(50, 18);
            this.rdbDLTemp.TabIndex = 6;
            this.rdbDLTemp.TabStop = true;
            this.rdbDLTemp.Text = "Temp";
            this.rdbDLTemp.UseVisualStyleBackColor = true;
            // 
            // rdbDLsystem
            // 
            this.rdbDLsystem.AutoSize = true;
            this.rdbDLsystem.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.rdbDLsystem.Location = new System.Drawing.Point(200, 154);
            this.rdbDLsystem.Name = "rdbDLsystem";
            this.rdbDLsystem.Size = new System.Drawing.Size(61, 18);
            this.rdbDLsystem.TabIndex = 5;
            this.rdbDLsystem.TabStop = true;
            this.rdbDLsystem.Text = "System";
            this.rdbDLsystem.UseVisualStyleBackColor = true;
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.rdbStart);
            this.groupBox23.Controls.Add(this.rdbEnd);
            this.groupBox23.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.groupBox23.Location = new System.Drawing.Point(10, 174);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(107, 30);
            this.groupBox23.TabIndex = 3;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Run On:";
            // 
            // rdbStart
            // 
            this.rdbStart.AutoSize = true;
            this.rdbStart.Location = new System.Drawing.Point(7, 11);
            this.rdbStart.Name = "rdbStart";
            this.rdbStart.Size = new System.Drawing.Size(48, 18);
            this.rdbStart.TabIndex = 1;
            this.rdbStart.TabStop = true;
            this.rdbStart.Text = "Start";
            this.rdbStart.UseVisualStyleBackColor = true;
            // 
            // rdbEnd
            // 
            this.rdbEnd.AutoSize = true;
            this.rdbEnd.Location = new System.Drawing.Point(57, 11);
            this.rdbEnd.Name = "rdbEnd";
            this.rdbEnd.Size = new System.Drawing.Size(43, 18);
            this.rdbEnd.TabIndex = 0;
            this.rdbEnd.TabStop = true;
            this.rdbEnd.Text = "End";
            this.rdbEnd.UseVisualStyleBackColor = true;
            // 
            // chckProxy
            // 
            this.chckProxy.AutoSize = true;
            this.chckProxy.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.chckProxy.Location = new System.Drawing.Point(137, 178);
            this.chckProxy.Name = "chckProxy";
            this.chckProxy.Size = new System.Drawing.Size(105, 32);
            this.chckProxy.TabIndex = 2;
            this.chckProxy.Text = "Set Proxy to Null\r\n(Anti-Fiddle)";
            this.chckProxy.UseVisualStyleBackColor = true;
            // 
            // txtDownloadLink
            // 
            this.txtDownloadLink.Boolean_0 = false;
            this.txtDownloadLink.Boolean_1 = false;
            this.txtDownloadLink.Boolean_2 = false;
            this.txtDownloadLink.Boolean_3 = false;
            this.txtDownloadLink.Boolean_4 = false;
            class0251.Color_0 = System.Drawing.Color.White;
            class0251.String_0 = "Text";
            class0252.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class0252.String_0 = "Back";
            class0253.Color_0 = System.Drawing.Color.Black;
            class0253.String_0 = "Border1";
            class0254.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            class0254.String_0 = "Border2";
            this.txtDownloadLink.Class0_0 = new Cryptex1.Class0[] {
        class0251,
        class0252,
        class0253,
        class0254};
            this.txtDownloadLink.Font = new System.Drawing.Font("Verdana", 8F);
            this.txtDownloadLink.HorizontalAlignment_0 = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtDownloadLink.Image_0 = null;
            this.txtDownloadLink.Int32_2 = 32767;
            this.txtDownloadLink.Location = new System.Drawing.Point(10, 100);
            this.txtDownloadLink.Name = "txtDownloadLink";
            this.txtDownloadLink.Size = new System.Drawing.Size(249, 24);
            this.txtDownloadLink.String_0 = "/////w4ODv8AAAD/Hh4e/w==";
            this.txtDownloadLink.TabIndex = 1;
            this.txtDownloadLink.Text = "http://www.linkhere.com/path.exe";
            // 
            // lstDownloadLinks
            // 
            this.lstDownloadLinks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            this.lstDownloadLinks.FormattingEnabled = true;
            this.lstDownloadLinks.ItemHeight = 14;
            this.lstDownloadLinks.Location = new System.Drawing.Point(10, 31);
            this.lstDownloadLinks.Name = "lstDownloadLinks";
            this.lstDownloadLinks.Size = new System.Drawing.Size(248, 60);
            this.lstDownloadLinks.TabIndex = 0;
            // 
            // control91
            // 
            this.control91.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.control91.Boolean_0 = true;
            this.control91.Boolean_1 = true;
            this.control91.Boolean_3 = false;
            class01.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            class01.String_0 = "Back";
            class02.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class02.String_0 = "MainFill";
            class03.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class03.String_0 = "MainOutline1";
            class04.Color_0 = System.Drawing.Color.Black;
            class04.String_0 = "MainOutline2";
            class05.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            class05.String_0 = "TitleShadow";
            class06.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            class06.String_0 = "TitleFill";
            class07.Color_0 = System.Drawing.Color.White;
            class07.String_0 = "Text";
            class08.Color_0 = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            class08.String_0 = "TitleOutline1";
            class09.Color_0 = System.Drawing.Color.Black;
            class09.String_0 = "TitleOutline2";
            this.control91.Class0_0 = new Cryptex1.Class0[] {
        class01,
        class02,
        class03,
        class04,
        class05,
        class06,
        class07,
        class08,
        class09};
            this.control91.Color_0 = System.Drawing.Color.Empty;
            this.control91.Font = new System.Drawing.Font("Verdana", 8F);
            this.control91.FormBorderStyle_0 = System.Windows.Forms.FormBorderStyle.None;
            this.control91.Image_0 = null;
            this.control91.Location = new System.Drawing.Point(378, 172);
            this.control91.Name = "control91";
            this.control91.Size = new System.Drawing.Size(147, 155);
            this.control91.String_0 = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//////yAgIP8AAAD/";
            this.control91.TabIndex = 63;
            this.control91.Text = "control91";
            // 
            // Form1
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 742);
            this.Controls.Add(this.control161);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.control161.ResumeLayout(false);
            this.control161.PerformLayout();
            this.pan5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.deumosGroupBox12.ResumeLayout(false);
            this.deumosGroupBox14.ResumeLayout(false);
            this.deumosGroupBox14.PerformLayout();
            this.deumosGroupBox15.ResumeLayout(false);
            this.deumosGroupBox15.PerformLayout();
            this.pan7.ResumeLayout(false);
            this.deumosGroupBox9.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.pan6.ResumeLayout(false);
            this.deumosGroupBox6.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.intRevision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.intBuild)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.intMinor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.intMajor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AssemblyLenght)).EndInit();
            this.pan2.ResumeLayout(false);
            this.deumosGroupBox2.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.pan10.ResumeLayout(false);
            this.deumosGroupBox10.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupEnc2.ResumeLayout(false);
            this.groupEnc2.PerformLayout();
            this.pan3.ResumeLayout(false);
            this.deumosGroupBox5.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numVariableLength)).EndInit();
            this.muButton13kk.ResumeLayout(false);
            this.muButton13kk.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRandomStringLength)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.pan8.ResumeLayout(false);
            this.deumosGroupBox3.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.grpEncryption.ResumeLayout(false);
            this.grpEncryption.PerformLayout();
            this.pan12.ResumeLayout(false);
            this.deumosGroupBox13.ResumeLayout(false);
            this.grpPic.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picMn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picEnc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRunPE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRest)).EndInit();
            this.grpPicBtn.ResumeLayout(false);
            this.grpPicBtn.PerformLayout();
            this.pan9.ResumeLayout(false);
            this.DeumosGroupBo.ResumeLayout(false);
            this.groupBox21m.ResumeLayout(false);
            this.groupBox21m.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numUpDownDelay)).EndInit();
            this.groupBox22b.ResumeLayout(false);
            this.groupBox22b.PerformLayout();
            this.txtDownloa.ResumeLayout(false);
            this.txtDownloa.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.pan4.ResumeLayout(false);
            this.deumosGroupBox7.ResumeLayout(false);
            this.groupBox6b.ResumeLayout(false);
            this.groupBox6b.PerformLayout();
            this.grpStorage.ResumeLayout(false);
            this.grpStorage.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox33.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.pan11.ResumeLayout(false);
            this.grpAntis.ResumeLayout(false);
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.pan1.ResumeLayout(false);
            this.deumosGroupBox1.ResumeLayout(false);
            this.deumosGroupBox1.PerformLayout();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Control16 control161;
        private System.Windows.Forms.Panel pan8;
        private Control9 deumosGroupBox3;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.RadioButton rdbLettersKey;
        private System.Windows.Forms.RadioButton rdbUnicodeKey;
        private System.Windows.Forms.RadioButton rdbChinKey;
        private Control14 randomPool1;
        private System.Windows.Forms.GroupBox grpEncryption;
        private System.Windows.Forms.RadioButton radioButton34;
        private System.Windows.Forms.RadioButton rdbPolyRev;
        private System.Windows.Forms.RadioButton rdbPolyStairs;
        private System.Windows.Forms.RadioButton rdbPolyAES;
        private System.Windows.Forms.RadioButton rdbRC4;
        private System.Windows.Forms.RadioButton rdbRSM;
        private System.Windows.Forms.RadioButton rdbPoly3DES;
        private System.Windows.Forms.RadioButton rdbPolyCloud;
        private System.Windows.Forms.RadioButton rdbAES;
        private System.Windows.Forms.RadioButton rdbRijndael;
        private System.Windows.Forms.RadioButton rdbPolyBaby;
        private System.Windows.Forms.RadioButton rdbPolyDex;
        private System.Windows.Forms.RadioButton rdbStairs;
        private System.Windows.Forms.RadioButton rdbPolyRC2;
        private System.Windows.Forms.RadioButton rdbXOR;
        private System.Windows.Forms.RadioButton radioButton19;
        private System.Windows.Forms.RadioButton rdbBind1;
        private System.Windows.Forms.RadioButton rdbDex;
        private System.Windows.Forms.RadioButton rdbPolyDES;
        private System.Windows.Forms.RadioButton rdbSymetric;
        private System.Windows.Forms.RadioButton rdbPolySym;
        private System.Windows.Forms.Panel pan4;
        private Control9 deumosGroupBox7;
        private System.Windows.Forms.GroupBox groupBox6b;
        private System.Windows.Forms.RadioButton rdbCrypt2x;
        private System.Windows.Forms.RadioButton rdbCryptNormal;
        private System.Windows.Forms.GroupBox grpStorage;
        private System.Windows.Forms.RadioButton rdbStorBytes;
        private System.Windows.Forms.RadioButton rdbStorString;
        private System.Windows.Forms.RadioButton rdbStorBase;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox33;
        private Control12 muButton3;
        private Control12 muButton2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.RadioButton rdbRunPE6;
        private System.Windows.Forms.RadioButton rdbRunPE5;
        private System.Windows.Forms.RadioButton rdbRunPE4;
        private System.Windows.Forms.RadioButton rdbRunPE3;
        private System.Windows.Forms.RadioButton rdbRunPE2;
        private System.Windows.Forms.RadioButton rdbRunPE1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel pan3;
        private Control9 deumosGroupBox5;
        private System.Windows.Forms.Panel pan12;
        private Control9 deumosGroupBox13;
        private System.Windows.Forms.Panel pan1;
        private Control9 deumosGroupBox1;
        private System.Windows.Forms.Panel pan9;
        private Control9 DeumosGroupBo;
        private System.Windows.Forms.Panel pan7;
        private Control9 deumosGroupBox9;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rdbMyDocuments;
        private System.Windows.Forms.RadioButton rdbDesktop;
        private System.Windows.Forms.RadioButton rdbResources;
        private System.Windows.Forms.RadioButton rdbProgramFiles;
        private System.Windows.Forms.RadioButton rdbWindows;
        private System.Windows.Forms.RadioButton rdbFavourites;
        private System.Windows.Forms.RadioButton rdbCookies;
        private System.Windows.Forms.RadioButton rdbSystem;
        private System.Windows.Forms.RadioButton rdbHistory;
        private System.Windows.Forms.RadioButton rdbAppData;
        private System.Windows.Forms.RadioButton rdbMyMusic;
        private System.Windows.Forms.RadioButton rdbSendTo;
        private System.Windows.Forms.RadioButton rdbStartMenu;
        private System.Windows.Forms.RadioButton rdbMyPrictures;
        private System.Windows.Forms.RadioButton rdbRecent;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.CheckBox chckActiveX;
        private System.Windows.Forms.CheckBox chckSubFolder;
        private System.Windows.Forms.RadioButton rdbStart1;
        private System.Windows.Forms.RadioButton rdbStart2;
        private System.Windows.Forms.CheckBox chckSUp2;
        private System.Windows.Forms.Panel pan10;
        private Control9 deumosGroupBox10;
        private Control2 txtKey2;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.RadioButton rdbLetterKey2;
        private System.Windows.Forms.RadioButton rdbUnicodeKey2;
        private System.Windows.Forms.RadioButton rdbChinKey2;
        private Control14 randomPool2;
        private System.Windows.Forms.GroupBox groupEnc2;
        private System.Windows.Forms.RadioButton rdbRC22;
        private System.Windows.Forms.RadioButton rdb3DES2;
        private System.Windows.Forms.RadioButton radioButton42;
        private System.Windows.Forms.RadioButton rdbPolyRev2;
        private System.Windows.Forms.RadioButton rdbPolyStairs2;
        private System.Windows.Forms.RadioButton rdbPolyAES2;
        private System.Windows.Forms.RadioButton rdbRC42;
        private System.Windows.Forms.RadioButton rdbRSM2;
        private System.Windows.Forms.RadioButton rdbPoly3DES2;
        private System.Windows.Forms.RadioButton rdbPolyCloud2;
        private System.Windows.Forms.RadioButton rdbAES2;
        private System.Windows.Forms.RadioButton rdbRijndael2;
        private System.Windows.Forms.RadioButton rdbPolyBaby2;
        private System.Windows.Forms.RadioButton rdbPolyDex2;
        private System.Windows.Forms.RadioButton rdbStairs2;
        private System.Windows.Forms.RadioButton rdbPolyRC22;
        private System.Windows.Forms.RadioButton rdbXOR2;
        private System.Windows.Forms.RadioButton radioButton57;
        private System.Windows.Forms.RadioButton rdbCloud2;
        private System.Windows.Forms.RadioButton rdbDex2;
        private System.Windows.Forms.RadioButton rdbPolyDES2;
        private System.Windows.Forms.RadioButton rdbSymetric2;
        private System.Windows.Forms.RadioButton rdbPolySym2;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.NumericUpDown numVariableLength;
        private System.Windows.Forms.RadioButton rdbUnicode;
        private System.Windows.Forms.RadioButton rdbLetter;
        private System.Windows.Forms.GroupBox muButton13kk;
        private System.Windows.Forms.CheckBox chkFakeAPI;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chkJunkCode;
        private Control2 txtKey;
        private System.Windows.Forms.RadioButton rdbRC2;
        private System.Windows.Forms.RadioButton rdbTripleDES;
        private System.Windows.Forms.GroupBox grpPicBtn;
        private System.Windows.Forms.RadioButton rdbCustomPic;
        private System.Windows.Forms.RadioButton rdbRndPic;
        private System.Windows.Forms.GroupBox groupBox21m;
        private System.Windows.Forms.GroupBox groupBox22b;
        private System.Windows.Forms.GroupBox txtDownloa;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.CheckBox chckNETfile;
        private System.Windows.Forms.CheckBox chckEOF;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtActiveXKey;
        private System.Windows.Forms.Label label2;
        private Control4 RandActiveX;
        private Control4 deumosButton2;
        private Control2 textBoxStartup2;
        private Control2 txtFileNameSU;
        private Control2 txtSubFolder;
        private System.Windows.Forms.Label label1;
        private Control2 txtInjectInto;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.RadioButton rdbRunPE7;
        private Control12 muButton10;
        private Control12 muButton9;
        private Control2 txtCryptFile;
        private Control12 btnClearPic;
        private System.Windows.Forms.GroupBox grpPic;
        private System.Windows.Forms.PictureBox pic2;
        private System.Windows.Forms.PictureBox pic3;
        private System.Windows.Forms.PictureBox pic4;
        private System.Windows.Forms.PictureBox picMn;
        private System.Windows.Forms.PictureBox picEnc;
        private System.Windows.Forms.PictureBox picRunPE;
        private System.Windows.Forms.PictureBox picRest;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblApiAmount;
        private Control1 trkFakeApi;
        private System.Windows.Forms.Label lblJunkAmount;
        private System.Windows.Forms.CheckBox chkArrayVariables;
        private System.Windows.Forms.CheckBox checkBox9;
        private Control1 trkJunkCode;
        private System.Windows.Forms.CheckBox chckDelay;
        private System.Windows.Forms.RichTextBox txtBatch2;
        private System.Windows.Forms.CheckBox chckBatch;
        private System.Windows.Forms.Label label8;
        private Control12 deumosButton1;
        private System.Windows.Forms.RadioButton rdbmutletters;
        private System.Windows.Forms.RadioButton rdbmutuni;
        private System.Windows.Forms.Panel pan2;
        private Control9 deumosGroupBox2;
        private System.Windows.Forms.GroupBox groupBox24;
        private Control12 muButton5;
        private Control12 muButton4;
        private System.Windows.Forms.ListBox lstBind;
        private Control12 muButton15;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.RadioButton rdbBindStart;
        private System.Windows.Forms.RadioButton radioButton93;
        private System.Windows.Forms.CheckBox checkBox13;
        private Control12 muButton6;
        private Control12 muButton7;
        private Control12 muButton8;
        private System.Windows.Forms.RadioButton rdbDLapp;
        private System.Windows.Forms.RadioButton rdbDLTemp;
        private System.Windows.Forms.RadioButton rdbDLsystem;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RadioButton rdbStart;
        private System.Windows.Forms.RadioButton rdbEnd;
        private System.Windows.Forms.CheckBox chckProxy;
        private Control2 txtDownloadLink;
        private System.Windows.Forms.ListBox lstDownloadLinks;
        private Control12 b12;
        private Control12 b11;
        private Control12 b10;
        private Control12 b2;
        private Control12 b6;
        private Control12 b3;
        private Control12 b4;
        private Control12 b7;
        private Control12 b8;
        private Control12 b9;
        private Control12 b1;
        private System.Windows.Forms.Panel pan11;
        private Control9 grpAntis;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.ListBox lstProc;
        private System.Windows.Forms.TextBox txtProcess;
        private Control12 muButton12;
        private Control12 muButton13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.RadioButton rdbKill;
        private System.Windows.Forms.RadioButton rdbExit;
        private System.Windows.Forms.RadioButton rdbKillExit;
        private System.Windows.Forms.CheckBox chckAnties;
        private System.Windows.Forms.Panel pan6;
        private Control9 deumosGroupBox6;
        private System.Windows.Forms.GroupBox groupBox9;
        private Control12 muButton14;
        private Control2 txtAssemblyTitle;
        private Control2 textAssemblyDescription;
        private Control2 textAssemblyCompany;
        private Control2 textAssemblyProduct;
        private Control2 textAssemblyCopyRight;
        private System.Windows.Forms.CheckBox chckAssembly;
        private System.Windows.Forms.NumericUpDown AssemblyLenght;
        private System.Windows.Forms.NumericUpDown intRevision;
        private System.Windows.Forms.NumericUpDown intBuild;
        private System.Windows.Forms.NumericUpDown intMinor;
        private System.Windows.Forms.NumericUpDown intMajor;
        private System.Windows.Forms.TextBox txtIcon;
        private Control2 txtInformation;
        private System.Windows.Forms.RadioButton rdbMinutes;
        private System.Windows.Forms.RadioButton rdbSeconds;
        private System.Windows.Forms.NumericUpDown numUpDownDelay;
        private System.Windows.Forms.NumericUpDown numRandomStringLength;
        private Control2 txtMutex;
        private Control2 txt111;
        private Control12 btnCrypt;
        private System.Windows.Forms.RadioButton rdbMeth1;
        private System.Windows.Forms.CheckBox chckHideFile;
        private System.Windows.Forms.RadioButton rdbPolyRijn;
        private System.Windows.Forms.RadioButton rdbPolyRijn2;
        private System.Windows.Forms.RadioButton radioBtnCustom;
        private System.Windows.Forms.RadioButton radioCSC;
        private System.Windows.Forms.RadioButton rdbVBC;
        private System.Windows.Forms.TextBox txtBindFile;
        private Control12 muButton11;
        private System.Windows.Forms.PictureBox pic1;
        private Control3 deumosSeperator1;
        private Control9 deumosGroupBox12;
        private Control12 btnLoad;
        private Control9 deumosGroupBox14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RadioButton rdbLoad3;
        private System.Windows.Forms.RadioButton rdbLoad2;
        private System.Windows.Forms.RadioButton rdbLoad1;
        private System.Windows.Forms.RadioButton rdbLoadCustom;
        private Control9 deumosGroupBox15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RadioButton rdbSave1;
        private System.Windows.Forms.RadioButton rdbSave2;
        private System.Windows.Forms.RadioButton rdbSave3;
        private System.Windows.Forms.RadioButton rdbSaveCustom;
        private Control12 muButton16;
        private System.Windows.Forms.CheckBox chckCMD;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chckReAlign;
        private Control3 deumosSeperator4;
        private Control3 deumosSeperator3;
        private Control3 control31;
        private System.Windows.Forms.Button b12232324;
        private System.Windows.Forms.Button b555;
        private Control12 muButton1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.CheckBox chckExeFusion;
        private System.Windows.Forms.CheckBox chckMelt;
        private System.Windows.Forms.CheckBox chckUAC;
        private System.Windows.Forms.CheckBox chckTASK;
        private System.Windows.Forms.CheckBox chckProtect;
        private System.Windows.Forms.CheckBox Regedit;
        private System.Windows.Forms.CheckBox chckReadOnly;
        private System.Windows.Forms.CheckBox chckReflect;
        private System.Windows.Forms.Panel pan5;
        private Control9 deumosGroupBox8;
        private System.Windows.Forms.RadioButton rdbNETfile;
        private Control9 control91;
    }
}

