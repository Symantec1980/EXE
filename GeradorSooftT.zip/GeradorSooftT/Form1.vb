﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading
Imports Microsoft.VisualBasic.CompilerServices

Public Class Form1

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click
        If (Me.ComboBox1.Text = "") Then
            Interaction.MsgBox("SELECIONE UMA OPÇAO PARA CONTINUAR", MsgBoxStyle.Exclamation, "CONTINUAR")
        End If
        If (Me.ComboBox1.Text = "SUB-MAIN") Then
            Dim str As String = My.Resources.SubMain.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (Me.ComboBox1.Text = "RC4") Then
            Dim str2 As String = My.Resources.RC4.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT9", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT10", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT11", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder2 As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str2
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (Me.ComboBox1.Text = "XOR") Then
            Dim str3 As String = My.Resources.XORR.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder3 As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str3
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (Me.ComboBox1.Text = "RUMPE") Then
            Dim str4 As String = My.Resources.RUMPE.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT9", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT10", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT11", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT12", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT13", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT14", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT15", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT16", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT17", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT18", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT19", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT20", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT21", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT22", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT23", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT24", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT25", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT26", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT27", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT28", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT29", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT30", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder4 As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str4
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (ComboBox1.Text = "ENTRY POINT") Then
            Dim str8 As String = My.Resources.Entry.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder8 As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str8
            Clipboard.SetDataObject(Me.TextBox3.Text, True)

        End If



        If (Me.ComboBox1.Text = "JUNK CODE 01") Then
            Dim str5 As String = My.Resources.JUNKE01.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT9", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT10", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT11", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT12", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT13", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT14", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT15", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT16", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT17", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT18", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT19", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT20", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT21", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT22", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT23", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT24", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT25", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT26", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT27", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT28", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT29", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT30", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT31", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT32", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT33", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT34", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT35", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT36", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT37", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT38", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT39", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT40", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT41", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT42", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT43", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT44", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT45", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT46", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT47", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT48", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT49", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder5 As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str5
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (Me.ComboBox1.Text = "JUNK CODE 02") Then
            Dim str6 As String = My.Resources.JUNKE02.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT9", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT10", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT11", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT12", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT13", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT14", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT15", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT16", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT17", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT18", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT19", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT20", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT21", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT22", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT23", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT24", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT25", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT26", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT27", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT28", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT29", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT30", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT31", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT32", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT33", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT34", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT35", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT36", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT37", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT38", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT39", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT40", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT41", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT42", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT43", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT44", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT45", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT46", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT47", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT48", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT49", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT50", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT51", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT52", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT53", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT54", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT55", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT56", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT57", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT58", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT59", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT60", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT61", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT62", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT63", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT64", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT65", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT66", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT67", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder6 As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str6
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (Me.ComboBox1.Text = "JUNK CODE 03") Then
            Dim str7 As String = My.Resources.JUNKE03.Replace("SOOFT1", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT2", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT3", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT4", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT5", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT6", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT7", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT8", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT9", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT10", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT11", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT12", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT13", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT14", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT15", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT16", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT17", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT18", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT19", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT20", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT21", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT22", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT23", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT24", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT25", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT26", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT27", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT28", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT29", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT30", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT31", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT32", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT33", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT34", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT35", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT36", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT37", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT38", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT39", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT40", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT41", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT42", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT43", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT44", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT45", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT46", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT47", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT48", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT49", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT50", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT51", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT52", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT53", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT54", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT55", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT56", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT57", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT58", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT59", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT60", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT61", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT62", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT63", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT64", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT65", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT66", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT67", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT68", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT69", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT70", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT71", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT72", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT73", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT74", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT75", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT76", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT77", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT78", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value))).Replace("SOOFT79", Me.GeneratePassword(True, True, False, False, Convert.ToInt32(Me.NumericUpDown1.Value)))
            Dim builder7 As New StringBuilder
            Me.TextBox3.Clear()
            Me.TextBox3.Text = str7
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (Me.ComboBox1.Text = "CLIENTE RC4") Then
            Me.TextBox3.Clear()
            Me.TextBox3.Text = My.Resources.ClienteRc4
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
        If (Me.ComboBox1.Text = "CLIENTE XOR") Then
            Me.TextBox3.Clear()
            Me.TextBox3.Text = My.Resources.ClienteXor
            Clipboard.SetDataObject(Me.TextBox3.Text, True)
        End If
    End Sub

    Private Sub Button10_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button10.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox12.Text = Stringss.rnd10(Convert.ToInt32(Me.NumericUpDown13.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox12.Text, True)
    End Sub

    Private Sub Button11_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button11.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox11.Text = Stringss.rnd9(Convert.ToInt32(Me.NumericUpDown8.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox11.Text, True)
    End Sub

    Private Sub Button12_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button12.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox14.Text = Module1.rnd12(Convert.ToInt32(Me.NumericUpDown11.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox14.Text, True)
    End Sub

    Private Sub Button13_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button13.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()

            If ((Decimal.Compare(Me.NumericUpDown12.Value, Decimal.Zero) > 0) And (Decimal.Compare(Me.NumericUpDown16.Value, Decimal.Zero) > 0)) Then
                Me.TextBox13.Text = Conversions.ToString(Module1.Generate_Key(Convert.ToInt32(Me.NumericUpDown12.Value), Convert.ToInt32(Me.NumericUpDown16.Value), "-"))
            End If
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox13.Text, True)
    End Sub

    Private Sub Button14_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button14.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()

            If ((Decimal.Compare(Me.NumericUpDown14.Value, Decimal.Zero) > 0) And (Decimal.Compare(Me.NumericUpDown16.Value, Decimal.Zero) > 0)) Then
                Me.TextBox16.Text = Conversions.ToString(Module1.Generate_Key1(Convert.ToInt32(Me.NumericUpDown14.Value), Convert.ToInt32(Me.NumericUpDown16.Value), "-"))
            End If
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox16.Text, True)
    End Sub

    Private Sub Button15_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button15.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox15.Text = Module1.rnd13(Convert.ToInt32(Me.NumericUpDown15.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox15.Text, True)
    End Sub

    Private Sub Button16_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button16.Click
        If (Me.Button16.Text = "M. Strings") Then
            Me.Width = (Me.Width + 530)
            Me.Button16.Text = "O. Strings"
        ElseIf (Me.Button16.Text = "O. Strings") Then
            Me.Width = (Me.Width - 530)
            Me.Button16.Text = "M. Strings"
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox1.Text = Stringss.rnd1(Convert.ToInt32(Me.NumericUpDown2.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox1.Text, True)
    End Sub

    Private Sub Button3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button3.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox4.Text = Stringss.rnd2(Convert.ToInt32(Me.NumericUpDown3.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox4.Text, True)
    End Sub

    Private Sub Button4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button4.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox6.Text = Stringss.rnd4(Convert.ToInt32(Me.NumericUpDown7.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox6.Text, True)
    End Sub

    Private Sub Button5_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button5.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox5.Text = Stringss.rnd3(Convert.ToInt32(Me.NumericUpDown4.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox5.Text, True)
    End Sub

    Private Sub Button6_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button6.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox8.Text = Stringss.rnd6(Convert.ToInt32(Me.NumericUpDown5.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox8.Text, True)
    End Sub

    Private Sub Button7_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button7.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox7.Text = Stringss.rnd5(Convert.ToInt32(Me.NumericUpDown6.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox7.Text, True)
    End Sub

    Private Sub Button8_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button8.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox10.Text = Stringss.rnd8(Convert.ToInt32(Me.NumericUpDown9.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox10.Text, True)
    End Sub

    Private Sub Button9_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button9.Click
        Dim num2 As Integer
        Dim num As Integer = 0
        Do
            Thread.Sleep(10)
            Application.DoEvents()
            Me.TextBox9.Text = Stringss.rnd7(Convert.ToInt32(Me.NumericUpDown10.Value))
            num += 1
            num2 = 30
        Loop While (num <= num2)
        Clipboard.SetDataObject(Me.TextBox9.Text, True)
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim num2 As Integer
        Dim num As Integer = 90
        Do
            Me.Opacity = (CDbl(num) / 100)
            Me.Refresh()
            Thread.Sleep(50)
            num = (num + -10)
            num2 = 10
        Loop While (num >= num2)
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Dim num2 As Double
        Me.Timer2.Interval = &H3E8
        Me.Timer2.Enabled = True

        Dim num As Double = 0
        Do
            Me.Opacity = num
            Me.Refresh()
            Thread.Sleep(50)
            num = (num + 0.1)
            num2 = 1.1
        Loop While (num <= num2)
    End Sub

    Public Function GeneratePassword(ByVal Uppers As Boolean, ByVal Lowers As Boolean, ByVal Numbers As Boolean, ByVal Specials As Boolean, ByVal passwordLength As Integer) As String
        Dim str2 As String
        Dim str3 As String
        str2 = (str2 & Me.TextBox2.Text)
        VBMath.Randomize()
        Dim num2 As Integer = (passwordLength - 1)
        Dim i As Integer = 0
        Do While (i <= num2)
            str3 = (str3 & Strings.Mid(str2, CInt(Math.Round(Math.Round(Math.Round(CDbl(((Strings.Len(str2) * VBMath.Rnd) + 1.0!)))))), 1))
            i += 1
        Loop
        Return str3
    End Function

    <DllImport("kernel32", CharSet:=CharSet.Ansi, SetLastError:=True, ExactSpelling:=True)>
    Public Shared Function GetTickCount() As Long
    End Function



    
    Private Sub CopyAllToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyAllToolStripMenuItem.Click
        Me.TextBox3.SelectAll()
        Me.TextBox3.Copy()
    End Sub

    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem.Click
        Me.TextBox3.Clear()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub
End Class
