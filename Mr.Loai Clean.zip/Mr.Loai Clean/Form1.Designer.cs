﻿namespace Mr.Loai_Clean
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Button1 = new RecuperareII.RecuperareIIButton();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.TextBox1 = new RecuperareII.RecuperareIITextBox();
            this.TextBox2 = new RecuperareII.RecuperareIITextBox();
            this.recuperareIIButton1 = new RecuperareII.RecuperareIIButton();
            this.recuperareIILabel2 = new RecuperareII.RecuperareIILabel();
            this.recuperareIIButton6 = new RecuperareII.RecuperareIIButton();
            this.recuperareIIButton2 = new RecuperareII.RecuperareIIButton();
            this.recuperareIIButton3 = new RecuperareII.RecuperareIIButton();
            this.SuspendLayout();
            // 
            // Button1
            // 
            this.Button1.BackColor = System.Drawing.Color.Transparent;
            this.Button1.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.Button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.Button1.Location = new System.Drawing.Point(432, 12);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(75, 21);
            this.Button1.TabIndex = 0;
            this.Button1.Text = "Select";
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.richTextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.richTextBox1.Location = new System.Drawing.Point(12, 66);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(495, 493);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // TextBox1
            // 
            this.TextBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.TextBox1.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.TextBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.TextBox1.Location = new System.Drawing.Point(17, 12);
            this.TextBox1.MaxLength = 32767;
            this.TextBox1.MultiLine = false;
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(409, 21);
            this.TextBox1.TabIndex = 3;
            this.TextBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBox1.UseSystemPasswordChar = false;
            // 
            // TextBox2
            // 
            this.TextBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(233)))), ((int)(((byte)(233)))));
            this.TextBox2.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.TextBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.TextBox2.Location = new System.Drawing.Point(57, 39);
            this.TextBox2.MaxLength = 32767;
            this.TextBox2.MultiLine = false;
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(144, 21);
            this.TextBox2.TabIndex = 4;
            this.TextBox2.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.TextBox2.UseSystemPasswordChar = false;
            // 
            // recuperareIIButton1
            // 
            this.recuperareIIButton1.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton1.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton1.Location = new System.Drawing.Point(432, 39);
            this.recuperareIIButton1.Name = "recuperareIIButton1";
            this.recuperareIIButton1.Size = new System.Drawing.Size(75, 21);
            this.recuperareIIButton1.TabIndex = 5;
            this.recuperareIIButton1.Text = "Go";
            this.recuperareIIButton1.Click += new System.EventHandler(this.recuperareIIButton1_Click);
            // 
            // recuperareIILabel2
            // 
            this.recuperareIILabel2.AutoSize = true;
            this.recuperareIILabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.recuperareIILabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIILabel2.Location = new System.Drawing.Point(14, 40);
            this.recuperareIILabel2.Name = "recuperareIILabel2";
            this.recuperareIILabel2.Size = new System.Drawing.Size(42, 16);
            this.recuperareIILabel2.TabIndex = 23;
            this.recuperareIILabel2.Text = "Key: ";
            // 
            // recuperareIIButton6
            // 
            this.recuperareIIButton6.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton6.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton6.Location = new System.Drawing.Point(12, 565);
            this.recuperareIIButton6.Name = "recuperareIIButton6";
            this.recuperareIIButton6.Size = new System.Drawing.Size(75, 21);
            this.recuperareIIButton6.TabIndex = 33;
            this.recuperareIIButton6.Text = "Copy";
            this.recuperareIIButton6.Click += new System.EventHandler(this.recuperareIIButton6_Click);
            // 
            // recuperareIIButton2
            // 
            this.recuperareIIButton2.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton2.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton2.Location = new System.Drawing.Point(432, 565);
            this.recuperareIIButton2.Name = "recuperareIIButton2";
            this.recuperareIIButton2.Size = new System.Drawing.Size(75, 21);
            this.recuperareIIButton2.TabIndex = 34;
            this.recuperareIIButton2.Text = "About";
            this.recuperareIIButton2.Click += new System.EventHandler(this.recuperareIIButton2_Click);
            // 
            // recuperareIIButton3
            // 
            this.recuperareIIButton3.BackColor = System.Drawing.Color.Transparent;
            this.recuperareIIButton3.Font = new System.Drawing.Font("Verdana", 6.75F, System.Drawing.FontStyle.Bold);
            this.recuperareIIButton3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(94)))), ((int)(((byte)(137)))));
            this.recuperareIIButton3.Location = new System.Drawing.Point(214, 565);
            this.recuperareIIButton3.Name = "recuperareIIButton3";
            this.recuperareIIButton3.Size = new System.Drawing.Size(75, 21);
            this.recuperareIIButton3.TabIndex = 35;
            this.recuperareIIButton3.Text = "Decrypt";
            this.recuperareIIButton3.Click += new System.EventHandler(this.recuperareIIButton3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(519, 593);
            this.Controls.Add(this.recuperareIIButton3);
            this.Controls.Add(this.recuperareIIButton2);
            this.Controls.Add(this.recuperareIIButton6);
            this.Controls.Add(this.recuperareIILabel2);
            this.Controls.Add(this.recuperareIIButton1);
            this.Controls.Add(this.TextBox2);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.Button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(535, 632);
            this.MinimumSize = new System.Drawing.Size(535, 632);
            this.Name = "Form1";
            this.Text = "Clean Encrypt By : Mr.ŁǾẪĪ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private RecuperareII.RecuperareIIButton Button1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private RecuperareII.RecuperareIITextBox TextBox1;
        private RecuperareII.RecuperareIITextBox TextBox2;
        private RecuperareII.RecuperareIIButton recuperareIIButton1;
        private RecuperareII.RecuperareIILabel recuperareIILabel2;
        private RecuperareII.RecuperareIIButton recuperareIIButton6;
        private RecuperareII.RecuperareIIButton recuperareIIButton2;
        private RecuperareII.RecuperareIIButton recuperareIIButton3;
    }
}

