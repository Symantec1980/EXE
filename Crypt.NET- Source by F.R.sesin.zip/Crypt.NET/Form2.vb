﻿
Public Class Form2
  

    Private Sub ReactorTheme1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReactorTheme1.Click

    End Sub
   
    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load





    End Sub
    Dim a As String = "ctl00_MainContent_txtHashes"
    Private Sub WebBrowser1_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted

        WebBrowser1.Document.GetElementById(a).SetAttribute("Value", Form1.ReactorMultiLineTextBox1.Text)

    End Sub
End Class