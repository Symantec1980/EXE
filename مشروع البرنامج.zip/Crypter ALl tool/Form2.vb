﻿Imports System.IO
Imports System.Text
Public Class Form2




    Public Function jordan(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "dGkjBoOiIuUhHgGyYrRnMkLlKUeEwWqQvVcCnNxXzZmM"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result

    End Function

    Private rand As Random

    Public Function gens() As String
        Dim num3 As Integer
        Dim rdf As String = "abcjklmnяоксркиdefghiасваевяuvwxyыююopqrstz"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num As Integer = 1
        Do
            Dim startIndex As Integer = random.Next(0, 35)
            builder.Append(rdf.Substring(startIndex, 1))
            num += 1
            num3 = 8
        Loop While (num <= num3)
        Return builder.ToString
    End Function
    Public Function FileToByteArray(ByVal _FileName As String) As Byte()
        Dim buffer As Byte() = Nothing
        Try
            Dim input As New FileStream(_FileName, FileMode.Open, FileAccess.Read)
            Dim reader As New BinaryReader(input)
            Dim length As Long = New FileInfo(_FileName).Length
            buffer = reader.ReadBytes(CInt(Conversion.Fix(length)))
            input.Close()
            input.Dispose()
            reader.Close()
        Catch exception1 As Exception
            Console.WriteLine("Exception caught in process: {0}", exception1.ToString)
        End Try
        Return buffer
    End Function


    Private Sub NotifyIcon1_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs)

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        On Error Resume Next

        If t1.Text = "" Then
            Label2.Text = "There are No File To Convert It"
        ElseIf Not File.Exists(t1.Text) Then
            Label2.Text = "File Don't Exists"

            Label2.Text = "There are an Box Empty"

        ElseIf t3.Text = "" Then
            Label2.Text = "There are an Box Empty"
        Else
            Dim num As Long
            Dim num3 As Integer = Convert.ToInt32(Me.T16.Text)
            Dim text As String = Me.t1.Text
            Dim writer As New StreamWriter((Application.StartupPath & "/FileHex.txt"))



            Dim length As Long = New FileInfo(Me.t1.Text).Length
            Dim strArray As String() = New String((CInt(length) + 1) - 1) {}
            Dim buffer As Byte() = New Byte((CInt(length) + 1) - 1) {}
            buffer = FileToByteArray(Me.t1.Text)
            length = (length - 1)
            writer.Write(String.Concat(New String() {vbNewLine & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10)}))
            Dim num4 As Long = length
            num = 0
            Do While (num <= num4)
                strArray(CInt(num)) = Conversion.Hex(buffer(CInt(num)))
                If (strArray(CInt(num)).Length = 1) Then
                    strArray(CInt(num)) = ("0" & strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write((ChrW(13) & ChrW(10) & t3.Text & " = """ & strArray(0)))
            Dim num5 As Long = length
            num = 1
            Do While (num <= num5)
                If ((CDbl(num) Mod (CDbl(num3) / 2)) = 0) Then
                    writer.Write(String.Concat(New String() {"""" & ChrW(13) & ChrW(10), t3.Text, " = ", t3.Text, " & """, strArray(CInt(num))}))
                Else
                    writer.Write(strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write("""" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & vbNewLine)
            writer.Close()
            Label2.Text = "Converted Successfully"
            MsgBox("Converted Successfully", vbInformation, "File To Hex")

        End If
        My.Computer.Audio.Play(My.Resources.button_43, AudioPlayMode.Background)
    End Sub

    Private Sub Form2_Load_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play(My.Resources.button_3, AudioPlayMode.Background)
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        My.Computer.Audio.Play(My.Resources.button_3, AudioPlayMode.Background)
        Dim SC As New OpenFileDialog
        SC.Filter = "Applications (*.exe)|*.exe|All Files (*.*)|*.*"
        SC.Title = "Choose A File To Convert"
        SC.FileName = ""
        SC.ShowDialog()
        t1.Text = SC.FileName

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Try
            T16.Text = CStr(Int(Rnd() * T16.Text))
        Catch ex As Exception

        End Try
        My.Computer.Audio.Play(My.Resources.button_17, AudioPlayMode.Background)
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        t3.Text = gens()
        My.Computer.Audio.Play(My.Resources.button_17, AudioPlayMode.Background)
    End Sub

    

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim lol As String = My.Resources.HEXENTRYBOINT
        Dim sam As String

        sam = lol.Replace("%1%", jordan(4)).Replace("%2%", jordan(8)).Replace("%3%", jordan(10)).Replace("%4%", jordan(14)).Replace("%5%", jordan(18)).Replace("%6%", jordan(22)).Replace("%7%", jordan(26)).Replace("%8%", jordan(30))

        r1.Text = sam


        My.Computer.Audio.Play(My.Resources.button_17, AudioPlayMode.Background)


    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        r1.SelectAll()
        r1.Cut()
        Beep()

        MsgBox("done")

    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles Button2.Click

    End Sub

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub

    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub

  

    Private Sub FlatButton1_Click_1(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Dim lol As String = My.Resources.String1
        Dim xxf As String = My.Resources.String2
        Dim hazem As String = My.Resources.String3

        Dim ss As String
        Dim hh As String
        Dim gg As String

        ss = lol.Replace("%1%", scorpionsam(1))

        hh = xxf.Replace("%2%", sam(0))

        gg = hazem.Replace("%2%", scorpionsam(1)).Replace("%2%", t3.Text).Replace("%1%", samx(1)).Replace("%3%", sam(0))







        t5.Text = ss
        t4.Text = hh
        a1.Text = gg

    End Sub

    Public Function scorpionsam(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "dGkjBoOiIuUhHgGyYrRnMkLlKUeEwWqQvVcCnNxXzZmM"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function sam(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ABCDEFGHIJKLMNOPQRSTUVDWXYZ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function samx(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "abcdefghijklmnopqrstuvwxyz"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        Dim WW As String = r1.Text
        Dim VV As String = t5.Text
        Dim FF As String

        FF = WW.Replace(t4.Text, VV)

        r2.Text = FF
    End Sub

    Private Sub FlatButton10_Click(sender As Object, e As EventArgs) Handles FlatButton10.Click
        r2.SelectAll()
        r2.Cut()
        Beep()

    End Sub

    Private Sub FlatButton2_Click_1(sender As Object, e As EventArgs) Handles FlatButton2.Click
        a1.Text = ""
        r1.Text = ""
        r2.Text = ""
        t4.Text = ""
        t5.Text = ""

    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

        Form1.Show()
        Me.Hide()
        My.Computer.Audio.Play(My.Resources.button_3, AudioPlayMode.Background)
    End Sub

    Private Sub FlatButton18_Click(sender As Object, e As EventArgs) Handles FlatButton18.Click
        a1.SelectAll()
        a1.Copy()
        Beep()
        Label2.Text = "ascii cod the copy"
    End Sub
End Class
