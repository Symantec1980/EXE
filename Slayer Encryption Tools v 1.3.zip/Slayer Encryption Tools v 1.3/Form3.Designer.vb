﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.NyX_Theme1 = New Slayer_Encryption_Tools_v_1._3.NYX_Theme()
        Me.NyX_ControlBox1 = New Slayer_Encryption_Tools_v_1._3.NYX_ControlBox()
        Me.NyX_Button3 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.GhostButton3 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button1 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.NyX_Theme1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'NyX_Theme1
        '
        Me.NyX_Theme1.Animated = True
        Me.NyX_Theme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_Theme1.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Theme1.Controls.Add(Me.NyX_ControlBox1)
        Me.NyX_Theme1.Controls.Add(Me.NyX_Button3)
        Me.NyX_Theme1.Controls.Add(Me.GhostButton3)
        Me.NyX_Theme1.Controls.Add(Me.NyX_Button1)
        Me.NyX_Theme1.Controls.Add(Me.TextBox1)
        Me.NyX_Theme1.Controls.Add(Me.StatusStrip1)
        Me.NyX_Theme1.Controls.Add(Me.TextBox3)
        Me.NyX_Theme1.Controls.Add(Me.TextBox2)
        Me.NyX_Theme1.Customization = ""
        Me.NyX_Theme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NyX_Theme1.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_Theme1.Image = Nothing
        Me.NyX_Theme1.Location = New System.Drawing.Point(0, 0)
        Me.NyX_Theme1.MaximumSize = New System.Drawing.Size(656, 437)
        Me.NyX_Theme1.MinimumSize = New System.Drawing.Size(656, 437)
        Me.NyX_Theme1.Movable = True
        Me.NyX_Theme1.Name = "NyX_Theme1"
        Me.NyX_Theme1.NoRounding = False
        Me.NyX_Theme1.Sizable = True
        Me.NyX_Theme1.Size = New System.Drawing.Size(656, 437)
        Me.NyX_Theme1.SmartBounds = True
        Me.NyX_Theme1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.NyX_Theme1.TabIndex = 0
        Me.NyX_Theme1.Text = "VB.NET Compiler"
        Me.NyX_Theme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.NyX_Theme1.Transparent = False
        '
        'NyX_ControlBox1
        '
        Me.NyX_ControlBox1.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_ControlBox1.Customization = ""
        Me.NyX_ControlBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.NyX_ControlBox1.Image = Nothing
        Me.NyX_ControlBox1.Location = New System.Drawing.Point(602, 1)
        Me.NyX_ControlBox1.Name = "NyX_ControlBox1"
        Me.NyX_ControlBox1.NoRounding = False
        Me.NyX_ControlBox1.Size = New System.Drawing.Size(52, 23)
        Me.NyX_ControlBox1.TabIndex = 17
        Me.NyX_ControlBox1.Text = "NyX_ControlBox1"
        Me.NyX_ControlBox1.Transparent = False
        '
        'NyX_Button3
        '
        Me.NyX_Button3.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button3.Customization = ""
        Me.NyX_Button3.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button3.Image = Nothing
        Me.NyX_Button3.Location = New System.Drawing.Point(575, 391)
        Me.NyX_Button3.Name = "NyX_Button3"
        Me.NyX_Button3.NoRounding = False
        Me.NyX_Button3.Size = New System.Drawing.Size(71, 21)
        Me.NyX_Button3.TabIndex = 15
        Me.NyX_Button3.Text = "Compile"
        Me.NyX_Button3.Transparent = False
        '
        'GhostButton3
        '
        Me.GhostButton3.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.GhostButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton3.Customization = ""
        Me.GhostButton3.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.GhostButton3.Image = Nothing
        Me.GhostButton3.Location = New System.Drawing.Point(497, 391)
        Me.GhostButton3.Name = "GhostButton3"
        Me.GhostButton3.NoRounding = False
        Me.GhostButton3.Size = New System.Drawing.Size(70, 21)
        Me.GhostButton3.TabIndex = 14
        Me.GhostButton3.Text = "Edit"
        Me.GhostButton3.Transparent = False
        '
        'NyX_Button1
        '
        Me.NyX_Button1.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button1.Customization = ""
        Me.NyX_Button1.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button1.Image = Nothing
        Me.NyX_Button1.Location = New System.Drawing.Point(10, 391)
        Me.NyX_Button1.Name = "NyX_Button1"
        Me.NyX_Button1.NoRounding = False
        Me.NyX_Button1.Size = New System.Drawing.Size(44, 21)
        Me.NyX_Button1.TabIndex = 13
        Me.NyX_Button1.Text = "......."
        Me.NyX_Button1.Transparent = False
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.White
        Me.TextBox1.Location = New System.Drawing.Point(55, 391)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(439, 21)
        Me.TextBox1.TabIndex = 12
        '
        'StatusStrip1
        '
        Me.StatusStrip1.AutoSize = False
        Me.StatusStrip1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.StatusStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(9, 414)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(638, 22)
        Me.StatusStrip1.TabIndex = 10
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.AutoSize = False
        Me.ToolStripStatusLabel1.ForeColor = System.Drawing.Color.Red
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(487, 17)
        Me.ToolStripStatusLabel1.Text = "                                                               ==>Note: In Case o" & _
    "f Error please Check the Library<=="
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Silver
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.ForeColor = System.Drawing.Color.Blue
        Me.TextBox3.Location = New System.Drawing.Point(10, 26)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox3.Size = New System.Drawing.Size(637, 364)
        Me.TextBox3.TabIndex = 11
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.DimGray
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(10, 26)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox2.Size = New System.Drawing.Size(635, 363)
        Me.TextBox2.TabIndex = 16
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(656, 437)
        Me.Controls.Add(Me.NyX_Theme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(656, 437)
        Me.MinimumSize = New System.Drawing.Size(656, 437)
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "VB.NET Compiler"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.NyX_Theme1.ResumeLayout(False)
        Me.NyX_Theme1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents NyX_Theme1 As Slayer_Encryption_Tools_v_1._3.NYX_Theme
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents NyX_Button3 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents GhostButton3 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button1 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents NyX_ControlBox1 As Slayer_Encryption_Tools_v_1._3.NYX_ControlBox
End Class
