﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.NyX_Theme1 = New Slayer_Encryption_Tools_v_1._3.NYX_Theme()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.NyX_GroupBox7 = New Slayer_Encryption_Tools_v_1._3.NYX_GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.NyX_Button19 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.NyX_Button18 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button17 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button16 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button15 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button14 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_GroupBox6 = New Slayer_Encryption_Tools_v_1._3.NYX_GroupBox()
        Me.NyX_Button13 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.NyX_Button12 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.NyX_GroupBox5 = New Slayer_Encryption_Tools_v_1._3.NYX_GroupBox()
        Me.NyX_Button11 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button10 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button9 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button8 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.NyX_GroupBox3 = New Slayer_Encryption_Tools_v_1._3.NYX_GroupBox()
        Me.NyX_Button4 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.NyX_Button3 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox4 = New Slayer_Encryption_Tools_v_1._3.CrystalClearTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox3 = New Slayer_Encryption_Tools_v_1._3.CrystalClearTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NyX_GroupBox2 = New Slayer_Encryption_Tools_v_1._3.NYX_GroupBox()
        Me.NyX_Button2 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button1 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_GroupBox1 = New Slayer_Encryption_Tools_v_1._3.NYX_GroupBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.NyX_GroupBox4 = New Slayer_Encryption_Tools_v_1._3.NYX_GroupBox()
        Me.NyX_Button7 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button6 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_Button5 = New Slayer_Encryption_Tools_v_1._3.NYX_Button()
        Me.NyX_ControlBox1 = New Slayer_Encryption_Tools_v_1._3.NYX_ControlBox()
        Me.NyX_Theme1.SuspendLayout()
        Me.NyX_GroupBox7.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NyX_GroupBox6.SuspendLayout()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NyX_GroupBox5.SuspendLayout()
        Me.NyX_GroupBox3.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NyX_GroupBox2.SuspendLayout()
        Me.NyX_GroupBox1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NyX_GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'NyX_Theme1
        '
        Me.NyX_Theme1.Animated = True
        Me.NyX_Theme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_Theme1.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Theme1.Controls.Add(Me.Button1)
        Me.NyX_Theme1.Controls.Add(Me.NyX_GroupBox7)
        Me.NyX_Theme1.Controls.Add(Me.TextBox1)
        Me.NyX_Theme1.Controls.Add(Me.NyX_Button18)
        Me.NyX_Theme1.Controls.Add(Me.NyX_Button17)
        Me.NyX_Theme1.Controls.Add(Me.NyX_Button16)
        Me.NyX_Theme1.Controls.Add(Me.NyX_Button15)
        Me.NyX_Theme1.Controls.Add(Me.NyX_Button14)
        Me.NyX_Theme1.Controls.Add(Me.NyX_GroupBox6)
        Me.NyX_Theme1.Controls.Add(Me.NyX_GroupBox5)
        Me.NyX_Theme1.Controls.Add(Me.TextBox2)
        Me.NyX_Theme1.Controls.Add(Me.NyX_GroupBox3)
        Me.NyX_Theme1.Controls.Add(Me.NyX_GroupBox2)
        Me.NyX_Theme1.Controls.Add(Me.NyX_GroupBox1)
        Me.NyX_Theme1.Controls.Add(Me.NyX_GroupBox4)
        Me.NyX_Theme1.Controls.Add(Me.NyX_ControlBox1)
        Me.NyX_Theme1.Customization = ""
        Me.NyX_Theme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NyX_Theme1.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_Theme1.Image = Nothing
        Me.NyX_Theme1.Location = New System.Drawing.Point(0, 0)
        Me.NyX_Theme1.Movable = True
        Me.NyX_Theme1.Name = "NyX_Theme1"
        Me.NyX_Theme1.NoRounding = False
        Me.NyX_Theme1.Sizable = False
        Me.NyX_Theme1.Size = New System.Drawing.Size(923, 495)
        Me.NyX_Theme1.SmartBounds = True
        Me.NyX_Theme1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.NyX_Theme1.TabIndex = 0
        Me.NyX_Theme1.Text = "Slayer Encryption Tools V1.1"
        Me.NyX_Theme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.NyX_Theme1.Transparent = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.Lime
        Me.Button1.Location = New System.Drawing.Point(757, 452)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(152, 31)
        Me.Button1.TabIndex = 31
        Me.Button1.Text = "ABOUT Coder"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'NyX_GroupBox7
        '
        Me.NyX_GroupBox7.Animated = True
        Me.NyX_GroupBox7.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_GroupBox7.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_GroupBox7.Controls.Add(Me.PictureBox1)
        Me.NyX_GroupBox7.Controls.Add(Me.NyX_Button19)
        Me.NyX_GroupBox7.Customization = ""
        Me.NyX_GroupBox7.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_GroupBox7.Image = Nothing
        Me.NyX_GroupBox7.Location = New System.Drawing.Point(686, 365)
        Me.NyX_GroupBox7.Movable = True
        Me.NyX_GroupBox7.Name = "NyX_GroupBox7"
        Me.NyX_GroupBox7.NoRounding = False
        Me.NyX_GroupBox7.Sizable = True
        Me.NyX_GroupBox7.Size = New System.Drawing.Size(225, 84)
        Me.NyX_GroupBox7.SmartBounds = True
        Me.NyX_GroupBox7.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NyX_GroupBox7.TabIndex = 30
        Me.NyX_GroupBox7.Text = "VB.NET"
        Me.NyX_GroupBox7.TransparencyKey = System.Drawing.Color.Empty
        Me.NyX_GroupBox7.Transparent = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(139, 2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(23, 18)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 32
        Me.PictureBox1.TabStop = False
        '
        'NyX_Button19
        '
        Me.NyX_Button19.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button19.Customization = ""
        Me.NyX_Button19.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button19.Image = Nothing
        Me.NyX_Button19.Location = New System.Drawing.Point(14, 32)
        Me.NyX_Button19.Name = "NyX_Button19"
        Me.NyX_Button19.NoRounding = False
        Me.NyX_Button19.Size = New System.Drawing.Size(204, 37)
        Me.NyX_Button19.TabIndex = 31
        Me.NyX_Button19.Text = "VB.NET Compiler"
        Me.NyX_Button19.Transparent = False
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.InfoText
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.White
        Me.TextBox1.Location = New System.Drawing.Point(303, 32)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(372, 21)
        Me.TextBox1.TabIndex = 29
        '
        'NyX_Button18
        '
        Me.NyX_Button18.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button18.Customization = ""
        Me.NyX_Button18.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button18.Image = Nothing
        Me.NyX_Button18.Location = New System.Drawing.Point(252, 31)
        Me.NyX_Button18.Name = "NyX_Button18"
        Me.NyX_Button18.NoRounding = False
        Me.NyX_Button18.Size = New System.Drawing.Size(49, 23)
        Me.NyX_Button18.TabIndex = 28
        Me.NyX_Button18.Text = ".........."
        Me.NyX_Button18.Transparent = False
        '
        'NyX_Button17
        '
        Me.NyX_Button17.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button17.Customization = ""
        Me.NyX_Button17.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button17.Image = Nothing
        Me.NyX_Button17.Location = New System.Drawing.Point(253, 457)
        Me.NyX_Button17.Name = "NyX_Button17"
        Me.NyX_Button17.NoRounding = False
        Me.NyX_Button17.Size = New System.Drawing.Size(85, 26)
        Me.NyX_Button17.TabIndex = 27
        Me.NyX_Button17.Text = "Copy"
        Me.NyX_Button17.Transparent = False
        '
        'NyX_Button16
        '
        Me.NyX_Button16.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button16.Customization = ""
        Me.NyX_Button16.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button16.Image = Nothing
        Me.NyX_Button16.Location = New System.Drawing.Point(365, 457)
        Me.NyX_Button16.Name = "NyX_Button16"
        Me.NyX_Button16.NoRounding = False
        Me.NyX_Button16.Size = New System.Drawing.Size(85, 26)
        Me.NyX_Button16.TabIndex = 26
        Me.NyX_Button16.Text = "Past"
        Me.NyX_Button16.Transparent = False
        '
        'NyX_Button15
        '
        Me.NyX_Button15.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button15.Customization = ""
        Me.NyX_Button15.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button15.Image = Nothing
        Me.NyX_Button15.Location = New System.Drawing.Point(486, 457)
        Me.NyX_Button15.Name = "NyX_Button15"
        Me.NyX_Button15.NoRounding = False
        Me.NyX_Button15.Size = New System.Drawing.Size(85, 26)
        Me.NyX_Button15.TabIndex = 25
        Me.NyX_Button15.Text = "Clear"
        Me.NyX_Button15.Transparent = False
        '
        'NyX_Button14
        '
        Me.NyX_Button14.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button14.Customization = ""
        Me.NyX_Button14.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button14.Image = Nothing
        Me.NyX_Button14.Location = New System.Drawing.Point(595, 456)
        Me.NyX_Button14.Name = "NyX_Button14"
        Me.NyX_Button14.NoRounding = False
        Me.NyX_Button14.Size = New System.Drawing.Size(85, 26)
        Me.NyX_Button14.TabIndex = 24
        Me.NyX_Button14.Text = "Save as"
        Me.NyX_Button14.Transparent = False
        '
        'NyX_GroupBox6
        '
        Me.NyX_GroupBox6.Animated = True
        Me.NyX_GroupBox6.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_GroupBox6.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_GroupBox6.Controls.Add(Me.NyX_Button13)
        Me.NyX_GroupBox6.Controls.Add(Me.NumericUpDown3)
        Me.NyX_GroupBox6.Controls.Add(Me.Label5)
        Me.NyX_GroupBox6.Controls.Add(Me.NyX_Button12)
        Me.NyX_GroupBox6.Controls.Add(Me.NumericUpDown2)
        Me.NyX_GroupBox6.Controls.Add(Me.Label4)
        Me.NyX_GroupBox6.Customization = ""
        Me.NyX_GroupBox6.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_GroupBox6.Image = Nothing
        Me.NyX_GroupBox6.Location = New System.Drawing.Point(685, 196)
        Me.NyX_GroupBox6.Movable = True
        Me.NyX_GroupBox6.Name = "NyX_GroupBox6"
        Me.NyX_GroupBox6.NoRounding = False
        Me.NyX_GroupBox6.Sizable = True
        Me.NyX_GroupBox6.Size = New System.Drawing.Size(226, 163)
        Me.NyX_GroupBox6.SmartBounds = True
        Me.NyX_GroupBox6.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NyX_GroupBox6.TabIndex = 23
        Me.NyX_GroupBox6.Text = ".NET Junk Codes and Strings"
        Me.NyX_GroupBox6.TransparencyKey = System.Drawing.Color.Empty
        Me.NyX_GroupBox6.Transparent = False
        '
        'NyX_Button13
        '
        Me.NyX_Button13.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button13.Customization = ""
        Me.NyX_Button13.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button13.Image = Nothing
        Me.NyX_Button13.Location = New System.Drawing.Point(4, 123)
        Me.NyX_Button13.Name = "NyX_Button13"
        Me.NyX_Button13.NoRounding = False
        Me.NyX_Button13.Size = New System.Drawing.Size(218, 26)
        Me.NyX_Button13.TabIndex = 30
        Me.NyX_Button13.Text = "Generate Codes"
        Me.NyX_Button13.Transparent = False
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown3.ForeColor = System.Drawing.Color.White
        Me.NumericUpDown3.Location = New System.Drawing.Point(119, 96)
        Me.NumericUpDown3.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(89, 21)
        Me.NumericUpDown3.TabIndex = 29
        Me.NumericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown3.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(15, 98)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(98, 15)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "SUB Number     :"
        '
        'NyX_Button12
        '
        Me.NyX_Button12.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button12.Customization = ""
        Me.NyX_Button12.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button12.Image = Nothing
        Me.NyX_Button12.Location = New System.Drawing.Point(4, 58)
        Me.NyX_Button12.Name = "NyX_Button12"
        Me.NyX_Button12.NoRounding = False
        Me.NyX_Button12.Size = New System.Drawing.Size(218, 26)
        Me.NyX_Button12.TabIndex = 27
        Me.NyX_Button12.Text = "Generate Strings"
        Me.NyX_Button12.Transparent = False
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown2.ForeColor = System.Drawing.Color.White
        Me.NumericUpDown2.Location = New System.Drawing.Point(119, 30)
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {50000000, 0, 0, 0})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(89, 21)
        Me.NumericUpDown2.TabIndex = 10
        Me.NumericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown2.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(13, 33)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 15)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Strings Number :"
        '
        'NyX_GroupBox5
        '
        Me.NyX_GroupBox5.Animated = True
        Me.NyX_GroupBox5.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_GroupBox5.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_GroupBox5.Controls.Add(Me.NyX_Button11)
        Me.NyX_GroupBox5.Controls.Add(Me.NyX_Button10)
        Me.NyX_GroupBox5.Controls.Add(Me.NyX_Button9)
        Me.NyX_GroupBox5.Controls.Add(Me.NyX_Button8)
        Me.NyX_GroupBox5.Customization = ""
        Me.NyX_GroupBox5.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_GroupBox5.Image = Nothing
        Me.NyX_GroupBox5.Location = New System.Drawing.Point(683, 28)
        Me.NyX_GroupBox5.Movable = True
        Me.NyX_GroupBox5.Name = "NyX_GroupBox5"
        Me.NyX_GroupBox5.NoRounding = False
        Me.NyX_GroupBox5.Sizable = True
        Me.NyX_GroupBox5.Size = New System.Drawing.Size(226, 163)
        Me.NyX_GroupBox5.SmartBounds = True
        Me.NyX_GroupBox5.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NyX_GroupBox5.TabIndex = 22
        Me.NyX_GroupBox5.Text = "Codes"
        Me.NyX_GroupBox5.TransparencyKey = System.Drawing.Color.Empty
        Me.NyX_GroupBox5.Transparent = False
        '
        'NyX_Button11
        '
        Me.NyX_Button11.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button11.Customization = ""
        Me.NyX_Button11.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button11.Image = Nothing
        Me.NyX_Button11.Location = New System.Drawing.Point(3, 129)
        Me.NyX_Button11.Name = "NyX_Button11"
        Me.NyX_Button11.NoRounding = False
        Me.NyX_Button11.Size = New System.Drawing.Size(220, 26)
        Me.NyX_Button11.TabIndex = 26
        Me.NyX_Button11.Text = "RES To BYTE"
        Me.NyX_Button11.Transparent = False
        '
        'NyX_Button10
        '
        Me.NyX_Button10.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button10.Customization = ""
        Me.NyX_Button10.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button10.Image = Nothing
        Me.NyX_Button10.Location = New System.Drawing.Point(3, 95)
        Me.NyX_Button10.Name = "NyX_Button10"
        Me.NyX_Button10.NoRounding = False
        Me.NyX_Button10.Size = New System.Drawing.Size(220, 26)
        Me.NyX_Button10.TabIndex = 25
        Me.NyX_Button10.Text = ".Net Ressource Writer Code"
        Me.NyX_Button10.Transparent = False
        '
        'NyX_Button9
        '
        Me.NyX_Button9.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button9.Customization = ""
        Me.NyX_Button9.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button9.Image = Nothing
        Me.NyX_Button9.Location = New System.Drawing.Point(3, 61)
        Me.NyX_Button9.Name = "NyX_Button9"
        Me.NyX_Button9.NoRounding = False
        Me.NyX_Button9.Size = New System.Drawing.Size(220, 26)
        Me.NyX_Button9.TabIndex = 24
        Me.NyX_Button9.Text = "Hex To Byte"
        Me.NyX_Button9.Transparent = False
        '
        'NyX_Button8
        '
        Me.NyX_Button8.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button8.Customization = ""
        Me.NyX_Button8.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button8.Image = Nothing
        Me.NyX_Button8.Location = New System.Drawing.Point(3, 28)
        Me.NyX_Button8.Name = "NyX_Button8"
        Me.NyX_Button8.NoRounding = False
        Me.NyX_Button8.Size = New System.Drawing.Size(220, 26)
        Me.NyX_Button8.TabIndex = 23
        Me.NyX_Button8.Text = "Gzip .NET Code"
        Me.NyX_Button8.Transparent = False
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Black
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TextBox2.Location = New System.Drawing.Point(251, 56)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox2.Size = New System.Drawing.Size(429, 393)
        Me.TextBox2.TabIndex = 21
        '
        'NyX_GroupBox3
        '
        Me.NyX_GroupBox3.Animated = True
        Me.NyX_GroupBox3.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_GroupBox3.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_GroupBox3.Controls.Add(Me.NyX_Button4)
        Me.NyX_GroupBox3.Controls.Add(Me.NumericUpDown1)
        Me.NyX_GroupBox3.Controls.Add(Me.NyX_Button3)
        Me.NyX_GroupBox3.Controls.Add(Me.Label3)
        Me.NyX_GroupBox3.Controls.Add(Me.TextBox4)
        Me.NyX_GroupBox3.Controls.Add(Me.Label2)
        Me.NyX_GroupBox3.Controls.Add(Me.TextBox3)
        Me.NyX_GroupBox3.Controls.Add(Me.Label1)
        Me.NyX_GroupBox3.Customization = ""
        Me.NyX_GroupBox3.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_GroupBox3.Image = Nothing
        Me.NyX_GroupBox3.Location = New System.Drawing.Point(12, 175)
        Me.NyX_GroupBox3.Movable = True
        Me.NyX_GroupBox3.Name = "NyX_GroupBox3"
        Me.NyX_GroupBox3.NoRounding = False
        Me.NyX_GroupBox3.Sizable = True
        Me.NyX_GroupBox3.Size = New System.Drawing.Size(235, 211)
        Me.NyX_GroupBox3.SmartBounds = True
        Me.NyX_GroupBox3.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NyX_GroupBox3.TabIndex = 20
        Me.NyX_GroupBox3.Text = "Hex"
        Me.NyX_GroupBox3.TransparencyKey = System.Drawing.Color.Empty
        Me.NyX_GroupBox3.Transparent = False
        '
        'NyX_Button4
        '
        Me.NyX_Button4.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button4.Customization = ""
        Me.NyX_Button4.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button4.Image = Nothing
        Me.NyX_Button4.Location = New System.Drawing.Point(6, 169)
        Me.NyX_Button4.Name = "NyX_Button4"
        Me.NyX_Button4.NoRounding = False
        Me.NyX_Button4.Size = New System.Drawing.Size(223, 26)
        Me.NyX_Button4.TabIndex = 10
        Me.NyX_Button4.Text = ".::Generate::."
        Me.NyX_Button4.Transparent = False
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown1.ForeColor = System.Drawing.Color.White
        Me.NumericUpDown1.Location = New System.Drawing.Point(112, 137)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(110, 21)
        Me.NumericUpDown1.TabIndex = 8
        Me.NumericUpDown1.Value = New Decimal(New Integer() {200, 0, 0, 0})
        '
        'NyX_Button3
        '
        Me.NyX_Button3.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button3.Customization = ""
        Me.NyX_Button3.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button3.Image = Nothing
        Me.NyX_Button3.Location = New System.Drawing.Point(6, 95)
        Me.NyX_Button3.Name = "NyX_Button3"
        Me.NyX_Button3.NoRounding = False
        Me.NyX_Button3.Size = New System.Drawing.Size(226, 26)
        Me.NyX_Button3.TabIndex = 5
        Me.NyX_Button3.Text = ".::Random::."
        Me.NyX_Button3.Transparent = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(7, 141)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(93, 15)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Strings Length :"
        '
        'TextBox4
        '
        Me.TextBox4.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.TextBox4.Customization = ""
        Me.TextBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TextBox4.Image = Nothing
        Me.TextBox4.Location = New System.Drawing.Point(66, 62)
        Me.TextBox4.MaxLength = 32767
        Me.TextBox4.Multiline = False
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.NoRounding = False
        Me.TextBox4.ReadOnly = False
        Me.TextBox4.Size = New System.Drawing.Size(152, 24)
        Me.TextBox4.TabIndex = 4
        Me.TextBox4.Text = "CLEAN"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox4.Transparent = False
        Me.TextBox4.UseSystemPasswordChar = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(1, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(67, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Var Name :"
        '
        'TextBox3
        '
        Me.TextBox3.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.TextBox3.Customization = ""
        Me.TextBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TextBox3.Image = Nothing
        Me.TextBox3.Location = New System.Drawing.Point(79, 27)
        Me.TextBox3.MaxLength = 32767
        Me.TextBox3.Multiline = False
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.NoRounding = False
        Me.TextBox3.ReadOnly = False
        Me.TextBox3.Size = New System.Drawing.Size(150, 24)
        Me.TextBox3.TabIndex = 2
        Me.TextBox3.Text = "SLAYER"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox3.Transparent = False
        Me.TextBox3.UseSystemPasswordChar = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(2, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(75, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "SUB Name :"
        '
        'NyX_GroupBox2
        '
        Me.NyX_GroupBox2.Animated = True
        Me.NyX_GroupBox2.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_GroupBox2.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_GroupBox2.Controls.Add(Me.NyX_Button2)
        Me.NyX_GroupBox2.Controls.Add(Me.NyX_Button1)
        Me.NyX_GroupBox2.Customization = ""
        Me.NyX_GroupBox2.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_GroupBox2.Image = Nothing
        Me.NyX_GroupBox2.Location = New System.Drawing.Point(12, 94)
        Me.NyX_GroupBox2.Movable = True
        Me.NyX_GroupBox2.Name = "NyX_GroupBox2"
        Me.NyX_GroupBox2.NoRounding = False
        Me.NyX_GroupBox2.Sizable = True
        Me.NyX_GroupBox2.Size = New System.Drawing.Size(235, 75)
        Me.NyX_GroupBox2.SmartBounds = True
        Me.NyX_GroupBox2.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NyX_GroupBox2.TabIndex = 19
        Me.NyX_GroupBox2.Text = "Gzip & Base64"
        Me.NyX_GroupBox2.TransparencyKey = System.Drawing.Color.Empty
        Me.NyX_GroupBox2.Transparent = False
        '
        'NyX_Button2
        '
        Me.NyX_Button2.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button2.Customization = ""
        Me.NyX_Button2.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button2.Image = Nothing
        Me.NyX_Button2.Location = New System.Drawing.Point(123, 31)
        Me.NyX_Button2.Name = "NyX_Button2"
        Me.NyX_Button2.NoRounding = False
        Me.NyX_Button2.Size = New System.Drawing.Size(109, 26)
        Me.NyX_Button2.TabIndex = 1
        Me.NyX_Button2.Text = "Gzip & Base64"
        Me.NyX_Button2.Transparent = False
        '
        'NyX_Button1
        '
        Me.NyX_Button1.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button1.Customization = ""
        Me.NyX_Button1.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button1.Image = Nothing
        Me.NyX_Button1.Location = New System.Drawing.Point(6, 30)
        Me.NyX_Button1.Name = "NyX_Button1"
        Me.NyX_Button1.NoRounding = False
        Me.NyX_Button1.Size = New System.Drawing.Size(98, 28)
        Me.NyX_Button1.TabIndex = 0
        Me.NyX_Button1.Text = "Base64"
        Me.NyX_Button1.Transparent = False
        '
        'NyX_GroupBox1
        '
        Me.NyX_GroupBox1.Animated = True
        Me.NyX_GroupBox1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_GroupBox1.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_GroupBox1.Controls.Add(Me.PictureBox3)
        Me.NyX_GroupBox1.Controls.Add(Me.PictureBox2)
        Me.NyX_GroupBox1.Controls.Add(Me.RadioButton2)
        Me.NyX_GroupBox1.Controls.Add(Me.RadioButton1)
        Me.NyX_GroupBox1.Customization = ""
        Me.NyX_GroupBox1.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_GroupBox1.Image = Nothing
        Me.NyX_GroupBox1.Location = New System.Drawing.Point(12, 29)
        Me.NyX_GroupBox1.Movable = True
        Me.NyX_GroupBox1.Name = "NyX_GroupBox1"
        Me.NyX_GroupBox1.NoRounding = False
        Me.NyX_GroupBox1.Sizable = True
        Me.NyX_GroupBox1.Size = New System.Drawing.Size(235, 60)
        Me.NyX_GroupBox1.SmartBounds = True
        Me.NyX_GroupBox1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NyX_GroupBox1.TabIndex = 18
        Me.NyX_GroupBox1.Text = "Language"
        Me.NyX_GroupBox1.TransparencyKey = System.Drawing.Color.Empty
        Me.NyX_GroupBox1.Transparent = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(139, 32)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(23, 18)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 34
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(69, 32)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(23, 18)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 33
        Me.PictureBox2.TabStop = False
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton2.ForeColor = System.Drawing.Color.Red
        Me.RadioButton2.Location = New System.Drawing.Point(164, 31)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(68, 19)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "C#.NET"
        Me.RadioButton2.UseVisualStyleBackColor = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.BackColor = System.Drawing.Color.Transparent
        Me.RadioButton1.Checked = True
        Me.RadioButton1.ForeColor = System.Drawing.Color.Red
        Me.RadioButton1.Location = New System.Drawing.Point(4, 31)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(67, 19)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "VB.NET"
        Me.RadioButton1.UseVisualStyleBackColor = False
        '
        'NyX_GroupBox4
        '
        Me.NyX_GroupBox4.Animated = True
        Me.NyX_GroupBox4.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NyX_GroupBox4.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_GroupBox4.Controls.Add(Me.NyX_Button7)
        Me.NyX_GroupBox4.Controls.Add(Me.NyX_Button6)
        Me.NyX_GroupBox4.Controls.Add(Me.NyX_Button5)
        Me.NyX_GroupBox4.Customization = ""
        Me.NyX_GroupBox4.Font = New System.Drawing.Font("Arial", 9.0!)
        Me.NyX_GroupBox4.Image = Nothing
        Me.NyX_GroupBox4.Location = New System.Drawing.Point(12, 398)
        Me.NyX_GroupBox4.Movable = True
        Me.NyX_GroupBox4.Name = "NyX_GroupBox4"
        Me.NyX_GroupBox4.NoRounding = False
        Me.NyX_GroupBox4.Sizable = True
        Me.NyX_GroupBox4.Size = New System.Drawing.Size(235, 80)
        Me.NyX_GroupBox4.SmartBounds = True
        Me.NyX_GroupBox4.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NyX_GroupBox4.TabIndex = 17
        Me.NyX_GroupBox4.Text = "RunPE x32 & x64"
        Me.NyX_GroupBox4.TransparencyKey = System.Drawing.Color.Empty
        Me.NyX_GroupBox4.Transparent = False
        '
        'NyX_Button7
        '
        Me.NyX_Button7.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button7.Customization = ""
        Me.NyX_Button7.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button7.Image = Nothing
        Me.NyX_Button7.Location = New System.Drawing.Point(157, 30)
        Me.NyX_Button7.Name = "NyX_Button7"
        Me.NyX_Button7.NoRounding = False
        Me.NyX_Button7.Size = New System.Drawing.Size(72, 39)
        Me.NyX_Button7.TabIndex = 13
        Me.NyX_Button7.Text = "RunPE 1"
        Me.NyX_Button7.Transparent = False
        '
        'NyX_Button6
        '
        Me.NyX_Button6.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button6.Customization = ""
        Me.NyX_Button6.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button6.Image = Nothing
        Me.NyX_Button6.Location = New System.Drawing.Point(80, 30)
        Me.NyX_Button6.Name = "NyX_Button6"
        Me.NyX_Button6.NoRounding = False
        Me.NyX_Button6.Size = New System.Drawing.Size(72, 39)
        Me.NyX_Button6.TabIndex = 12
        Me.NyX_Button6.Text = "RunPE 2"
        Me.NyX_Button6.Transparent = False
        '
        'NyX_Button5
        '
        Me.NyX_Button5.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.NyX_Button5.Customization = ""
        Me.NyX_Button5.Font = New System.Drawing.Font("Arial", 8.0!)
        Me.NyX_Button5.Image = Nothing
        Me.NyX_Button5.Location = New System.Drawing.Point(5, 30)
        Me.NyX_Button5.Name = "NyX_Button5"
        Me.NyX_Button5.NoRounding = False
        Me.NyX_Button5.Size = New System.Drawing.Size(72, 39)
        Me.NyX_Button5.TabIndex = 11
        Me.NyX_Button5.Text = "RunPE 3"
        Me.NyX_Button5.Transparent = False
        '
        'NyX_ControlBox1
        '
        Me.NyX_ControlBox1.Colors = New Slayer_Encryption_Tools_v_1._3.Bloom(-1) {}
        Me.NyX_ControlBox1.Customization = ""
        Me.NyX_ControlBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.NyX_ControlBox1.Image = Nothing
        Me.NyX_ControlBox1.Location = New System.Drawing.Point(882, 0)
        Me.NyX_ControlBox1.Name = "NyX_ControlBox1"
        Me.NyX_ControlBox1.NoRounding = False
        Me.NyX_ControlBox1.Size = New System.Drawing.Size(41, 25)
        Me.NyX_ControlBox1.TabIndex = 1
        Me.NyX_ControlBox1.Text = "NyX_ControlBox1"
        Me.NyX_ControlBox1.Transparent = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(923, 495)
        Me.Controls.Add(Me.NyX_Theme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Slayer Encryption Tools v 1.1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.NyX_Theme1.ResumeLayout(False)
        Me.NyX_Theme1.PerformLayout()
        Me.NyX_GroupBox7.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NyX_GroupBox6.ResumeLayout(False)
        Me.NyX_GroupBox6.PerformLayout()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NyX_GroupBox5.ResumeLayout(False)
        Me.NyX_GroupBox3.ResumeLayout(False)
        Me.NyX_GroupBox3.PerformLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NyX_GroupBox2.ResumeLayout(False)
        Me.NyX_GroupBox1.ResumeLayout(False)
        Me.NyX_GroupBox1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NyX_GroupBox4.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents NyX_Theme1 As Slayer_Encryption_Tools_v_1._3.NYX_Theme
    Friend WithEvents NyX_ControlBox1 As Slayer_Encryption_Tools_v_1._3.NYX_ControlBox
    Friend WithEvents NyX_GroupBox3 As Slayer_Encryption_Tools_v_1._3.NYX_GroupBox
    Friend WithEvents NyX_Button4 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents NyX_Button3 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As Slayer_Encryption_Tools_v_1._3.CrystalClearTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As Slayer_Encryption_Tools_v_1._3.CrystalClearTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NyX_GroupBox2 As Slayer_Encryption_Tools_v_1._3.NYX_GroupBox
    Friend WithEvents NyX_Button2 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button1 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_GroupBox1 As Slayer_Encryption_Tools_v_1._3.NYX_GroupBox
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents NyX_GroupBox4 As Slayer_Encryption_Tools_v_1._3.NYX_GroupBox
    Friend WithEvents NyX_Button7 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button6 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button5 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_GroupBox5 As Slayer_Encryption_Tools_v_1._3.NYX_GroupBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents NyX_Button11 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button10 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button9 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button8 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_GroupBox6 As Slayer_Encryption_Tools_v_1._3.NYX_GroupBox
    Friend WithEvents NumericUpDown2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents NyX_Button13 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NumericUpDown3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents NyX_Button12 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents NyX_GroupBox7 As Slayer_Encryption_Tools_v_1._3.NYX_GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents NyX_Button19 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents NyX_Button18 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button17 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button16 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button15 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents NyX_Button14 As Slayer_Encryption_Tools_v_1._3.NYX_Button
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox

End Class
