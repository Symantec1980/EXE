﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FormSkin1 = New Crypter_ALl_tool.FormSkin()
        Me.FlatCheckBox6 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox5 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox4 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox3 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox2 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox1 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FormSkin1.SuspendLayout()
        Me.SuspendLayout()
        '
        'FormSkin1
        '
        Me.FormSkin1.BackColor = System.Drawing.Color.White
        Me.FormSkin1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FormSkin1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox6)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox5)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox4)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox3)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox2)
        Me.FormSkin1.Controls.Add(Me.FlatCheckBox1)
        Me.FormSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormSkin1.FlatColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FormSkin1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FormSkin1.HeaderColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FormSkin1.HeaderMaximize = False
        Me.FormSkin1.Location = New System.Drawing.Point(0, 0)
        Me.FormSkin1.Name = "FormSkin1"
        Me.FormSkin1.Size = New System.Drawing.Size(161, 275)
        Me.FormSkin1.TabIndex = 0
        Me.FormSkin1.Text = "Option"
        '
        'FlatCheckBox6
        '
        Me.FlatCheckBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox6.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox6.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox6.Checked = False
        Me.FlatCheckBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox6.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox6.Location = New System.Drawing.Point(12, 205)
        Me.FlatCheckBox6.Name = "FlatCheckBox6"
        Me.FlatCheckBox6.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox6.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox6.TabIndex = 6
        Me.FlatCheckBox6.Text = "FlatCheckBox6"
        '
        'FlatCheckBox5
        '
        Me.FlatCheckBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox5.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox5.Checked = False
        Me.FlatCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox5.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox5.Location = New System.Drawing.Point(12, 177)
        Me.FlatCheckBox5.Name = "FlatCheckBox5"
        Me.FlatCheckBox5.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox5.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox5.TabIndex = 5
        Me.FlatCheckBox5.Text = "JUNK COD"
        '
        'FlatCheckBox4
        '
        Me.FlatCheckBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox4.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox4.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox4.Checked = False
        Me.FlatCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox4.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox4.Location = New System.Drawing.Point(12, 149)
        Me.FlatCheckBox4.Name = "FlatCheckBox4"
        Me.FlatCheckBox4.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox4.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox4.TabIndex = 4
        Me.FlatCheckBox4.Text = "Registry key"
        '
        'FlatCheckBox3
        '
        Me.FlatCheckBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox3.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox3.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox3.Checked = False
        Me.FlatCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox3.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox3.Location = New System.Drawing.Point(12, 121)
        Me.FlatCheckBox3.Name = "FlatCheckBox3"
        Me.FlatCheckBox3.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox3.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox3.TabIndex = 3
        Me.FlatCheckBox3.Text = "Run start up"
        '
        'FlatCheckBox2
        '
        Me.FlatCheckBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox2.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox2.Checked = False
        Me.FlatCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox2.Location = New System.Drawing.Point(12, 93)
        Me.FlatCheckBox2.Name = "FlatCheckBox2"
        Me.FlatCheckBox2.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox2.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox2.TabIndex = 2
        Me.FlatCheckBox2.Text = "Anti task"
        '
        'FlatCheckBox1
        '
        Me.FlatCheckBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatCheckBox1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatCheckBox1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox1.Checked = False
        Me.FlatCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatCheckBox1.Location = New System.Drawing.Point(12, 65)
        Me.FlatCheckBox1.Name = "FlatCheckBox1"
        Me.FlatCheckBox1.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox1.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox1.TabIndex = 1
        Me.FlatCheckBox1.Text = "Sleep (20000)"
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(161, 275)
        Me.Controls.Add(Me.FormSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form4"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form4"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.FormSkin1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FormSkin1 As Crypter_ALl_tool.FormSkin
    Friend WithEvents FlatCheckBox6 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox5 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox4 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox3 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox2 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox1 As Crypter_ALl_tool.FlatCheckBox
End Class
