Module ModGen
    Const KeyPair As String = "Abt$9>3ZyX 21~)**1_0d%1xOp0#?s!14k-L7`3s9cxPo1ilIj=-0DnmOpas#$%5854/*?>00021atanu???"

    '>>> custome encryption routine used for password
    Public Function StrEncrypt(ByVal EnStr As String, Optional ByVal Key As String = KeyPair) As String
        If Len(Key) < Len(EnStr) Then
            Err.Raise(1, "Argument error", "Small Key found ????")
        End If
        Dim KeyPair As String
        KeyPair = Key
        Dim p1 As Integer
        Randomize()
        p1 = (Rnd() * 8) + 1
        Dim p2 As Integer
        p2 = Len(EnStr)
        Dim RandSeed As Integer
        RandSeed = p1
        Dim i As Integer
        Dim s1 As String = ""
        Dim ft As String
        ft = ""
        For i = 1 To 50
            s1 = s1 & Chr(Asc(Rnd() * 255))
        Next

        ft = Chr(p1) & Chr(p2)
        Dim iXor As Integer
        For i = 1 To Len(EnStr)
            iXor = Asc(Mid(KeyPair, i + p1, 1)) Xor Asc(Mid(EnStr, i, 1))
            ft = ft & Chr(iXor)
        Next
        For i = Len(ft) To 50
            ft = ft & Chr(Rnd() * 255)
        Next
        StrEncrypt = ft
    End Function

    '>>>> decryption routine used for password
    Public Function StrDecrypt(ByVal EnStr As String, Optional ByVal Key As String = KeyPair) As String
        Dim EText As String
        Dim Rt As String
        Dim p1, i As Integer
        EText = EnStr
        Dim Pbit As Integer
        Pbit = Asc(Mid(EText, 1, 1))
        p1 = Asc(Mid(EText, 1, 1))
        Dim PLen As Integer
        PLen = Asc(Mid(EText, 2, 1))
        Rt = ""
        If Len(Key) < PLen Then
            Err.Raise(1, "Argument error", "Small Key found ????")
        End If
        For i = 3 To PLen + 2
            Rt = Rt & Chr(Asc(Mid(EText, i, 1)) Xor Asc(Mid(Key, i - 2 + p1, 1)))
        Next
        StrDecrypt = Rt
    End Function
End Module
