﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form2))
        Me.HuraForm1 = New Lime_Crypter_v3.HuraForm()
        Me.HuraTabControl1 = New Lime_Crypter_v3.HuraTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtExeFolder = New Lime_Crypter_v3.HuraComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtExeName = New Lime_Crypter_v3.HuraTextBox()
        Me.HuraGroupBox3 = New Lime_Crypter_v3.HuraGroupBox()
        Me.chkInstall = New Lime_Crypter_v3.HuraCheckBox()
        Me.btnRandomExeName = New Lime_Crypter_v3.HuraButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.HuraGroupBox1 = New Lime_Crypter_v3.HuraGroupBox()
        Me.chkBindOnce = New Lime_Crypter_v3.HuraCheckBox()
        Me.HuraButton1 = New Lime_Crypter_v3.HuraButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtBind = New Lime_Crypter_v3.HuraTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtUSG = New Lime_Crypter_v3.HuraComboBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtDelay = New Lime_Crypter_v3.HuraTextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtInjection = New Lime_Crypter_v3.HuraComboBox()
        Me.chkDelay = New Lime_Crypter_v3.HuraCheckBox()
        Me.chkAntiVM = New Lime_Crypter_v3.HuraCheckBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.chkAssembly = New Lime_Crypter_v3.HuraCheckBox()
        Me.btnAssemblyRandom = New Lime_Crypter_v3.HuraButton()
        Me.btnAssemblyClone = New Lime_Crypter_v3.HuraButton()
        Me.txtAssemblyv4 = New Lime_Crypter_v3.HuraTextBox()
        Me.txtAssemblyv3 = New Lime_Crypter_v3.HuraTextBox()
        Me.txtAssemblyv2 = New Lime_Crypter_v3.HuraTextBox()
        Me.txtAssemblyv1 = New Lime_Crypter_v3.HuraTextBox()
        Me.txtAssemblyProduct = New Lime_Crypter_v3.HuraTextBox()
        Me.txtAssemblyDescription = New Lime_Crypter_v3.HuraTextBox()
        Me.txtAssemblyTitle = New Lime_Crypter_v3.HuraTextBox()
        Me.HuraGroupBox5 = New Lime_Crypter_v3.HuraGroupBox()
        Me.txtAssemblyCompany = New Lime_Crypter_v3.HuraTextBox()
        Me.btnIcon = New Lime_Crypter_v3.HuraButton()
        Me.chkIcon = New Lime_Crypter_v3.HuraCheckBox()
        Me.HuraGroupBox6 = New Lime_Crypter_v3.HuraGroupBox()
        Me.picIcon = New System.Windows.Forms.PictureBox()
        Me.txtAssemblyTrademark = New Lime_Crypter_v3.HuraTextBox()
        Me.txtAssemblyCopyright = New Lime_Crypter_v3.HuraTextBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.txtLog = New Lime_Crypter_v3.HuraTextBox()
        Me.HuraGroupBox4 = New Lime_Crypter_v3.HuraGroupBox()
        Me.btnReturn = New Lime_Crypter_v3.HuraButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnBuild = New Lime_Crypter_v3.HuraButton()
        Me.txtStub = New Lime_Crypter_v3.HuraComboBox()
        Me.HuraGroupBox2 = New Lime_Crypter_v3.HuraGroupBox()
        Me.HuraButton3 = New Lime_Crypter_v3.HuraButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.HuraCheckBox4 = New Lime_Crypter_v3.HuraCheckBox()
        Me.HuraForm1.SuspendLayout()
        Me.HuraTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.HuraGroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.HuraGroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.HuraGroupBox5.SuspendLayout()
        Me.HuraGroupBox6.SuspendLayout()
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.HuraGroupBox4.SuspendLayout()
        Me.HuraGroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'HuraForm1
        '
        Me.HuraForm1.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.HuraForm1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.HuraForm1.ColorScheme = Lime_Crypter_v3.HuraForm.ColorSchemes.Dark
        Me.HuraForm1.Controls.Add(Me.HuraTabControl1)
        Me.HuraForm1.Controls.Add(Me.HuraGroupBox2)
        Me.HuraForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HuraForm1.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraForm1.ForeColor = System.Drawing.Color.Gray
        Me.HuraForm1.Location = New System.Drawing.Point(0, 0)
        Me.HuraForm1.Name = "HuraForm1"
        Me.HuraForm1.Size = New System.Drawing.Size(530, 644)
        Me.HuraForm1.TabIndex = 0
        Me.HuraForm1.Text = "Lime Crypter | Builder"
        '
        'HuraTabControl1
        '
        Me.HuraTabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons
        Me.HuraTabControl1.Controls.Add(Me.TabPage1)
        Me.HuraTabControl1.Controls.Add(Me.TabPage3)
        Me.HuraTabControl1.Controls.Add(Me.TabPage2)
        Me.HuraTabControl1.Controls.Add(Me.TabPage4)
        Me.HuraTabControl1.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraTabControl1.ItemSize = New System.Drawing.Size(0, 30)
        Me.HuraTabControl1.Location = New System.Drawing.Point(12, 79)
        Me.HuraTabControl1.Name = "HuraTabControl1"
        Me.HuraTabControl1.SelectedIndex = 0
        Me.HuraTabControl1.Size = New System.Drawing.Size(506, 553)
        Me.HuraTabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.txtExeFolder)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.txtExeName)
        Me.TabPage1.Controls.Add(Me.HuraGroupBox3)
        Me.TabPage1.Location = New System.Drawing.Point(4, 34)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(498, 515)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Install"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(16, 131)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 25)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Folder: "
        '
        'txtExeFolder
        '
        Me.txtExeFolder.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(6, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(167, Byte), Integer))
        Me.txtExeFolder.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtExeFolder.ColorScheme = Lime_Crypter_v3.HuraComboBox.ColorSchemes.Dark
        Me.txtExeFolder.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.txtExeFolder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtExeFolder.Enabled = False
        Me.txtExeFolder.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtExeFolder.ForeColor = System.Drawing.Color.Black
        Me.txtExeFolder.FormattingEnabled = True
        Me.txtExeFolder.Items.AddRange(New Object() {"Temp", "Appdata", "UserFolder"})
        Me.txtExeFolder.Location = New System.Drawing.Point(114, 128)
        Me.txtExeFolder.Name = "txtExeFolder"
        Me.txtExeFolder.Size = New System.Drawing.Size(189, 34)
        Me.txtExeFolder.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(16, 74)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 25)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Filename:"
        '
        'txtExeName
        '
        Me.txtExeName.BackColor = System.Drawing.Color.Transparent
        Me.txtExeName.BackgroundColour = System.Drawing.Color.Black
        Me.txtExeName.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtExeName.Enabled = False
        Me.txtExeName.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtExeName.Location = New System.Drawing.Point(114, 67)
        Me.txtExeName.MaxLength = 32767
        Me.txtExeName.Multiline = False
        Me.txtExeName.Name = "txtExeName"
        Me.txtExeName.ReadOnly = False
        Me.txtExeName.Size = New System.Drawing.Size(189, 38)
        Me.txtExeName.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtExeName.TabIndex = 2
        Me.txtExeName.Text = "MServices.exe"
        Me.txtExeName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtExeName.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtExeName.UseSystemPasswordChar = False
        '
        'HuraGroupBox3
        '
        Me.HuraGroupBox3.BackColor = System.Drawing.Color.Black
        Me.HuraGroupBox3.Controls.Add(Me.chkInstall)
        Me.HuraGroupBox3.Controls.Add(Me.btnRandomExeName)
        Me.HuraGroupBox3.Location = New System.Drawing.Point(0, 3)
        Me.HuraGroupBox3.Name = "HuraGroupBox3"
        Me.HuraGroupBox3.Size = New System.Drawing.Size(492, 506)
        Me.HuraGroupBox3.TabIndex = 10
        Me.HuraGroupBox3.Text = "HuraGroupBox3"
        '
        'chkInstall
        '
        Me.chkInstall.BaseColour = System.Drawing.Color.Black
        Me.chkInstall.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkInstall.Checked = False
        Me.chkInstall.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkInstall.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chkInstall.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.chkInstall.Location = New System.Drawing.Point(20, 17)
        Me.chkInstall.Name = "chkInstall"
        Me.chkInstall.Size = New System.Drawing.Size(100, 22)
        Me.chkInstall.TabIndex = 20
        Me.chkInstall.Text = "OFF"
        '
        'btnRandomExeName
        '
        Me.btnRandomExeName.BackColor = System.Drawing.Color.Transparent
        Me.btnRandomExeName.BaseColour = System.Drawing.Color.Black
        Me.btnRandomExeName.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnRandomExeName.Enabled = False
        Me.btnRandomExeName.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnRandomExeName.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnRandomExeName.Location = New System.Drawing.Point(309, 64)
        Me.btnRandomExeName.Name = "btnRandomExeName"
        Me.btnRandomExeName.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnRandomExeName.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnRandomExeName.Size = New System.Drawing.Size(32, 38)
        Me.btnRandomExeName.TabIndex = 19
        Me.btnRandomExeName.Text = "R"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.HuraGroupBox1)
        Me.TabPage3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.TabPage3.Location = New System.Drawing.Point(4, 34)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(498, 515)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Settings"
        '
        'HuraGroupBox1
        '
        Me.HuraGroupBox1.BackColor = System.Drawing.Color.Black
        Me.HuraGroupBox1.Controls.Add(Me.chkBindOnce)
        Me.HuraGroupBox1.Controls.Add(Me.HuraButton1)
        Me.HuraGroupBox1.Controls.Add(Me.Label3)
        Me.HuraGroupBox1.Controls.Add(Me.txtBind)
        Me.HuraGroupBox1.Controls.Add(Me.Label10)
        Me.HuraGroupBox1.Controls.Add(Me.txtUSG)
        Me.HuraGroupBox1.Controls.Add(Me.Label4)
        Me.HuraGroupBox1.Controls.Add(Me.txtDelay)
        Me.HuraGroupBox1.Controls.Add(Me.Label7)
        Me.HuraGroupBox1.Controls.Add(Me.txtInjection)
        Me.HuraGroupBox1.Controls.Add(Me.chkDelay)
        Me.HuraGroupBox1.Controls.Add(Me.chkAntiVM)
        Me.HuraGroupBox1.Location = New System.Drawing.Point(0, 3)
        Me.HuraGroupBox1.Name = "HuraGroupBox1"
        Me.HuraGroupBox1.Size = New System.Drawing.Size(492, 506)
        Me.HuraGroupBox1.TabIndex = 5
        Me.HuraGroupBox1.Text = "HuraGroupBox1"
        '
        'chkBindOnce
        '
        Me.chkBindOnce.BaseColour = System.Drawing.Color.Black
        Me.chkBindOnce.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkBindOnce.Checked = False
        Me.chkBindOnce.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkBindOnce.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chkBindOnce.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.chkBindOnce.Location = New System.Drawing.Point(350, 159)
        Me.chkBindOnce.Name = "chkBindOnce"
        Me.chkBindOnce.Size = New System.Drawing.Size(116, 22)
        Me.chkBindOnce.TabIndex = 25
        Me.chkBindOnce.Text = "Once"
        '
        'HuraButton1
        '
        Me.HuraButton1.BackColor = System.Drawing.Color.Transparent
        Me.HuraButton1.BaseColour = System.Drawing.Color.Black
        Me.HuraButton1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.HuraButton1.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.HuraButton1.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.HuraButton1.Location = New System.Drawing.Point(307, 152)
        Me.HuraButton1.Name = "HuraButton1"
        Me.HuraButton1.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.HuraButton1.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.HuraButton1.Size = New System.Drawing.Size(32, 38)
        Me.HuraButton1.TabIndex = 24
        Me.HuraButton1.Text = "O"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(10, 159)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 25)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Bind:"
        '
        'txtBind
        '
        Me.txtBind.BackColor = System.Drawing.Color.Transparent
        Me.txtBind.BackgroundColour = System.Drawing.Color.Black
        Me.txtBind.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtBind.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtBind.Location = New System.Drawing.Point(108, 152)
        Me.txtBind.MaxLength = 32767
        Me.txtBind.Multiline = False
        Me.txtBind.Name = "txtBind"
        Me.txtBind.ReadOnly = False
        Me.txtBind.Size = New System.Drawing.Size(189, 38)
        Me.txtBind.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtBind.TabIndex = 22
        Me.txtBind.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtBind.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtBind.UseSystemPasswordChar = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label10.Location = New System.Drawing.Point(10, 97)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(52, 25)
        Me.Label10.TabIndex = 21
        Me.Label10.Text = "USG:"
        '
        'txtUSG
        '
        Me.txtUSG.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(6, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(167, Byte), Integer))
        Me.txtUSG.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtUSG.ColorScheme = Lime_Crypter_v3.HuraComboBox.ColorSchemes.Dark
        Me.txtUSG.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.txtUSG.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtUSG.Enabled = False
        Me.txtUSG.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtUSG.ForeColor = System.Drawing.Color.Black
        Me.txtUSG.FormattingEnabled = True
        Me.txtUSG.Items.AddRange(New Object() {"English", "Chinese"})
        Me.txtUSG.Location = New System.Drawing.Point(108, 94)
        Me.txtUSG.Name = "txtUSG"
        Me.txtUSG.Size = New System.Drawing.Size(189, 34)
        Me.txtUSG.TabIndex = 20
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(168, 227)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(74, 25)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Second"
        '
        'txtDelay
        '
        Me.txtDelay.BackColor = System.Drawing.Color.Transparent
        Me.txtDelay.BackgroundColour = System.Drawing.Color.Black
        Me.txtDelay.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtDelay.Location = New System.Drawing.Point(108, 223)
        Me.txtDelay.MaxLength = 32767
        Me.txtDelay.Multiline = False
        Me.txtDelay.Name = "txtDelay"
        Me.txtDelay.ReadOnly = False
        Me.txtDelay.Size = New System.Drawing.Size(54, 38)
        Me.txtDelay.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtDelay.TabIndex = 4
        Me.txtDelay.Text = "1"
        Me.txtDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtDelay.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtDelay.UseSystemPasswordChar = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(10, 33)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(89, 25)
        Me.Label7.TabIndex = 8
        Me.Label7.Text = "Injection:"
        '
        'txtInjection
        '
        Me.txtInjection.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(6, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(167, Byte), Integer))
        Me.txtInjection.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtInjection.ColorScheme = Lime_Crypter_v3.HuraComboBox.ColorSchemes.Dark
        Me.txtInjection.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.txtInjection.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtInjection.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtInjection.ForeColor = System.Drawing.Color.Black
        Me.txtInjection.FormattingEnabled = True
        Me.txtInjection.Items.AddRange(New Object() {"Itself", "Regasm", "MSBuild"})
        Me.txtInjection.Location = New System.Drawing.Point(108, 30)
        Me.txtInjection.Name = "txtInjection"
        Me.txtInjection.Size = New System.Drawing.Size(189, 34)
        Me.txtInjection.TabIndex = 7
        '
        'chkDelay
        '
        Me.chkDelay.BaseColour = System.Drawing.Color.Black
        Me.chkDelay.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkDelay.Checked = False
        Me.chkDelay.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkDelay.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chkDelay.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.chkDelay.Location = New System.Drawing.Point(15, 230)
        Me.chkDelay.Name = "chkDelay"
        Me.chkDelay.Size = New System.Drawing.Size(87, 22)
        Me.chkDelay.TabIndex = 0
        Me.chkDelay.Text = "Delay"
        '
        'chkAntiVM
        '
        Me.chkAntiVM.BaseColour = System.Drawing.Color.Black
        Me.chkAntiVM.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkAntiVM.Checked = False
        Me.chkAntiVM.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkAntiVM.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chkAntiVM.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.chkAntiVM.Location = New System.Drawing.Point(15, 280)
        Me.chkAntiVM.Name = "chkAntiVM"
        Me.chkAntiVM.Size = New System.Drawing.Size(290, 22)
        Me.chkAntiVM.TabIndex = 1
        Me.chkAntiVM.Text = "Anti Virtual Environment"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.chkAssembly)
        Me.TabPage2.Controls.Add(Me.btnAssemblyRandom)
        Me.TabPage2.Controls.Add(Me.btnAssemblyClone)
        Me.TabPage2.Controls.Add(Me.txtAssemblyv4)
        Me.TabPage2.Controls.Add(Me.txtAssemblyv3)
        Me.TabPage2.Controls.Add(Me.txtAssemblyv2)
        Me.TabPage2.Controls.Add(Me.txtAssemblyv1)
        Me.TabPage2.Controls.Add(Me.txtAssemblyProduct)
        Me.TabPage2.Controls.Add(Me.txtAssemblyDescription)
        Me.TabPage2.Controls.Add(Me.txtAssemblyTitle)
        Me.TabPage2.Controls.Add(Me.HuraGroupBox5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 34)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(498, 515)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Assembly"
        '
        'chkAssembly
        '
        Me.chkAssembly.BaseColour = System.Drawing.Color.Black
        Me.chkAssembly.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkAssembly.Checked = False
        Me.chkAssembly.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkAssembly.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chkAssembly.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.chkAssembly.Location = New System.Drawing.Point(20, 20)
        Me.chkAssembly.Name = "chkAssembly"
        Me.chkAssembly.Size = New System.Drawing.Size(100, 22)
        Me.chkAssembly.TabIndex = 11
        Me.chkAssembly.Text = "OFF"
        '
        'btnAssemblyRandom
        '
        Me.btnAssemblyRandom.BackColor = System.Drawing.Color.Transparent
        Me.btnAssemblyRandom.BaseColour = System.Drawing.Color.Black
        Me.btnAssemblyRandom.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnAssemblyRandom.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnAssemblyRandom.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnAssemblyRandom.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAssemblyRandom.Location = New System.Drawing.Point(162, 439)
        Me.btnAssemblyRandom.Name = "btnAssemblyRandom"
        Me.btnAssemblyRandom.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnAssemblyRandom.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAssemblyRandom.Size = New System.Drawing.Size(75, 30)
        Me.btnAssemblyRandom.TabIndex = 10
        Me.btnAssemblyRandom.Text = "R"
        '
        'btnAssemblyClone
        '
        Me.btnAssemblyClone.BackColor = System.Drawing.Color.Transparent
        Me.btnAssemblyClone.BaseColour = System.Drawing.Color.Black
        Me.btnAssemblyClone.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnAssemblyClone.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnAssemblyClone.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnAssemblyClone.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnAssemblyClone.Location = New System.Drawing.Point(19, 439)
        Me.btnAssemblyClone.Name = "btnAssemblyClone"
        Me.btnAssemblyClone.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnAssemblyClone.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnAssemblyClone.Size = New System.Drawing.Size(75, 30)
        Me.btnAssemblyClone.TabIndex = 1
        Me.btnAssemblyClone.Text = "C"
        '
        'txtAssemblyv4
        '
        Me.txtAssemblyv4.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyv4.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyv4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyv4.Enabled = False
        Me.txtAssemblyv4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv4.Location = New System.Drawing.Point(196, 378)
        Me.txtAssemblyv4.MaxLength = 32767
        Me.txtAssemblyv4.Multiline = False
        Me.txtAssemblyv4.Name = "txtAssemblyv4"
        Me.txtAssemblyv4.ReadOnly = False
        Me.txtAssemblyv4.Size = New System.Drawing.Size(41, 38)
        Me.txtAssemblyv4.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyv4.TabIndex = 9
        Me.txtAssemblyv4.Text = "0"
        Me.txtAssemblyv4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyv4.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv4.UseSystemPasswordChar = False
        '
        'txtAssemblyv3
        '
        Me.txtAssemblyv3.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyv3.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyv3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyv3.Enabled = False
        Me.txtAssemblyv3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv3.Location = New System.Drawing.Point(136, 378)
        Me.txtAssemblyv3.MaxLength = 32767
        Me.txtAssemblyv3.Multiline = False
        Me.txtAssemblyv3.Name = "txtAssemblyv3"
        Me.txtAssemblyv3.ReadOnly = False
        Me.txtAssemblyv3.Size = New System.Drawing.Size(41, 38)
        Me.txtAssemblyv3.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyv3.TabIndex = 8
        Me.txtAssemblyv3.Text = "0"
        Me.txtAssemblyv3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyv3.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv3.UseSystemPasswordChar = False
        '
        'txtAssemblyv2
        '
        Me.txtAssemblyv2.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyv2.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyv2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyv2.Enabled = False
        Me.txtAssemblyv2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv2.Location = New System.Drawing.Point(77, 378)
        Me.txtAssemblyv2.MaxLength = 32767
        Me.txtAssemblyv2.Multiline = False
        Me.txtAssemblyv2.Name = "txtAssemblyv2"
        Me.txtAssemblyv2.ReadOnly = False
        Me.txtAssemblyv2.Size = New System.Drawing.Size(41, 38)
        Me.txtAssemblyv2.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyv2.TabIndex = 7
        Me.txtAssemblyv2.Text = "0"
        Me.txtAssemblyv2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyv2.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv2.UseSystemPasswordChar = False
        '
        'txtAssemblyv1
        '
        Me.txtAssemblyv1.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyv1.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyv1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyv1.Enabled = False
        Me.txtAssemblyv1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv1.Location = New System.Drawing.Point(19, 378)
        Me.txtAssemblyv1.MaxLength = 32767
        Me.txtAssemblyv1.Multiline = False
        Me.txtAssemblyv1.Name = "txtAssemblyv1"
        Me.txtAssemblyv1.ReadOnly = False
        Me.txtAssemblyv1.Size = New System.Drawing.Size(41, 38)
        Me.txtAssemblyv1.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyv1.TabIndex = 6
        Me.txtAssemblyv1.Text = "0"
        Me.txtAssemblyv1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyv1.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyv1.UseSystemPasswordChar = False
        '
        'txtAssemblyProduct
        '
        Me.txtAssemblyProduct.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyProduct.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyProduct.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyProduct.Enabled = False
        Me.txtAssemblyProduct.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyProduct.Location = New System.Drawing.Point(19, 163)
        Me.txtAssemblyProduct.MaxLength = 32767
        Me.txtAssemblyProduct.Multiline = False
        Me.txtAssemblyProduct.Name = "txtAssemblyProduct"
        Me.txtAssemblyProduct.ReadOnly = False
        Me.txtAssemblyProduct.Size = New System.Drawing.Size(218, 38)
        Me.txtAssemblyProduct.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyProduct.TabIndex = 4
        Me.txtAssemblyProduct.Text = "Product"
        Me.txtAssemblyProduct.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyProduct.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyProduct.UseSystemPasswordChar = False
        '
        'txtAssemblyDescription
        '
        Me.txtAssemblyDescription.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyDescription.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyDescription.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyDescription.Enabled = False
        Me.txtAssemblyDescription.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyDescription.Location = New System.Drawing.Point(19, 109)
        Me.txtAssemblyDescription.MaxLength = 32767
        Me.txtAssemblyDescription.Multiline = False
        Me.txtAssemblyDescription.Name = "txtAssemblyDescription"
        Me.txtAssemblyDescription.ReadOnly = False
        Me.txtAssemblyDescription.Size = New System.Drawing.Size(218, 38)
        Me.txtAssemblyDescription.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyDescription.TabIndex = 4
        Me.txtAssemblyDescription.Text = "Description"
        Me.txtAssemblyDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyDescription.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyDescription.UseSystemPasswordChar = False
        '
        'txtAssemblyTitle
        '
        Me.txtAssemblyTitle.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyTitle.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyTitle.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyTitle.Enabled = False
        Me.txtAssemblyTitle.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyTitle.Location = New System.Drawing.Point(19, 55)
        Me.txtAssemblyTitle.MaxLength = 32767
        Me.txtAssemblyTitle.Multiline = False
        Me.txtAssemblyTitle.Name = "txtAssemblyTitle"
        Me.txtAssemblyTitle.ReadOnly = False
        Me.txtAssemblyTitle.Size = New System.Drawing.Size(218, 38)
        Me.txtAssemblyTitle.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyTitle.TabIndex = 3
        Me.txtAssemblyTitle.Text = "Title"
        Me.txtAssemblyTitle.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyTitle.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyTitle.UseSystemPasswordChar = False
        '
        'HuraGroupBox5
        '
        Me.HuraGroupBox5.BackColor = System.Drawing.Color.Black
        Me.HuraGroupBox5.Controls.Add(Me.txtAssemblyCompany)
        Me.HuraGroupBox5.Controls.Add(Me.btnIcon)
        Me.HuraGroupBox5.Controls.Add(Me.chkIcon)
        Me.HuraGroupBox5.Controls.Add(Me.HuraGroupBox6)
        Me.HuraGroupBox5.Controls.Add(Me.txtAssemblyTrademark)
        Me.HuraGroupBox5.Controls.Add(Me.txtAssemblyCopyright)
        Me.HuraGroupBox5.Location = New System.Drawing.Point(0, 3)
        Me.HuraGroupBox5.Name = "HuraGroupBox5"
        Me.HuraGroupBox5.Size = New System.Drawing.Size(492, 506)
        Me.HuraGroupBox5.TabIndex = 12
        Me.HuraGroupBox5.Text = "HuraGroupBox5"
        '
        'txtAssemblyCompany
        '
        Me.txtAssemblyCompany.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyCompany.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyCompany.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyCompany.Enabled = False
        Me.txtAssemblyCompany.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyCompany.Location = New System.Drawing.Point(19, 211)
        Me.txtAssemblyCompany.MaxLength = 32767
        Me.txtAssemblyCompany.Multiline = False
        Me.txtAssemblyCompany.Name = "txtAssemblyCompany"
        Me.txtAssemblyCompany.ReadOnly = False
        Me.txtAssemblyCompany.Size = New System.Drawing.Size(218, 38)
        Me.txtAssemblyCompany.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyCompany.TabIndex = 17
        Me.txtAssemblyCompany.Text = "Company"
        Me.txtAssemblyCompany.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyCompany.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyCompany.UseSystemPasswordChar = False
        '
        'btnIcon
        '
        Me.btnIcon.BackColor = System.Drawing.Color.Transparent
        Me.btnIcon.BaseColour = System.Drawing.Color.Black
        Me.btnIcon.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnIcon.Enabled = False
        Me.btnIcon.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnIcon.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnIcon.Location = New System.Drawing.Point(329, 52)
        Me.btnIcon.Name = "btnIcon"
        Me.btnIcon.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnIcon.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnIcon.Size = New System.Drawing.Size(141, 38)
        Me.btnIcon.TabIndex = 16
        Me.btnIcon.Text = "Select Icon"
        '
        'chkIcon
        '
        Me.chkIcon.BaseColour = System.Drawing.Color.Black
        Me.chkIcon.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkIcon.Checked = False
        Me.chkIcon.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.chkIcon.Cursor = System.Windows.Forms.Cursors.Hand
        Me.chkIcon.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.chkIcon.Location = New System.Drawing.Point(330, 15)
        Me.chkIcon.Name = "chkIcon"
        Me.chkIcon.Size = New System.Drawing.Size(100, 22)
        Me.chkIcon.TabIndex = 13
        Me.chkIcon.Text = "OFF"
        '
        'HuraGroupBox6
        '
        Me.HuraGroupBox6.BackColor = System.Drawing.Color.Black
        Me.HuraGroupBox6.Controls.Add(Me.picIcon)
        Me.HuraGroupBox6.Location = New System.Drawing.Point(330, 106)
        Me.HuraGroupBox6.Name = "HuraGroupBox6"
        Me.HuraGroupBox6.Size = New System.Drawing.Size(100, 100)
        Me.HuraGroupBox6.TabIndex = 16
        Me.HuraGroupBox6.Text = "HuraGroupBox6"
        '
        'picIcon
        '
        Me.picIcon.Enabled = False
        Me.picIcon.Image = Global.Lime_Crypter_v3.My.Resources.Resources.nyan
        Me.picIcon.Location = New System.Drawing.Point(1, 3)
        Me.picIcon.Name = "picIcon"
        Me.picIcon.Size = New System.Drawing.Size(96, 96)
        Me.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picIcon.TabIndex = 17
        Me.picIcon.TabStop = False
        '
        'txtAssemblyTrademark
        '
        Me.txtAssemblyTrademark.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyTrademark.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyTrademark.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyTrademark.Enabled = False
        Me.txtAssemblyTrademark.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyTrademark.Location = New System.Drawing.Point(19, 321)
        Me.txtAssemblyTrademark.MaxLength = 32767
        Me.txtAssemblyTrademark.Multiline = False
        Me.txtAssemblyTrademark.Name = "txtAssemblyTrademark"
        Me.txtAssemblyTrademark.ReadOnly = False
        Me.txtAssemblyTrademark.Size = New System.Drawing.Size(218, 38)
        Me.txtAssemblyTrademark.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyTrademark.TabIndex = 5
        Me.txtAssemblyTrademark.Text = "Trademark"
        Me.txtAssemblyTrademark.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyTrademark.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyTrademark.UseSystemPasswordChar = False
        '
        'txtAssemblyCopyright
        '
        Me.txtAssemblyCopyright.BackColor = System.Drawing.Color.Transparent
        Me.txtAssemblyCopyright.BackgroundColour = System.Drawing.Color.Black
        Me.txtAssemblyCopyright.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtAssemblyCopyright.Enabled = False
        Me.txtAssemblyCopyright.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyCopyright.Location = New System.Drawing.Point(19, 267)
        Me.txtAssemblyCopyright.MaxLength = 32767
        Me.txtAssemblyCopyright.Multiline = False
        Me.txtAssemblyCopyright.Name = "txtAssemblyCopyright"
        Me.txtAssemblyCopyright.ReadOnly = False
        Me.txtAssemblyCopyright.Size = New System.Drawing.Size(218, 38)
        Me.txtAssemblyCopyright.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtAssemblyCopyright.TabIndex = 5
        Me.txtAssemblyCopyright.Text = "Copyright"
        Me.txtAssemblyCopyright.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtAssemblyCopyright.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtAssemblyCopyright.UseSystemPasswordChar = False
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.txtLog)
        Me.TabPage4.Controls.Add(Me.HuraGroupBox4)
        Me.TabPage4.Location = New System.Drawing.Point(4, 34)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(498, 515)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Build"
        '
        'txtLog
        '
        Me.txtLog.BackColor = System.Drawing.Color.Transparent
        Me.txtLog.BackgroundColour = System.Drawing.Color.Black
        Me.txtLog.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.txtLog.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtLog.Location = New System.Drawing.Point(8, 82)
        Me.txtLog.MaxLength = 32767
        Me.txtLog.Multiline = True
        Me.txtLog.Name = "txtLog"
        Me.txtLog.ReadOnly = True
        Me.txtLog.Size = New System.Drawing.Size(477, 340)
        Me.txtLog.Style = Lime_Crypter_v3.HuraTextBox.Styles.Normal
        Me.txtLog.TabIndex = 1
        Me.txtLog.Text = "..."
        Me.txtLog.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtLog.TextColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.txtLog.UseSystemPasswordChar = False
        '
        'HuraGroupBox4
        '
        Me.HuraGroupBox4.BackColor = System.Drawing.Color.Black
        Me.HuraGroupBox4.Controls.Add(Me.btnReturn)
        Me.HuraGroupBox4.Controls.Add(Me.Label6)
        Me.HuraGroupBox4.Controls.Add(Me.btnBuild)
        Me.HuraGroupBox4.Controls.Add(Me.txtStub)
        Me.HuraGroupBox4.Location = New System.Drawing.Point(0, 3)
        Me.HuraGroupBox4.Name = "HuraGroupBox4"
        Me.HuraGroupBox4.Size = New System.Drawing.Size(492, 506)
        Me.HuraGroupBox4.TabIndex = 17
        Me.HuraGroupBox4.Text = "HuraGroupBox4"
        '
        'btnReturn
        '
        Me.btnReturn.BackColor = System.Drawing.Color.Transparent
        Me.btnReturn.BaseColour = System.Drawing.Color.Black
        Me.btnReturn.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnReturn.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnReturn.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnReturn.Location = New System.Drawing.Point(345, 447)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnReturn.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnReturn.Size = New System.Drawing.Size(140, 38)
        Me.btnReturn.TabIndex = 16
        Me.btnReturn.Text = "RETURN"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(13, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(50, 25)
        Me.Label6.TabIndex = 4
        Me.Label6.Text = "Stub"
        '
        'btnBuild
        '
        Me.btnBuild.BackColor = System.Drawing.Color.Transparent
        Me.btnBuild.BaseColour = System.Drawing.Color.Black
        Me.btnBuild.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnBuild.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.btnBuild.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.btnBuild.Location = New System.Drawing.Point(8, 447)
        Me.btnBuild.Name = "btnBuild"
        Me.btnBuild.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.btnBuild.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBuild.Size = New System.Drawing.Size(140, 38)
        Me.btnBuild.TabIndex = 15
        Me.btnBuild.Text = "BUILD"
        '
        'txtStub
        '
        Me.txtStub.AccentColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(6, Byte), Integer), CType(CType(160, Byte), Integer), CType(CType(167, Byte), Integer))
        Me.txtStub.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.txtStub.ColorScheme = Lime_Crypter_v3.HuraComboBox.ColorSchemes.Dark
        Me.txtStub.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.txtStub.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.txtStub.Enabled = False
        Me.txtStub.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.txtStub.ForeColor = System.Drawing.Color.Black
        Me.txtStub.FormattingEnabled = True
        Me.txtStub.Items.AddRange(New Object() {"#1", "#2", "#3"})
        Me.txtStub.Location = New System.Drawing.Point(109, 19)
        Me.txtStub.Name = "txtStub"
        Me.txtStub.Size = New System.Drawing.Size(120, 34)
        Me.txtStub.TabIndex = 3
        '
        'HuraGroupBox2
        '
        Me.HuraGroupBox2.BackColor = System.Drawing.Color.Black
        Me.HuraGroupBox2.Controls.Add(Me.HuraButton3)
        Me.HuraGroupBox2.Controls.Add(Me.PictureBox1)
        Me.HuraGroupBox2.Controls.Add(Me.HuraCheckBox4)
        Me.HuraGroupBox2.Location = New System.Drawing.Point(12, 120)
        Me.HuraGroupBox2.Name = "HuraGroupBox2"
        Me.HuraGroupBox2.Size = New System.Drawing.Size(492, 437)
        Me.HuraGroupBox2.TabIndex = 15
        Me.HuraGroupBox2.Text = "HuraGroupBox2"
        '
        'HuraButton3
        '
        Me.HuraButton3.BackColor = System.Drawing.Color.Transparent
        Me.HuraButton3.BaseColour = System.Drawing.Color.Black
        Me.HuraButton3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.HuraButton3.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.HuraButton3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.HuraButton3.HoverColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.HuraButton3.Location = New System.Drawing.Point(334, 52)
        Me.HuraButton3.Name = "HuraButton3"
        Me.HuraButton3.PressedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.HuraButton3.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.HuraButton3.Size = New System.Drawing.Size(140, 38)
        Me.HuraButton3.TabIndex = 14
        Me.HuraButton3.Text = "Select Icon"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(334, 106)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(96, 96)
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'HuraCheckBox4
        '
        Me.HuraCheckBox4.BaseColour = System.Drawing.Color.Black
        Me.HuraCheckBox4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.HuraCheckBox4.Checked = False
        Me.HuraCheckBox4.CheckedColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(219, Byte), Integer), CType(CType(106, Byte), Integer))
        Me.HuraCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.HuraCheckBox4.FontColour = System.Drawing.Color.FromArgb(CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer), CType(CType(150, Byte), Integer))
        Me.HuraCheckBox4.Location = New System.Drawing.Point(334, 15)
        Me.HuraCheckBox4.Name = "HuraCheckBox4"
        Me.HuraCheckBox4.Size = New System.Drawing.Size(100, 22)
        Me.HuraCheckBox4.TabIndex = 12
        Me.HuraCheckBox4.Text = "OFF"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(530, 644)
        Me.Controls.Add(Me.HuraForm1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.HuraForm1.ResumeLayout(False)
        Me.HuraTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.HuraGroupBox3.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.HuraGroupBox1.ResumeLayout(False)
        Me.HuraGroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.HuraGroupBox5.ResumeLayout(False)
        Me.HuraGroupBox6.ResumeLayout(False)
        CType(Me.picIcon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.HuraGroupBox4.ResumeLayout(False)
        Me.HuraGroupBox4.PerformLayout()
        Me.HuraGroupBox2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents HuraForm1 As HuraForm
    Friend WithEvents HuraTabControl1 As HuraTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Label2 As Label
    Friend WithEvents txtExeFolder As HuraComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtExeName As HuraTextBox
    Friend WithEvents btnAssemblyRandom As HuraButton
    Friend WithEvents btnAssemblyClone As HuraButton
    Friend WithEvents txtAssemblyv4 As HuraTextBox
    Friend WithEvents txtAssemblyv3 As HuraTextBox
    Friend WithEvents txtAssemblyv2 As HuraTextBox
    Friend WithEvents txtAssemblyv1 As HuraTextBox
    Friend WithEvents txtAssemblyTrademark As HuraTextBox
    Friend WithEvents txtAssemblyCopyright As HuraTextBox
    Friend WithEvents txtAssemblyProduct As HuraTextBox
    Friend WithEvents txtAssemblyDescription As HuraTextBox
    Friend WithEvents txtAssemblyTitle As HuraTextBox
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents chkAssembly As HuraCheckBox
    Friend WithEvents HuraCheckBox4 As HuraCheckBox
    Friend WithEvents HuraButton3 As HuraButton
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents chkAntiVM As HuraCheckBox
    Friend WithEvents chkDelay As HuraCheckBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtDelay As HuraTextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtStub As HuraComboBox
    Friend WithEvents txtLog As HuraTextBox
    Friend WithEvents btnReturn As HuraButton
    Friend WithEvents btnBuild As HuraButton
    Friend WithEvents HuraGroupBox3 As HuraGroupBox
    Friend WithEvents HuraGroupBox2 As HuraGroupBox
    Friend WithEvents HuraGroupBox1 As HuraGroupBox
    Friend WithEvents HuraGroupBox4 As HuraGroupBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtInjection As HuraComboBox
    Friend WithEvents HuraGroupBox5 As HuraGroupBox
    Friend WithEvents btnIcon As HuraButton
    Friend WithEvents chkIcon As HuraCheckBox
    Friend WithEvents HuraGroupBox6 As HuraGroupBox
    Friend WithEvents picIcon As PictureBox
    Friend WithEvents btnRandomExeName As HuraButton
    Friend WithEvents Label10 As Label
    Friend WithEvents txtUSG As HuraComboBox
    Friend WithEvents chkInstall As HuraCheckBox
    Friend WithEvents txtAssemblyCompany As HuraTextBox
    Friend WithEvents chkBindOnce As HuraCheckBox
    Friend WithEvents HuraButton1 As HuraButton
    Friend WithEvents Label3 As Label
    Friend WithEvents txtBind As HuraTextBox
End Class
