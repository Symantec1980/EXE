﻿Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic.CompilerServices

Public Class Form1
    'Arabyou
    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click
        'Arabyou
    End Sub
    'Arabyou
    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Dim folderBrowserDialog As FolderBrowserDialog = New FolderBrowserDialog()
        If folderBrowserDialog.ShowDialog() = DialogResult.OK Then
            Dim str As String = folderBrowserDialog.SelectedPath + "\"
            Directory.CreateDirectory(str + "NjClean")
            Directory.CreateDirectory(str + "NjClean\My Project")
            File.WriteAllText(str + "NjClean\NjClean.vbproj", My.Resources.NjClean)
            File.WriteAllText(str + "NjClean\NjClean.vbproj.user", My.Resources.NjClean_vbproj)
            File.WriteAllText(str + "NjClean\GzipDecompress.vb", My.Resources.GzipDecompress)
            File.WriteAllText(str + "NjClean\Module1.vb", My.Resources.Module1)
            File.WriteAllText(str + "NjClean\Module2.vb", My.Resources.Module2)
            File.WriteAllText(str + "NjClean\My Project\Resources3.Designer.vb", My.Resources.Resources3_Designer)
            File.WriteAllText(str + "NjClean\My Project\Application3.Designer.vb", My.Resources.Application3_Designer)
            File.WriteAllText(str + "NjClean\My Project\Application3.myapp", My.Resources.Application3)
            File.WriteAllText(str + "NjClean\My Project\Resources3.resx", My.Resources.Resources3)
            File.WriteAllText(str + "NjClean\My Project\Settings3.settings", My.Resources.Settings3)
            File.WriteAllText(str + "NjClean\My Project\Settings3.Designer.vb", My.Resources.Settings3_Designer)
            File.WriteAllText(str + "NjClean\My Project\AssemblyInfo3.vb", My.Resources.AssemblyInfo3)
            File.WriteAllText(str + "NjClean\My Project\app3.manifest", My.Resources.app3)
            File.WriteAllText(str + "NjClean\My Project\Resources.Designer.vb", My.Resources.Resources_Designer)
            File.WriteAllText(str + "NjClean\My Project\Resources.resx", My.Resources.Resourcess)
            File.WriteAllText(str + "NjClean\My Project\Settings.settings", My.Resources.Settings3)
            File.WriteAllText(str + "NjClean\My Project\AssemblyInfo.vb", My.Resources.AssemblyInfo)
        End If
    End Sub
End Class
