﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Public Class Form1
    'Suhaib Of JorDan
    'OmaR AL AraQ
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim openFileDialog As OpenFileDialog = New OpenFileDialog()
        Dim openFileDialog2 As OpenFileDialog = openFileDialog
        openFileDialog2.Title = "Select EXE File"
        openFileDialog2.Filter = "Arabyou (*.exe)|*.exe"
        openFileDialog2.ShowDialog()
        Me.TextBox1.Text = openFileDialog.FileName
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.TextBox2.Text = Convert.ToBase64String(File.ReadAllBytes(Me.TextBox1.Text))
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.TextBox2.SelectAll()
        Me.TextBox2.Copy()
        Interaction.MsgBox("Don ! Copy", MsgBoxStyle.OkOnly, Nothing)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.TextBox2.SelectAll()
        Me.TextBox2.Clear()
        Interaction.MsgBox("Don ! Clear", MsgBoxStyle.OkOnly, Nothing)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Me.TextBox2.Text = My.Resources.String1
        Interaction.MsgBox("Don !", MsgBoxStyle.OkOnly, Nothing)
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Me.TextBox2.Text = My.Resources.String2
        Interaction.MsgBox("Don !", MsgBoxStyle.OkOnly, Nothing)
    End Sub
End Class
