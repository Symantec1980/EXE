﻿Imports System.IO
Public Class Form1
    Private Sub bSeleccionarArchivo_Click(sender As Object, e As EventArgs) Handles bSeleccionarArchivo.Click
        Dim OpenFileDialog1 As New OpenFileDialog()
        OpenFileDialog1.Title = "Selecciona un archivo"
        If OpenFileDialog1.ShowDialog() = System.Windows.Forms.DialogResult.OK Then
            tRuta.Text = OpenFileDialog1.FileName
        End If
    End Sub

    Private Sub bSeleccionarCarpeta_Click(sender As Object, e As EventArgs) Handles bSeleccionarCarpeta.Click
        Dim FolderBrowserDialog1 As New FolderBrowserDialog()
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            tRuta.Text = FolderBrowserDialog1.SelectedPath
        End If
    End Sub

    Private Sub bGenerarClave_Click(sender As Object, e As EventArgs) Handles bGenerarClave.Click
        bGenerarClave.Enabled = False
        Dim claveGenerada As String = ""
        Dim numero As Integer
        Dim numeroAleatorio As New Random()
        For i = 0 To 60
            numero = numeroAleatorio.Next(33, 239)
            claveGenerada += Chr(numero)
        Next
        tClave.Text = claveGenerada
        bGenerarClave.Enabled = True
    End Sub

    Private Sub bDesencriptar_Click(sender As Object, e As EventArgs) Handles bDesencriptar.Click
        If tClave.Text = "" Or tRuta.Text = "" Then
            MessageBox.Show("Debes rellenar los dos campos")
        Else
            bSeleccionarArchivo.Enabled = False
            bSeleccionarCarpeta.Enabled = False
            bGenerarClave.Enabled = False
            bEncriptar.Enabled = False
            bDesencriptar.Enabled = False
            tClave.Enabled = False
            Desencriptar(tClave.Text, tRuta.Text)
            MessageBox.Show("El proceso de desencriptado ha terminado")
            bSeleccionarArchivo.Enabled = True
            bSeleccionarCarpeta.Enabled = True
            bGenerarClave.Enabled = True
            bEncriptar.Enabled = True
            bDesencriptar.Enabled = True
            tClave.Enabled = True
        End If
    End Sub

    Private Sub bEncriptar_Click(sender As Object, e As EventArgs) Handles bEncriptar.Click
        If tClave.Text = "" Or tRuta.Text = "" Then
            MessageBox.Show("Debes rellenar los dos campos")
        Else
            bSeleccionarArchivo.Enabled = False
            bSeleccionarCarpeta.Enabled = False
            bGenerarClave.Enabled = False
            bEncriptar.Enabled = False
            bDesencriptar.Enabled = False
            tClave.Enabled = False
            Encriptar(tClave.Text, tRuta.Text)
            MessageBox.Show("El proceso de encriptado ha terminado")
            bSeleccionarArchivo.Enabled = True
            bSeleccionarCarpeta.Enabled = True
            bGenerarClave.Enabled = True
            bEncriptar.Enabled = True
            bDesencriptar.Enabled = True
            tClave.Enabled = True
        End If
    End Sub

    Public Sub Encriptar(clave As String, ruta As String)
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim SHA256 As New System.Security.Cryptography.SHA256Cng
        Dim textocifrado As String = ""

        If File.Exists(ruta) Then
            Try
                ' Aqui genera el IV
                AES.GenerateIV()

                ' Aquí hace un hash SHA 256 de la clave
                AES.Key = SHA256.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(clave))

                ' Aqui se prepara para hacer encriptacion AES 256 CBC
                AES.Mode = Security.Cryptography.CipherMode.CBC
                Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateEncryptor

                ' Aqui lee los bytes del archivo y los guarda en Buffer
                Dim Buffer As Byte() = My.Computer.FileSystem.ReadAllBytes(ruta)

                Dim extensionActual As String
                extensionActual = Path.GetExtension(ruta)

                ' Aqui encripta al Buffer en AES 256 y le concatena al principio el IV, todo en base64
                textocifrado = (extensionActual + "==") & Convert.ToBase64String(AES.IV) & Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))

                ' Aqui se sobreescribe el archivo con la variable misBytes2 (textocifrado en bytes)
                Dim misBytes2 As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(textocifrado)
                My.Computer.FileSystem.WriteAllBytes(ruta, misBytes2, False)

                ' Le cambia la extension a .crypt
                Dim extensionCrypt As String
                extensionCrypt = Path.ChangeExtension(ruta, ".crypt")
                System.IO.File.Move(ruta, extensionCrypt)

            Catch ex As Exception
            End Try
        ElseIf Directory.Exists(ruta) Then
            For Each archivoEncontrado As String In My.Computer.FileSystem.GetFiles(ruta)
                Encriptar(clave, archivoEncontrado)
            Next
            For Each carpetaEncontrada As String In My.Computer.FileSystem.GetDirectories(ruta)
                Encriptar(clave, carpetaEncontrada)
            Next
        End If
    End Sub

    Public Sub Desencriptar(clave As String, ruta As String)
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim SHA256 As New System.Security.Cryptography.SHA256Cng
        Dim textoplano As Byte()
        Dim iv As String = ""
        Dim textocifrado As String = ""
        Dim extensionOriginal As String = ""

        If File.Exists(ruta) Then
            Try
                ' Aqui se recoge el texto en base64 del archivo a desencriptar en la variable textocifrado
                textocifrado = My.Computer.FileSystem.ReadAllText(ruta)

                ' Aqui se saca el iv para su desencriptado
                Dim ivct = textocifrado.Split({"=="}, StringSplitOptions.None)
                extensionOriginal = ivct(0)
                iv = ivct(1) & "=="
                textocifrado = If(ivct.Length = 4, ivct(2) & "==", ivct(2))

                ' Este ultimo if significa lo siguiente: Si ivct tiene un length de 4 (esto significa
                ' que el ultimo base64 (el texto cifrado) termina en ==), le añadira un == al texto cifrado,
                ' y sino, significa que termina en un = y el ivct tendra un length de 3
                ' (porque el caracter a splittear es ==)
                ' y cogera el texto cifrado con su correspondiente = para hacer un decoding sin fallos

                ' Aqui se saca el hash SHA 256 de la clave
                AES.Key = SHA256.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(clave))

                ' Aqui saca el IV
                AES.IV = Convert.FromBase64String(iv)

                ' Aqui se prepara para el desencriptado
                AES.Mode = Security.Cryptography.CipherMode.CBC
                Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateDecryptor

                ' Aqui decodea el mensaje cifrado en base64 de textocifrado y lo mete en la variable Buffer
                Dim Buffer As Byte() = Convert.FromBase64String(textocifrado)

                ' Aqui desencripta la variable Buffer en la variable textoplano
                textoplano = (DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))

                ' Aqui se sobreescribe el archivo con la variable textoplano
                My.Computer.FileSystem.WriteAllBytes(ruta, textoplano, False)

                ' Se usa la variable extensionOriginal para recuperar la extension original del archivo
                ' Con extensionDecrypt se cambia la extension de la variable extensionOriginal
                Dim extensionDecrypt As String
                extensionDecrypt = Path.ChangeExtension(ruta, extensionOriginal)
                System.IO.File.Move(ruta, extensionDecrypt)

            Catch ex As Exception
            End Try
        ElseIf Directory.Exists(ruta) Then
            For Each archivoEncontrado As String In My.Computer.FileSystem.GetFiles(ruta)
                Desencriptar(clave, archivoEncontrado)
            Next
            For Each carpetaEncontrada As String In My.Computer.FileSystem.GetDirectories(ruta)
                Desencriptar(clave, carpetaEncontrada)
            Next
        End If
    End Sub
End Class
