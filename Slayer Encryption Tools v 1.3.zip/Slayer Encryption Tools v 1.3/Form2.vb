﻿Public Class Form2

    Private Sub NyX_Button1_Click(sender As Object, e As EventArgs) Handles NyX_Button1.Click
        Clipboard.Clear()
        Clipboard.SetText(TextBox1.Text)
        MsgBox("Copied To ClipBoard", MsgBoxStyle.Information, "Information")
    End Sub
End Class