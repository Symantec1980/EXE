﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Hazem crypter 2015")> 
<Assembly: AssemblyDescription("Hazem crypter 2015")> 
<Assembly: AssemblyCompany("Hazem crypter 2015")> 
<Assembly: AssemblyProduct("Hazem crypter 2015")> 
<Assembly: AssemblyCopyright("Hazem crypter 2015")> 
<Assembly: AssemblyTrademark("Hazem crypter 2015")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("0357a003-b071-4d05-96c8-86f121ceec38")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
