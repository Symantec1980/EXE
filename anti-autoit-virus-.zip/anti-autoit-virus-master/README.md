# anti-autoit-virus
An AutoIt3 script that stops Spykee Virus from running
