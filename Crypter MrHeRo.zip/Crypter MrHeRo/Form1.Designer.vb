﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DevSkin1 = New Crypter_MrHeRo.DevSkin()
        Me.DevButton9 = New Crypter_MrHeRo.DevButton()
        Me.DevButton8 = New Crypter_MrHeRo.DevButton()
        Me.DevTextBox6 = New Crypter_MrHeRo.DevTextBox()
        Me.DevTextBox5 = New Crypter_MrHeRo.DevTextBox()
        Me.DevButton7 = New Crypter_MrHeRo.DevButton()
        Me.DevButton6 = New Crypter_MrHeRo.DevButton()
        Me.DevButton5 = New Crypter_MrHeRo.DevButton()
        Me.DevControlBox1 = New Crypter_MrHeRo.DevControlBox()
        Me.DevTextBox4 = New Crypter_MrHeRo.DevTextBox()
        Me.DevTextBox3 = New Crypter_MrHeRo.DevTextBox()
        Me.DevTextBox1 = New Crypter_MrHeRo.DevTextBox()
        Me.DevButton3 = New Crypter_MrHeRo.DevButton()
        Me.DevButton2 = New Crypter_MrHeRo.DevButton()
        Me.DevButton1 = New Crypter_MrHeRo.DevButton()
        Me.DevSkin1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DevSkin1
        '
        Me.DevSkin1.Controls.Add(Me.DevButton9)
        Me.DevSkin1.Controls.Add(Me.DevButton8)
        Me.DevSkin1.Controls.Add(Me.DevTextBox6)
        Me.DevSkin1.Controls.Add(Me.DevTextBox5)
        Me.DevSkin1.Controls.Add(Me.DevButton7)
        Me.DevSkin1.Controls.Add(Me.DevButton6)
        Me.DevSkin1.Controls.Add(Me.DevButton5)
        Me.DevSkin1.Controls.Add(Me.DevControlBox1)
        Me.DevSkin1.Controls.Add(Me.DevTextBox4)
        Me.DevSkin1.Controls.Add(Me.DevTextBox3)
        Me.DevSkin1.Controls.Add(Me.DevTextBox1)
        Me.DevSkin1.Controls.Add(Me.DevButton3)
        Me.DevSkin1.Controls.Add(Me.DevButton2)
        Me.DevSkin1.Controls.Add(Me.DevButton1)
        Me.DevSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DevSkin1.HeaderLogo = Nothing
        Me.DevSkin1.Location = New System.Drawing.Point(0, 0)
        Me.DevSkin1.Name = "DevSkin1"
        Me.DevSkin1.Size = New System.Drawing.Size(453, 353)
        Me.DevSkin1.TabIndex = 0
        Me.DevSkin1.Text = "Program Crypter ıllıllıMя.HeRoıllıllı  3.0"
        '
        'DevButton9
        '
        Me.DevButton9.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton9.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton9.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton9.Location = New System.Drawing.Point(14, 309)
        Me.DevButton9.Name = "DevButton9"
        Me.DevButton9.Size = New System.Drawing.Size(432, 30)
        Me.DevButton9.TabIndex = 18
        Me.DevButton9.Text = "About"
        '
        'DevButton8
        '
        Me.DevButton8.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton8.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton8.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton8.Location = New System.Drawing.Point(14, 273)
        Me.DevButton8.Name = "DevButton8"
        Me.DevButton8.Size = New System.Drawing.Size(432, 30)
        Me.DevButton8.TabIndex = 17
        Me.DevButton8.Text = "Compiler"
        '
        'DevTextBox6
        '
        Me.DevTextBox6.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevTextBox6.Location = New System.Drawing.Point(12, 239)
        Me.DevTextBox6.MaxLength = 32767
        Me.DevTextBox6.MultiLine = False
        Me.DevTextBox6.Name = "DevTextBox6"
        Me.DevTextBox6.ReadOnly = False
        Me.DevTextBox6.Size = New System.Drawing.Size(299, 28)
        Me.DevTextBox6.TabIndex = 15
        Me.DevTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.DevTextBox6.UseSystemPasswordChar = False
        '
        'DevTextBox5
        '
        Me.DevTextBox5.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevTextBox5.Location = New System.Drawing.Point(12, 201)
        Me.DevTextBox5.MaxLength = 32767
        Me.DevTextBox5.MultiLine = False
        Me.DevTextBox5.Name = "DevTextBox5"
        Me.DevTextBox5.ReadOnly = False
        Me.DevTextBox5.Size = New System.Drawing.Size(299, 28)
        Me.DevTextBox5.TabIndex = 14
        Me.DevTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.DevTextBox5.UseSystemPasswordChar = False
        '
        'DevButton7
        '
        Me.DevButton7.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton7.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton7.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton7.Location = New System.Drawing.Point(317, 237)
        Me.DevButton7.Name = "DevButton7"
        Me.DevButton7.Size = New System.Drawing.Size(129, 30)
        Me.DevButton7.TabIndex = 13
        Me.DevButton7.Text = "Add Program"
        '
        'DevButton6
        '
        Me.DevButton6.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton6.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton6.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton6.Location = New System.Drawing.Point(317, 201)
        Me.DevButton6.Name = "DevButton6"
        Me.DevButton6.Size = New System.Drawing.Size(129, 30)
        Me.DevButton6.TabIndex = 12
        Me.DevButton6.Text = "Add Server"
        '
        'DevButton5
        '
        Me.DevButton5.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton5.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton5.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton5.Location = New System.Drawing.Point(12, 165)
        Me.DevButton5.Name = "DevButton5"
        Me.DevButton5.Size = New System.Drawing.Size(434, 30)
        Me.DevButton5.TabIndex = 11
        Me.DevButton5.Text = "Build"
        '
        'DevControlBox1
        '
        Me.DevControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DevControlBox1.BoxType = Crypter_MrHeRo.DevControlBox.xBoxType.Close
        Me.DevControlBox1.Location = New System.Drawing.Point(419, 3)
        Me.DevControlBox1.Name = "DevControlBox1"
        Me.DevControlBox1.Size = New System.Drawing.Size(31, 23)
        Me.DevControlBox1.TabIndex = 10
        Me.DevControlBox1.Text = "DevControlBox1"
        '
        'DevTextBox4
        '
        Me.DevTextBox4.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevTextBox4.Location = New System.Drawing.Point(12, 131)
        Me.DevTextBox4.MaxLength = 32767
        Me.DevTextBox4.MultiLine = False
        Me.DevTextBox4.Name = "DevTextBox4"
        Me.DevTextBox4.ReadOnly = False
        Me.DevTextBox4.Size = New System.Drawing.Size(299, 28)
        Me.DevTextBox4.TabIndex = 8
        Me.DevTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.DevTextBox4.UseSystemPasswordChar = False
        '
        'DevTextBox3
        '
        Me.DevTextBox3.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevTextBox3.Location = New System.Drawing.Point(12, 93)
        Me.DevTextBox3.MaxLength = 32767
        Me.DevTextBox3.MultiLine = False
        Me.DevTextBox3.Name = "DevTextBox3"
        Me.DevTextBox3.ReadOnly = False
        Me.DevTextBox3.Size = New System.Drawing.Size(299, 28)
        Me.DevTextBox3.TabIndex = 7
        Me.DevTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.DevTextBox3.UseSystemPasswordChar = False
        '
        'DevTextBox1
        '
        Me.DevTextBox1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevTextBox1.Location = New System.Drawing.Point(12, 59)
        Me.DevTextBox1.MaxLength = 32767
        Me.DevTextBox1.MultiLine = False
        Me.DevTextBox1.Name = "DevTextBox1"
        Me.DevTextBox1.ReadOnly = False
        Me.DevTextBox1.Size = New System.Drawing.Size(333, 28)
        Me.DevTextBox1.TabIndex = 5
        Me.DevTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.DevTextBox1.UseSystemPasswordChar = False
        '
        'DevButton3
        '
        Me.DevButton3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton3.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton3.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton3.Location = New System.Drawing.Point(317, 129)
        Me.DevButton3.Name = "DevButton3"
        Me.DevButton3.Size = New System.Drawing.Size(129, 30)
        Me.DevButton3.TabIndex = 3
        Me.DevButton3.Text = "Gen Bulgarian"
        '
        'DevButton2
        '
        Me.DevButton2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton2.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton2.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton2.Location = New System.Drawing.Point(317, 93)
        Me.DevButton2.Name = "DevButton2"
        Me.DevButton2.Size = New System.Drawing.Size(129, 30)
        Me.DevButton2.TabIndex = 2
        Me.DevButton2.Text = "Gen China"
        '
        'DevButton1
        '
        Me.DevButton1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.DevButton1.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton1.Font = New System.Drawing.Font("Kozuka Gothic Pr6N R", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DevButton1.Location = New System.Drawing.Point(351, 57)
        Me.DevButton1.Name = "DevButton1"
        Me.DevButton1.Size = New System.Drawing.Size(95, 30)
        Me.DevButton1.TabIndex = 1
        Me.DevButton1.Text = "Add File"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(453, 353)
        Me.Controls.Add(Me.DevSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.DevSkin1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DevSkin1 As Crypter_MrHeRo.DevSkin
    Friend WithEvents DevTextBox4 As Crypter_MrHeRo.DevTextBox
    Friend WithEvents DevTextBox3 As Crypter_MrHeRo.DevTextBox
    Friend WithEvents DevTextBox1 As Crypter_MrHeRo.DevTextBox
    Friend WithEvents DevButton3 As Crypter_MrHeRo.DevButton
    Friend WithEvents DevButton2 As Crypter_MrHeRo.DevButton
    Friend WithEvents DevButton1 As Crypter_MrHeRo.DevButton
    Friend WithEvents DevControlBox1 As Crypter_MrHeRo.DevControlBox
    Friend WithEvents DevButton5 As Crypter_MrHeRo.DevButton
    Friend WithEvents DevTextBox6 As Crypter_MrHeRo.DevTextBox
    Friend WithEvents DevTextBox5 As Crypter_MrHeRo.DevTextBox
    Friend WithEvents DevButton7 As Crypter_MrHeRo.DevButton
    Friend WithEvents DevButton6 As Crypter_MrHeRo.DevButton
    Friend WithEvents DevButton8 As Crypter_MrHeRo.DevButton
    Friend WithEvents DevButton9 As Crypter_MrHeRo.DevButton

End Class
