﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.HuraForm1 = New Team_Boys_Hacker_Crypter.HuraForm()
        Me.HuraGroupBox3 = New Team_Boys_Hacker_Crypter.HuraGroupBox()
        Me.HuraTextBox3 = New Team_Boys_Hacker_Crypter.HuraTextBox()
        Me.HuraGroupBox2 = New Team_Boys_Hacker_Crypter.HuraGroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.HuraGroupBox1 = New Team_Boys_Hacker_Crypter.HuraGroupBox()
        Me.HuraTextBox2 = New Team_Boys_Hacker_Crypter.HuraTextBox()
        Me.HuraButton4 = New Team_Boys_Hacker_Crypter.HuraButton()
        Me.HuraButton3 = New Team_Boys_Hacker_Crypter.HuraButton()
        Me.HuraButton2 = New Team_Boys_Hacker_Crypter.HuraButton()
        Me.HuraButton1 = New Team_Boys_Hacker_Crypter.HuraButton()
        Me.HuraTextBox1 = New Team_Boys_Hacker_Crypter.HuraTextBox()
        Me.HuraControlBox1 = New Team_Boys_Hacker_Crypter.HuraControlBox()
        Me.HuraForm1.SuspendLayout()
        Me.HuraGroupBox3.SuspendLayout()
        Me.HuraGroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.HuraGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'HuraForm1
        '
        Me.HuraForm1.AccentColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.HuraForm1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.HuraForm1.ColorScheme = Team_Boys_Hacker_Crypter.HuraForm.ColorSchemes.Dark
        Me.HuraForm1.Controls.Add(Me.HuraGroupBox3)
        Me.HuraForm1.Controls.Add(Me.HuraGroupBox2)
        Me.HuraForm1.Controls.Add(Me.HuraGroupBox1)
        Me.HuraForm1.Controls.Add(Me.HuraControlBox1)
        Me.HuraForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HuraForm1.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraForm1.ForeColor = System.Drawing.Color.White
        Me.HuraForm1.Location = New System.Drawing.Point(0, 0)
        Me.HuraForm1.Name = "HuraForm1"
        Me.HuraForm1.Size = New System.Drawing.Size(568, 471)
        Me.HuraForm1.TabIndex = 0
        Me.HuraForm1.Text = "Team Boys Hacker Crypter"
        '
        'HuraGroupBox3
        '
        Me.HuraGroupBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraGroupBox3.Controls.Add(Me.HuraTextBox3)
        Me.HuraGroupBox3.Location = New System.Drawing.Point(3, 91)
        Me.HuraGroupBox3.Name = "HuraGroupBox3"
        Me.HuraGroupBox3.Size = New System.Drawing.Size(343, 377)
        Me.HuraGroupBox3.TabIndex = 3
        Me.HuraGroupBox3.Text = "HuraGroupBox3"
        '
        'HuraTextBox3
        '
        Me.HuraTextBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraTextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.HuraTextBox3.ColorScheme = Team_Boys_Hacker_Crypter.HuraTextBox.ColorSchemes.Dark
        Me.HuraTextBox3.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraTextBox3.ForeColor = System.Drawing.Color.White
        Me.HuraTextBox3.Location = New System.Drawing.Point(3, 3)
        Me.HuraTextBox3.Multiline = True
        Me.HuraTextBox3.Name = "HuraTextBox3"
        Me.HuraTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.HuraTextBox3.Size = New System.Drawing.Size(337, 371)
        Me.HuraTextBox3.TabIndex = 0
        '
        'HuraGroupBox2
        '
        Me.HuraGroupBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraGroupBox2.Controls.Add(Me.PictureBox1)
        Me.HuraGroupBox2.Location = New System.Drawing.Point(349, 33)
        Me.HuraGroupBox2.Name = "HuraGroupBox2"
        Me.HuraGroupBox2.Size = New System.Drawing.Size(216, 435)
        Me.HuraGroupBox2.TabIndex = 2
        Me.HuraGroupBox2.Text = "HuraGroupBox2"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(210, 429)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'HuraGroupBox1
        '
        Me.HuraGroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraGroupBox1.Controls.Add(Me.HuraTextBox2)
        Me.HuraGroupBox1.Controls.Add(Me.HuraButton4)
        Me.HuraGroupBox1.Controls.Add(Me.HuraButton3)
        Me.HuraGroupBox1.Controls.Add(Me.HuraButton2)
        Me.HuraGroupBox1.Controls.Add(Me.HuraButton1)
        Me.HuraGroupBox1.Controls.Add(Me.HuraTextBox1)
        Me.HuraGroupBox1.Location = New System.Drawing.Point(3, 33)
        Me.HuraGroupBox1.Name = "HuraGroupBox1"
        Me.HuraGroupBox1.Size = New System.Drawing.Size(343, 52)
        Me.HuraGroupBox1.TabIndex = 1
        Me.HuraGroupBox1.Text = "HuraGroupBox1"
        '
        'HuraTextBox2
        '
        Me.HuraTextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraTextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.HuraTextBox2.ColorScheme = Team_Boys_Hacker_Crypter.HuraTextBox.ColorSchemes.Dark
        Me.HuraTextBox2.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraTextBox2.ForeColor = System.Drawing.Color.White
        Me.HuraTextBox2.Location = New System.Drawing.Point(3, 28)
        Me.HuraTextBox2.Multiline = True
        Me.HuraTextBox2.Name = "HuraTextBox2"
        Me.HuraTextBox2.Size = New System.Drawing.Size(31, 20)
        Me.HuraTextBox2.TabIndex = 4
        Me.HuraTextBox2.Text = "4"
        '
        'HuraButton4
        '
        Me.HuraButton4.AccentColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.HuraButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraButton4.ColorScheme = Team_Boys_Hacker_Crypter.HuraButton.ColorSchemes.Dark
        Me.HuraButton4.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraButton4.ForeColor = System.Drawing.Color.White
        Me.HuraButton4.Location = New System.Drawing.Point(40, 28)
        Me.HuraButton4.Name = "HuraButton4"
        Me.HuraButton4.Size = New System.Drawing.Size(96, 20)
        Me.HuraButton4.TabIndex = 3
        Me.HuraButton4.Text = "About"
        Me.HuraButton4.UseVisualStyleBackColor = False
        '
        'HuraButton3
        '
        Me.HuraButton3.AccentColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.HuraButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraButton3.ColorScheme = Team_Boys_Hacker_Crypter.HuraButton.ColorSchemes.Dark
        Me.HuraButton3.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraButton3.ForeColor = System.Drawing.Color.White
        Me.HuraButton3.Location = New System.Drawing.Point(142, 28)
        Me.HuraButton3.Name = "HuraButton3"
        Me.HuraButton3.Size = New System.Drawing.Size(96, 20)
        Me.HuraButton3.TabIndex = 5
        Me.HuraButton3.Text = "Copy"
        Me.HuraButton3.UseVisualStyleBackColor = False
        '
        'HuraButton2
        '
        Me.HuraButton2.AccentColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.HuraButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraButton2.ColorScheme = Team_Boys_Hacker_Crypter.HuraButton.ColorSchemes.Dark
        Me.HuraButton2.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraButton2.ForeColor = System.Drawing.Color.White
        Me.HuraButton2.Location = New System.Drawing.Point(244, 29)
        Me.HuraButton2.Name = "HuraButton2"
        Me.HuraButton2.Size = New System.Drawing.Size(96, 19)
        Me.HuraButton2.TabIndex = 4
        Me.HuraButton2.Text = "Gen"
        Me.HuraButton2.UseVisualStyleBackColor = False
        '
        'HuraButton1
        '
        Me.HuraButton1.AccentColor = System.Drawing.Color.FromArgb(CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(70, Byte), Integer))
        Me.HuraButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraButton1.ColorScheme = Team_Boys_Hacker_Crypter.HuraButton.ColorSchemes.Dark
        Me.HuraButton1.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraButton1.ForeColor = System.Drawing.Color.White
        Me.HuraButton1.Location = New System.Drawing.Point(244, 4)
        Me.HuraButton1.Name = "HuraButton1"
        Me.HuraButton1.Size = New System.Drawing.Size(96, 19)
        Me.HuraButton1.TabIndex = 2
        Me.HuraButton1.Text = "Select Server"
        Me.HuraButton1.UseVisualStyleBackColor = False
        '
        'HuraTextBox1
        '
        Me.HuraTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.HuraTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.HuraTextBox1.ColorScheme = Team_Boys_Hacker_Crypter.HuraTextBox.ColorSchemes.Dark
        Me.HuraTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.5!)
        Me.HuraTextBox1.ForeColor = System.Drawing.Color.White
        Me.HuraTextBox1.Location = New System.Drawing.Point(3, 3)
        Me.HuraTextBox1.Multiline = True
        Me.HuraTextBox1.Name = "HuraTextBox1"
        Me.HuraTextBox1.Size = New System.Drawing.Size(235, 20)
        Me.HuraTextBox1.TabIndex = 3
        '
        'HuraControlBox1
        '
        Me.HuraControlBox1.AccentColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.HuraControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.HuraControlBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.HuraControlBox1.ColorScheme = Team_Boys_Hacker_Crypter.HuraControlBox.ColorSchemes.Dark
        Me.HuraControlBox1.ForeColor = System.Drawing.Color.White
        Me.HuraControlBox1.Location = New System.Drawing.Point(466, 2)
        Me.HuraControlBox1.Name = "HuraControlBox1"
        Me.HuraControlBox1.Size = New System.Drawing.Size(100, 25)
        Me.HuraControlBox1.TabIndex = 0
        Me.HuraControlBox1.Text = "HuraControlBox1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(568, 471)
        Me.Controls.Add(Me.HuraForm1)
        Me.Font = New System.Drawing.Font("Comic Sans MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "Team-Boys-Hacker‬"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.HuraForm1.ResumeLayout(False)
        Me.HuraGroupBox3.ResumeLayout(False)
        Me.HuraGroupBox3.PerformLayout()
        Me.HuraGroupBox2.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.HuraGroupBox1.ResumeLayout(False)
        Me.HuraGroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents HuraForm1 As HuraForm
    Friend WithEvents HuraControlBox1 As HuraControlBox
    Friend WithEvents HuraGroupBox3 As HuraGroupBox
    Friend WithEvents HuraTextBox3 As HuraTextBox
    Friend WithEvents HuraGroupBox2 As HuraGroupBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents HuraGroupBox1 As HuraGroupBox
    Friend WithEvents HuraTextBox2 As HuraTextBox
    Friend WithEvents HuraButton4 As HuraButton
    Friend WithEvents HuraButton3 As HuraButton
    Friend WithEvents HuraButton2 As HuraButton
    Friend WithEvents HuraButton1 As HuraButton
    Friend WithEvents HuraTextBox1 As HuraTextBox
End Class
