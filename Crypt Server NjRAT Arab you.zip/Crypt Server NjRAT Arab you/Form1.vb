﻿Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dialog As New OpenFileDialog
        Dim dialog2 As OpenFileDialog = dialog
        dialog2.Title = "Select EXE File"
        dialog2.Filter = "Exe Files (*.exe)|*.exe"
        dialog2.ShowDialog()
        dialog2 = Nothing
        Me.TextBox1.Text = dialog.FileName
        Me.RichTextBox1.Text = Convert.ToBase64String(File.ReadAllBytes(Me.TextBox1.Text))
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim str As String = My.Resources.OMAR1.Replace("###", Me.RichTextBox1.Text)
        Me.RichTextBox1.Text = str
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Button1.ForeColor = ColorTranslator.FromOle(Information.RGB(CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 255.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!))))))
        Me.TextBox1.ForeColor = ColorTranslator.FromOle(Information.RGB(CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 255.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!))))))
        Me.Button3.ForeColor = ColorTranslator.FromOle(Information.RGB(CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 255.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!))))))

        Me.RichTextBox1.ForeColor = ColorTranslator.FromOle(Information.RGB(CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 255.0!)))), CInt(Math.Round(CDbl((VBMath.Rnd * 500.0!))))))
    End Sub

End Class
