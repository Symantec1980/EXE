using System;
using System.Collections.Generic;
using System.Text;

namespace SharpObfuscator
{
	static public class SharpObfuscatorSettings
	{
		static public string NETFrameworkPath = @"C:\WINDOWS\Microsoft.NET\Framework\v2.0.50727\";
		static public string NETSDKPath = @"C:\Program Files\Microsoft Visual Studio 8\SDK\v2.0\Bin\";
	}
}
