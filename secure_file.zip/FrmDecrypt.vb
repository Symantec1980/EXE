Imports System.IO
Public Class FrmDecrypt

    Private Sub CmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdClose.Click
        Application.Exit()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim p As New Process
        p.Start("http://www.programmer2programmer.net")
    End Sub

    Private Sub CmdBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdBrowse.Click
        Cd1.Filter = "Secure p2p file|*.sp2p"
        Cd1.Title = "Select *.sp2p file to decrypt."
        Cd1.ShowDialog()

        TxtFileName.Text = Cd1.FileName
    End Sub

    Private Sub CmdDecryption_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdDecryption.Click
        '>>> check the file name entered is exist or not
        If File.Exists(TxtFileName.Text) = False Then
            TxtFileName.SelectionStart = 0
            TxtFileName.SelectionLength = TxtFileName.Text.Length
            TxtFileName.Focus()
            MsgBox("File does not exist, select a file to decrypt.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        '>>> check for password
        If TxtPassword.Text = "" Then
            TxtPassword.Focus()
            MsgBox("Enter password, password can not be blank.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If


        '>>> create a dataset, datatable to hold file content, password
        Dim DsImg As New DataSet
        Dim Dt As New DataTable("Images")
        Dt.Columns.Add(New DataColumn("sysid", System.Type.GetType("System.String")))
        Dt.Columns.Add(New DataColumn("filename", System.Type.GetType("System.String")))
        Dt.Columns.Add(New DataColumn("image", System.Type.GetType("System.Byte[]")))
        Dt.Columns.Add(New DataColumn("filetag", System.Type.GetType("System.String")))
        DsImg.Tables.Add(Dt)

        '>>> read the content from the xml file
        DsImg.ReadXml(TxtFileName.Text)

        '>>> check for encrypted password
        If TxtPassword.Text <> StrDecrypt(DsImg.Tables(0).Rows(0).Item("filetag")) Then
            TxtFileName.SelectionStart = 0
            TxtPassword.SelectionLength = TxtPassword.Text.Length
            TxtPassword.Focus()
            MsgBox("Invalid security code. cannot decrypt the file", MsgBoxStyle.Critical)
            Exit Sub
        End If

        '>>> if password is ok create new file
        '>>> remove sp2p from the file name before save
        Dim FileName As String
        FileName = Mid(TxtFileName.Text, 1, Len(TxtFileName.Text) - 5)
        '>>> read content from dataaset
        '>>> and write to file stream
        Dim Content As Byte()
        Content = DsImg.Tables(0).Rows(0).Item(2)
        Dim Fs As New System.IO.FileStream(FileName, System.IO.FileMode.Create)
        Fs.Write(Content, 0, Content.Length)
        Fs.Close()

        MsgBox("Decryption process completed." & vbCrLf & vbCrLf & "New file created as..." & vbCrLf & FileName, MsgBoxStyle.Information)


    End Sub
End Class