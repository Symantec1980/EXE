﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.DivinityThemeContainer1 = New Galaxy_Crypter.DivinityThemeContainer()
        Me.btnCrypt = New Galaxy_Crypter.DivinityButton()
        Me.DivinityControlBox1 = New Galaxy_Crypter.DivinityControlBox()
        Me.DivinityTabControl1 = New Galaxy_Crypter.DivinityTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnProfile = New Galaxy_Crypter.DivinityButton()
        Me.btnRedeem = New Galaxy_Crypter.DivinityButton()
        Me.txtNews = New Galaxy_Crypter.DivinityTextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblExpire = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblUser = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txtKey = New Galaxy_Crypter.DivinityTextBox()
        Me.rndPool = New Galaxy_Crypter.RandomPool()
        Me.chkEOF = New Galaxy_Crypter.DivinityCheckBox()
        Me.grpBinder = New Galaxy_Crypter.DivinityGroupBox()
        Me.chkOnce = New Galaxy_Crypter.DivinityCheckBox()
        Me.txtBind = New Galaxy_Crypter.DivinityTextBox()
        Me.btnBind = New Galaxy_Crypter.DivinityButton()
        Me.chkBind = New Galaxy_Crypter.DivinityCheckBox()
        Me.txtFile = New Galaxy_Crypter.DivinityTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnBrowse = New Galaxy_Crypter.DivinityButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.txtReg = New Galaxy_Crypter.DivinityTextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtInstall = New Galaxy_Crypter.DivinityTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.chkStartup = New Galaxy_Crypter.DivinityCheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtKB = New Galaxy_Crypter.DivinityTextBox()
        Me.chkPump = New Galaxy_Crypter.DivinityCheckBox()
        Me.txtExt = New Galaxy_Crypter.DivinityTextBox()
        Me.chkSpoof = New Galaxy_Crypter.DivinityCheckBox()
        Me.chkMelt = New Galaxy_Crypter.DivinityCheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtDelay = New Galaxy_Crypter.DivinityTextBox()
        Me.chkDelay = New Galaxy_Crypter.DivinityCheckBox()
        Me.chkPersist = New Galaxy_Crypter.DivinityCheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.comboInject = New Galaxy_Crypter.DivinityComboBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.btnClone = New Galaxy_Crypter.DivinityButton()
        Me.btnIco = New Galaxy_Crypter.DivinityButton()
        Me.txtIcon = New Galaxy_Crypter.DivinityTextBox()
        Me.chkIco = New Galaxy_Crypter.DivinityCheckBox()
        Me.btnRand = New Galaxy_Crypter.DivinityButton()
        Me.txtV4 = New Galaxy_Crypter.DivinityTextBox()
        Me.txtV3 = New Galaxy_Crypter.DivinityTextBox()
        Me.txtV2 = New Galaxy_Crypter.DivinityTextBox()
        Me.txtV1 = New Galaxy_Crypter.DivinityTextBox()
        Me.txtTM = New Galaxy_Crypter.DivinityTextBox()
        Me.txtCopy = New Galaxy_Crypter.DivinityTextBox()
        Me.txtDesc = New Galaxy_Crypter.DivinityTextBox()
        Me.txtProduct = New Galaxy_Crypter.DivinityTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.chkAsm = New Galaxy_Crypter.DivinityCheckBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.lblDetections = New System.Windows.Forms.Label()
        Me.txtLink = New Galaxy_Crypter.DivinityTextBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnScan = New Galaxy_Crypter.DivinityButton()
        Me.DivinityThemeContainer1.SuspendLayout()
        Me.DivinityTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.grpBinder.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.SuspendLayout()
        '
        'DivinityThemeContainer1
        '
        Me.DivinityThemeContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Me.DivinityThemeContainer1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.DivinityThemeContainer1.Controls.Add(Me.btnCrypt)
        Me.DivinityThemeContainer1.Controls.Add(Me.DivinityControlBox1)
        Me.DivinityThemeContainer1.Controls.Add(Me.DivinityTabControl1)
        Me.DivinityThemeContainer1.Customization = "Dg4O/zAwMP8EBAT/AAAA//////////8aLS0t/wAAAP////8PKCgo/////yr///8PDg4O/ykpKf8="
        Me.DivinityThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DivinityThemeContainer1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.DivinityThemeContainer1.HeaderOffset = 1
        Me.DivinityThemeContainer1.Hidable = True
        Me.DivinityThemeContainer1.Image = Nothing
        Me.DivinityThemeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.DivinityThemeContainer1.Movable = True
        Me.DivinityThemeContainer1.Name = "DivinityThemeContainer1"
        Me.DivinityThemeContainer1.NoRounding = False
        Me.DivinityThemeContainer1.Rounded = True
        Me.DivinityThemeContainer1.Sizable = True
        Me.DivinityThemeContainer1.Size = New System.Drawing.Size(386, 389)
        Me.DivinityThemeContainer1.SmartBounds = True
        Me.DivinityThemeContainer1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.DivinityThemeContainer1.TabIndex = 0
        Me.DivinityThemeContainer1.Text = "DivinityThemeContainer1"
        Me.DivinityThemeContainer1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.DivinityThemeContainer1.Transparent = False
        '
        'btnCrypt
        '
        Me.btnCrypt.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnCrypt.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnCrypt.Image = Nothing
        Me.btnCrypt.Location = New System.Drawing.Point(28, 354)
        Me.btnCrypt.Name = "btnCrypt"
        Me.btnCrypt.NoRounding = False
        Me.btnCrypt.Size = New System.Drawing.Size(330, 23)
        Me.btnCrypt.TabIndex = 2
        Me.btnCrypt.Text = "Encrypt My File(s)"
        Me.btnCrypt.Transparent = False
        '
        'DivinityControlBox1
        '
        Me.DivinityControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DivinityControlBox1.Customization = "/78A/y8vL/8AAAD/Wlpa/w=="
        Me.DivinityControlBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.DivinityControlBox1.Image = Nothing
        Me.DivinityControlBox1.Location = New System.Drawing.Point(311, 3)
        Me.DivinityControlBox1.Name = "DivinityControlBox1"
        Me.DivinityControlBox1.NoRounding = False
        Me.DivinityControlBox1.Size = New System.Drawing.Size(71, 19)
        Me.DivinityControlBox1.TabIndex = 1
        Me.DivinityControlBox1.Text = "DivinityControlBox1"
        Me.DivinityControlBox1.Transparent = False
        '
        'DivinityTabControl1
        '
        Me.DivinityTabControl1.Controls.Add(Me.TabPage1)
        Me.DivinityTabControl1.Controls.Add(Me.TabPage2)
        Me.DivinityTabControl1.Controls.Add(Me.TabPage3)
        Me.DivinityTabControl1.Controls.Add(Me.TabPage4)
        Me.DivinityTabControl1.Controls.Add(Me.TabPage5)
        Me.DivinityTabControl1.Location = New System.Drawing.Point(24, 39)
        Me.DivinityTabControl1.Name = "DivinityTabControl1"
        Me.DivinityTabControl1.SelectedIndex = 0
        Me.DivinityTabControl1.Size = New System.Drawing.Size(338, 308)
        Me.DivinityTabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.btnProfile)
        Me.TabPage1.Controls.Add(Me.btnRedeem)
        Me.TabPage1.Controls.Add(Me.txtNews)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.lblExpire)
        Me.TabPage1.Controls.Add(Me.Label13)
        Me.TabPage1.Controls.Add(Me.lblUser)
        Me.TabPage1.Controls.Add(Me.Label12)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(330, 279)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Account"
        '
        'btnProfile
        '
        Me.btnProfile.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnProfile.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnProfile.Image = Nothing
        Me.btnProfile.Location = New System.Drawing.Point(100, 8)
        Me.btnProfile.Name = "btnProfile"
        Me.btnProfile.NoRounding = False
        Me.btnProfile.Size = New System.Drawing.Size(107, 23)
        Me.btnProfile.TabIndex = 12
        Me.btnProfile.Text = "View Profile"
        Me.btnProfile.Transparent = False
        '
        'btnRedeem
        '
        Me.btnRedeem.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnRedeem.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnRedeem.Image = Nothing
        Me.btnRedeem.Location = New System.Drawing.Point(213, 8)
        Me.btnRedeem.Name = "btnRedeem"
        Me.btnRedeem.NoRounding = False
        Me.btnRedeem.Size = New System.Drawing.Size(107, 23)
        Me.btnRedeem.TabIndex = 11
        Me.btnRedeem.Text = "Redeem Lisense"
        Me.btnRedeem.Transparent = False
        '
        'txtNews
        '
        Me.txtNews.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtNews.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtNews.Image = Nothing
        Me.txtNews.Location = New System.Drawing.Point(32, 126)
        Me.txtNews.MaxLength = 32767
        Me.txtNews.Multiline = True
        Me.txtNews.Name = "txtNews"
        Me.txtNews.NoRounding = False
        Me.txtNews.ReadOnly = True
        Me.txtNews.Size = New System.Drawing.Size(271, 128)
        Me.txtNews.TabIndex = 10
        Me.txtNews.Text = "Empty!"
        Me.txtNews.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtNews.Transparent = False
        Me.txtNews.UseSystemPasswordChar = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label14.Location = New System.Drawing.Point(29, 102)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(153, 13)
        Me.Label14.TabIndex = 9
        Me.Label14.Text = "Latest news and updates:"
        '
        'lblExpire
        '
        Me.lblExpire.AutoSize = True
        Me.lblExpire.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.lblExpire.Location = New System.Drawing.Point(142, 70)
        Me.lblExpire.Name = "lblExpire"
        Me.lblExpire.Size = New System.Drawing.Size(12, 13)
        Me.lblExpire.TabIndex = 8
        Me.lblExpire.Text = "-"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label13.Location = New System.Drawing.Point(29, 70)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(107, 13)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "Lisensed Expires:"
        '
        'lblUser
        '
        Me.lblUser.AutoSize = True
        Me.lblUser.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.lblUser.Location = New System.Drawing.Point(114, 38)
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(12, 13)
        Me.lblUser.TabIndex = 6
        Me.lblUser.Text = "-"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label12.Location = New System.Drawing.Point(29, 38)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 13)
        Me.Label12.TabIndex = 5
        Me.Label12.Text = "Lisensed To:"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.txtKey)
        Me.TabPage2.Controls.Add(Me.rndPool)
        Me.TabPage2.Controls.Add(Me.chkEOF)
        Me.TabPage2.Controls.Add(Me.grpBinder)
        Me.TabPage2.Controls.Add(Me.txtFile)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.btnBrowse)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(330, 279)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Main"
        '
        'txtKey
        '
        Me.txtKey.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtKey.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtKey.Image = Nothing
        Me.txtKey.Location = New System.Drawing.Point(18, 194)
        Me.txtKey.MaxLength = 32767
        Me.txtKey.Multiline = False
        Me.txtKey.Name = "txtKey"
        Me.txtKey.NoRounding = False
        Me.txtKey.ReadOnly = False
        Me.txtKey.Size = New System.Drawing.Size(298, 24)
        Me.txtKey.TabIndex = 10
        Me.txtKey.Text = "Encryption Key"
        Me.txtKey.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtKey.Transparent = False
        Me.txtKey.UseSystemPasswordChar = False
        '
        'rndPool
        '
        Me.rndPool.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.rndPool.Image = Nothing
        Me.rndPool.Location = New System.Drawing.Point(18, 224)
        Me.rndPool.Name = "rndPool"
        Me.rndPool.NoRounding = False
        Me.rndPool.Range = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        Me.rndPool.RangePadding = 2
        Me.rndPool.Size = New System.Drawing.Size(298, 46)
        Me.rndPool.TabIndex = 9
        Me.rndPool.Text = "rndPool"
        '
        'chkEOF
        '
        Me.chkEOF.Checked = False
        Me.chkEOF.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkEOF.Field = 16
        Me.chkEOF.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkEOF.Image = Nothing
        Me.chkEOF.Location = New System.Drawing.Point(18, 45)
        Me.chkEOF.Name = "chkEOF"
        Me.chkEOF.NoRounding = False
        Me.chkEOF.Size = New System.Drawing.Size(118, 16)
        Me.chkEOF.TabIndex = 8
        Me.chkEOF.Text = "Write EOF Data"
        Me.chkEOF.Transparent = False
        '
        'grpBinder
        '
        Me.grpBinder.BackColor = System.Drawing.Color.FromArgb(CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer), CType(CType(20, Byte), Integer))
        Me.grpBinder.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.grpBinder.Controls.Add(Me.chkOnce)
        Me.grpBinder.Controls.Add(Me.txtBind)
        Me.grpBinder.Controls.Add(Me.btnBind)
        Me.grpBinder.Controls.Add(Me.chkBind)
        Me.grpBinder.Customization = "Dg4O/xQUFP8gICD/AAAA/wAAADIUFBT//78A/yAgIP8AAAD/"
        Me.grpBinder.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.grpBinder.Hidable = True
        Me.grpBinder.Image = Nothing
        Me.grpBinder.Location = New System.Drawing.Point(18, 73)
        Me.grpBinder.Movable = True
        Me.grpBinder.Name = "grpBinder"
        Me.grpBinder.NoRounding = False
        Me.grpBinder.Sizable = True
        Me.grpBinder.Size = New System.Drawing.Size(298, 115)
        Me.grpBinder.SmartBounds = True
        Me.grpBinder.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.grpBinder.TabIndex = 7
        Me.grpBinder.Text = "File Binder"
        Me.grpBinder.TransparencyKey = System.Drawing.Color.Empty
        Me.grpBinder.Transparent = False
        '
        'chkOnce
        '
        Me.chkOnce.Checked = True
        Me.chkOnce.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkOnce.Enabled = False
        Me.chkOnce.Field = 16
        Me.chkOnce.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkOnce.Image = Nothing
        Me.chkOnce.Location = New System.Drawing.Point(15, 84)
        Me.chkOnce.Name = "chkOnce"
        Me.chkOnce.NoRounding = False
        Me.chkOnce.Size = New System.Drawing.Size(85, 16)
        Me.chkOnce.TabIndex = 9
        Me.chkOnce.Text = "Run Once"
        Me.chkOnce.Transparent = False
        '
        'txtBind
        '
        Me.txtBind.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtBind.Enabled = False
        Me.txtBind.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtBind.Image = Nothing
        Me.txtBind.Location = New System.Drawing.Point(19, 54)
        Me.txtBind.MaxLength = 32767
        Me.txtBind.Multiline = False
        Me.txtBind.Name = "txtBind"
        Me.txtBind.NoRounding = False
        Me.txtBind.ReadOnly = False
        Me.txtBind.Size = New System.Drawing.Size(183, 24)
        Me.txtBind.TabIndex = 7
        Me.txtBind.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtBind.Transparent = False
        Me.txtBind.UseSystemPasswordChar = False
        '
        'btnBind
        '
        Me.btnBind.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnBind.Enabled = False
        Me.btnBind.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnBind.Image = Nothing
        Me.btnBind.Location = New System.Drawing.Point(208, 55)
        Me.btnBind.Name = "btnBind"
        Me.btnBind.NoRounding = False
        Me.btnBind.Size = New System.Drawing.Size(75, 23)
        Me.btnBind.TabIndex = 8
        Me.btnBind.Text = "Browse..."
        Me.btnBind.Transparent = False
        '
        'chkBind
        '
        Me.chkBind.Checked = False
        Me.chkBind.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkBind.Field = 16
        Me.chkBind.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkBind.Image = Nothing
        Me.chkBind.Location = New System.Drawing.Point(15, 32)
        Me.chkBind.Name = "chkBind"
        Me.chkBind.NoRounding = False
        Me.chkBind.Size = New System.Drawing.Size(75, 16)
        Me.chkBind.TabIndex = 0
        Me.chkBind.Text = "Enable"
        Me.chkBind.Transparent = False
        '
        'txtFile
        '
        Me.txtFile.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtFile.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtFile.Image = Nothing
        Me.txtFile.Location = New System.Drawing.Point(52, 15)
        Me.txtFile.MaxLength = 32767
        Me.txtFile.Multiline = False
        Me.txtFile.Name = "txtFile"
        Me.txtFile.NoRounding = False
        Me.txtFile.ReadOnly = False
        Me.txtFile.Size = New System.Drawing.Size(183, 24)
        Me.txtFile.TabIndex = 5
        Me.txtFile.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtFile.Transparent = False
        Me.txtFile.UseSystemPasswordChar = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label1.Location = New System.Drawing.Point(15, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(31, 13)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "File:"
        '
        'btnBrowse
        '
        Me.btnBrowse.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnBrowse.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnBrowse.Image = Nothing
        Me.btnBrowse.Location = New System.Drawing.Point(241, 16)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.NoRounding = False
        Me.btnBrowse.Size = New System.Drawing.Size(75, 23)
        Me.btnBrowse.TabIndex = 6
        Me.btnBrowse.Text = "Browse..."
        Me.btnBrowse.Transparent = False
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.txtReg)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.txtInstall)
        Me.TabPage3.Controls.Add(Me.Label5)
        Me.TabPage3.Controls.Add(Me.chkStartup)
        Me.TabPage3.Controls.Add(Me.Label4)
        Me.TabPage3.Controls.Add(Me.txtKB)
        Me.TabPage3.Controls.Add(Me.chkPump)
        Me.TabPage3.Controls.Add(Me.txtExt)
        Me.TabPage3.Controls.Add(Me.chkSpoof)
        Me.TabPage3.Controls.Add(Me.chkMelt)
        Me.TabPage3.Controls.Add(Me.Label3)
        Me.TabPage3.Controls.Add(Me.txtDelay)
        Me.TabPage3.Controls.Add(Me.chkDelay)
        Me.TabPage3.Controls.Add(Me.chkPersist)
        Me.TabPage3.Controls.Add(Me.Label2)
        Me.TabPage3.Controls.Add(Me.comboInject)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(330, 279)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Settings"
        '
        'txtReg
        '
        Me.txtReg.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtReg.Enabled = False
        Me.txtReg.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtReg.Image = Nothing
        Me.txtReg.Location = New System.Drawing.Point(237, 77)
        Me.txtReg.MaxLength = 32767
        Me.txtReg.Multiline = False
        Me.txtReg.Name = "txtReg"
        Me.txtReg.NoRounding = False
        Me.txtReg.ReadOnly = False
        Me.txtReg.Size = New System.Drawing.Size(75, 24)
        Me.txtReg.TabIndex = 20
        Me.txtReg.Text = "vbc"
        Me.txtReg.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtReg.Transparent = False
        Me.txtReg.UseSystemPasswordChar = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label6.Location = New System.Drawing.Point(197, 82)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 13)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Key:"
        '
        'txtInstall
        '
        Me.txtInstall.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtInstall.Enabled = False
        Me.txtInstall.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtInstall.Image = Nothing
        Me.txtInstall.Location = New System.Drawing.Point(116, 77)
        Me.txtInstall.MaxLength = 32767
        Me.txtInstall.Multiline = False
        Me.txtInstall.Name = "txtInstall"
        Me.txtInstall.NoRounding = False
        Me.txtInstall.ReadOnly = False
        Me.txtInstall.Size = New System.Drawing.Size(75, 24)
        Me.txtInstall.TabIndex = 18
        Me.txtInstall.Text = "vbc.exe"
        Me.txtInstall.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtInstall.Transparent = False
        Me.txtInstall.UseSystemPasswordChar = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label5.Location = New System.Drawing.Point(26, 82)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(84, 13)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Install Name:"
        '
        'chkStartup
        '
        Me.chkStartup.Checked = False
        Me.chkStartup.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkStartup.Field = 16
        Me.chkStartup.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkStartup.Image = Nothing
        Me.chkStartup.Location = New System.Drawing.Point(22, 59)
        Me.chkStartup.Name = "chkStartup"
        Me.chkStartup.NoRounding = False
        Me.chkStartup.Size = New System.Drawing.Size(75, 16)
        Me.chkStartup.TabIndex = 16
        Me.chkStartup.Text = "Startup"
        Me.chkStartup.Transparent = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label4.Location = New System.Drawing.Point(210, 243)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(23, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "KB"
        '
        'txtKB
        '
        Me.txtKB.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtKB.Enabled = False
        Me.txtKB.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtKB.Image = Nothing
        Me.txtKB.Location = New System.Drawing.Point(152, 238)
        Me.txtKB.MaxLength = 32767
        Me.txtKB.Multiline = False
        Me.txtKB.Name = "txtKB"
        Me.txtKB.NoRounding = False
        Me.txtKB.ReadOnly = False
        Me.txtKB.Size = New System.Drawing.Size(48, 24)
        Me.txtKB.TabIndex = 14
        Me.txtKB.Text = "100"
        Me.txtKB.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtKB.Transparent = False
        Me.txtKB.UseSystemPasswordChar = False
        '
        'chkPump
        '
        Me.chkPump.Checked = False
        Me.chkPump.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkPump.Field = 16
        Me.chkPump.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkPump.Image = Nothing
        Me.chkPump.Location = New System.Drawing.Point(22, 243)
        Me.chkPump.Name = "chkPump"
        Me.chkPump.NoRounding = False
        Me.chkPump.Size = New System.Drawing.Size(84, 16)
        Me.chkPump.TabIndex = 13
        Me.chkPump.Text = "Pump File"
        Me.chkPump.Transparent = False
        '
        'txtExt
        '
        Me.txtExt.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtExt.Enabled = False
        Me.txtExt.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtExt.Image = Nothing
        Me.txtExt.Location = New System.Drawing.Point(152, 206)
        Me.txtExt.MaxLength = 32767
        Me.txtExt.Multiline = False
        Me.txtExt.Name = "txtExt"
        Me.txtExt.NoRounding = False
        Me.txtExt.ReadOnly = False
        Me.txtExt.Size = New System.Drawing.Size(48, 24)
        Me.txtExt.TabIndex = 12
        Me.txtExt.Text = ".png"
        Me.txtExt.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtExt.Transparent = False
        Me.txtExt.UseSystemPasswordChar = False
        '
        'chkSpoof
        '
        Me.chkSpoof.Checked = False
        Me.chkSpoof.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkSpoof.Field = 16
        Me.chkSpoof.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkSpoof.Image = Nothing
        Me.chkSpoof.Location = New System.Drawing.Point(22, 210)
        Me.chkSpoof.Name = "chkSpoof"
        Me.chkSpoof.NoRounding = False
        Me.chkSpoof.Size = New System.Drawing.Size(125, 16)
        Me.chkSpoof.TabIndex = 11
        Me.chkSpoof.Text = "Extension Spoofer"
        Me.chkSpoof.Transparent = False
        '
        'chkMelt
        '
        Me.chkMelt.Checked = False
        Me.chkMelt.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkMelt.Field = 16
        Me.chkMelt.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkMelt.Image = Nothing
        Me.chkMelt.Location = New System.Drawing.Point(22, 179)
        Me.chkMelt.Name = "chkMelt"
        Me.chkMelt.NoRounding = False
        Me.chkMelt.Size = New System.Drawing.Size(75, 16)
        Me.chkMelt.TabIndex = 10
        Me.chkMelt.Text = "Hide File"
        Me.chkMelt.Transparent = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label3.Location = New System.Drawing.Point(210, 148)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Seconds"
        '
        'txtDelay
        '
        Me.txtDelay.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtDelay.Enabled = False
        Me.txtDelay.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtDelay.Image = Nothing
        Me.txtDelay.Location = New System.Drawing.Point(152, 143)
        Me.txtDelay.MaxLength = 32767
        Me.txtDelay.Multiline = False
        Me.txtDelay.Name = "txtDelay"
        Me.txtDelay.NoRounding = False
        Me.txtDelay.ReadOnly = False
        Me.txtDelay.Size = New System.Drawing.Size(48, 24)
        Me.txtDelay.TabIndex = 8
        Me.txtDelay.Text = "10"
        Me.txtDelay.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtDelay.Transparent = False
        Me.txtDelay.UseSystemPasswordChar = False
        '
        'chkDelay
        '
        Me.chkDelay.Checked = False
        Me.chkDelay.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkDelay.Field = 16
        Me.chkDelay.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkDelay.Image = Nothing
        Me.chkDelay.Location = New System.Drawing.Point(22, 147)
        Me.chkDelay.Name = "chkDelay"
        Me.chkDelay.NoRounding = False
        Me.chkDelay.Size = New System.Drawing.Size(125, 16)
        Me.chkDelay.TabIndex = 7
        Me.chkDelay.Text = "Delay Execution"
        Me.chkDelay.Transparent = False
        '
        'chkPersist
        '
        Me.chkPersist.Checked = False
        Me.chkPersist.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkPersist.Field = 16
        Me.chkPersist.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkPersist.Image = Nothing
        Me.chkPersist.Location = New System.Drawing.Point(22, 115)
        Me.chkPersist.Name = "chkPersist"
        Me.chkPersist.NoRounding = False
        Me.chkPersist.Size = New System.Drawing.Size(150, 16)
        Me.chkPersist.TabIndex = 6
        Me.chkPersist.Text = "Protect Process"
        Me.chkPersist.Transparent = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label2.Location = New System.Drawing.Point(26, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Injection:"
        '
        'comboInject
        '
        Me.comboInject.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Me.comboInject.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.comboInject.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboInject.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.comboInject.FormattingEnabled = True
        Me.comboInject.ItemHeight = 16
        Me.comboInject.Items.AddRange(New Object() {"Self", "Applaunch", "vbc", "cvtres", "calc", "RegAsm"})
        Me.comboInject.Location = New System.Drawing.Point(103, 15)
        Me.comboInject.Name = "comboInject"
        Me.comboInject.Size = New System.Drawing.Size(130, 22)
        Me.comboInject.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.btnClone)
        Me.TabPage4.Controls.Add(Me.btnIco)
        Me.TabPage4.Controls.Add(Me.txtIcon)
        Me.TabPage4.Controls.Add(Me.chkIco)
        Me.TabPage4.Controls.Add(Me.btnRand)
        Me.TabPage4.Controls.Add(Me.txtV4)
        Me.TabPage4.Controls.Add(Me.txtV3)
        Me.TabPage4.Controls.Add(Me.txtV2)
        Me.TabPage4.Controls.Add(Me.txtV1)
        Me.TabPage4.Controls.Add(Me.txtTM)
        Me.TabPage4.Controls.Add(Me.txtCopy)
        Me.TabPage4.Controls.Add(Me.txtDesc)
        Me.TabPage4.Controls.Add(Me.txtProduct)
        Me.TabPage4.Controls.Add(Me.Label11)
        Me.TabPage4.Controls.Add(Me.Label10)
        Me.TabPage4.Controls.Add(Me.Label9)
        Me.TabPage4.Controls.Add(Me.Label8)
        Me.TabPage4.Controls.Add(Me.Label7)
        Me.TabPage4.Controls.Add(Me.chkAsm)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(330, 279)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Configure"
        '
        'btnClone
        '
        Me.btnClone.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnClone.Enabled = False
        Me.btnClone.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnClone.Image = Nothing
        Me.btnClone.Location = New System.Drawing.Point(171, 179)
        Me.btnClone.Name = "btnClone"
        Me.btnClone.NoRounding = False
        Me.btnClone.Size = New System.Drawing.Size(151, 23)
        Me.btnClone.TabIndex = 23
        Me.btnClone.Text = "Clone Assembly"
        Me.btnClone.Transparent = False
        '
        'btnIco
        '
        Me.btnIco.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnIco.Enabled = False
        Me.btnIco.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnIco.Image = Nothing
        Me.btnIco.Location = New System.Drawing.Point(261, 233)
        Me.btnIco.Name = "btnIco"
        Me.btnIco.NoRounding = False
        Me.btnIco.Size = New System.Drawing.Size(61, 23)
        Me.btnIco.TabIndex = 22
        Me.btnIco.Text = "Browse..."
        Me.btnIco.Transparent = False
        '
        'txtIcon
        '
        Me.txtIcon.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtIcon.Enabled = False
        Me.txtIcon.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtIcon.Image = Nothing
        Me.txtIcon.Location = New System.Drawing.Point(27, 232)
        Me.txtIcon.MaxLength = 32767
        Me.txtIcon.Multiline = False
        Me.txtIcon.Name = "txtIcon"
        Me.txtIcon.NoRounding = False
        Me.txtIcon.ReadOnly = False
        Me.txtIcon.Size = New System.Drawing.Size(230, 24)
        Me.txtIcon.TabIndex = 21
        Me.txtIcon.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtIcon.Transparent = False
        Me.txtIcon.UseSystemPasswordChar = False
        '
        'chkIco
        '
        Me.chkIco.Checked = False
        Me.chkIco.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkIco.Field = 16
        Me.chkIco.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkIco.Image = Nothing
        Me.chkIco.Location = New System.Drawing.Point(27, 209)
        Me.chkIco.Name = "chkIco"
        Me.chkIco.NoRounding = False
        Me.chkIco.Size = New System.Drawing.Size(111, 16)
        Me.chkIco.TabIndex = 20
        Me.chkIco.Text = "Change Icon"
        Me.chkIco.Transparent = False
        '
        'btnRand
        '
        Me.btnRand.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnRand.Enabled = False
        Me.btnRand.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnRand.Image = Nothing
        Me.btnRand.Location = New System.Drawing.Point(14, 179)
        Me.btnRand.Name = "btnRand"
        Me.btnRand.NoRounding = False
        Me.btnRand.Size = New System.Drawing.Size(151, 23)
        Me.btnRand.TabIndex = 19
        Me.btnRand.Text = "Random Assembly"
        Me.btnRand.Transparent = False
        '
        'txtV4
        '
        Me.txtV4.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtV4.Enabled = False
        Me.txtV4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtV4.Image = Nothing
        Me.txtV4.Location = New System.Drawing.Point(225, 149)
        Me.txtV4.MaxLength = 32767
        Me.txtV4.Multiline = False
        Me.txtV4.Name = "txtV4"
        Me.txtV4.NoRounding = False
        Me.txtV4.ReadOnly = False
        Me.txtV4.Size = New System.Drawing.Size(32, 24)
        Me.txtV4.TabIndex = 18
        Me.txtV4.Text = "0"
        Me.txtV4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtV4.Transparent = False
        Me.txtV4.UseSystemPasswordChar = False
        '
        'txtV3
        '
        Me.txtV3.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtV3.Enabled = False
        Me.txtV3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtV3.Image = Nothing
        Me.txtV3.Location = New System.Drawing.Point(187, 149)
        Me.txtV3.MaxLength = 32767
        Me.txtV3.Multiline = False
        Me.txtV3.Name = "txtV3"
        Me.txtV3.NoRounding = False
        Me.txtV3.ReadOnly = False
        Me.txtV3.Size = New System.Drawing.Size(32, 24)
        Me.txtV3.TabIndex = 17
        Me.txtV3.Text = "0"
        Me.txtV3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtV3.Transparent = False
        Me.txtV3.UseSystemPasswordChar = False
        '
        'txtV2
        '
        Me.txtV2.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtV2.Enabled = False
        Me.txtV2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtV2.Image = Nothing
        Me.txtV2.Location = New System.Drawing.Point(148, 149)
        Me.txtV2.MaxLength = 32767
        Me.txtV2.Multiline = False
        Me.txtV2.Name = "txtV2"
        Me.txtV2.NoRounding = False
        Me.txtV2.ReadOnly = False
        Me.txtV2.Size = New System.Drawing.Size(32, 24)
        Me.txtV2.TabIndex = 16
        Me.txtV2.Text = "0"
        Me.txtV2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtV2.Transparent = False
        Me.txtV2.UseSystemPasswordChar = False
        '
        'txtV1
        '
        Me.txtV1.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtV1.Enabled = False
        Me.txtV1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtV1.Image = Nothing
        Me.txtV1.Location = New System.Drawing.Point(106, 149)
        Me.txtV1.MaxLength = 32767
        Me.txtV1.Multiline = False
        Me.txtV1.Name = "txtV1"
        Me.txtV1.NoRounding = False
        Me.txtV1.ReadOnly = False
        Me.txtV1.Size = New System.Drawing.Size(32, 24)
        Me.txtV1.TabIndex = 15
        Me.txtV1.Text = "1"
        Me.txtV1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtV1.Transparent = False
        Me.txtV1.UseSystemPasswordChar = False
        '
        'txtTM
        '
        Me.txtTM.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtTM.Enabled = False
        Me.txtTM.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtTM.Image = Nothing
        Me.txtTM.Location = New System.Drawing.Point(106, 123)
        Me.txtTM.MaxLength = 32767
        Me.txtTM.Multiline = False
        Me.txtTM.Name = "txtTM"
        Me.txtTM.NoRounding = False
        Me.txtTM.ReadOnly = False
        Me.txtTM.Size = New System.Drawing.Size(151, 24)
        Me.txtTM.TabIndex = 14
        Me.txtTM.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtTM.Transparent = False
        Me.txtTM.UseSystemPasswordChar = False
        '
        'txtCopy
        '
        Me.txtCopy.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtCopy.Enabled = False
        Me.txtCopy.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtCopy.Image = Nothing
        Me.txtCopy.Location = New System.Drawing.Point(106, 95)
        Me.txtCopy.MaxLength = 32767
        Me.txtCopy.Multiline = False
        Me.txtCopy.Name = "txtCopy"
        Me.txtCopy.NoRounding = False
        Me.txtCopy.ReadOnly = False
        Me.txtCopy.Size = New System.Drawing.Size(151, 24)
        Me.txtCopy.TabIndex = 13
        Me.txtCopy.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtCopy.Transparent = False
        Me.txtCopy.UseSystemPasswordChar = False
        '
        'txtDesc
        '
        Me.txtDesc.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtDesc.Enabled = False
        Me.txtDesc.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtDesc.Image = Nothing
        Me.txtDesc.Location = New System.Drawing.Point(106, 68)
        Me.txtDesc.MaxLength = 32767
        Me.txtDesc.Multiline = False
        Me.txtDesc.Name = "txtDesc"
        Me.txtDesc.NoRounding = False
        Me.txtDesc.ReadOnly = False
        Me.txtDesc.Size = New System.Drawing.Size(151, 24)
        Me.txtDesc.TabIndex = 12
        Me.txtDesc.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtDesc.Transparent = False
        Me.txtDesc.UseSystemPasswordChar = False
        '
        'txtProduct
        '
        Me.txtProduct.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtProduct.Enabled = False
        Me.txtProduct.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtProduct.Image = Nothing
        Me.txtProduct.Location = New System.Drawing.Point(106, 42)
        Me.txtProduct.MaxLength = 32767
        Me.txtProduct.Multiline = False
        Me.txtProduct.Name = "txtProduct"
        Me.txtProduct.NoRounding = False
        Me.txtProduct.ReadOnly = False
        Me.txtProduct.Size = New System.Drawing.Size(151, 24)
        Me.txtProduct.TabIndex = 11
        Me.txtProduct.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtProduct.Transparent = False
        Me.txtProduct.UseSystemPasswordChar = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label11.Location = New System.Drawing.Point(45, 154)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(54, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Version:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label10.Location = New System.Drawing.Point(25, 127)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(74, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Trademark:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label9.Location = New System.Drawing.Point(32, 101)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Copyright:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label8.Location = New System.Drawing.Point(24, 73)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Description:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.Label7.Location = New System.Drawing.Point(45, 47)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(55, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Product:"
        '
        'chkAsm
        '
        Me.chkAsm.Checked = False
        Me.chkAsm.Customization = "ICAg/9KWMv9QPAD/CAgI/xAQEP////8K/78A/wAAAP8AAAD/"
        Me.chkAsm.Field = 16
        Me.chkAsm.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkAsm.Image = Nothing
        Me.chkAsm.Location = New System.Drawing.Point(27, 16)
        Me.chkAsm.Name = "chkAsm"
        Me.chkAsm.NoRounding = False
        Me.chkAsm.Size = New System.Drawing.Size(131, 16)
        Me.chkAsm.TabIndex = 0
        Me.chkAsm.Text = "Change Assembly"
        Me.chkAsm.Transparent = False
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Me.TabPage5.Controls.Add(Me.lblDetections)
        Me.TabPage5.Controls.Add(Me.txtLink)
        Me.TabPage5.Controls.Add(Me.ListView1)
        Me.TabPage5.Controls.Add(Me.btnScan)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(330, 279)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Scanner"
        '
        'lblDetections
        '
        Me.lblDetections.AutoSize = True
        Me.lblDetections.ForeColor = System.Drawing.Color.DeepSkyBlue
        Me.lblDetections.Location = New System.Drawing.Point(17, 216)
        Me.lblDetections.Name = "lblDetections"
        Me.lblDetections.Size = New System.Drawing.Size(95, 13)
        Me.lblDetections.TabIndex = 6
        Me.lblDetections.Text = "Detections: 0/0"
        '
        'txtLink
        '
        Me.txtLink.Customization = "/78A/wcHB/8AAAD/KCgo/w=="
        Me.txtLink.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtLink.Image = Nothing
        Me.txtLink.Location = New System.Drawing.Point(122, 240)
        Me.txtLink.MaxLength = 32767
        Me.txtLink.Multiline = False
        Me.txtLink.Name = "txtLink"
        Me.txtLink.NoRounding = False
        Me.txtLink.ReadOnly = False
        Me.txtLink.Size = New System.Drawing.Size(188, 24)
        Me.txtLink.TabIndex = 2
        Me.txtLink.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.txtLink.Transparent = False
        Me.txtLink.UseSystemPasswordChar = False
        '
        'ListView1
        '
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1, Me.ColumnHeader2})
        Me.ListView1.Location = New System.Drawing.Point(20, 16)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(290, 194)
        Me.ListView1.TabIndex = 1
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "Antivirus"
        Me.ColumnHeader1.Width = 146
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Result"
        Me.ColumnHeader2.Width = 135
        '
        'btnScan
        '
        Me.btnScan.Customization = "Dg4O/w4ODv8pKSn/////Bf///x7///8FPj4+/////w8AAAD/EBAQ//+/AP8="
        Me.btnScan.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.btnScan.Image = Nothing
        Me.btnScan.Location = New System.Drawing.Point(20, 240)
        Me.btnScan.Name = "btnScan"
        Me.btnScan.NoRounding = False
        Me.btnScan.Size = New System.Drawing.Size(96, 23)
        Me.btnScan.TabIndex = 0
        Me.btnScan.Text = "Scan"
        Me.btnScan.Transparent = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(386, 389)
        Me.Controls.Add(Me.DivinityThemeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Galaxy Crypter"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.DivinityThemeContainer1.ResumeLayout(False)
        Me.DivinityTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.grpBinder.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DivinityThemeContainer1 As Galaxy_Crypter.DivinityThemeContainer
    Friend WithEvents DivinityTabControl1 As Galaxy_Crypter.DivinityTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents DivinityControlBox1 As Galaxy_Crypter.DivinityControlBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents chkEOF As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents grpBinder As Galaxy_Crypter.DivinityGroupBox
    Friend WithEvents chkOnce As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents txtBind As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents btnBind As Galaxy_Crypter.DivinityButton
    Friend WithEvents chkBind As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents txtFile As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnBrowse As Galaxy_Crypter.DivinityButton
    Friend WithEvents rndPool As Galaxy_Crypter.RandomPool
    Friend WithEvents txtKey As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents comboInject As Galaxy_Crypter.DivinityComboBox
    Friend WithEvents btnCrypt As Galaxy_Crypter.DivinityButton
    Friend WithEvents txtReg As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtInstall As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents chkStartup As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtKB As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents chkPump As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents txtExt As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents chkSpoof As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents chkMelt As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtDelay As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents chkDelay As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents chkPersist As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents chkAsm As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents btnIco As Galaxy_Crypter.DivinityButton
    Friend WithEvents txtIcon As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents chkIco As Galaxy_Crypter.DivinityCheckBox
    Friend WithEvents btnRand As Galaxy_Crypter.DivinityButton
    Friend WithEvents txtV4 As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents txtV3 As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents txtV2 As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents txtV1 As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents txtTM As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents txtCopy As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents txtDesc As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents txtProduct As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents btnProfile As Galaxy_Crypter.DivinityButton
    Friend WithEvents btnRedeem As Galaxy_Crypter.DivinityButton
    Friend WithEvents txtNews As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblExpire As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents lblUser As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnScan As Galaxy_Crypter.DivinityButton
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents txtLink As Galaxy_Crypter.DivinityTextBox
    Friend WithEvents lblDetections As System.Windows.Forms.Label
    Friend WithEvents btnClone As Galaxy_Crypter.DivinityButton

End Class
