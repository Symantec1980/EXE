﻿Imports System.IO
Imports Microsoft.Win32
Public Class Form87

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Try
            ListBox1.Items.Clear()

            Dim Mi As String = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
            For Each s As String In Directory.GetFiles(Mi)
                ListBox1.Items.Add(s)
            Next
        Catch : End Try
        ProgressBar1.Value = 100
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Try
            For Each x As String In ListBox1.Items
                Try
                    IO.File.Delete(x)
                Catch ex As Exception
                End Try
            Next
            MsgBox("Done", MsgBoxStyle.Information)
            ListBox1.Items.Clear()
        Catch : End Try
    End Sub

    Private Sub FlatButton3_Click(sender As Object, e As EventArgs)
        ListBox1.Items.Clear()
    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Me.Close()
    End Sub
End Class