﻿Imports System.Text
Imports System.Windows.Forms

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim text As String = Convert.ToBase64String(Encoding.Unicode.GetBytes(Me.RichTextBox1.Text))
        Me.RichTextBox1.Text = Convert.ToBase64String(Encoding.Unicode.GetBytes(Me.RichTextBox1.Text))
    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim f As String = My.Resources.ENTRY
        f = f.Replace("%P%", TextBox1.Text)
        RichTextBox1.Text = f
    End Sub
End Class