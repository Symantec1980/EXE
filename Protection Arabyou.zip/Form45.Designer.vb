﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form45
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FormSkin1 = New WindowsApplication17.FormSkin()
        Me.FlatButton10 = New WindowsApplication17.FlatButton()
        Me.FlatButton9 = New WindowsApplication17.FlatButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FlatButton7 = New WindowsApplication17.FlatButton()
        Me.FlatButton8 = New WindowsApplication17.FlatButton()
        Me.FlatButton4 = New WindowsApplication17.FlatButton()
        Me.FlatButton5 = New WindowsApplication17.FlatButton()
        Me.FlatButton6 = New WindowsApplication17.FlatButton()
        Me.FlatButton3 = New WindowsApplication17.FlatButton()
        Me.FlatButton2 = New WindowsApplication17.FlatButton()
        Me.FlatButton1 = New WindowsApplication17.FlatButton()
        Me.FlatMini1 = New WindowsApplication17.FlatMini()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.FormSkin1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FormSkin1
        '
        Me.FormSkin1.BackColor = System.Drawing.Color.White
        Me.FormSkin1.BaseColor = System.Drawing.Color.Black
        Me.FormSkin1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FormSkin1.Controls.Add(Me.Label2)
        Me.FormSkin1.Controls.Add(Me.FlatButton10)
        Me.FormSkin1.Controls.Add(Me.FlatButton9)
        Me.FormSkin1.Controls.Add(Me.Label1)
        Me.FormSkin1.Controls.Add(Me.RichTextBox1)
        Me.FormSkin1.Controls.Add(Me.PictureBox2)
        Me.FormSkin1.Controls.Add(Me.PictureBox1)
        Me.FormSkin1.Controls.Add(Me.FlatButton7)
        Me.FormSkin1.Controls.Add(Me.FlatButton8)
        Me.FormSkin1.Controls.Add(Me.FlatButton4)
        Me.FormSkin1.Controls.Add(Me.FlatButton5)
        Me.FormSkin1.Controls.Add(Me.FlatButton6)
        Me.FormSkin1.Controls.Add(Me.FlatButton3)
        Me.FormSkin1.Controls.Add(Me.FlatButton2)
        Me.FormSkin1.Controls.Add(Me.FlatButton1)
        Me.FormSkin1.Controls.Add(Me.FlatMini1)
        Me.FormSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormSkin1.FlatColor = System.Drawing.Color.Lime
        Me.FormSkin1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FormSkin1.HeaderColor = System.Drawing.Color.Black
        Me.FormSkin1.HeaderMaximize = False
        Me.FormSkin1.Location = New System.Drawing.Point(0, 0)
        Me.FormSkin1.Name = "FormSkin1"
        Me.FormSkin1.Size = New System.Drawing.Size(686, 402)
        Me.FormSkin1.TabIndex = 1
        Me.FormSkin1.Text = "FormSkin1"
        '
        'FlatButton10
        '
        Me.FlatButton10.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton10.BaseColor = System.Drawing.Color.Black
        Me.FlatButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton10.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton10.Location = New System.Drawing.Point(614, 318)
        Me.FlatButton10.Name = "FlatButton10"
        Me.FlatButton10.Rounded = False
        Me.FlatButton10.Size = New System.Drawing.Size(27, 32)
        Me.FlatButton10.TabIndex = 15
        Me.FlatButton10.Text = "X"
        Me.FlatButton10.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton9
        '
        Me.FlatButton9.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton9.BaseColor = System.Drawing.Color.Black
        Me.FlatButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton9.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton9.Location = New System.Drawing.Point(647, 318)
        Me.FlatButton9.Name = "FlatButton9"
        Me.FlatButton9.Rounded = False
        Me.FlatButton9.Size = New System.Drawing.Size(27, 32)
        Me.FlatButton9.TabIndex = 14
        Me.FlatButton9.Text = "D"
        Me.FlatButton9.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Black
        Me.Label1.ForeColor = System.Drawing.Color.Lime
        Me.Label1.Location = New System.Drawing.Point(124, 329)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 21)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "...!"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.WindowText
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.RichTextBox1.Cursor = System.Windows.Forms.Cursors.Cross
        Me.RichTextBox1.EnableAutoDragDrop = True
        Me.RichTextBox1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.ForeColor = System.Drawing.Color.Lime
        Me.RichTextBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.RichTextBox1.Location = New System.Drawing.Point(124, 51)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(550, 261)
        Me.RichTextBox1.TabIndex = 12
        Me.RichTextBox1.Text = ""
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.WindowsApplication17.My.Resources.Resources._9898
        Me.PictureBox2.Location = New System.Drawing.Point(346, 363)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(337, 36)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 11
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.WindowsApplication17.My.Resources.Resources.cooltext274861160422487
        Me.PictureBox1.Location = New System.Drawing.Point(3, 363)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(337, 36)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'FlatButton7
        '
        Me.FlatButton7.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton7.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton7.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton7.Location = New System.Drawing.Point(12, 318)
        Me.FlatButton7.Name = "FlatButton7"
        Me.FlatButton7.Rounded = False
        Me.FlatButton7.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton7.TabIndex = 9
        Me.FlatButton7.Text = "H_worm"
        Me.FlatButton7.TextColor = System.Drawing.Color.Red
        '
        'FlatButton8
        '
        Me.FlatButton8.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton8.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton8.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton8.Location = New System.Drawing.Point(12, 280)
        Me.FlatButton8.Name = "FlatButton8"
        Me.FlatButton8.Rounded = False
        Me.FlatButton8.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton8.TabIndex = 8
        Me.FlatButton8.Text = "CyberGate"
        Me.FlatButton8.TextColor = System.Drawing.Color.Red
        '
        'FlatButton4
        '
        Me.FlatButton4.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton4.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton4.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton4.Location = New System.Drawing.Point(12, 241)
        Me.FlatButton4.Name = "FlatButton4"
        Me.FlatButton4.Rounded = False
        Me.FlatButton4.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton4.TabIndex = 7
        Me.FlatButton4.Text = "xtreme Rat"
        Me.FlatButton4.TextColor = System.Drawing.Color.Red
        '
        'FlatButton5
        '
        Me.FlatButton5.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton5.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton5.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton5.Location = New System.Drawing.Point(12, 203)
        Me.FlatButton5.Name = "FlatButton5"
        Me.FlatButton5.Rounded = False
        Me.FlatButton5.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton5.TabIndex = 6
        Me.FlatButton5.Text = "Dark comet"
        Me.FlatButton5.TextColor = System.Drawing.Color.Red
        '
        'FlatButton6
        '
        Me.FlatButton6.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton6.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton6.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton6.Location = New System.Drawing.Point(12, 165)
        Me.FlatButton6.Name = "FlatButton6"
        Me.FlatButton6.Rounded = False
        Me.FlatButton6.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton6.TabIndex = 5
        Me.FlatButton6.Text = "Bifrost"
        Me.FlatButton6.TextColor = System.Drawing.Color.Red
        '
        'FlatButton3
        '
        Me.FlatButton3.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton3.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton3.Location = New System.Drawing.Point(12, 127)
        Me.FlatButton3.Name = "FlatButton3"
        Me.FlatButton3.Rounded = False
        Me.FlatButton3.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton3.TabIndex = 4
        Me.FlatButton3.Text = "Spy net"
        Me.FlatButton3.TextColor = System.Drawing.Color.Red
        '
        'FlatButton2
        '
        Me.FlatButton2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton2.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton2.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton2.Location = New System.Drawing.Point(12, 89)
        Me.FlatButton2.Name = "FlatButton2"
        Me.FlatButton2.Rounded = False
        Me.FlatButton2.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton2.TabIndex = 3
        Me.FlatButton2.Text = "H_worm"
        Me.FlatButton2.TextColor = System.Drawing.Color.Red
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.FlatButton1.BaseColor = System.Drawing.SystemColors.MenuText
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton1.Location = New System.Drawing.Point(12, 51)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(106, 32)
        Me.FlatButton1.TabIndex = 2
        Me.FlatButton1.Text = "NJrat"
        Me.FlatButton1.TextColor = System.Drawing.Color.Red
        '
        'FlatMini1
        '
        Me.FlatMini1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatMini1.BackColor = System.Drawing.Color.Black
        Me.FlatMini1.BaseColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.FlatMini1.Font = New System.Drawing.Font("Marlett", 12.0!)
        Me.FlatMini1.Location = New System.Drawing.Point(632, 12)
        Me.FlatMini1.Name = "FlatMini1"
        Me.FlatMini1.Size = New System.Drawing.Size(18, 18)
        Me.FlatMini1.TabIndex = 0
        Me.FlatMini1.Text = "FlatMini1"
        Me.FlatMini1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Black
        Me.Label2.ForeColor = System.Drawing.Color.Linen
        Me.Label2.Location = New System.Drawing.Point(655, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 21)
        Me.Label2.TabIndex = 16
        Me.Label2.Text = "X"
        '
        'Form45
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(686, 402)
        Me.Controls.Add(Me.FormSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form45"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form45"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.FormSkin1.ResumeLayout(False)
        Me.FormSkin1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1,System.ComponentModel.ISupportInitialize).EndInit
        Me.ResumeLayout(false)

End Sub
    Friend WithEvents FormSkin1 As WindowsApplication17.FormSkin
    Friend WithEvents FlatButton7 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton8 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton4 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton5 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton6 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton3 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton2 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton1 As WindowsApplication17.FlatButton
    Friend WithEvents FlatMini1 As WindowsApplication17.FlatMini
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents FlatButton10 As WindowsApplication17.FlatButton
    Friend WithEvents FlatButton9 As WindowsApplication17.FlatButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
End Class
