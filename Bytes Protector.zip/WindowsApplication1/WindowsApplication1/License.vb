﻿Imports System
Imports System.Net
Imports System.Text
Imports System.IO
Imports System.IO.Compression
Imports System.Diagnostics
Imports System.Reflection
Imports System.Windows.Forms
Imports System.ComponentModel
Imports System.Security.Cryptography

''' <summary>
''' License Loader, Version: 1.2.0.0, Change: 3/14/2012
''' </summary>

Public Class License

#Region " ReadOnly Properties "

    ReadOnly Property Username As String
        Get
            Dim Data As Object = Instance.GetMethod("GetUsername").Invoke(Nothing, Nothing)
            Return DirectCast(Data, String)
        End Get
    End Property

    ReadOnly Property ProgramChecksum As String
        Get
            Dim Data As Object = Instance.GetMethod("GetChecksum").Invoke(Nothing, Nothing)
            Return DirectCast(Data, String)
        End Get
    End Property

    ReadOnly Property ExecutablePath As String
        Get
            Dim Data As Object = Instance.GetMethod("GetExecutablePath").Invoke(Nothing, Nothing)
            Return DirectCast(Data, String)
        End Get
    End Property

    ReadOnly Property GlobalMessage As String
        Get
            Dim Data As Object = Instance.GetMethod("GetMessage").Invoke(Nothing, Nothing)
            Return DirectCast(Data, String)
        End Get
    End Property

    ReadOnly Property ExpirationDate As Date
        Get
            Dim Data As Object = Instance.GetMethod("GetExpiration").Invoke(Nothing, Nothing)
            Return DirectCast(Data, Date)
        End Get
    End Property

    ReadOnly Property TimeRemaining As TimeSpan
        Get
            Dim Data As Object = Instance.GetMethod("GetRemaining").Invoke(Nothing, Nothing)
            Return DirectCast(Data, TimeSpan)
        End Get
    End Property

    ReadOnly Property Demo As Boolean
        Get
            Dim Data As Object = Instance.GetMethod("GetDemo").Invoke(Nothing, Nothing)
            Return DirectCast(Data, Boolean)
        End Get
    End Property

    ReadOnly Property Continuous As Boolean
        Get
            Dim Data As Object = Instance.GetMethod("GetContinuous").Invoke(Nothing, Nothing)
            Return DirectCast(Data, Boolean)
        End Get
    End Property

    ReadOnly Property UsersCount As Integer
        Get
            Dim Data As Object = Instance.GetMethod("GetUsersCount").Invoke(Nothing, Nothing)
            Return DirectCast(Data, Integer)
        End Get
    End Property

    ReadOnly Property UsersOnline As Integer
        Get
            Dim Data As Object = Instance.GetMethod("GetUsersOnline").Invoke(Nothing, Nothing)
            Return DirectCast(Data, Integer)
        End Get
    End Property

    ReadOnly Property GUID As String
        Get
            Dim Data As Object = Instance.GetMethod("GetGUID").Invoke(Nothing, Nothing)
            Return DirectCast(Data, String)
        End Get
    End Property

#End Region

#Region " Initialize Properties "

    Private _ID As String
    Property ID() As String
        Get
            Return _ID
        End Get
        Set(ByVal value As String)
            _ID = value
        End Set
    End Property

    Private _Catch As Boolean
    Property [Catch]() As Boolean
        Get
            Return _Catch
        End Get
        Set(ByVal value As Boolean)
            _Catch = value
        End Set
    End Property

    Private _RunHook As GenericDelegate
    Property RunHook() As GenericDelegate
        Get
            Return _RunHook
        End Get
        Set(ByVal value As GenericDelegate)
            _RunHook = value
        End Set
    End Property

    Private _BanHook As GenericDelegate
    Property BanHook() As GenericDelegate
        Get
            Return _BanHook
        End Get
        Set(ByVal value As GenericDelegate)
            _BanHook = value
        End Set
    End Property

    Private _RenewHook As GenericDelegate
    Property RenewHook() As GenericDelegate
        Get
            Return _RenewHook
        End Get
        Set(ByVal value As GenericDelegate)
            _RenewHook = value
        End Set
    End Property

    Private _Protection As Guard
    Property Protection() As Guard
        Get
            Return _Protection
        End Get
        Set(ByVal value As Guard)
            _Protection = value
        End Set
    End Property

#End Region

#Region " Public Methods "

    Sub Initialize()
        Try
            Client = New WebClient

            InitializeChecksums()
            InitializeComponents()
            InitializeProgram()

            Instance.GetMethod("SetID").Invoke(Nothing, New Object() {ID})
            Instance.GetMethod("SetCatch").Invoke(Nothing, New Object() {[Catch]})
            Instance.GetMethod("SetRunHook").Invoke(Nothing, New Object() {RunHook})
            Instance.GetMethod("SetBanHook").Invoke(Nothing, New Object() {BanHook})
            Instance.GetMethod("SetRenewHook").Invoke(Nothing, New Object() {RenewHook})
            Instance.GetMethod("SetScan").Invoke(Nothing, New Object() {DirectCast(Protection, Byte)})
        Catch ex As Exception
            Dim T As New StringBuilder
            T.AppendLine(Date.UtcNow.ToString)
            T.AppendLine()
            T.AppendLine(ex.Message)
            T.AppendLine(ex.StackTrace)
            File.WriteAllText("loader.error", T.ToString)

            ErrorKill("An unknown error has occurred.")
            Return
        End Try

        Try
            Instance.GetMethod("InitializeLicense").Invoke(Nothing, Nothing)
        Catch
            ErrorKill("An unknown error has occurred.")
        End Try
    End Sub

    Sub ShowAccount()
        Instance.GetMethod("ShowAccount").Invoke(Nothing, Nothing)
    End Sub

#End Region


#Region " System Properties "

    Private _LocationPath As String = String.Empty
    Private ReadOnly Property LocationPath As String
        Get
            If _LocationPath.Length = 0 Then
                Dim Common As String = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)
                _LocationPath = Path.Combine(Common, "Nimoru")
            End If

            Return _LocationPath
        End Get
    End Property

    Private ReadOnly Property GizmoDllLocation As String
        Get
            Return Path.Combine(LocationPath, "GizmoDll")
        End Get
    End Property

    Private ReadOnly Property GizmoLocation As String
        Get
            Return Path.Combine(LocationPath, "Gizmo")
        End Get
    End Property

    Private ReadOnly Property LicenseLocation As String
        Get
            Return Path.Combine(LocationPath, "License")
        End Get
    End Property

    Private _Checksum As String()
    Private ReadOnly Property Checksum As String()
        Get
            Return _Checksum
        End Get
    End Property

#End Region

#Region " System Declarations "

    Private Instance As Type
    Private Client As WebClient

    Private Const Domain As String = "http://seal.elitevs.net/Base/"
    Private Const PublicKey As String = "BgIAAAAiAABEU1MxAAQAAKVlurdZMaHymNk04yRy3VGj0Bhf6gGIBsGr1zk42LrdnwYLfvn7MBAiYoCH2cD07M/HuM6NW1WqJQVF2omwH5S211wfvBCutU92RxXldmfvd06l8eQqmppztYIrXdxmW0BRlosBKPM5ms6YXZnoMKseAoqZ6Ajza8U9QCJMkSHSR+O23EoGj9V+7xwkCoYHklFtLJzERB6y/DW1BCCHhLblzpFz+mht1CD6xAi2QBNY7vZcWdbqo+ZLT4y7sw8jU61liYBuZLA/t+6KHhoIwZ+NIErsCHW5RD9ln5VpMC66wBCcY594ZTIManIuvmpw4eQaUXZPoMogf29gJgJSolaDg5iP1XDqzOTPu9RdsHe3R1ZaNglrL05zoTM94Zkl5KT+bPAUC99kGrEDmNipe6tj8FwoOTNNaTaOvWZlXTtAfaxqGV47nxKfabgxEl08n0c3PBJEjUZzJ4chwQ2Ex2A5uYBgRukcmKmRmdwIphHq0IwdoxS1+6HSwXxg1d3EEAoxJ75R1eSXF+cXOeC7d/U2UY0tqwAAAMvTiz5uMzpBQIYdNcbYnrJwHObk"

    <EditorBrowsable(EditorBrowsableState.Advanced)> _
    Delegate Sub GenericDelegate()

    Private Tries As Integer

    <Flags(), EditorBrowsable(EditorBrowsableState.Advanced)> _
    Enum Guard As Byte
        None = 0
        Debuggers = 1
        DebuggersEx = 2
        Timing = 4
        Parent = 8
        FullScan = 15
    End Enum

#End Region

#Region " System Methods "

    Private Sub InitializeChecksums()
        _Checksum = Client.DownloadString(Domain & "getChecksum.php").Split(Char.MinValue)
    End Sub

    Private Sub InitializeComponents()
        Dim Hash As String

        If Not Directory.Exists(LocationPath) Then
            Directory.CreateDirectory(LocationPath)
        End If

        If Not File.Exists(GizmoDllLocation) Then
            DownloadGizmoDll()
        End If

        Hash = MD5File(GizmoDllLocation)
        If Not Hash = Checksum(1) Then
            DownloadGizmoDll()
        End If


        If Not File.Exists(GizmoLocation) Then
            DownloadGizmo()
        End If

        Hash = MD5File(GizmoLocation)
        If Not Hash = Checksum(2) Then
            DownloadGizmo()
        End If


        If Not File.Exists(LicenseLocation) Then
            DownloadLicense()
        End If

        Hash = MD5File(LicenseLocation)
        If Not Hash = Checksum(3) Then
            DownloadLicense()
        End If
    End Sub

    Private Sub InitializeProgram()
        Dim M As FileStream = File.OpenRead(LicenseLocation)
        Dim R As New BinaryReader(M)

        Dim Sign As Byte() = R.ReadBytes(40)
        Dim Data As Byte() = R.ReadBytes(CInt(M.Length - Sign.Length))

        Dim DSA As New DSACryptoServiceProvider
        DSA.ImportCspBlob(Convert.FromBase64String(PublicKey))

        If Not DSA.VerifyData(Data, Sign) Then
            R.Close()
            Throw New InvalidDataException
            Return
        End If

        Instance = Assembly.Load(Data).GetType("Share")
    End Sub


    Private Sub DownloadGizmoDll()
        Dim Data As Byte() = Client.DownloadData(Checksum(0) & Checksum(1) & ".co")
        Data = Decompress(Data)

        Dim Hash As String = MD5(Data)
        If Not Checksum(1) = Hash Then
            Fail(GizmoDllLocation)
            Return
        End If

        File.WriteAllBytes(GizmoDllLocation, Data)
    End Sub

    Private Sub DownloadGizmo()
        Dim Data As Byte() = Client.DownloadData(Checksum(0) & Checksum(2) & ".co")
        Data = GizmoDecompress(Data)

        Dim Hash As String = MD5(Data)
        If Not Checksum(2) = Hash Then
            Fail(GizmoLocation)
            Return
        End If

        File.WriteAllBytes(GizmoLocation, Data)
    End Sub

    Private Sub DownloadLicense()
        Dim PI As New ProcessStartInfo
        PI.Arguments = String.Format("""{0}"" ""{1}"" {2} -s", Checksum(0) & Checksum(3) & ".co", LicenseLocation, Checksum(3))
        PI.FileName = GizmoLocation
        PI.UseShellExecute = False

        Dim P As Process = Process.Start(PI)
        If Not P.WaitForExit(20000) Then
            Environment.Exit(0)
        End If

        If Not P.ExitCode = 7788 Then
            Environment.Exit(0)
        End If
    End Sub


    Private Sub Fail(ByVal path As String)
        File.Delete(path)
        ErrorKill("Failed to initialize all the required components.")
    End Sub

    Private Sub ErrorKill(ByVal message As String)
        MessageBox.Show(message & " Please try again later.", "Loader Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Environment.Exit(0)
    End Sub


    Private Function Decompress(ByVal data As Byte()) As Byte()
        Dim Size As Integer = BitConverter.ToInt32(data, 0)

        Dim U(Size - 1) As Byte
        Dim M As New MemoryStream(data, 4, data.Length - 4)

        Dim D As New DeflateStream(M, CompressionMode.Decompress, False)
        D.Read(U, 0, U.Length)

        D.Close()
        M.Close()
        Return U
    End Function

    Private Function GizmoDecompress(ByVal data As Byte()) As Byte()
        Dim GizmoDll As Byte() = File.ReadAllBytes(GizmoDllLocation)
        Dim G As MethodInfo = Assembly.Load(GizmoDll).GetType("H").GetMethod("Decompress")
        Return DirectCast(G.Invoke(Nothing, New Object() {data}), Byte())
    End Function


    Private Function MD5(ByVal data As Byte()) As String
        Dim H As New MD5CryptoServiceProvider
        Return HashToString(H.ComputeHash(data))
    End Function

    Private Function MD5File(ByVal path As String) As String
        Dim F As New FileStream(path, FileMode.Open, FileAccess.Read)
        Dim H As New MD5CryptoServiceProvider

        Dim Hash As String = HashToString(H.ComputeHash(F))

        F.Close()
        Return Hash
    End Function

    Private Function HashToString(ByVal data As Byte()) As String
        Return BitConverter.ToString(data).ToLower().Replace("-", String.Empty)
    End Function

#End Region

End Class
