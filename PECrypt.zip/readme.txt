

Package: pecrypt-src.rar
Date: November 23, 2003
Author: archphase

Summary: PECRYPT is a tool that
takes a normal win32 PE and preforms a
simple algorithm upon the executable file.  It
then takes it and adds it as a resource to a
stub which on execution decrypts our body and
launches our device.  Therefore providing streamless
undetection by current antivirus measures unless
of course the stub is tagged.

If you would like the source code it is written
in Delphi (v6) then please shoot me an email and
I'll be sure to send you a copy back.

If you don't like the icon of the default stub
then use reshacker or Resource Tuner to change
the default stub or the stub you create.  This
does __not__ work on Windows 9x systems so you
should be using NT which a (duh!), 9x technolgy
is old and pretty dense. 


 - The stub is containued as a resource in pecrypt.exe so
 after the tasks are preformed it will drop it. 

Files:
 - .\stub\ - Source code for decrypting stub..
 - .\pecrypt\ - source code for encryption and output of stub
 - .\readme.txt - yer looking at me, *blush*

 - Note that this source code is provided for EDUCATIONAL
 purposes only and is ment to yield those of us who want to
 further our knowledge not to be exported for harm to another.
 The source code is my personal work and no others, therefore
 I say that you can use it to you hearts content but you must
 refrence back to the original author (archphase).  With that
 said enjoy the sourcecode and play nice kids.

Regards,
archphase 