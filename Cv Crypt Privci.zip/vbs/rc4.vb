﻿Public Class rc4
    Public Shared Function RC4Encrypt(ByVal A6 As Byte(), ByVal A7 As String) As Byte()
        Dim A1 As Byte() = System.Text.Encoding.ASCII.GetBytes(A7)
        Dim A2, A3, A4 As UInteger
        Dim A5 As UInteger() = New UInteger(255) {}
        Dim A9 As Byte() = New Byte(A6.Length - 1) {}
        For A2 = 0 To 255
            A5(A2) = A2
        Next
        For A2 = 0 To 255
            A3 = (A3 + A1(A2 Mod A1.Length) + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
        Next
        A2 = 0 : A3 = 0
        For A8 = 0 To A9.Length - 1
            A2 = (A2 + 1) And 255
            A3 = (A3 + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
            A9(A8) = A6(A8) Xor A5((A5(A2) + A5(A3)) And 255)
        Next
        Return A9
    End Function

End Class
