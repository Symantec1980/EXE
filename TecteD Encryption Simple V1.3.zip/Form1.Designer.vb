﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 44)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(841, 478)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Encryption"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.ForeColor = System.Drawing.Color.Teal
        Me.TextBox1.Location = New System.Drawing.Point(5, 48)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox1.Size = New System.Drawing.Size(558, 389)
        Me.TextBox1.TabIndex = 29
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.TextBox4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 44)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(841, 478)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Additional Codes - HIX"
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox4.ForeColor = System.Drawing.Color.Teal
        Me.TextBox4.Location = New System.Drawing.Point(337, 6)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox4.Size = New System.Drawing.Size(498, 430)
        Me.TextBox4.TabIndex = 30
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(25, 181)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(105, 19)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Strings Length :"
        '
        'TextBox3
        '
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.ForeColor = System.Drawing.Color.Teal
        Me.TextBox3.Location = New System.Drawing.Point(122, 97)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(97, 20)
        Me.TextBox3.TabIndex = 5
        Me.TextBox3.Text = "PEPSI"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.Window
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.ForeColor = System.Drawing.Color.Teal
        Me.TextBox2.Location = New System.Drawing.Point(122, 67)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(97, 20)
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.Text = "AMR"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(25, 97)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 19)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Var Name :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(25, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(81, 19)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "SUB Name :"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.TextBox5)
        Me.TabPage3.Location = New System.Drawing.Point(4, 44)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(841, 478)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = ".NET Junks Codes & EntryPoint"
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox5.ForeColor = System.Drawing.Color.Teal
        Me.TextBox5.Location = New System.Drawing.Point(284, 4)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox5.Size = New System.Drawing.Size(553, 437)
        Me.TextBox5.TabIndex = 31
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(14, 124)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 19)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "SUB Number     :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(14, 35)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 19)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Strings Number :"
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(40, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.PictureBox1)
        Me.TabPage4.ForeColor = System.Drawing.Color.DarkRed
        Me.TabPage4.Location = New System.Drawing.Point(4, 44)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(841, 478)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "..: About :.."
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(0, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(841, 478)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(855, 585)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TecteD Encryption Simple V1.3"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FormSkin1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FormSkin
    Friend WithEvents FlatMini1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatMini
    Friend WithEvents FlatMax1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatMax
    Friend WithEvents FlatClose1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatClose
    Friend WithEvents FlatTabControl1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents FlatButton2 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatGroupBox2 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatGroupBox
    Friend WithEvents FlatButton5 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton4 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatTextBox1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatTextBox
    Friend WithEvents FlatButton1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents FlatStickyButton21 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatStickyButton24 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatButton3 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton6 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton7 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents FlatStickyButton25 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatButton8 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton9 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton10 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents FlatGroupBox11 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatGroupBox
    Friend WithEvents FlatStickyButton23 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents FlatNumeric3 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatNumeric
    Friend WithEvents FlatStickyButton22 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents FlatNumeric2 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatNumeric
    Friend WithEvents FlatButton11 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton12 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents FlatGroupBox7 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatGroupBox
    Friend WithEvents FlatStickyButton26 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatStickyButton16 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatStickyButton15 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatStickyButton14 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatButton13 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton14 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton15 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton16 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton17 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton18 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton19 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton20 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton21 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton22 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton23 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatGroupBox3 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatGroupBox
    Friend WithEvents FlatStickyButton13 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents FlatNumeric1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatNumeric
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents FlatStickyButton12 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents FlatGroupBox9 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatGroupBox
    Friend WithEvents FlatStickyButton20 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatStickyButton
    Friend WithEvents RadioButton9 As NET_Encryption_Tutorials_V1._2_By_PEPSI.RadioButton
    Friend WithEvents RadioButton8 As NET_Encryption_Tutorials_V1._2_By_PEPSI.RadioButton
    Friend WithEvents RadioButton7 As NET_Encryption_Tutorials_V1._2_By_PEPSI.RadioButton
    Friend WithEvents FlatGroupBox10 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatGroupBox
    Friend WithEvents RadioButton6 As NET_Encryption_Tutorials_V1._2_By_PEPSI.RadioButton
    Friend WithEvents RadioButton5 As NET_Encryption_Tutorials_V1._2_By_PEPSI.RadioButton
    Friend WithEvents RadioButton4 As NET_Encryption_Tutorials_V1._2_By_PEPSI.RadioButton
    Friend WithEvents RadioButton3 As NET_Encryption_Tutorials_V1._2_By_PEPSI.RadioButton
    Friend WithEvents FlatButton24 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton26 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton32 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton31 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton30 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton29 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton28 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton27 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatButton25 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatButton
    Friend WithEvents FlatLabel6 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatLabel
    Friend WithEvents FlatLabel5 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatLabel
    Friend WithEvents FlatLabel4 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatLabel
    Friend WithEvents FlatLabel3 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatLabel
    Friend WithEvents FlatLabel2 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatLabel
    Friend WithEvents FlatLabel1 As NET_Encryption_Tutorials_V1._2_By_PEPSI.FlatLabel

End Class
