﻿'--------------------- [ Source ] --------------------
'Creator: F.R.sesin 
'Twitter: Twitter.com/FRsesin   
'Contact: F.R.sesin@googlemail.com
'Created: 2012
'Changed: 2013
'Released: 2013
'-------------------- [ /Source ] ---------------------


Imports System.Security.Cryptography
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.IO
Imports System.IO.Compression

Public Class Form1
  

    Public Shared Function Zip_G(ByVal text As String) As String
        Dim buffer As Byte() = System.Text.Encoding.Unicode.GetBytes(text)
        Dim ms As New MemoryStream()
        Using zip__1 As New System.IO.Compression.GZipStream(ms, System.IO.Compression.CompressionMode.Compress, True)
            zip__1.Write(buffer, 0, buffer.Length)
        End Using

        ms.Position = 0
        Dim outStream As New MemoryStream()

        Dim compressed As Byte() = New Byte(ms.Length - 1) {}
        ms.Read(compressed, 0, compressed.Length)

        Dim gzBuffer As Byte() = New Byte(compressed.Length + 3) {}
        System.Buffer.BlockCopy(compressed, 0, gzBuffer, 4, compressed.Length)
        System.Buffer.BlockCopy(BitConverter.GetBytes(buffer.Length), 0, gzBuffer, 0, 4)
        Return Convert.ToBase64String(gzBuffer)
    End Function

    Public Shared Function UnZip_G(ByVal compressedText As String) As String
        Dim gzBuffer As Byte() = Convert.FromBase64String(compressedText)
        Using ms As New MemoryStream()
            Dim msgLength As Integer = BitConverter.ToInt32(gzBuffer, 0)
            ms.Write(gzBuffer, 4, gzBuffer.Length - 4)

            Dim buffer As Byte() = New Byte(msgLength - 1) {}

            ms.Position = 0
            Using zip As New System.IO.Compression.GZipStream(ms, System.IO.Compression.CompressionMode.Decompress)
                zip.Read(buffer, 0, buffer.Length)
            End Using

            Return System.Text.Encoding.Unicode.GetString(buffer, 0, buffer.Length)
        End Using
    End Function


    Public Shared Function Zip_deflate(ByVal text As String) As String
        Dim buffer As Byte() = System.Text.Encoding.Unicode.GetBytes(text)
        Dim ms As New MemoryStream()
        Using zip__1 As New System.IO.Compression.DeflateStream(ms, System.IO.Compression.CompressionMode.Compress, True)
            zip__1.Write(buffer, 0, buffer.Length)
        End Using

        ms.Position = 0
        Dim outStream As New MemoryStream()

        Dim compressed As Byte() = New Byte(ms.Length - 1) {}
        ms.Read(compressed, 0, compressed.Length)

        Dim gzBuffer As Byte() = New Byte(compressed.Length + 3) {}
        System.Buffer.BlockCopy(compressed, 0, gzBuffer, 4, compressed.Length)
        System.Buffer.BlockCopy(BitConverter.GetBytes(buffer.Length), 0, gzBuffer, 0, 4)
        Return Convert.ToBase64String(gzBuffer)
    End Function

    Public Shared Function UnZip_deflate(ByVal compressedText As String) As String
        Dim gzBuffer As Byte() = Convert.FromBase64String(compressedText)
        Using ms As New MemoryStream()
            Dim msgLength As Integer = BitConverter.ToInt32(gzBuffer, 0)
            ms.Write(gzBuffer, 4, gzBuffer.Length - 4)

            Dim buffer As Byte() = New Byte(msgLength - 1) {}

            ms.Position = 0
            Using zip As New System.IO.Compression.DeflateStream(ms, System.IO.Compression.CompressionMode.Decompress)
                zip.Read(buffer, 0, buffer.Length)
            End Using

            Return System.Text.Encoding.Unicode.GetString(buffer, 0, buffer.Length)
        End Using
    End Function



    Function DecryptString_1(ByVal Text As String) As String
        Dim DecryptedString As String
        Dim CharFound As Integer
        Dim DecryptedChar As Integer

        DecryptedString = ""

        For N = 1 To Len(Text)
            CharFound = SearchChar(Mid(Text, N, 1))
            If CharFound >= 20 Then
                DecryptedChar = CharFound - 20
            Else
                DecryptedChar = CharFound + 236
            End If
            DecryptedString = DecryptedString & Chr(DecryptedChar)
        Next N

        Return DecryptedString
    End Function



    Function CryptString_1(ByVal Text As String) As String
        Dim CryptedString As String
        Dim CharFound As Integer
        Dim CryptedChar As Integer

        CryptedString = ""

        For N = 1 To Len(Text)
            CharFound = SearchChar(Mid(Text, N, 1))
            If CharFound <= 235 Then
                CryptedChar = CharFound + 20
            Else
                CryptedChar = CharFound - 236
            End If
            CryptedString = CryptedString & Chr(CryptedChar)
        Next N

        Return CryptedString
    End Function

    Function SearchChar(ByVal Character As String) As Integer
        For I = 0 To 255
            If Chr(I) = Character Then
                Return I
            End If
        Next I
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Private Shared Function converttoline(ByVal text_to_convert As String) As String
        Dim str2 As String = text_to_convert
        If str2.Contains("|") Then
            Return str2.Replace(" || ", "0").Replace(" | ", "1")
        End If
        Return str2.Replace("0", " || ").Replace("1", " | ")
    End Function

    Public Shared Function Decrypt_CustomLine(ByVal Text_to_Decrypt As String) As String
        Dim str2 As String = Text_to_Decrypt
        str2 = converttoline(str2)
        Dim str As String = Regex.Replace(str2, "[^01]", "")
        Dim bytes As Byte() = New Byte((CInt(Math.Round(CDbl(((CDbl(str.Length) / 8) - 1)))) + 1) - 1) {}
        Dim num2 As Integer = (bytes.Length - 1)
        Dim i As Integer = 0
        Do While (i <= num2)
            bytes(i) = Convert.ToByte(str.Substring((i * 8), 8), 2)
            i += 1
        Loop
        Return Encoding.ASCII.GetString(bytes)
    End Function

    Public Shared Function Encrypt_CustomLine(ByVal text_to_Encrypt As String) As String
        Dim str2 As String = text_to_Encrypt
        Dim builder As New StringBuilder
        Dim num As Byte
        For Each num In Encoding.ASCII.GetBytes(text_to_Encrypt)
            builder.Append(Convert.ToString(num, 2).PadLeft(8, "0"c))
            builder.Append(" ")
        Next
        Return converttoline(builder.ToString.Substring(0, (builder.ToString.Length - 1)))
    End Function



    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Private Function ConvertToAscii(ByVal str As String) As String
        Dim chars As String = Regex.Replace(str, "[^01]", "")
        Dim arr((chars.Length / 8) - 1) As Byte
        For i As Integer = 0 To arr.Length - 1
            arr(i) = Convert.ToByte(chars.Substring(i * 8, 8), 2)
        Next
        Return ASCIIEncoding.ASCII.GetString(arr)
    End Function
    Private Function ConvertToBinary(ByVal str As String) As String
        Dim converted As New StringBuilder
        For Each b As Byte In ASCIIEncoding.ASCII.GetBytes(str)
            converted.Append(Convert.ToString(b, 2).PadLeft(8, "0"))
        Next
        Return converted.ToString()
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function String2Hex(ByVal input As String) As String
        Dim out As New System.Text.StringBuilder
        For Each c As String In input
            Dim temp As String = Hex(Asc(c))
            out.Append(temp & " ")
        Next
        Return out.ToString.Substring(0, out.Length - 1)
    End Function
    Public Function Hex2String(ByVal input As String) As String
        Dim out As New System.Text.StringBuilder
        Dim data As String() = Split(input, " ")
        For Each s As String In data
            out.Append(Chr("&H" & s))
        Next
        Return out.ToString
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function ReverseString(ByRef strToReverse As String) As String
        Dim result As String = ""
        For i As Integer = 0 To strToReverse.Length - 1
            result += strToReverse(strToReverse.Length - 1 - i)
        Next
        Return result
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////


    Public Function AES_Encrypt(ByVal input As String, ByVal pass As String) As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateEncryptor

            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
        End Try
    End Function

    Public Function AES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
        End Try
    End Function
    
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function DES_Encrypt(ByVal input As String, ByVal pass As String) As String
        Dim DES As New System.Security.Cryptography.DESCryptoServiceProvider
        Dim Hash_DES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(7) As Byte
            Dim temp As Byte() = Hash_DES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 8)
            DES.Key = hash
            DES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = DES.CreateEncryptor
            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
        End Try
    End Function
    Public Function DES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim DES As New System.Security.Cryptography.DESCryptoServiceProvider
        Dim Hash_DES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(7) As Byte
            Dim temp As Byte() = Hash_DES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 8)
            DES.Key = hash
            DES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = DES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
        End Try
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function CustomXOR_Encrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim Hash As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim XorHash As Byte() = Hash.ComputeHash(System.Text.Encoding.ASCII.GetBytes(pass))
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1
            Dim tmp As String = Hex(Asc(Input(i)) Xor XorHash(u))
            If tmp.Length = 1 Then tmp = "0" & tmp
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function
    Public Function CustomXOR_Decrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim Hash As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim XorHash As Byte() = Hash.ComputeHash(System.Text.Encoding.ASCII.GetBytes(pass))
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1 Step +2
            Dim tmp As String = Chr(("&H" & Input.Substring(i, 2)) Xor XorHash(u))
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function XOR_Encrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1
            Dim tmp As String = Hex(Asc(Input(i)) Xor Asc(pass(u)))
            If tmp.Length = 1 Then tmp = "0" & tmp
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function
    Public Function XOR_Decrypt(ByVal Input As String, ByVal pass As String) As String
        Dim out As New System.Text.StringBuilder
        Dim u As Integer
        For i As Integer = 0 To Input.Length - 1 Step +2
            Dim tmp As String = Chr(("&H" & Input.Substring(i, 2)) Xor Asc(pass(u)))
            out.Append(tmp)
            If u = pass.Length - 1 Then u = 0 Else u = u + 1
        Next
        Return out.ToString
    End Function



    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function RSA_Encrypt(ByVal Input As String) As String
        Dim cp As New Security.Cryptography.CspParameters
        cp.Flags = Security.Cryptography.CspProviderFlags.UseMachineKeyStore
        cp.KeyContainerName = "Keys"
        Dim RSA As New Security.Cryptography.RSACryptoServiceProvider(cp)

        Dim buffer As Byte() = System.Text.Encoding.UTF8.GetBytes(Input)
        Dim encrypted As Byte() = RSA.Encrypt(buffer, True)
        Return Convert.ToBase64String(encrypted)
    End Function
    Public Function RSA_Decrypt(ByVal Input As String) As String
        Dim cp As New Security.Cryptography.CspParameters
        cp.Flags = Security.Cryptography.CspProviderFlags.UseMachineKeyStore
        cp.KeyContainerName = "Keys"
        Dim RSA As New Security.Cryptography.RSACryptoServiceProvider(cp)
        Dim buffer As Byte() = Convert.FromBase64String(Input)
        Dim decrypted As Byte() = RSA.Decrypt(buffer, True)
        Return System.Text.Encoding.UTF8.GetString(decrypted)
    End Function


    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function Rot13(ByVal value As String) As String
        ' Could be stored as integers directly.
        Dim lowerA As Integer = Asc("a"c)
        Dim lowerZ As Integer = Asc("z"c)
        Dim lowerM As Integer = Asc("m"c)

        Dim upperA As Integer = Asc("A"c)
        Dim upperZ As Integer = Asc("Z"c)
        Dim upperM As Integer = Asc("M"c)

        ' Convert to character array.
        Dim array As Char() = value.ToCharArray

        ' Loop over string.
        Dim i As Integer
        For i = 0 To array.Length - 1

            ' Convert to integer.
            Dim number As Integer = Asc(array(i))

            ' Shift letters.
            If ((number >= lowerA) AndAlso (number <= lowerZ)) Then
                If (number > lowerM) Then
                    number -= 13
                Else
                    number += 13
                End If
            ElseIf ((number >= upperA) AndAlso (number <= upperZ)) Then
                If (number > upperM) Then
                    number -= 13
                Else
                    number += 13
                End If
            End If

            ' Convert to character.
            array(i) = Chr(number)
        Next i

        ' Return string.
        Return New String(array)
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function c_Encrypt(ByVal PlainText As String, ByVal Key As Integer) As String
        Dim PlainChar() As Char = PlainText.ToCharArray()
        Dim Ascii(PlainChar.Length) As Integer
        For Count As Integer = 0 To PlainChar.Length - 1
            Ascii(Count) = Asc(PlainChar(Count))
            If Ascii(Count) >= 65 And Ascii(Count) <= 90 Then
                Ascii(Count) = ((Ascii(Count) - 65 + Key) Mod 26) + 65
            ElseIf Ascii(Count) >= 97 And Ascii(Count) <= 122 Then
                Ascii(Count) = ((Ascii(Count) - 97 + Key) Mod 26) + 97
            End If
            PlainChar(Count) = Chr(Ascii(Count))
        Next
        Return PlainChar
    End Function
    Public Function c_Decrypt(ByVal CipherText As String, ByVal Key As Integer) As String
        Dim CipherChar() As Char = CipherText.ToCharArray()
        Dim Ascii(CipherChar.Length) As Integer

        For Count As Integer = 0 To CipherChar.Length - 1
            Ascii(Count) = Asc(CipherChar(Count))
            If Ascii(Count) >= 65 And Ascii(Count) <= 90 Then
                Ascii(Count) = ((Ascii(Count) - 65 - (Key Mod 26) + 26)) Mod 26 + 65
            ElseIf Ascii(Count) >= 97 And Ascii(Count) <= 122 Then
                Ascii(Count) = (((Ascii(Count) - 97 - (Key Mod 26) + 26)) Mod 26) + 97
            End If
            CipherChar(Count) = Chr(Ascii(Count))
        Next
        Return CipherChar
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function RIPEMD160Hash(ByVal input As String) As String
        Dim RIPEMD160 As New System.Security.Cryptography.RIPEMD160Managed
        Dim Data As Byte()
        Dim Result As Byte()
        Dim Res As String = ""
        Dim Tmp As String = ""
        Data = System.Text.Encoding.ASCII.GetBytes(input)
        Result = RIPEMD160.ComputeHash(Data)
        For i As Integer = 0 To Result.Length - 1
            Tmp = Hex(Result(i))
            If Len(Tmp) = 1 Then Tmp = "0" & Tmp
            Res += Tmp
        Next
        Return Res
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function SHA1Hash(ByVal input As String) As String
        Dim SHA1 As New System.Security.Cryptography.SHA1CryptoServiceProvider
        Dim Data As Byte()
        Dim Result As Byte()
        Dim Res As String = ""
        Dim Tmp As String = ""
        Data = System.Text.Encoding.ASCII.GetBytes(input)
        Result = SHA1.ComputeHash(Data)
        For i As Integer = 0 To Result.Length - 1
            Tmp = Hex(Result(i))
            If Len(Tmp) = 1 Then Tmp = "0" & Tmp
            Res += Tmp
        Next
        Return Res
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function SHA256Hash(ByVal input As String) As String
        Dim SHA256 As New System.Security.Cryptography.SHA256Managed
        Dim Data As Byte()
        Dim Result As Byte()
        Dim Res As String = ""
        Dim Tmp As String = ""
        Data = System.Text.Encoding.ASCII.GetBytes(input)
        Result = SHA256.ComputeHash(Data)
        For i As Integer = 0 To Result.Length - 1
            Tmp = Hex(Result(i))
            If Len(Tmp) = 1 Then Tmp = "0" & Tmp
            Res += Tmp
        Next
        Return Res
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function SHA348Hash(ByVal input As String) As String
        Dim SHA348 As New System.Security.Cryptography.SHA384Managed
        Dim Data As Byte()
        Dim Result As Byte()
        Dim Res As String = ""
        Dim Tmp As String = ""
        Data = System.Text.Encoding.ASCII.GetBytes(input)
        Result = SHA348.ComputeHash(Data)
        For i As Integer = 0 To Result.Length - 1
            Tmp = Hex(Result(i))
            If Len(Tmp) = 1 Then Tmp = "0" & Tmp
            Res += Tmp
        Next
        Return Res
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function SHA512Hash(ByVal input As String) As String
        Dim SHA512 As New System.Security.Cryptography.SHA512Managed
        Dim Data As Byte()
        Dim Result As Byte()
        Dim Res As String = ""
        Dim Tmp As String = ""
        Data = System.Text.Encoding.ASCII.GetBytes(input)
        Result = SHA512.ComputeHash(Data)
        For i As Integer = 0 To Result.Length - 1
            Tmp = Hex(Result(i))
            If Len(Tmp) = 1 Then Tmp = "0" & Tmp
            Res += Tmp
        Next
        Return Res
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function MD5Hash(ByVal input As String) As String
        Dim MD5 As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim Data As Byte()
        Dim Result As Byte()
        Dim Res As String = ""
        Dim Tmp As String = ""
        Data = System.Text.Encoding.ASCII.GetBytes(input)
        Result = MD5.ComputeHash(Data)
        For i As Integer = 0 To Result.Length - 1
            Tmp = Hex(Result(i))
            If Len(Tmp) = 1 Then Tmp = "0" & Tmp
            Res += Tmp
        Next
        Return Res
    End Function


    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function BASE64_Encode(ByVal input As String) As String
        Return Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes(input))
    End Function
    Public Function BASE64_Decode(ByVal input As String) As String
        Return System.Text.Encoding.ASCII.GetString(Convert.FromBase64String(input))
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function MEGAN35_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "3GHIJKLMNOPQRSTUb=cdefghijklmnopWXYZ/12+406789VaqrstuvwxyzABCDEF5"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function MEGAN35_Decode(ByVal input As String) As String
        Dim key As String = "3GHIJKLMNOPQRSTUb=cdefghijklmnopWXYZ/12+406789VaqrstuvwxyzABCDEF5"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Function ZONG22_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "ZKj9n+yf0wDVX1s/5YbdxSo=ILaUpPBCHg8uvNO4klm6iJGhQ7eFrWczAMEq3RTt2"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function ZONG22_Decode(ByVal input As String) As String
        Dim key As String = "ZKj9n+yf0wDVX1s/5YbdxSo=ILaUpPBCHg8uvNO4klm6iJGhQ7eFrWczAMEq3RTt2"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function TRIPO5_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "ghijopE+G78lmnIJQRXY=abcS/UVWdefABCs456tDqruvNOPwx2KLyz01M3Hk9ZFT"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function TRIPO5_Decode(ByVal input As String) As String
        Dim key As String = "ghijopE+G78lmnIJQRXY=abcS/UVWdefABCs456tDqruvNOPwx2KLyz01M3Hk9ZFT"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function TIGO3FX_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "FrsxyzA8VtuvwDEqWZ/1+4klm67=cBCa5Ybdef0g2hij9nopMNO3GHIRSTJKLPQUX"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function TIGO3FX_Decode(ByVal input As String) As String
        Dim key As String = "FrsxyzA8VtuvwDEqWZ/1+4klm67=cBCa5Ybdef0g2hij9nopMNO3GHIRSTJKLPQUX"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function FERON74_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "75XYTabcS/UVWdefADqr6RuvN8PBCsQtwx2KLyz+OM3Hk9ghi01ZFlmnjopE=GIJ4"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function FERON74_Decode(ByVal input As String) As String
        Dim key As String = "75XYTabcS/UVWdefADqr6RuvN8PBCsQtwx2KLyz+OM3Hk9ghi01ZFlmnjopE=GIJ4"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function


    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////


    Public Function ESAB46_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "ABCDqrs456tuvNOPwxyz012KLM3789=+QRSTUVWXYZabcdefghijklmnopEFGHIJ/"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function ESAB46_Decode(ByVal input As String) As String
        Dim key As String = "ABCDqrs456tuvNOPwxyz012KLM3789=+QRSTUVWXYZabcdefghijklmnopEFGHIJ/"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function GILA7_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "7ZSTJK+W=cVtBCasyf0gzA8uvwDEq3XH/1RMNOILPQU4klm65YbdeFrx2hij9nopG"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function GILA7_Decode(ByVal input As String) As String
        Dim key As String = "7ZSTJK+W=cVtBCasyf0gzA8uvwDEq3XH/1RMNOILPQU4klm65YbdeFrx2hij9nopG"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function HAZZ15_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "HNO4klm6ij9n+J2hyf0gzA8uvwDEq3X1Q7ZKeFrWcVTts/MRGYbdxSo=ILaUpPBC5"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function HAZZ15_Decode(ByVal input As String) As String
        Dim key As String = "HNO4klm6ij9n+J2hyf0gzA8uvwDEq3X1Q7ZKeFrWcVTts/MRGYbdxSo=ILaUpPBC5"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function

    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function Atom128_Encode(ByVal input As String) As String
        input = Uri.EscapeDataString(input)
        Dim key As String = "/128GhIoPQROSTeUbADfgHijKLM+n0pFWXY456xyzB7=39VaqrstJklmNuZvwcdEC"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs As Integer() = {0, 0, 0}
            For b As Integer = 0 To 2
                If i < input.Length Then chrs(b) = Asc(input(i))
                i += 1
            Next
            enc(0) = chrs(0) >> 2
            enc(1) = ((chrs(0) And 3) << 4) Or (chrs(1) >> 4)
            enc(2) = ((chrs(1) And 15) << 2) Or (chrs(2) >> 6)
            enc(3) = chrs(2) And 63
            If chrs(1) = 0 Then
                enc(2) = 64
                enc(3) = 64
            End If
            If chrs(2) = 0 Then
                enc(3) = 64
            End If
            For Each x As Integer In enc
                out.Append(key(x))
            Next
        Loop While i < input.Length
        Return out.ToString
    End Function
    Public Function Atom128_Decode(ByVal input As String) As String
        Dim key As String = "/128GhIoPQROSTeUbADfgHijKLM+n0pFWXY456xyzB7=39VaqrstJklmNuZvwcdEC"
        Dim out As New System.Text.StringBuilder
        Dim i As Integer
        Do
            Dim enc(3) As Integer
            Dim chrs() As Integer = {0, 0, 0}
            For b As Integer = 0 To 3
                enc(b) = key.IndexOf(input(i))
                i = i + 1
            Next
            chrs(0) = (enc(0) << 2) Or (enc(1) >> 4)
            chrs(1) = (enc(1) And 15) << 4 Or (enc(2) >> 2)
            chrs(2) = (enc(2) And 3) << 6 Or enc(3)
            out.Append(Chr(chrs(0)))
            If enc(2) <> 64 Then out.Append(Chr(chrs(1)))
            If enc(3) <> 64 Then out.Append(Chr(chrs(2)))
        Loop While i < input.Length
        Return out.ToString
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function RC2Encrypt(ByVal strInput As String, ByVal strPassword As String) As String
        Dim RC2 As New System.Security.Cryptography.RC2CryptoServiceProvider
        Dim HashRC2 As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim strEncrypted As String = ""
        Try
            Dim Hash() As Byte = HashRC2.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(strPassword))

            RC2.Key = Hash
            RC2.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = RC2.CreateEncryptor
            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(strInput)
            strEncrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return strEncrypted
        Catch ex As Exception
        End Try
    End Function

    Public Function RC2Decrypt(ByVal strInput As String, ByVal strPassword As String) As String
        Dim RC2 As New System.Security.Cryptography.RC2CryptoServiceProvider
        Dim HashRC2 As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim strDecrypted As String = ""
        Try
            Dim Hash() As Byte = HashRC2.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(strPassword))
            RC2.Key = Hash
            RC2.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = RC2.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(strInput)
            strDecrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return strDecrypted
        Catch ex As Exception
        End Try
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Shared Function rc4(ByVal message As String, ByVal password As String) As String

        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim cipher As New StringBuilder
        Dim returnCipher As String = String.Empty

        Dim sbox As Integer() = New Integer(256) {}
        Dim key As Integer() = New Integer(256) {}

        Dim intLength As Integer = password.Length

        Dim a As Integer = 0
        While a <= 255

            Dim ctmp As Char = (password.Substring((a Mod intLength), 1).ToCharArray()(0))

            key(a) = Microsoft.VisualBasic.Strings.Asc(ctmp)
            sbox(a) = a
            System.Math.Max(System.Threading.Interlocked.Increment(a), a - 1)
        End While

        Dim x As Integer = 0

        Dim b As Integer = 0
        While b <= 255
            x = (x + sbox(b) + key(b)) Mod 256
            Dim tempSwap As Integer = sbox(b)
            sbox(b) = sbox(x)
            sbox(x) = tempSwap
            System.Math.Max(System.Threading.Interlocked.Increment(b), b - 1)
        End While

        a = 1

        While a <= message.Length

            Dim itmp As Integer = 0

            i = (i + 1) Mod 256
            j = (j + sbox(i)) Mod 256
            itmp = sbox(i)
            sbox(i) = sbox(j)
            sbox(j) = itmp

            Dim k As Integer = sbox((sbox(i) + sbox(j)) Mod 256)

            Dim ctmp As Char = message.Substring(a - 1, 1).ToCharArray()(0)

            itmp = Asc(ctmp)

            Dim cipherby As Integer = itmp Xor k

            cipher.Append(Chr(cipherby))
            System.Math.Max(System.Threading.Interlocked.Increment(a), a - 1)
        End While

        returnCipher = cipher.ToString
        cipher.Length = 0

        Return returnCipher

    End Function


    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Public Function TripleDES_Encrypt(ByVal input As String, ByVal pass As String) As String
        Dim TripleDES As New System.Security.Cryptography.TripleDESCryptoServiceProvider
        Dim Hash_TripleDES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(23) As Byte
            Dim temp As Byte() = Hash_TripleDES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 8)
            TripleDES.Key = hash
            TripleDES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESEncrypter As System.Security.Cryptography.ICryptoTransform = TripleDES.CreateEncryptor
            Dim Buffer As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return encrypted
        Catch ex As Exception
        End Try
    End Function
    Public Function TripleDES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim TripleDES As New System.Security.Cryptography.TripleDESCryptoServiceProvider
        Dim Hash_TripleDES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(23) As Byte
            Dim temp As Byte() = Hash_TripleDES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 8)
            TripleDES.Key = hash
            TripleDES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = TripleDES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
        End Try
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////

    Dim EncryptionKey As String

    Public Function Encrypt1(ByVal message As String) As String
        Dim Key As String = ReactorTextBox1.Text
        message = x(message, Key)
        Dim random As New Random()
        Dim list1 As New ArrayList(), list2 As New ArrayList()
        Dim out As String = ""
        Dim num1 As Integer = random.[Next](1, 10255)
        For i As Integer = 0 To message.Length - 1
            Dim num2 As Integer = random.[Next](num1) '(&H7A) + &H44
            list1.Add(Convert.ToInt32(message(i)) + num2)
            list2.Add(num2)
        Next
        For j As Integer = 0 To message.Length - 1
            out += ChrW(list1(j)) & ChrW(list2(j))
        Next

        Return out
    End Function

    Public Function Decrypt1(ByVal message As String) As String
        Dim Key As String = ReactorTextBox1.Text
        Dim numArray As Integer() = New Integer(message.Length - 1) {}
        Dim temp As String = ""

        For i As Integer = 0 To message.Length - 1
            numArray(i) = Convert.ToInt32(message(i))
        Next

        For j As Integer = 0 To message.Length - 1 Step 2
            Dim num3 As Integer = numArray(j)
            Dim num4 As Integer = numArray(j + 1)
            Dim num5 As Integer = num3 - num4
            temp = temp + ChrW(num5)
        Next
        Return x(temp, Key)
    End Function

    Private Function x(ByVal nGeeKnK As String, ByVal eKieBrN As String) As String
        Dim oHgeIrT As Integer = 0
        Dim rErnEoE As Integer = 0
        Dim rEeiRfF As New StringBuilder
        Dim nJrnJgL As String = String.Empty
        Dim bIjeGnR As Integer() = New Integer(256) {}
        Dim nBjvRbE As Integer() = New Integer(256) {}
        Dim gEgeGnE As Integer = eKieBrN.Length
        Dim fBjeEgE As Integer = 0
        While fBjeEgE <= 255
            Dim fGrjEnG As Char = (eKieBrN.Substring((fBjeEgE Mod gEgeGnE), 1).ToCharArray()(0))
            nBjvRbE(fBjeEgE) = Microsoft.VisualBasic.Strings.Asc(fGrjEnG)
            bIjeGnR(fBjeEgE) = fBjeEgE
            System.Math.Max(System.Threading.Interlocked.Increment(fBjeEgE), fBjeEgE - 1)
        End While
        Dim vHbrDnG As Integer = 0
        Dim jPkkXjV As Integer = 0
        While jPkkXjV <= 255
            vHbrDnG = (vHbrDnG + bIjeGnR(jPkkXjV) + nBjvRbE(jPkkXjV)) Mod 256
            Dim nCokVrH As Integer = bIjeGnR(jPkkXjV)
            bIjeGnR(jPkkXjV) = bIjeGnR(vHbrDnG)
            bIjeGnR(vHbrDnG) = nCokVrH
            System.Math.Max(System.Threading.Interlocked.Increment(jPkkXjV), jPkkXjV - 1)
        End While
        fBjeEgE = 1
        While fBjeEgE <= nGeeKnK.Length
            Dim rErrTnE As Integer = 0
            oHgeIrT = (oHgeIrT + 1) Mod 256
            rErnEoE = (rErnEoE + bIjeGnR(oHgeIrT)) Mod 256
            rErrTnE = bIjeGnR(oHgeIrT)
            bIjeGnR(oHgeIrT) = bIjeGnR(rErnEoE)
            bIjeGnR(rErnEoE) = rErrTnE
            Dim rHgeHgH As Integer = bIjeGnR((bIjeGnR(oHgeIrT) + bIjeGnR(rErnEoE)) Mod 256)
            Dim fGrjEnG As Char = nGeeKnK.Substring(fBjeEgE - 1, 1).ToCharArray()(0)
            rErrTnE = Asc(fGrjEnG)
            Dim vRbTKeR As Integer = rErrTnE Xor rHgeHgH
            rEeiRfF.Append(Chr(vRbTKeR))
            System.Math.Max(System.Threading.Interlocked.Increment(fBjeEgE), fBjeEgE - 1)
        End While
        nJrnJgL = rEeiRfF.ToString
        rEeiRfF.Length = 0
        Return nJrnJgL
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Shared Function Crypt(ByVal Data As String, ByVal key As String) As String
        Return Encoding.Default.GetString(Crypt(Encoding.Default.GetBytes(Data), Encoding.Default.GetBytes(key)))
    End Function
    Public Shared Function Crypt(ByVal Data() As Byte, ByVal key() As Byte) As Byte()
        For i = 0 To (Data.Length * 2) + key.Length
            Data(i Mod Data.Length) = CByte(CInt((Data(i Mod Data.Length)) + CInt(Data((i + 1) Mod Data.Length))) Mod 256) Xor key(i Mod key.Length)
        Next
        Return Data
    End Function
    Public Shared Function DeCrypt(ByVal Data As String, ByVal key As String) As String
        Return Encoding.Default.GetString(DeCrypt(Encoding.Default.GetBytes(Data), Encoding.Default.GetBytes(key)))
    End Function
    Public Shared Function DeCrypt(ByVal Data() As Byte, ByVal key() As Byte) As Byte()
        For i = (Data.Length * 2) + key.Length To 0 Step -1
            Data(i Mod Data.Length) = CByte((CInt(Data(i Mod Data.Length) Xor key(i Mod key.Length)) - CInt(Data((i + 1) Mod Data.Length)) + 256) Mod 256)
        Next
        Return Data
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Overloads Shared Function PolyCrypt(ByVal Data As String, ByVal Key As String, Optional ByVal ExtraRounds As UInteger = 0) As String
        Dim buff() As Byte = PolyCrypt(Encoding.Default.GetBytes(Data), Encoding.Default.GetBytes(Key), ExtraRounds)
        PolyCrypt = Encoding.Default.GetString(buff)
        Erase buff
    End Function
    Overloads Shared Function PolyDeCrypt(ByVal Data As String, ByVal Key As String, Optional ByVal ExtraRounds As UInteger = 0) As String
        Dim buff() As Byte = PolyDeCrypt(Encoding.Default.GetBytes(Data), Encoding.Default.GetBytes(Key), ExtraRounds)
        PolyDeCrypt = Encoding.Default.GetString(buff)
        Erase buff
    End Function
    Overloads Shared Function PolyCrypt(ByRef Data() As Byte, ByVal Key() As Byte, Optional ByVal ExtraRounds As UInteger = 0) As Byte()
        Array.Resize(Data, Data.Length + 1)
        Data(Data.Length - 1) = Convert.ToByte(New Random().Next(1, 255))
        For i = (Data.Length - 1) * (ExtraRounds + 1) To 0 Step -1
            Data(i Mod Data.Length) = CByte(CInt((Data(i Mod Data.Length)) + CInt(Data((i + 1) Mod Data.Length))) Mod 256) Xor Key(i Mod Key.Length)
        Next
        Return Data
    End Function
    Overloads Shared Function PolyDeCrypt(ByRef Data() As Byte, ByVal Key() As Byte, Optional ByVal ExtraRounds As UInteger = 0) As Byte()
        For i = 0 To (Data.Length - 1) * (ExtraRounds + 1)
            Data(i Mod Data.Length) = CByte((CInt(Data(i Mod Data.Length) Xor Key(i Mod Key.Length)) - CInt(Data((i + 1) Mod Data.Length)) + 256) Mod 256)
        Next
        Array.Resize(Data, Data.Length - 1)
        Return Data
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Public Shared Function Rijndaelcrypt(ByVal File As String, ByVal Key As String)
        Dim oAesProvider As New RijndaelManaged
        Dim btClear() As Byte
        Dim btSalt() As Byte = New Byte() {1, 2, 3, 4, 5, 6, 7, 8}
        Dim oKeyGenerator As New Rfc2898DeriveBytes(Key, btSalt)
        oAesProvider.Key = oKeyGenerator.GetBytes(oAesProvider.Key.Length)
        oAesProvider.IV = oKeyGenerator.GetBytes(oAesProvider.IV.Length)
        Dim ms As New IO.MemoryStream
        Dim cs As New CryptoStream(ms, _
          oAesProvider.CreateEncryptor(), _
          CryptoStreamMode.Write)
        btClear = System.Text.Encoding.UTF8.GetBytes(File)
        cs.Write(btClear, 0, btClear.Length)
        cs.Close()
        File = Convert.ToBase64String(ms.ToArray)
        Return File
    End Function

    Public Shared Function RijndaelDecrypt(ByVal UDecryptU As String, ByVal UKeyU As String)
        Dim XoAesProviderX As New RijndaelManaged
        Dim XbtCipherX() As Byte
        Dim XbtSaltX() As Byte = New Byte() {1, 2, 3, 4, 5, 6, 7, 8}
        Dim XoKeyGeneratorX As New Rfc2898DeriveBytes(UKeyU, XbtSaltX)
        XoAesProviderX.Key = XoKeyGeneratorX.GetBytes(XoAesProviderX.Key.Length)
        XoAesProviderX.IV = XoKeyGeneratorX.GetBytes(XoAesProviderX.IV.Length)
        Dim XmsX As New IO.MemoryStream
        Dim XcsX As New CryptoStream(XmsX, XoAesProviderX.CreateDecryptor(), _
          CryptoStreamMode.Write)
        Try
            XbtCipherX = Convert.FromBase64String(UDecryptU)
            XcsX.Write(XbtCipherX, 0, XbtCipherX.Length)
            XcsX.Close()
            UDecryptU = System.Text.Encoding.UTF8.GetString(XmsX.ToArray)
        Catch
        End Try
        Return UDecryptU
    End Function
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    '/////////////////////////////////////////////////////////
    Private Sub ReactorMultiLineTextBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReactorMultiLineTextBox1.Click

    End Sub

    Dim WC As New System.Net.WebClient
    Dim k1 As String = "http://www.md5decrypter.co.uk/"

    Dim k2 As String = "http://www.md5decrypter.co.uk/sha1-decrypt.aspx"
    Private Sub ReactorButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReactorButton1.Click
        Try
            If ReactorComboBox1.SelectedItem = "Rinjandel" Then
                ReactorMultiLineTextBox1.Text = Rijndaelcrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Polymorphic Stairs" Then
                ReactorMultiLineTextBox1.Text = PolyCrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Stairs" Then
                ReactorMultiLineTextBox1.Text = Crypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Polymorphic RC4" Then
                ReactorMultiLineTextBox1.Text = Encrypt1(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "3DES" Then
                ReactorMultiLineTextBox1.Text = EncryptString(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)


            ElseIf ReactorComboBox1.SelectedItem = "RC4" Then
                ReactorMultiLineTextBox1.Text = rc4(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "RC2" Then
                ReactorMultiLineTextBox1.Text = RC2Encrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "ATOM-128" Then
                ReactorMultiLineTextBox1.Text = Atom128_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "HAZZ-15" Then
                ReactorMultiLineTextBox1.Text = HAZZ15_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "GILA7" Then
                ReactorMultiLineTextBox1.Text = GILA7_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "ESAB-46" Then
                ReactorMultiLineTextBox1.Text = ESAB46_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "MEGAN-35" Then
                ReactorMultiLineTextBox1.Text = MEGAN35_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "ZONG-22" Then
                ReactorMultiLineTextBox1.Text = ZONG22_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "TRIPO-5" Then
                ReactorMultiLineTextBox1.Text = TRIPO5_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "TIGO-3FX" Then
                ReactorMultiLineTextBox1.Text = TIGO3FX_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "FERON-74" Then
                ReactorMultiLineTextBox1.Text = FERON74_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Base64" Then
                ReactorMultiLineTextBox1.Text = BASE64_Encode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "MD5" Then
                ReactorMultiLineTextBox1.Text = MD5Hash(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "RIPEMD-160" Then
                ReactorMultiLineTextBox1.Text = RIPEMD160Hash(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-1" Then
                ReactorMultiLineTextBox1.Text = SHA1Hash(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-256" Then
                ReactorMultiLineTextBox1.Text = SHA256Hash(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-348" Then
                ReactorMultiLineTextBox1.Text = SHA348Hash(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-512" Then
                ReactorMultiLineTextBox1.Text = SHA512Hash(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Caesar Cipher" Then
                If IsNumeric(ReactorTextBox1.Text) Then

                    ReactorMultiLineTextBox1.Text = c_Encrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
                Else
                    MsgBox("The secret key of this algorithm must be numeric!", MsgBoxStyle.Exclamation)

                End If
            ElseIf ReactorComboBox1.SelectedItem = "ROT-13" Then
                ReactorMultiLineTextBox1.Text = Rot13(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "RSA" Then
                ReactorMultiLineTextBox1.Text = RSA_Encrypt(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "XOR" Then
                ReactorMultiLineTextBox1.Text = XOR_Encrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "CustomXOR" Then
                ReactorMultiLineTextBox1.Text = CustomXOR_Encrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "DES" Then
                ReactorMultiLineTextBox1.Text = DES_Encrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "AES" Then
                ReactorMultiLineTextBox1.Text = AES_Encrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Reverse" Then
                ReactorMultiLineTextBox1.Text = ReverseString(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "HEX" Then
                ReactorMultiLineTextBox1.Text = String2Hex(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Binary" Then
                ReactorMultiLineTextBox1.Text = ConvertToBinary(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Custom_Line" Then
                ReactorMultiLineTextBox1.Text = Encrypt_CustomLine(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "~Draven's Algorithm" Then
                ReactorMultiLineTextBox1.Text = CryptString_1(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "UpperCase" Then
                ReactorMultiLineTextBox1.Text = ReactorMultiLineTextBox1.Text.ToUpper
            ElseIf ReactorComboBox1.SelectedItem = "LowerCase" Then
                ReactorMultiLineTextBox1.Text = ReactorMultiLineTextBox1.Text.ToLower
            ElseIf ReactorComboBox1.SelectedItem = "Compression(Deflate)" Then
                ReactorMultiLineTextBox1.Text = Zip_deflate(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Compression(GZip)" Then
                ReactorMultiLineTextBox1.Text = Zip_G(ReactorMultiLineTextBox1.Text)
            End If


        Catch Ex As Exception
            MsgBox(Err.Description)
        End Try

    End Sub


    Private Sub ReactorButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReactorButton2.Click
        Try
            If ReactorComboBox1.SelectedItem = "Rinjandel" Then
                ReactorMultiLineTextBox1.Text = RijndaelDecrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Polymorphic Stairs" Then
                ReactorMultiLineTextBox1.Text = PolyDeCrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Stairs" Then
                ReactorMultiLineTextBox1.Text = DeCrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Polymorphic RC4" Then
                ReactorMultiLineTextBox1.Text = Decrypt1(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "3DES" Then
                ReactorMultiLineTextBox1.Text = DecryptString(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "RC4" Then
                ReactorMultiLineTextBox1.Text = rc4(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "RC2" Then
                ReactorMultiLineTextBox1.Text = RC2Decrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "ATOM-128" Then
                Dim cost As String
                cost = Atom128_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost
            ElseIf ReactorComboBox1.SelectedItem = "HAZZ-15" Then
                Dim cost As String
                cost = HAZZ15_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost

            ElseIf ReactorComboBox1.SelectedItem = "GILA7" Then
                Dim cost As String
                cost = GILA7_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost


            ElseIf ReactorComboBox1.SelectedItem = "ESAB-46" Then
                Dim cost As String
                cost = ESAB46_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost

            ElseIf ReactorComboBox1.SelectedItem = "MEGAN-35" Then
                Dim cost As String
                cost = MEGAN35_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost

            ElseIf ReactorComboBox1.SelectedItem = "ZONG-22" Then
                Dim cost As String
                cost = ZONG22_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost

            ElseIf ReactorComboBox1.SelectedItem = "TRIPO-5" Then
                Dim cost As String
                cost = TRIPO5_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost

            ElseIf ReactorComboBox1.SelectedItem = "TIGO-3FX" Then
                Dim cost As String
                cost = TIGO3FX_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost

            ElseIf ReactorComboBox1.SelectedItem = "FERON-74" Then
                Dim cost As String
                cost = FERON74_Decode(ReactorMultiLineTextBox1.Text)
                cost = Replace(cost, "%20", " ")
                cost = Replace(cost, "%3F", "?")
                cost = Replace(cost, "%2C", ",")

                ReactorMultiLineTextBox1.Text = cost

            ElseIf ReactorComboBox1.SelectedItem = "Base64" Then
                ReactorMultiLineTextBox1.Text = BASE64_Decode(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "MD5" Then
                Form2.Show()
                Form2.WebBrowser1.Navigate(k1)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-1" Then
                Form2.Show()
                Form2.WebBrowser1.Navigate(k2)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-256" Then
                MsgBox("Feature not available", MsgBoxStyle.Information)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-348" Then
                MsgBox("Feature not available", MsgBoxStyle.Information)
            ElseIf ReactorComboBox1.SelectedItem = "SHA-512" Then
                MsgBox("Feature not available", MsgBoxStyle.Information)
            ElseIf ReactorComboBox1.SelectedItem = "RIPEMD-160" Then
                MsgBox("Feature not available", MsgBoxStyle.Information)
            ElseIf ReactorComboBox1.SelectedItem = "Caesar Cipher" Then
                ReactorMultiLineTextBox1.Text = c_Decrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "ROT-13" Then
                ReactorMultiLineTextBox1.Text = Rot13(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "RSA" Then
                ReactorMultiLineTextBox1.Text = RSA_Decrypt(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "XOR" Then
                ReactorMultiLineTextBox1.Text = XOR_Decrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "CustomXOR" Then
                ReactorMultiLineTextBox1.Text = CustomXOR_Decrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "DES" Then
                ReactorMultiLineTextBox1.Text = DES_Decrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "AES" Then
                ReactorMultiLineTextBox1.Text = AES_Decrypt(ReactorMultiLineTextBox1.Text, ReactorTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Reverse" Then
                ReactorMultiLineTextBox1.Text = ReverseString(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "HEX" Then
                ReactorMultiLineTextBox1.Text = Hex2String(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Binary" Then
                ReactorMultiLineTextBox1.Text = ConvertToAscii(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Custom_Line" Then
                ReactorMultiLineTextBox1.Text = Decrypt_CustomLine(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "~Draven's Algorithm" Then
                ReactorMultiLineTextBox1.Text = DecryptString_1(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Compression(Deflate)" Then
                ReactorMultiLineTextBox1.Text = UnZip_deflate(ReactorMultiLineTextBox1.Text)
            ElseIf ReactorComboBox1.SelectedItem = "Compression(GZip)" Then
                ReactorMultiLineTextBox1.Text = UnZip_G(ReactorMultiLineTextBox1.Text)
            End If

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try

    End Sub

    Private Sub ReactorTextBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReactorTextBox1.Click


    End Sub

    Private Sub ReactorTheme1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReactorTheme1.Click

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ReactorComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReactorComboBox1.SelectedIndexChanged
        Try
            If ReactorComboBox1.SelectedItem = "ATOM-128" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "HAZZ-15" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "GILA7" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "ESAB-46" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "MEGAN-35" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "ZONG-22" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "TRIPO-5" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "TIGO-3FX" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "FERON-74" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "Base64" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "MD5" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "RIPEMD-160" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "SHA-1" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "SHA-256" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "SHA-348" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "SHA-512" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "ROT-13" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "RSA" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "Reverse" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "HEX" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "Binary" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "Custom_Line" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "~Draven's Algorithm" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "UpperCase" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "LowerCase" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "Compression(GZip)" Then
                ReactorTextBox1.Enabled = False
            ElseIf ReactorComboBox1.SelectedItem = "Compression(Deflate)" Then
                ReactorTextBox1.Enabled = False
            Else
                ReactorTextBox1.Enabled = True
            End If
        Catch ex As Exception

        End Try



    End Sub

    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click

    End Sub

    

    Private Sub PictureBox4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox4.Click

    End Sub

    Private Sub PictureBox3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox3.Click
        ReactorTextBox1.Text = ""
        ReactorMultiLineTextBox1.Text = ""
        ReactorComboBox1.SelectedItem = "3DES"
    End Sub

    Private Sub PictureBox3_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox3.MouseLeave
        PictureBox4.Visible = True
    End Sub

    Private Sub PictureBox4_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox4.MouseEnter
        PictureBox4.Visible = False
    End Sub

    Private Sub PictureBox5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox5.Click

    End Sub

    Private Sub PictureBox5_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox5.MouseEnter
        PictureBox5.Visible = False
    End Sub

    Private Sub PictureBox6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox6.Click
        SaveFileDialog1.AddExtension = False
        SaveFileDialog1.InitialDirectory = "C:\"
        SaveFileDialog1.Title = "Crypt.net"
        SaveFileDialog1.FileName = "Crypt.NET_Text"
        SaveFileDialog1.Filter = "Text File(*.txt)|*.txt"
        If SaveFileDialog1.ShowDialog = Windows.Forms.DialogResult.OK Then
            My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, ReactorMultiLineTextBox1.Text, 0)

        End If
    End Sub

    Private Sub PictureBox6_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox6.MouseLeave
        PictureBox5.Visible = True
    End Sub

    Private Sub SaveFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk

    End Sub

    Private Sub PictureBox7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox7.Click

    End Sub

    Private Sub PictureBox7_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox7.MouseEnter
        PictureBox7.Visible = False

    End Sub

    Private Sub PictureBox8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox8.Click
        My.Computer.Clipboard.SetText(ReactorMultiLineTextBox1.Text)
    End Sub

    Private Sub PictureBox8_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox8.MouseLeave
        PictureBox7.Visible = True

    End Sub


    Private Sub PictureBox10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox10.Click
        Info.Show()
    End Sub

    Private Sub PictureBox9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox9.Click
        Process.Start("MettereLinkCrypt.net")
    End Sub

    Private Sub PictureBox9_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox9.MouseEnter
        PictureBox9.Visible = False
    End Sub

    Private Sub PictureBox10_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox10.MouseLeave
        PictureBox9.Visible = True
    End Sub

    Private Sub PictureBox11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox11.Click

    End Sub

    Private Sub PictureBox11_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox11.MouseEnter
        PictureBox11.Visible = False
    End Sub

    Private Sub PictureBox12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox12.Click
        End
    End Sub

    Private Sub PictureBox12_MouseLeave(ByVal sender As Object, ByVal e As System.EventArgs) Handles PictureBox12.MouseLeave
        PictureBox11.Visible = True
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("http://twitter.com/FRsesin")
    End Sub


 
    Public Shared Function EncryptString(ByVal Message As String, ByVal Passphrase As String) As String
        Dim Results() As Byte
        Dim UTF8 As System.Text.UTF8Encoding = New System.Text.UTF8Encoding
        ' Step 1. We hash the Passphrase using MD5
        ' We use the MD5 hash generator as the result is a 128 bit byte array
        ' which is a valid length for the TripleDES encoder we use below
        Using HashProvider As MD5CryptoServiceProvider = New MD5CryptoServiceProvider()
            Dim TDESKey() As Byte = HashProvider.ComputeHash(UTF8.GetBytes(Passphrase))

            ' Step 2. Create a new TripleDESCryptoServiceProvider object

            ' Step 3. Setup the encoder
            Using TDESAlgorithm As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider() With {.Key = TDESKey, .Mode = CipherMode.ECB, .Padding = PaddingMode.PKCS7}
                ' Step 4. Convert the input string to a byte[]

                Dim DataToEncrypt() As Byte = UTF8.GetBytes(Message)

                ' Step 5. Attempt to encrypt the string
                Try
                    Dim Encryptor As ICryptoTransform = TDESAlgorithm.CreateEncryptor
                    Results = Encryptor.TransformFinalBlock(DataToEncrypt, 0, DataToEncrypt.Length)
                Finally
                    ' Clear the TripleDes and Hashprovider services of any sensitive information
                    TDESAlgorithm.Clear()
                    HashProvider.Clear()
                End Try
            End Using
        End Using

        ' Step 6. Return the encrypted string as a base64 encoded string
        Return Convert.ToBase64String(Results)
    End Function

    Public Shared Function DecryptString(ByVal Message As String, ByVal Passphrase As String) As String
        Dim Results() As Byte
        Dim UTF8 As System.Text.UTF8Encoding = New System.Text.UTF8Encoding

        ' Step 1. We hash the Pass phrase using MD5
        ' We use the MD5 hash generator as the result is a 128 bit byte array
        ' which is a valid length for the TripleDES encoder we use below
        Using HashProvider As MD5CryptoServiceProvider = New MD5CryptoServiceProvider()
            Dim TDESKey() As Byte = HashProvider.ComputeHash(UTF8.GetBytes(Passphrase))

            ' Step 2. Create a new TripleDESCryptoServiceProvider object
            ' Step 3. Setup the decoder
            Using TDESAlgorithm As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider() With {.Key = TDESKey, .Mode = CipherMode.ECB, .Padding = PaddingMode.PKCS7}

                ' Step 4. Convert the input string to a byte[]
                Dim DataToDecrypt() As Byte = Convert.FromBase64String(Message)
                ' Step 5. Attempt to decrypt the string
                Try
                    Dim Decryptor As ICryptoTransform = TDESAlgorithm.CreateDecryptor
                    Results = Decryptor.TransformFinalBlock(DataToDecrypt, 0, DataToDecrypt.Length)
                Finally

                    ' Clear the TripleDes and Hash provider services of any sensitive information
                    TDESAlgorithm.Clear()
                    HashProvider.Clear()
                End Try
            End Using
        End Using

        ' Step 6. Return the decrypted string in UTF8 format
        Return UTF8.GetString(Results)
    End Function
    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try
            k1 = System.Text.Encoding.ASCII.GetString((WC.DownloadData("http://frserver.altervista.org/Crypt.NET/MD5.php")))
            k2 = System.Text.Encoding.ASCII.GetString((WC.DownloadData("http://frserver.altervista.org/Crypt.NET/SHA1.php")))

        Catch ex As Exception

        End Try

        ReactorComboBox1.SelectedIndex = 0
    End Sub
#Region "alpa"
    Private Shared f_key As UInteger()

    Public Sub a(ByVal password As String)
        f_key = FormatKey(password)
    End Sub

    Public Function Encrypt_xtea(ByVal input As String) As String
        If input.Length = 0 Then
            Throw New ArgumentException("Invalid input length!")
        End If

        If input.Length Mod 2 <> 0 Then
            input += ControlChars.NullChar
        End If

        Dim dataBytes As Byte() = System.Text.ASCIIEncoding.ASCII.GetBytes(input)

        Dim cipher As String = String.Empty
        Dim tempData As UInteger() = New UInteger(1) {}
        For i As Integer = 0 To dataBytes.Length - 1 Step 2
            tempData(0) = dataBytes(i)
            tempData(1) = dataBytes(i + 1)
            code(tempData, f_key)
            cipher += ConvertUIntToString(tempData(0)) + ConvertUIntToString(tempData(1))
        Next

        Return cipher
    End Function

    Public Function Decrypt_xtea(ByVal Data As String) As String
        Dim x As Integer = 0
        Dim tempData As UInteger() = New UInteger(1) {}
        Dim dataBytes As Byte() = New Byte((Data.Length \ 8) * 2 - 1) {}
        For i As Integer = 0 To Data.Length - 1 Step 8
            tempData(0) = ConvertStringToUInt(Data.Substring(i, 4))
            tempData(1) = ConvertStringToUInt(Data.Substring(i + 4, 4))
            decode(tempData, f_key)
            dataBytes(x) = CByte(tempData(0))
            x += 1
            dataBytes(x) = CByte(tempData(1))
            x += 1
        Next
        Dim decipheredString As String = System.Text.ASCIIEncoding.ASCII.GetString(dataBytes, 0, dataBytes.Length)
        If decipheredString(decipheredString.Length - 1) = ControlChars.NullChar Then
            decipheredString = decipheredString.Substring(0, decipheredString.Length - 1)
        End If
        Return decipheredString
    End Function

    Private Shared Function FormatKey(ByVal Key As String) As UInteger()
        If Key.Length <= 5 Then
            Throw New ArgumentException("Key must be between 6 and 16 characters in length")
        End If

        Key = Key.PadRight(16, " "c).Substring(0, 16)

        Dim formattedKey As UInteger() = New UInteger(4) {}

        Dim j As Integer = 0
        For i As Integer = 0 To Key.Length - 1 Step 4
            formattedKey(j) = ConvertStringToUInt(Key.Substring(i, 4))
            j += 1
        Next
        Return formattedKey
    End Function

    Private Shared Sub code(ByVal v As UInteger(), ByVal k As UInteger())
        Dim y As UInteger = v(0)
        Dim z As UInteger = v(1)
        Dim sum As UInteger = 0
        Dim delta As UInteger = &H9E3779B9UI

        For i = 0 To 31
            y += (z << 4 Xor z >> 5) + z Xor sum + k(sum And 3)
            sum += delta
            z += (y << 4 Xor y >> 5) + y Xor sum + k(sum >> 11 And 3)
        Next

        v(0) = y
        v(1) = z
    End Sub

    Private Shared Sub decode(ByVal v As UInteger(), ByVal k As UInteger())
        Dim y As UInteger = v(0)
        Dim z As UInteger = v(1)
        Dim sum As UInteger = &HC6EF3720UI
        Dim delta As UInteger = &H9E3779B9UI

        For i = 0 To 31
            z -= (y << 4 Xor y >> 5) + y Xor sum + k(sum >> 11 And 3)
            sum -= delta
            y -= (z << 4 Xor z >> 5) + z Xor sum + k(sum And 3)
        Next

        v(0) = y
        v(1) = z
    End Sub

    Private Shared Function ConvertStringToUInt(ByVal Input As String) As System.UInt32
        Dim output As UInt32
        output = Convert.ToUInt32(Input(0))
        output += (Convert.ToUInt32(Input(1)) << 8)
        output += (Convert.ToUInt32(Input(2)) << 16)
        output += (Convert.ToUInt32(Input(3)) << 24)
        Return output
    End Function
    Private Shared Function ConvertUIntToString(ByVal Input As System.UInt32) As String
        Dim output As New System.Text.StringBuilder()
        output.Append(Convert.ToChar(Input And &HFF))
        output.Append(Convert.ToChar((Input >> 8) And &HFF))
        output.Append(Convert.ToChar((Input >> 16) And &HFF))
        output.Append(Convert.ToChar((Input >> 24) And &HFF))
        Return output.ToString()
    End Function
#End Region



    Private Sub ReactorMultiLineTextBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ReactorMultiLineTextBox1.TextChanged
        Label3.Text = ReactorMultiLineTextBox1.Text.Length
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox2.Click
        Process.Start("http://twitter.com/FRsesin")
    End Sub
End Class
