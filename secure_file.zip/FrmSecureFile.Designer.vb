<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmSecureFile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmSecureFile))
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.CmdDecryption = New System.Windows.Forms.Button
        Me.CmdEncryption = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(0, 296)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(406, 59)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = resources.GetString("Label1.Text")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(83, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(250, 20)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Encrypt any file with password"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(0, 189)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(422, 24)
        Me.Label3.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Location = New System.Drawing.Point(1, 2)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(417, 188)
        Me.Label4.TabIndex = 5
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.BackColor = System.Drawing.Color.Black
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Gainsboro
        Me.LinkLabel1.Location = New System.Drawing.Point(99, 191)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(199, 13)
        Me.LinkLabel1.TabIndex = 6
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "http://www.programmer2programmer.net"
        '
        'CmdDecryption
        '
        Me.CmdDecryption.BackgroundImage = Global.secure_file.My.Resources.Resources.dec
        Me.CmdDecryption.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdDecryption.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CmdDecryption.Location = New System.Drawing.Point(227, 64)
        Me.CmdDecryption.Name = "CmdDecryption"
        Me.CmdDecryption.Size = New System.Drawing.Size(169, 60)
        Me.CmdDecryption.TabIndex = 2
        Me.CmdDecryption.UseVisualStyleBackColor = True
        '
        'CmdEncryption
        '
        Me.CmdEncryption.BackgroundImage = Global.secure_file.My.Resources.Resources.enc
        Me.CmdEncryption.Cursor = System.Windows.Forms.Cursors.Hand
        Me.CmdEncryption.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.CmdEncryption.Location = New System.Drawing.Point(13, 64)
        Me.CmdEncryption.Name = "CmdEncryption"
        Me.CmdEncryption.Size = New System.Drawing.Size(169, 60)
        Me.CmdEncryption.TabIndex = 1
        Me.CmdEncryption.UseVisualStyleBackColor = True
        '
        'FrmSecureFile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(418, 207)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.CmdDecryption)
        Me.Controls.Add(Me.CmdEncryption)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "FrmSecureFile"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Secure File"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CmdEncryption As System.Windows.Forms.Button
    Friend WithEvents CmdDecryption As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel

End Class
