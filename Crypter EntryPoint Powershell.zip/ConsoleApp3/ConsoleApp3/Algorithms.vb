﻿Public Class Algorithms

    Function Bs64(ByVal bytes As Byte()) As String
        Return Convert.ToBase64String(bytes)
    End Function
End Class
