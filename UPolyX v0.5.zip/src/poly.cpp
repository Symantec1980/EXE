#include <windows.h>
#include <stdio.h>
#include <time.h>

#define RegEax 0
#define RegEcx 1
#define RegEdx 2
#define RegEbx 3
#define RegEsp 4
#define RegEbp 5
#define RegEsi 6
#define RegEdi 7



void StackFrame(BYTE  buf[],int &pos){
   //55              PUSH EBP
   //8BEC            MOV EBP,ESP
	BYTE stack[]="\x55\x8b\xec";
	memcpy(buf+pos,stack,3);
	pos+=3;

}



void AddToRegOneByte(BYTE  buf[],int Reg,int value,int &pos){
	
	
		// 8000 01         ADD BYTE PTR DS:[EAX],1
		BYTE add[]="\x80\x00\x00";
		add[1]=add[1]+Reg;
		add[2]=add[2]+value;
		memcpy(buf+pos,add,3);	
		pos+=3;
	
	


}



void AddToReg(BYTE  buf[],int Reg,int value,int &pos){
	int switchme=rand()%4;
	
	
	if(switchme==0||Reg==RegEcx){

		BYTE add[]="\x83\xc0\x00";
		add[1]=add[1]+Reg;
		add[2]=add[2]+value;
		memcpy(buf+pos,add,3);	
		pos+=3;
	}

	else  if(switchme==1){
		/*0043F852      51            PUSH ECX
		0043F853      2BC9          SUB ECX,ECX
		0043F855      B9 04000000   MOV ECX,4
		0043F85A      83C0 01       ADD EAX,1
		0043F85D    ^ E2 FB         LOOPD SHORT putty1.0043F85A
		0043F85F      59            POP ECX*/
		BYTE add[]="\x51\x2B\xC9\xB9\x04\x00\x00\x00\x83\xC0\x01\xE2\xFB\x59";
		memcpy(add+4,&value,4);
		add[9]+=Reg;
		memcpy(buf+pos,add,14);	
		pos+=14;		
	}
	else  if(switchme==2){
		/*0043F852      51            PUSH ECX
		0043F853      33C9          xor ECX,ECX
		0043F855      B9 04000000   MOV ECX,4
		0043F85A      83C0 01       ADD EAX,1
		0043F85D    ^ E2 FB         LOOPD SHORT putty1.0043F85A
		0043F85F      59            POP ECX*/
		BYTE add[]="\x51\x33\xC9\xB9\x04\x00\x00\x00\x83\xC0\x01\xE2\xFB\x59";
		memcpy(add+4,&value,4);
		add[9]+=Reg;
		memcpy(buf+pos,add,14);	
		pos+=14;		
	}
	else  if(switchme==3){
		/*0046BE92      50          PUSH EAX
		0046BE93      B8 11111111   MOV EAX,11111111
		0046BE98      50            PUSH EAX
		0046BE99      030424        ADD EAX,DWORD PTR SS:[ESP]
		0046BE9C      58            POP EAX
		0046BE9D      58            POP EAX*/
		BYTE add[]="\x50\xB8\x11\x11\x11\x11\x50\x03\x04\x24\x58\x58";
		if(Reg==0){	
			add[0]+=1;
			add[1]+=1;
			add[6]+=1;
			add[10]+=1;
			add[11]+=1;
					
		}
		memcpy(add+2,&value,4);
		add[8]+=(Reg*8);
		memcpy(buf+pos,add,12);	
		pos+=12;		
		


	}



}

void SubFromReg(BYTE  buf[],int Reg,int value,int &pos){

	int switchme=rand()%3;
	 if(switchme==0||value==0||Reg==RegEcx){
		BYTE sub[]="\x83\xe8\x00";
		sub[1]=sub[1]+Reg;
		sub[2]=sub[2]+value;
		memcpy(buf+pos,sub,3);	
		pos+=3;
	}
	else  if(switchme==1){
		/*0043F852      51            PUSH ECX
		0043F853      2BC9          SUB ECX,ECX
		0043F855      B9 04000000   MOV ECX,4
		0043F85A      83E8 01       SUB EAX,1
		0043F85D    ^ E2 FB         LOOPD SHORT putty1.0043F85A
		0043F85F      59            POP ECX*/
		BYTE add[]="\x51\x2B\xC9\xB9\x04\x00\x00\x00\x83\xE8\x01\xE2\xFB\x59";
		memcpy(add+4,&value,4);
		add[9]+=Reg;
		memcpy(buf+pos,add,14);	
		pos+=14;		
	}
	else  if(switchme==2){
		/*0043F852      51           PUSH ECX
		0043F853      33C9          xor ECX,ECX
		0043F855      B9 04000000   MOV ECX,4
		0043F85A      83E8 01       SUB EAX,1
		0043F85D    ^ E2 FB         LOOPD SHORT putty1.0043F85A
		0043F85F      59            POP ECX*/
		BYTE add[]="\x51\x33\xC9\xB9\x04\x00\x00\x00\x83\xE8\x01\xE2\xFB\x59";
		memcpy(add+4,&value,4);
		add[9]+=Reg;
		memcpy(buf+pos,add,14);	
		pos+=14;		
	}
}

void MoveAddrToReg(BYTE buf[],int Reg,DWORD Addr,int &pos){

	BYTE move[]="\xb8\x00\x00\x00\x00";
	move[0]=move[0]+Reg;
	memcpy(move+1,&Addr,4);
	memcpy(buf+pos,move,5);

	pos+=5;		
}
void MoveRegToReg(BYTE buf[],int DesReg,int SrcReg,int &pos){

	BYTE move[]="\x8b\xc0";
	move[1]=move[1]+(DesReg*8+SrcReg);
	
	memcpy(buf+pos,move,2);

	pos+=2;		
}

void JumpToReg(BYTE buf[],int Reg,int &pos){
		
	BYTE jmp[]="\xff\xe0";
	jmp[1]=jmp[1]+Reg;
	memcpy(buf+pos,jmp,2);
	pos+=2;
}

int SetLabel(int pos){
	return pos;
}

void LoopToLabel(BYTE buf[],int label,int &pos){

	BYTE loop[]="\xe2\xff";
	loop[1]=loop[1]-2-(pos-label-1);
	memcpy(buf+pos,loop,2);

	pos+=2;

		
}

void XorRegOneByte(BYTE buf[],int Reg,BYTE XorByte,int &pos){

		//8033 97       XOR BYTE PTR DS:[EBX],97
	BYTE XorBuf[]="\x80\x30\x00";
	XorBuf[1]=XorBuf[1]+Reg;
	XorBuf[2]=XorByte;

	memcpy(buf+pos,XorBuf,3);

	pos+=3;
}
void XorRegFourBytes(BYTE buf[],int Reg,DWORD XorBytes,int &pos){

		//004C44B2      8130 44434241 XOR DWORD PTR DS:[EAX],41424344
	BYTE XorBuf[]="\x81\x30\x00\x00\x00\x00";
	XorBuf[1]=XorBuf[1]+Reg;
	//XorBuf[2]=XorByte;
	memcpy(XorBuf+2,&XorBytes,4);

	memcpy(buf+pos,XorBuf,6);

	pos+=6;
}

void PushReg(BYTE buf[],int Reg,int &pos){
	int switchme=rand()%2;
	//switchme=1;
	 if(switchme==0){	
		BYTE Push =0x50+Reg;
		buf[pos]=Push;
		pos++;
	 }
	/*0046BE82      83EC 04       SUB ESP,4
	0046BE85      890424        MOV DWORD PTR SS:[ESP],EAX
	*/
	 else if(switchme==1){
		BYTE push[]="\x83\xEC\x04\x89\x04\x24";	 
		push[4]+=(Reg*8);
		memcpy(buf+pos,push,6);
		pos+=6;

	 }
}
void PopReg(BYTE buf[],int Reg,int &pos){
	
	BYTE Pop=0x58+Reg;
	buf[pos]=Pop;
	pos++;

}

void JumpForward(BYTE buf[],int bytes,int &pos){


		int switchme=rand()%2;
		// switchme=1;
	 if(switchme==0){
		BYTE Jump[]="\xeb\x00";
		Jump[1]=bytes;
		memcpy(buf+pos,Jump,2);
		pos++;pos++;
		 }
	/*	0046BEA3      E8 00000000   CALL putty1.0046BEA8
		0046BEA8      59            POP ECX
		0046BEA9      83C1 06       ADD ECX,6
		0046BEAC      51            PUSH ECX
		0046BEAD      C3            RETN*/
	 else if(switchme==1){
			BYTE Jump[]="\xE8\x00\x00\x00\x00\x59\x83\xC1\x06\x51\xC3";
			Jump[8]+=bytes;
			memcpy(buf+pos,Jump,11);
			pos+=11;
	 
	 }


}
void JumpBackward(BYTE buf[],int label,int &pos){

	
		BYTE Jump[]="\xeb\xff";
		Jump[1]=Jump[1]-2-(pos-label-1);
		memcpy(buf+pos,Jump,2);
		pos++;pos++;
	
}

void Ret(BYTE buf[],int &pos){
//	int switchme=rand()%2;
		 //switchme=1;
//	 if(switchme==0){
		buf[pos]='\xc3';
		pos++;
//	 }
/*	 else if(switchme==1){
		
		// 0046BE7F      59            POP ECX
		//0046BE80      FFE1          JMP ECX
		 
		 BYTE back[]="\x59\xff\xe1";
		 memcpy(buf+pos,back,3);
		 pos+=3;

	 }*/

}
/*

int main(){

	BYTE buff[200];
	int pos=0;
	int label=0;

	AddToReg(buff,RegEax,2,pos);
	AddToReg(buff,RegEsp,2,pos);
	AddToReg(buff,3,3,pos);
	AddToReg(buff,4,4,pos);
	SubFromReg(buff,4,4,pos);
	MoveAddrToReg(buff,0,0x41424344,pos);
	MoveAddrToReg(buff,2,0x12234567,pos);
	label=SetLabel(pos);
	PushReg(buff,RegEcx,pos);
	PopReg(buff,RegEdx,pos);
	MoveRegToReg(buff,0,0,pos);
	MoveRegToReg(buff,0,1,pos);
	MoveRegToReg(buff,1,0,pos);
	MoveRegToReg(buff,4,3,pos);
	XorRegOneByte(buff,0,0x41,pos);
	XorRegFourBytes(buff,0,0x41424344,pos);
	LoopToLabel(buff,label,pos);
	


	 
	 BYTE *temp=buff;
	 _asm{
		 mov eax,[temp]
         jmp eax
		
	 }
	 




	return 0;
}

*/