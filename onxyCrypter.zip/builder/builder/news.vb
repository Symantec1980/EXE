﻿Public Class news

    Private Sub VTheme1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VTheme1.Click

    End Sub

    Private Sub VButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VButton1.Click
        Me.Close()
    End Sub
End Class