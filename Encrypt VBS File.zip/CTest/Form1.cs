﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
            private void button1_Click(object sender, EventArgs e)
{
    var f = "";
    string s = textBox1.Text;
    foreach (char c in s)
    {
        f += System.Convert.ToInt32(c).ToString() + ")&chr(";
    }
    f = f.Remove(f.Length - 6);
    textBox2.Text = "Execute(chr(" + f + "))";
        }
    }
}