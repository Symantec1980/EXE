﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ButtonENCRIPTAR = New System.Windows.Forms.Button()
        Me.TextBoxIN = New System.Windows.Forms.TextBox()
        Me.TextBoxOUT = New System.Windows.Forms.TextBox()
        Me.TextBoxPASSWORD = New System.Windows.Forms.TextBox()
        Me.ButtonDESENCRIPTAR = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ButtonARCHIVO = New System.Windows.Forms.Button()
        Me.ButtonGUARDAR = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.ButtonGUARDARDES = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ButtonENCRIPTAR
        '
        Me.ButtonENCRIPTAR.BackColor = System.Drawing.Color.Transparent
        Me.ButtonENCRIPTAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonENCRIPTAR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonENCRIPTAR.ForeColor = System.Drawing.Color.Black
        Me.ButtonENCRIPTAR.Location = New System.Drawing.Point(165, 304)
        Me.ButtonENCRIPTAR.Name = "ButtonENCRIPTAR"
        Me.ButtonENCRIPTAR.Size = New System.Drawing.Size(103, 25)
        Me.ButtonENCRIPTAR.TabIndex = 0
        Me.ButtonENCRIPTAR.Text = "Chiffrer le texte"
        Me.ButtonENCRIPTAR.UseVisualStyleBackColor = False
        '
        'TextBoxIN
        '
        Me.TextBoxIN.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.TextBoxIN.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxIN.Location = New System.Drawing.Point(10, 44)
        Me.TextBoxIN.Multiline = True
        Me.TextBoxIN.Name = "TextBoxIN"
        Me.TextBoxIN.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBoxIN.Size = New System.Drawing.Size(314, 254)
        Me.TextBoxIN.TabIndex = 1
        Me.TextBoxIN.Text = "Ecrire ici"
        '
        'TextBoxOUT
        '
        Me.TextBoxOUT.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TextBoxOUT.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxOUT.ForeColor = System.Drawing.Color.Yellow
        Me.TextBoxOUT.Location = New System.Drawing.Point(330, 16)
        Me.TextBoxOUT.Multiline = True
        Me.TextBoxOUT.Name = "TextBoxOUT"
        Me.TextBoxOUT.ReadOnly = True
        Me.TextBoxOUT.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBoxOUT.Size = New System.Drawing.Size(308, 282)
        Me.TextBoxOUT.TabIndex = 2
        '
        'TextBoxPASSWORD
        '
        Me.TextBoxPASSWORD.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxPASSWORD.Location = New System.Drawing.Point(10, 16)
        Me.TextBoxPASSWORD.Name = "TextBoxPASSWORD"
        Me.TextBoxPASSWORD.Size = New System.Drawing.Size(314, 20)
        Me.TextBoxPASSWORD.TabIndex = 3
        Me.TextBoxPASSWORD.Text = "password"
        '
        'ButtonDESENCRIPTAR
        '
        Me.ButtonDESENCRIPTAR.BackColor = System.Drawing.Color.Transparent
        Me.ButtonDESENCRIPTAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDESENCRIPTAR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonDESENCRIPTAR.ForeColor = System.Drawing.Color.Black
        Me.ButtonDESENCRIPTAR.Location = New System.Drawing.Point(418, 304)
        Me.ButtonDESENCRIPTAR.Name = "ButtonDESENCRIPTAR"
        Me.ButtonDESENCRIPTAR.Size = New System.Drawing.Size(65, 25)
        Me.ButtonDESENCRIPTAR.TabIndex = 4
        Me.ButtonDESENCRIPTAR.Text = "décrypter"
        Me.ButtonDESENCRIPTAR.UseVisualStyleBackColor = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'ButtonARCHIVO
        '
        Me.ButtonARCHIVO.BackColor = System.Drawing.Color.Transparent
        Me.ButtonARCHIVO.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonARCHIVO.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonARCHIVO.ForeColor = System.Drawing.Color.Black
        Me.ButtonARCHIVO.Location = New System.Drawing.Point(42, 304)
        Me.ButtonARCHIVO.Name = "ButtonARCHIVO"
        Me.ButtonARCHIVO.Size = New System.Drawing.Size(117, 25)
        Me.ButtonARCHIVO.TabIndex = 5
        Me.ButtonARCHIVO.Text = "Télécharger le fichier"
        Me.ButtonARCHIVO.UseVisualStyleBackColor = False
        '
        'ButtonGUARDAR
        '
        Me.ButtonGUARDAR.BackColor = System.Drawing.Color.Transparent
        Me.ButtonGUARDAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonGUARDAR.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGUARDAR.ForeColor = System.Drawing.Color.Black
        Me.ButtonGUARDAR.Location = New System.Drawing.Point(274, 304)
        Me.ButtonGUARDAR.Name = "ButtonGUARDAR"
        Me.ButtonGUARDAR.Size = New System.Drawing.Size(107, 25)
        Me.ButtonGUARDAR.TabIndex = 6
        Me.ButtonGUARDAR.Text = "Enregistrer crypté"
        Me.ButtonGUARDAR.UseVisualStyleBackColor = False
        '
        'ButtonGUARDARDES
        '
        Me.ButtonGUARDARDES.BackColor = System.Drawing.Color.Transparent
        Me.ButtonGUARDARDES.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonGUARDARDES.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonGUARDARDES.ForeColor = System.Drawing.Color.Black
        Me.ButtonGUARDARDES.Location = New System.Drawing.Point(489, 304)
        Me.ButtonGUARDARDES.Name = "ButtonGUARDARDES"
        Me.ButtonGUARDARDES.Size = New System.Drawing.Size(111, 25)
        Me.ButtonGUARDARDES.TabIndex = 7
        Me.ButtonGUARDARDES.Text = "Enregistrer Decrypt"
        Me.ButtonGUARDARDES.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(648, 344)
        Me.Controls.Add(Me.ButtonGUARDARDES)
        Me.Controls.Add(Me.ButtonGUARDAR)
        Me.Controls.Add(Me.ButtonARCHIVO)
        Me.Controls.Add(Me.ButtonDESENCRIPTAR)
        Me.Controls.Add(Me.TextBoxPASSWORD)
        Me.Controls.Add(Me.TextBoxOUT)
        Me.Controls.Add(Me.TextBoxIN)
        Me.Controls.Add(Me.ButtonENCRIPTAR)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.DimGray
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "Cryptographie AES"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ButtonENCRIPTAR As System.Windows.Forms.Button
    Friend WithEvents TextBoxIN As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxOUT As System.Windows.Forms.TextBox
    Friend WithEvents TextBoxPASSWORD As System.Windows.Forms.TextBox
    Friend WithEvents ButtonDESENCRIPTAR As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents ButtonARCHIVO As System.Windows.Forms.Button
    Friend WithEvents ButtonGUARDAR As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ButtonGUARDARDES As System.Windows.Forms.Button

End Class
