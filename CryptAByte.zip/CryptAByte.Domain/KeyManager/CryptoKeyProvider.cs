//using System;

//namespace CryptAByte.Domain.KeyManager
//{
//    class CryptoKeyProvider  : ICryptoKeyProvider
//    {
//        public KeyRequest GetKeyPairForDate(DateTime releaseDate)
//        {
//            return KeyRequest.CreateRequest(releaseDate);
//        }

//        public KeyRequest RequestForToken(Guid token)
//        {
//            throw new NotImplementedException();
//        }

//        public bool IsReleased(Guid token)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}