﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class form2
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Bloom1 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom2 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom3 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom4 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom5 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom6 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom7 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom8 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom9 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom10 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom11 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom12 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim Bloom13 As WindowsApplication1.UTheme.Bloom = New WindowsApplication1.UTheme.Bloom()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(form2))
        Me.UTheme1 = New WindowsApplication1.UTheme()
        Me.GhostButton1 = New WindowsApplication1.GhostButton()
        Me.GhostTextbox3 = New WindowsApplication1.GhostTextbox()
        Me.UTheme1.SuspendLayout()
        Me.SuspendLayout()
        '
        'UTheme1
        '
        Bloom1.Name = "BackColor"
        Bloom1.Value = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Bloom2.Name = "CornerGradient1"
        Bloom2.Value = System.Drawing.Color.FromArgb(CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(48, Byte), Integer))
        Bloom3.Name = "CornerGradient2"
        Bloom3.Value = System.Drawing.Color.FromArgb(CType(CType(4, Byte), Integer), CType(CType(4, Byte), Integer), CType(CType(4, Byte), Integer))
        Bloom4.Name = "TextShadow"
        Bloom4.Value = System.Drawing.Color.Black
        Bloom5.Name = "TextColor"
        Bloom5.Value = System.Drawing.Color.White
        Bloom6.Name = "BorderColor"
        Bloom6.Value = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer), CType(CType(45, Byte), Integer))
        Bloom7.Name = "Outline"
        Bloom7.Value = System.Drawing.Color.Black
        Bloom8.Name = "CornerHighlight"
        Bloom8.Value = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Bloom9.Name = "TitleShine"
        Bloom9.Value = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer), CType(CType(100, Byte), Integer))
        Bloom10.Name = "TitleGloss"
        Bloom10.Value = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Bloom11.Name = "CornerGloss"
        Bloom11.Value = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Bloom12.Name = "TitleGradient1"
        Bloom12.Value = System.Drawing.Color.FromArgb(CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer), CType(CType(14, Byte), Integer))
        Bloom13.Name = "TitleGradient2"
        Bloom13.Value = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.UTheme1.Colors = New WindowsApplication1.UTheme.Bloom() {Bloom1, Bloom2, Bloom3, Bloom4, Bloom5, Bloom6, Bloom7, Bloom8, Bloom9, Bloom10, Bloom11, Bloom12, Bloom13}
        Me.UTheme1.Controls.Add(Me.GhostButton1)
        Me.UTheme1.Controls.Add(Me.GhostTextbox3)
        Me.UTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.UTheme1.Image = Nothing
        Me.UTheme1.Location = New System.Drawing.Point(0, 0)
        Me.UTheme1.MoveHeight = 24
        Me.UTheme1.Name = "UTheme1"
        Me.UTheme1.Resizable = True
        Me.UTheme1.Size = New System.Drawing.Size(508, 409)
        Me.UTheme1.TabIndex = 0
        Me.UTheme1.Text = "Login System"
        Me.UTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        '
        'GhostButton1
        '
        Me.GhostButton1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton1.Customization = ""
        Me.GhostButton1.EnableGlass = True
        Me.GhostButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton1.Image = Nothing
        Me.GhostButton1.Location = New System.Drawing.Point(185, 273)
        Me.GhostButton1.Name = "GhostButton1"
        Me.GhostButton1.NoRounding = False
        Me.GhostButton1.Size = New System.Drawing.Size(116, 32)
        Me.GhostButton1.TabIndex = 4
        Me.GhostButton1.Text = "Login"
        Me.GhostButton1.Transparent = False
        '
        'GhostTextbox3
        '
        Me.GhostTextbox3.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox3.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox3.Location = New System.Drawing.Point(107, 223)
        Me.GhostTextbox3.Name = "GhostTextbox3"
        Me.GhostTextbox3.ReadOnly = True
        Me.GhostTextbox3.Size = New System.Drawing.Size(276, 20)
        Me.GhostTextbox3.TabIndex = 3
        '
        'form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(508, 409)
        Me.Controls.Add(Me.UTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(120, 80)
        Me.Name = "form2"
        Me.Opacity = 0.0R
        Me.Text = "Form2"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.UTheme1.ResumeLayout(False)
        Me.UTheme1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents UTheme1 As WindowsApplication1.UTheme
    Friend WithEvents GhostTextbox3 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostButton1 As WindowsApplication1.GhostButton
End Class
