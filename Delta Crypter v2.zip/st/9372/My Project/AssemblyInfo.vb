﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("827328364923242")> 
<Assembly: AssemblyDescription("827328364923242")> 
<Assembly: AssemblyCompany("827328364923242")> 
<Assembly: AssemblyProduct("827328364923242")> 
<Assembly: AssemblyCopyright("827328364923242")> 
<Assembly: AssemblyTrademark("827328364923242")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("72529501-1E26-482C-A0D7-0F08A9FBC7BE")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("5.6.2.3")> 
<Assembly: AssemblyFileVersion("5.4.4.2")> 
