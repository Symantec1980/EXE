﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox13 = New System.Windows.Forms.GroupBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtIcon = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtFile = New System.Windows.Forms.TextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GroupBox12 = New System.Windows.Forms.GroupBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.CheckBox13 = New System.Windows.Forms.CheckBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.cbReadOnly = New System.Windows.Forms.CheckBox()
        Me.cbRemovePadding = New System.Windows.Forms.CheckBox()
        Me.cbHideFiles = New System.Windows.Forms.CheckBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.txtBootName = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbBootLM = New System.Windows.Forms.CheckBox()
        Me.txtBootFolder = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cbBootCU = New System.Windows.Forms.CheckBox()
        Me.cbBootWindows = New System.Windows.Forms.CheckBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtVisitUrl = New System.Windows.Forms.TextBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.cbVisitUrl = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox6 = New System.Windows.Forms.CheckBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.cbAntiVPC = New System.Windows.Forms.CheckBox()
        Me.cbAntiThreatExpert = New System.Windows.Forms.CheckBox()
        Me.cbSelectAllAnti = New System.Windows.Forms.CheckBox()
        Me.cbAntiSpyBot = New System.Windows.Forms.CheckBox()
        Me.cbAntiAVG = New System.Windows.Forms.CheckBox()
        Me.cbAntiHijackThis = New System.Windows.Forms.CheckBox()
        Me.cbAntiWireShark = New System.Windows.Forms.CheckBox()
        Me.cbAntiTaskMgr = New System.Windows.Forms.CheckBox()
        Me.cbAntiMalwareByte = New System.Windows.Forms.CheckBox()
        Me.cbAntiVMWare = New System.Windows.Forms.CheckBox()
        Me.cbAntISandBoxie = New System.Windows.Forms.CheckBox()
        Me.cbAntiBitDefender = New System.Windows.Forms.CheckBox()
        Me.cbAntiOllyDbg = New System.Windows.Forms.CheckBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.cbPblacklist = New System.Windows.Forms.CheckBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtProcess = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lbProcessBlacklist = New System.Windows.Forms.ListBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox11 = New System.Windows.Forms.GroupBox()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.cbBlockSites = New System.Windows.Forms.CheckBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ColumnHeader1 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GroupBox16 = New System.Windows.Forms.GroupBox()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.GroupBox15 = New System.Windows.Forms.GroupBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.CheckBox15 = New System.Windows.Forms.CheckBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtnumb4 = New System.Windows.Forms.TextBox()
        Me.txtnumb3 = New System.Windows.Forms.TextBox()
        Me.txtnumb2 = New System.Windows.Forms.TextBox()
        Me.txtnumb1 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtTrademark = New System.Windows.Forms.TextBox()
        Me.txtCopyright = New System.Windows.Forms.TextBox()
        Me.txtProduct = New System.Windows.Forms.TextBox()
        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtTitleA = New System.Windows.Forms.TextBox()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.cbMessageBox = New System.Windows.Forms.CheckBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.txtMessageBody = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtMessageTitle = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.RadioButton8 = New System.Windows.Forms.RadioButton()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.RadioButton15 = New System.Windows.Forms.RadioButton()
        Me.RadioButton13 = New System.Windows.Forms.RadioButton()
        Me.RadioButton12 = New System.Windows.Forms.RadioButton()
        Me.RadioButton14 = New System.Windows.Forms.RadioButton()
        Me.RadioButton11 = New System.Windows.Forms.RadioButton()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.GroupBox14 = New System.Windows.Forms.GroupBox()
        Me.comboMsgExecution = New System.Windows.Forms.ComboBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.CheckBox17 = New System.Windows.Forms.CheckBox()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.ListView2 = New System.Windows.Forms.ListView()
        Me.ColumnHeader2 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader3 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader4 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader5 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader6 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColumnHeader7 = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.AddToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BinderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DownloaderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveSelectedToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExecutionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HDDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MemoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.cbDropBind = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb5 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb6 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb7 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb15 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb8 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb9 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb10 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb11 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb12 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb13 = New System.Windows.Forms.ToolStripMenuItem()
        Me.cb14 = New System.Windows.Forms.ToolStripMenuItem()
        Me.RandomizeNameToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CompileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox13.SuspendLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox12.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox10.SuspendLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox9.SuspendLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox11.SuspendLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.GroupBox16.SuspendLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox15.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox14.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ImageList = Me.ImageList1
        Me.TabControl1.Location = New System.Drawing.Point(8, 7)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(576, 240)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.Controls.Add(Me.GroupBox13)
        Me.TabPage1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TabPage1.ImageIndex = 0
        Me.TabPage1.Location = New System.Drawing.Point(4, 23)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(568, 213)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Main"
        '
        'GroupBox13
        '
        Me.GroupBox13.BackColor = System.Drawing.Color.White
        Me.GroupBox13.Controls.Add(Me.PictureBox14)
        Me.GroupBox13.Controls.Add(Me.PictureBox2)
        Me.GroupBox13.Controls.Add(Me.PictureBox1)
        Me.GroupBox13.Controls.Add(Me.RadioButton1)
        Me.GroupBox13.Controls.Add(Me.RadioButton2)
        Me.GroupBox13.Controls.Add(Me.Label2)
        Me.GroupBox13.Controls.Add(Me.Button2)
        Me.GroupBox13.Controls.Add(Me.txtIcon)
        Me.GroupBox13.Controls.Add(Me.Label1)
        Me.GroupBox13.Controls.Add(Me.Button1)
        Me.GroupBox13.Controls.Add(Me.txtFile)
        Me.GroupBox13.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox13.ForeColor = System.Drawing.Color.Black
        Me.GroupBox13.Location = New System.Drawing.Point(5, 3)
        Me.GroupBox13.Name = "GroupBox13"
        Me.GroupBox13.Size = New System.Drawing.Size(559, 207)
        Me.GroupBox13.TabIndex = 15
        Me.GroupBox13.TabStop = False
        Me.GroupBox13.Text = "Crypting Options"
        '
        'PictureBox14
        '
        Me.PictureBox14.Location = New System.Drawing.Point(503, 105)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(48, 42)
        Me.PictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox14.TabIndex = 16
        Me.PictureBox14.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(8, 61)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox2.TabIndex = 11
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(8, 15)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton1.Location = New System.Drawing.Point(8, 104)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(121, 16)
        Me.RadioButton1.TabIndex = 7
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Real Icon (use .ico)"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton2.Location = New System.Drawing.Point(8, 124)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(146, 16)
        Me.RadioButton2.TabIndex = 6
        Me.RadioButton2.Text = "Steal Icon (extract .exe)"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(26, 62)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 12)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Icon Location"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.Control
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(475, 79)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(76, 20)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Browse"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'txtIcon
        '
        Me.txtIcon.AllowDrop = True
        Me.txtIcon.BackColor = System.Drawing.Color.White
        Me.txtIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIcon.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtIcon.Location = New System.Drawing.Point(8, 80)
        Me.txtIcon.Name = "txtIcon"
        Me.txtIcon.ReadOnly = True
        Me.txtIcon.Size = New System.Drawing.Size(461, 18)
        Me.txtIcon.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(26, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(107, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Executable Location"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(475, 34)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(76, 20)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Browse"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'txtFile
        '
        Me.txtFile.AllowDrop = True
        Me.txtFile.BackColor = System.Drawing.Color.White
        Me.txtFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFile.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFile.Location = New System.Drawing.Point(8, 35)
        Me.txtFile.Name = "txtFile"
        Me.txtFile.ReadOnly = True
        Me.txtFile.Size = New System.Drawing.Size(461, 18)
        Me.txtFile.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.Controls.Add(Me.GroupBox12)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.ImageIndex = 1
        Me.TabPage2.Location = New System.Drawing.Point(4, 23)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(568, 213)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Options"
        '
        'GroupBox12
        '
        Me.GroupBox12.Controls.Add(Me.PictureBox11)
        Me.GroupBox12.Controls.Add(Me.Label3)
        Me.GroupBox12.Controls.Add(Me.ComboBox1)
        Me.GroupBox12.Controls.Add(Me.Label12)
        Me.GroupBox12.Controls.Add(Me.ComboBox6)
        Me.GroupBox12.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox12.ForeColor = System.Drawing.Color.Black
        Me.GroupBox12.Location = New System.Drawing.Point(342, 106)
        Me.GroupBox12.Name = "GroupBox12"
        Me.GroupBox12.Size = New System.Drawing.Size(220, 96)
        Me.GroupBox12.TabIndex = 23
        Me.GroupBox12.TabStop = False
        Me.GroupBox12.Text = "        -  Compiler's Options"
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), System.Drawing.Image)
        Me.PictureBox11.Location = New System.Drawing.Point(9, 0)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox11.TabIndex = 11
        Me.PictureBox11.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(7, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 12)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Storage Method"
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Native Resources", "Managed Resources", "String Variable", "Numeric Variable"})
        Me.ComboBox1.Location = New System.Drawing.Point(9, 70)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(205, 20)
        Me.ComboBox1.TabIndex = 2
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(7, 17)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(93, 12)
        Me.Label12.TabIndex = 13
        Me.Label12.Text = "Output Extension"
        '
        'ComboBox6
        '
        Me.ComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox6.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Items.AddRange(New Object() {"Executable Files [.exe]", "SCR Files [.scr]", "COM Files [.com]", "Batch Files [.bat]", "PIF Files [.pif]"})
        Me.ComboBox6.Location = New System.Drawing.Point(9, 32)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(205, 20)
        Me.ComboBox6.TabIndex = 12
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.ComboBox4)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.ComboBox3)
        Me.GroupBox3.Controls.Add(Me.CheckBox13)
        Me.GroupBox3.Controls.Add(Me.PictureBox5)
        Me.GroupBox3.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(415, 3)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(147, 103)
        Me.GroupBox3.TabIndex = 20
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "                                "
        '
        'ComboBox4
        '
        Me.ComboBox4.Enabled = False
        Me.ComboBox4.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ComboBox4.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Items.AddRange(New Object() {"msconfig", "Adobe Acrobat", "svchost", "lsass", "explorer", "taskhost", "winlogon", "service", "wuauserev", "csrss"})
        Me.ComboBox4.Location = New System.Drawing.Point(7, 76)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(133, 20)
        Me.ComboBox4.TabIndex = 21
        Me.ComboBox4.Text = "msconfig"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(4, 19)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 12)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Location:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(5, 61)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(38, 12)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Name:"
        '
        'ComboBox3
        '
        Me.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox3.Enabled = False
        Me.ComboBox3.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Items.AddRange(New Object() {"ApplicationData", "CommonApplicationData", "CommonProgramFiles", "Cookies", "Desktop", "DesktopDirectory", "Favorites", "History", "InternetCache", "LocalApplicationData", "MyDocuments", "MyMusic", "MyPictures", "InternetCache", "ProgramFiles", "Programs", "Startup", "System", "Templates"})
        Me.ComboBox3.Location = New System.Drawing.Point(7, 35)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(133, 20)
        Me.ComboBox3.TabIndex = 13
        '
        'CheckBox13
        '
        Me.CheckBox13.AutoSize = True
        Me.CheckBox13.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox13.Location = New System.Drawing.Point(30, 0)
        Me.CheckBox13.Name = "CheckBox13"
        Me.CheckBox13.Size = New System.Drawing.Size(78, 16)
        Me.CheckBox13.TabIndex = 12
        Me.CheckBox13.Text = "Install File"
        Me.CheckBox13.UseVisualStyleBackColor = True
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), System.Drawing.Image)
        Me.PictureBox5.Location = New System.Drawing.Point(9, 0)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox5.TabIndex = 11
        Me.PictureBox5.TabStop = False
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cbReadOnly)
        Me.GroupBox4.Controls.Add(Me.cbRemovePadding)
        Me.GroupBox4.Controls.Add(Me.cbHideFiles)
        Me.GroupBox4.Controls.Add(Me.PictureBox6)
        Me.GroupBox4.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.ForeColor = System.Drawing.Color.Black
        Me.GroupBox4.Location = New System.Drawing.Point(259, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(150, 103)
        Me.GroupBox4.TabIndex = 22
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "        -  File Attributes"
        '
        'cbReadOnly
        '
        Me.cbReadOnly.AutoSize = True
        Me.cbReadOnly.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbReadOnly.Location = New System.Drawing.Point(9, 58)
        Me.cbReadOnly.Name = "cbReadOnly"
        Me.cbReadOnly.Size = New System.Drawing.Size(73, 16)
        Me.cbReadOnly.TabIndex = 16
        Me.cbReadOnly.Text = "ReadOnly"
        Me.cbReadOnly.UseVisualStyleBackColor = True
        '
        'cbRemovePadding
        '
        Me.cbRemovePadding.AutoSize = True
        Me.cbRemovePadding.Checked = True
        Me.cbRemovePadding.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbRemovePadding.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbRemovePadding.Location = New System.Drawing.Point(9, 18)
        Me.cbRemovePadding.Name = "cbRemovePadding"
        Me.cbRemovePadding.Size = New System.Drawing.Size(119, 16)
        Me.cbRemovePadding.TabIndex = 15
        Me.cbRemovePadding.Text = "Remove PADDING"
        Me.cbRemovePadding.UseVisualStyleBackColor = True
        '
        'cbHideFiles
        '
        Me.cbHideFiles.AutoSize = True
        Me.cbHideFiles.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbHideFiles.Location = New System.Drawing.Point(9, 38)
        Me.cbHideFiles.Name = "cbHideFiles"
        Me.cbHideFiles.Size = New System.Drawing.Size(71, 16)
        Me.cbHideFiles.TabIndex = 12
        Me.cbHideFiles.Text = "Hide files"
        Me.cbHideFiles.UseVisualStyleBackColor = True
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), System.Drawing.Image)
        Me.PictureBox6.Location = New System.Drawing.Point(9, 0)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox6.TabIndex = 11
        Me.PictureBox6.TabStop = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.txtBootName)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.cbBootLM)
        Me.GroupBox1.Controls.Add(Me.txtBootFolder)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.cbBootCU)
        Me.GroupBox1.Controls.Add(Me.cbBootWindows)
        Me.GroupBox1.Controls.Add(Me.PictureBox4)
        Me.GroupBox1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(6, 113)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(330, 89)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "                                       "
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.Control
        Me.Button3.Enabled = False
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(296, 28)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(26, 23)
        Me.Button3.TabIndex = 19
        Me.Button3.UseVisualStyleBackColor = False
        '
        'txtBootName
        '
        Me.txtBootName.Enabled = False
        Me.txtBootName.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.txtBootName.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBootName.FormattingEnabled = True
        Me.txtBootName.Items.AddRange(New Object() {"msconfig", "Adobe Acrobat", "svchost", "lsass", "explorer", "taskhost", "winlogon", "service", "wuauserev", "csrss"})
        Me.txtBootName.Location = New System.Drawing.Point(206, 57)
        Me.txtBootName.Name = "txtBootName"
        Me.txtBootName.Size = New System.Drawing.Size(116, 20)
        Me.txtBootName.TabIndex = 18
        Me.txtBootName.Text = "msconfig"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(204, 43)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(38, 12)
        Me.Label5.TabIndex = 17
        Me.Label5.Text = "Name:"
        '
        'cbBootLM
        '
        Me.cbBootLM.AutoSize = True
        Me.cbBootLM.Enabled = False
        Me.cbBootLM.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBootLM.Location = New System.Drawing.Point(122, 21)
        Me.cbBootLM.Name = "cbBootLM"
        Me.cbBootLM.Size = New System.Drawing.Size(114, 16)
        Me.cbBootLM.TabIndex = 13
        Me.cbBootLM.Text = "HK_LocalMachine"
        Me.cbBootLM.UseVisualStyleBackColor = True
        '
        'txtBootFolder
        '
        Me.txtBootFolder.BackColor = System.Drawing.Color.White
        Me.txtBootFolder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBootFolder.Enabled = False
        Me.txtBootFolder.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBootFolder.Location = New System.Drawing.Point(10, 58)
        Me.txtBootFolder.Name = "txtBootFolder"
        Me.txtBootFolder.Size = New System.Drawing.Size(190, 18)
        Me.txtBootFolder.TabIndex = 16
        Me.txtBootFolder.Text = "Microsoft\System\Services"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 43)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 12)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Folder:"
        '
        'cbBootCU
        '
        Me.cbBootCU.AutoSize = True
        Me.cbBootCU.Checked = True
        Me.cbBootCU.CheckState = System.Windows.Forms.CheckState.Checked
        Me.cbBootCU.Enabled = False
        Me.cbBootCU.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBootCU.Location = New System.Drawing.Point(9, 21)
        Me.cbBootCU.Name = "cbBootCU"
        Me.cbBootCU.Size = New System.Drawing.Size(107, 16)
        Me.cbBootCU.TabIndex = 14
        Me.cbBootCU.Text = "HK_CurrentUser"
        Me.cbBootCU.UseVisualStyleBackColor = True
        '
        'cbBootWindows
        '
        Me.cbBootWindows.AutoSize = True
        Me.cbBootWindows.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBootWindows.Location = New System.Drawing.Point(30, 0)
        Me.cbBootWindows.Name = "cbBootWindows"
        Me.cbBootWindows.Size = New System.Drawing.Size(100, 16)
        Me.cbBootWindows.TabIndex = 12
        Me.cbBootWindows.Text = "Add To Startup"
        Me.cbBootWindows.UseVisualStyleBackColor = True
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(9, 0)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox4.TabIndex = 11
        Me.PictureBox4.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtVisitUrl)
        Me.GroupBox2.Controls.Add(Me.PictureBox3)
        Me.GroupBox2.Controls.Add(Me.cbVisitUrl)
        Me.GroupBox2.Controls.Add(Me.CheckBox2)
        Me.GroupBox2.Controls.Add(Me.CheckBox1)
        Me.GroupBox2.Controls.Add(Me.CheckBox6)
        Me.GroupBox2.Controls.Add(Me.CheckBox4)
        Me.GroupBox2.Controls.Add(Me.CheckBox3)
        Me.GroupBox2.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(6, 3)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(247, 103)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "        -  Options"
        '
        'txtVisitUrl
        '
        Me.txtVisitUrl.BackColor = System.Drawing.Color.White
        Me.txtVisitUrl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVisitUrl.Enabled = False
        Me.txtVisitUrl.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtVisitUrl.Location = New System.Drawing.Point(9, 79)
        Me.txtVisitUrl.Name = "txtVisitUrl"
        Me.txtVisitUrl.Size = New System.Drawing.Size(185, 18)
        Me.txtVisitUrl.TabIndex = 20
        Me.txtVisitUrl.Text = "www.google.com"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(9, 0)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox3.TabIndex = 11
        Me.PictureBox3.TabStop = False
        '
        'cbVisitUrl
        '
        Me.cbVisitUrl.AutoSize = True
        Me.cbVisitUrl.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbVisitUrl.Location = New System.Drawing.Point(9, 60)
        Me.cbVisitUrl.Name = "cbVisitUrl"
        Me.cbVisitUrl.Size = New System.Drawing.Size(91, 16)
        Me.cbVisitUrl.TabIndex = 4
        Me.cbVisitUrl.Text = "Visit Website"
        Me.cbVisitUrl.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox2.Location = New System.Drawing.Point(113, 20)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(130, 16)
        Me.CheckBox2.TabIndex = 1
        Me.CheckBox2.Text = "Record used settings"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox1.Location = New System.Drawing.Point(113, 40)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(121, 16)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "Preverse EOF Data"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox6
        '
        Me.CheckBox6.AutoSize = True
        Me.CheckBox6.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox6.Location = New System.Drawing.Point(9, 40)
        Me.CheckBox6.Name = "CheckBox6"
        Me.CheckBox6.Size = New System.Drawing.Size(83, 16)
        Me.CheckBox6.TabIndex = 3
        Me.CheckBox6.Text = "P2P Spread"
        Me.CheckBox6.UseVisualStyleBackColor = True
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox4.Location = New System.Drawing.Point(113, 60)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(106, 16)
        Me.CheckBox4.TabIndex = 1
        Me.CheckBox4.Text = "Execution Delay"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox3.Location = New System.Drawing.Point(9, 20)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(84, 16)
        Me.CheckBox3.TabIndex = 0
        Me.CheckBox3.Text = "Melt Output"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.White
        Me.TabPage3.Controls.Add(Me.GroupBox10)
        Me.TabPage3.Controls.Add(Me.GroupBox9)
        Me.TabPage3.ImageIndex = 2
        Me.TabPage3.Location = New System.Drawing.Point(4, 23)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(568, 213)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Anti"
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.cbAntiVPC)
        Me.GroupBox10.Controls.Add(Me.cbAntiThreatExpert)
        Me.GroupBox10.Controls.Add(Me.cbSelectAllAnti)
        Me.GroupBox10.Controls.Add(Me.cbAntiSpyBot)
        Me.GroupBox10.Controls.Add(Me.cbAntiAVG)
        Me.GroupBox10.Controls.Add(Me.cbAntiHijackThis)
        Me.GroupBox10.Controls.Add(Me.cbAntiWireShark)
        Me.GroupBox10.Controls.Add(Me.cbAntiTaskMgr)
        Me.GroupBox10.Controls.Add(Me.cbAntiMalwareByte)
        Me.GroupBox10.Controls.Add(Me.cbAntiVMWare)
        Me.GroupBox10.Controls.Add(Me.cbAntISandBoxie)
        Me.GroupBox10.Controls.Add(Me.cbAntiBitDefender)
        Me.GroupBox10.Controls.Add(Me.cbAntiOllyDbg)
        Me.GroupBox10.Controls.Add(Me.PictureBox8)
        Me.GroupBox10.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox10.ForeColor = System.Drawing.Color.Black
        Me.GroupBox10.Location = New System.Drawing.Point(289, 3)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(276, 200)
        Me.GroupBox10.TabIndex = 1
        Me.GroupBox10.TabStop = False
        Me.GroupBox10.Text = "        -  Anti Methods"
        '
        'cbAntiVPC
        '
        Me.cbAntiVPC.AutoSize = True
        Me.cbAntiVPC.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiVPC.Location = New System.Drawing.Point(135, 21)
        Me.cbAntiVPC.Name = "cbAntiVPC"
        Me.cbAntiVPC.Size = New System.Drawing.Size(102, 16)
        Me.cbAntiVPC.TabIndex = 26
        Me.cbAntiVPC.Text = "Anti-Virtual PC"
        Me.cbAntiVPC.UseVisualStyleBackColor = True
        '
        'cbAntiThreatExpert
        '
        Me.cbAntiThreatExpert.AutoSize = True
        Me.cbAntiThreatExpert.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiThreatExpert.Location = New System.Drawing.Point(135, 38)
        Me.cbAntiThreatExpert.Name = "cbAntiThreatExpert"
        Me.cbAntiThreatExpert.Size = New System.Drawing.Size(116, 16)
        Me.cbAntiThreatExpert.TabIndex = 27
        Me.cbAntiThreatExpert.Text = "Anti-ThreatExpert"
        Me.cbAntiThreatExpert.UseVisualStyleBackColor = True
        '
        'cbSelectAllAnti
        '
        Me.cbSelectAllAnti.AutoSize = True
        Me.cbSelectAllAnti.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbSelectAllAnti.Location = New System.Drawing.Point(171, 0)
        Me.cbSelectAllAnti.Name = "cbSelectAllAnti"
        Me.cbSelectAllAnti.Size = New System.Drawing.Size(73, 16)
        Me.cbSelectAllAnti.TabIndex = 24
        Me.cbSelectAllAnti.Text = "Select All"
        Me.cbSelectAllAnti.UseVisualStyleBackColor = True
        '
        'cbAntiSpyBot
        '
        Me.cbAntiSpyBot.AutoSize = True
        Me.cbAntiSpyBot.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiSpyBot.Location = New System.Drawing.Point(6, 125)
        Me.cbAntiSpyBot.Name = "cbAntiSpyBot"
        Me.cbAntiSpyBot.Size = New System.Drawing.Size(86, 16)
        Me.cbAntiSpyBot.TabIndex = 23
        Me.cbAntiSpyBot.Text = "Anti-SpyBot"
        Me.cbAntiSpyBot.UseVisualStyleBackColor = True
        '
        'cbAntiAVG
        '
        Me.cbAntiAVG.AutoSize = True
        Me.cbAntiAVG.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiAVG.Location = New System.Drawing.Point(6, 108)
        Me.cbAntiAVG.Name = "cbAntiAVG"
        Me.cbAntiAVG.Size = New System.Drawing.Size(74, 16)
        Me.cbAntiAVG.TabIndex = 22
        Me.cbAntiAVG.Text = "Anti-AVG"
        Me.cbAntiAVG.UseVisualStyleBackColor = True
        '
        'cbAntiHijackThis
        '
        Me.cbAntiHijackThis.AutoSize = True
        Me.cbAntiHijackThis.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiHijackThis.Location = New System.Drawing.Point(6, 176)
        Me.cbAntiHijackThis.Name = "cbAntiHijackThis"
        Me.cbAntiHijackThis.Size = New System.Drawing.Size(104, 16)
        Me.cbAntiHijackThis.TabIndex = 21
        Me.cbAntiHijackThis.Text = "Anti-HijackThis"
        Me.cbAntiHijackThis.UseVisualStyleBackColor = True
        '
        'cbAntiWireShark
        '
        Me.cbAntiWireShark.AutoSize = True
        Me.cbAntiWireShark.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiWireShark.Location = New System.Drawing.Point(6, 159)
        Me.cbAntiWireShark.Name = "cbAntiWireShark"
        Me.cbAntiWireShark.Size = New System.Drawing.Size(101, 16)
        Me.cbAntiWireShark.TabIndex = 20
        Me.cbAntiWireShark.Text = "Anti-WireShark"
        Me.cbAntiWireShark.UseVisualStyleBackColor = True
        '
        'cbAntiTaskMgr
        '
        Me.cbAntiTaskMgr.AutoSize = True
        Me.cbAntiTaskMgr.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiTaskMgr.Location = New System.Drawing.Point(6, 142)
        Me.cbAntiTaskMgr.Name = "cbAntiTaskMgr"
        Me.cbAntiTaskMgr.Size = New System.Drawing.Size(118, 16)
        Me.cbAntiTaskMgr.TabIndex = 19
        Me.cbAntiTaskMgr.Text = "Anti-TaskManager"
        Me.cbAntiTaskMgr.UseVisualStyleBackColor = True
        '
        'cbAntiMalwareByte
        '
        Me.cbAntiMalwareByte.AutoSize = True
        Me.cbAntiMalwareByte.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiMalwareByte.Location = New System.Drawing.Point(6, 72)
        Me.cbAntiMalwareByte.Name = "cbAntiMalwareByte"
        Me.cbAntiMalwareByte.Size = New System.Drawing.Size(114, 16)
        Me.cbAntiMalwareByte.TabIndex = 14
        Me.cbAntiMalwareByte.Text = "Anti-MalwareByte"
        Me.cbAntiMalwareByte.UseVisualStyleBackColor = True
        '
        'cbAntiVMWare
        '
        Me.cbAntiVMWare.AutoSize = True
        Me.cbAntiVMWare.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiVMWare.Location = New System.Drawing.Point(6, 90)
        Me.cbAntiVMWare.Name = "cbAntiVMWare"
        Me.cbAntiVMWare.Size = New System.Drawing.Size(92, 16)
        Me.cbAntiVMWare.TabIndex = 18
        Me.cbAntiVMWare.Text = "Anti-VMWare"
        Me.cbAntiVMWare.UseVisualStyleBackColor = True
        '
        'cbAntISandBoxie
        '
        Me.cbAntISandBoxie.AutoSize = True
        Me.cbAntISandBoxie.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntISandBoxie.Location = New System.Drawing.Point(6, 55)
        Me.cbAntISandBoxie.Name = "cbAntISandBoxie"
        Me.cbAntISandBoxie.Size = New System.Drawing.Size(103, 16)
        Me.cbAntISandBoxie.TabIndex = 17
        Me.cbAntISandBoxie.Text = "Anti-SandBoxie"
        Me.cbAntISandBoxie.UseVisualStyleBackColor = True
        '
        'cbAntiBitDefender
        '
        Me.cbAntiBitDefender.AutoSize = True
        Me.cbAntiBitDefender.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiBitDefender.Location = New System.Drawing.Point(6, 21)
        Me.cbAntiBitDefender.Name = "cbAntiBitDefender"
        Me.cbAntiBitDefender.Size = New System.Drawing.Size(109, 16)
        Me.cbAntiBitDefender.TabIndex = 15
        Me.cbAntiBitDefender.Text = "Anti-BitDefender"
        Me.cbAntiBitDefender.UseVisualStyleBackColor = True
        '
        'cbAntiOllyDbg
        '
        Me.cbAntiOllyDbg.AutoSize = True
        Me.cbAntiOllyDbg.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAntiOllyDbg.Location = New System.Drawing.Point(6, 38)
        Me.cbAntiOllyDbg.Name = "cbAntiOllyDbg"
        Me.cbAntiOllyDbg.Size = New System.Drawing.Size(91, 16)
        Me.cbAntiOllyDbg.TabIndex = 16
        Me.cbAntiOllyDbg.Text = "Anti-OllyDbg"
        Me.cbAntiOllyDbg.UseVisualStyleBackColor = True
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = CType(resources.GetObject("PictureBox8.Image"), System.Drawing.Image)
        Me.PictureBox8.Location = New System.Drawing.Point(6, 0)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox8.TabIndex = 12
        Me.PictureBox8.TabStop = False
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.cbPblacklist)
        Me.GroupBox9.Controls.Add(Me.PictureBox9)
        Me.GroupBox9.Controls.Add(Me.Button7)
        Me.GroupBox9.Controls.Add(Me.Button6)
        Me.GroupBox9.Controls.Add(Me.Button5)
        Me.GroupBox9.Controls.Add(Me.Label11)
        Me.GroupBox9.Controls.Add(Me.txtProcess)
        Me.GroupBox9.Controls.Add(Me.Label10)
        Me.GroupBox9.Controls.Add(Me.lbProcessBlacklist)
        Me.GroupBox9.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox9.ForeColor = System.Drawing.Color.Black
        Me.GroupBox9.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(280, 200)
        Me.GroupBox9.TabIndex = 0
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "                                                          "
        '
        'cbPblacklist
        '
        Me.cbPblacklist.AutoSize = True
        Me.cbPblacklist.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbPblacklist.Location = New System.Drawing.Point(30, 0)
        Me.cbPblacklist.Name = "cbPblacklist"
        Me.cbPblacklist.Size = New System.Drawing.Size(154, 16)
        Me.cbPblacklist.TabIndex = 25
        Me.cbPblacklist.Text = "Custom Process Blacklist"
        Me.cbPblacklist.UseVisualStyleBackColor = True
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), System.Drawing.Image)
        Me.PictureBox9.Location = New System.Drawing.Point(8, 0)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox9.TabIndex = 13
        Me.PictureBox9.TabStop = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.Control
        Me.Button7.Enabled = False
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button7.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(174, 116)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(100, 23)
        Me.Button7.TabIndex = 9
        Me.Button7.Text = "Clear list"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.Control
        Me.Button6.Enabled = False
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button6.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(174, 87)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(100, 23)
        Me.Button6.TabIndex = 7
        Me.Button6.Text = "Remove from list"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.Control
        Me.Button5.Enabled = False
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button5.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(174, 58)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(100, 23)
        Me.Button5.TabIndex = 6
        Me.Button5.Text = "Add to list"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(172, 18)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(80, 12)
        Me.Label11.TabIndex = 5
        Me.Label11.Text = "Process name:"
        '
        'txtProcess
        '
        Me.txtProcess.BackColor = System.Drawing.Color.White
        Me.txtProcess.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtProcess.Enabled = False
        Me.txtProcess.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProcess.Location = New System.Drawing.Point(174, 34)
        Me.txtProcess.Name = "txtProcess"
        Me.txtProcess.Size = New System.Drawing.Size(100, 18)
        Me.txtProcess.TabIndex = 4
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(6, 19)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(69, 12)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Process list:"
        '
        'lbProcessBlacklist
        '
        Me.lbProcessBlacklist.Enabled = False
        Me.lbProcessBlacklist.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbProcessBlacklist.FormattingEnabled = True
        Me.lbProcessBlacklist.ItemHeight = 12
        Me.lbProcessBlacklist.Location = New System.Drawing.Point(6, 34)
        Me.lbProcessBlacklist.Name = "lbProcessBlacklist"
        Me.lbProcessBlacklist.Size = New System.Drawing.Size(162, 160)
        Me.lbProcessBlacklist.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.White
        Me.TabPage4.Controls.Add(Me.GroupBox11)
        Me.TabPage4.ImageKey = "page_cross.gif"
        Me.TabPage4.Location = New System.Drawing.Point(4, 23)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(568, 213)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Block Sites"
        '
        'GroupBox11
        '
        Me.GroupBox11.BackColor = System.Drawing.Color.White
        Me.GroupBox11.Controls.Add(Me.Button16)
        Me.GroupBox11.Controls.Add(Me.PictureBox10)
        Me.GroupBox11.Controls.Add(Me.cbBlockSites)
        Me.GroupBox11.Controls.Add(Me.Button11)
        Me.GroupBox11.Controls.Add(Me.Button10)
        Me.GroupBox11.Controls.Add(Me.ComboBox7)
        Me.GroupBox11.Controls.Add(Me.ListView1)
        Me.GroupBox11.Location = New System.Drawing.Point(11, 4)
        Me.GroupBox11.Name = "GroupBox11"
        Me.GroupBox11.Size = New System.Drawing.Size(547, 202)
        Me.GroupBox11.TabIndex = 25
        Me.GroupBox11.TabStop = False
        Me.GroupBox11.Text = "                                 "
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.SystemColors.Control
        Me.Button16.Enabled = False
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button16.Location = New System.Drawing.Point(488, 174)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(53, 20)
        Me.Button16.TabIndex = 41
        Me.Button16.Text = "Add All"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), System.Drawing.Image)
        Me.PictureBox10.Location = New System.Drawing.Point(8, -1)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox10.TabIndex = 40
        Me.PictureBox10.TabStop = False
        '
        'cbBlockSites
        '
        Me.cbBlockSites.AutoSize = True
        Me.cbBlockSites.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbBlockSites.Location = New System.Drawing.Point(29, -1)
        Me.cbBlockSites.Name = "cbBlockSites"
        Me.cbBlockSites.Size = New System.Drawing.Size(81, 16)
        Me.cbBlockSites.TabIndex = 39
        Me.cbBlockSites.Text = "Block Sites"
        Me.cbBlockSites.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.SystemColors.Control
        Me.Button11.Enabled = False
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button11.Location = New System.Drawing.Point(424, 174)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(58, 20)
        Me.Button11.TabIndex = 24
        Me.Button11.Text = "Remove"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.Control
        Me.Button10.Enabled = False
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button10.Location = New System.Drawing.Point(375, 174)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(43, 20)
        Me.Button10.TabIndex = 23
        Me.Button10.Text = "Add"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'ComboBox7
        '
        Me.ComboBox7.Enabled = False
        Me.ComboBox7.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.ComboBox7.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Items.AddRange(New Object() {"virscan.org", "virustotal.com", "virusscan.jotti.org", "vscan.novirusthanks.org", "free.avg.com", "avg.com", "norton.com", "www.norton.com", "avast.com", "trendmicro.com", "pctools.com", "kaskersky.com", "www.kaspersky.com", "bullguard.com", "secunia.com", "community.norton.com", "av-comparatives.org", "computerhope.com", "nl.clamwin.com", "clamwin.com", "mac-forums.com", "mcafee.com", "barracudanetworks.com", "stopzilla.com", "free-av.com", "symantec.com", "eset.com"})
        Me.ComboBox7.Location = New System.Drawing.Point(12, 175)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(357, 20)
        Me.ComboBox7.TabIndex = 22
        '
        'ListView1
        '
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListView1.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader1})
        Me.ListView1.FullRowSelect = True
        Me.ListView1.GridLines = True
        Me.ListView1.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.ListView1.Location = New System.Drawing.Point(12, 18)
        Me.ListView1.MultiSelect = False
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(529, 150)
        Me.ListView1.TabIndex = 1
        Me.ListView1.UseCompatibleStateImageBehavior = False
        Me.ListView1.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader1
        '
        Me.ColumnHeader1.Text = "URL"
        Me.ColumnHeader1.Width = 528
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.White
        Me.TabPage5.Controls.Add(Me.GroupBox16)
        Me.TabPage5.Controls.Add(Me.GroupBox15)
        Me.TabPage5.ImageIndex = 6
        Me.TabPage5.Location = New System.Drawing.Point(4, 23)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(568, 213)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Extra Options"
        '
        'GroupBox16
        '
        Me.GroupBox16.Controls.Add(Me.Button14)
        Me.GroupBox16.Controls.Add(Me.Button15)
        Me.GroupBox16.Controls.Add(Me.Button13)
        Me.GroupBox16.Controls.Add(Me.PictureBox15)
        Me.GroupBox16.Controls.Add(Me.Button12)
        Me.GroupBox16.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox16.ForeColor = System.Drawing.Color.Black
        Me.GroupBox16.Location = New System.Drawing.Point(327, 9)
        Me.GroupBox16.Name = "GroupBox16"
        Me.GroupBox16.Size = New System.Drawing.Size(230, 195)
        Me.GroupBox16.TabIndex = 40
        Me.GroupBox16.TabStop = False
        Me.GroupBox16.Text = "        -  Additional Tools"
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.SystemColors.Control
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button14.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.Image = CType(resources.GetObject("Button14.Image"), System.Drawing.Image)
        Me.Button14.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button14.Location = New System.Drawing.Point(8, 131)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(215, 31)
        Me.Button14.TabIndex = 18
        Me.Button14.Text = "Script Compilers"
        Me.Button14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.SystemColors.Control
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button15.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.Image = CType(resources.GetObject("Button15.Image"), System.Drawing.Image)
        Me.Button15.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button15.Location = New System.Drawing.Point(8, 94)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(215, 31)
        Me.Button15.TabIndex = 17
        Me.Button15.Text = "Help Documents"
        Me.Button15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.SystemColors.Control
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button13.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button13.Location = New System.Drawing.Point(8, 57)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(215, 31)
        Me.Button13.TabIndex = 16
        Me.Button13.Text = "Hex Viewer"
        Me.Button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button13.UseVisualStyleBackColor = False
        '
        'PictureBox15
        '
        Me.PictureBox15.Image = CType(resources.GetObject("PictureBox15.Image"), System.Drawing.Image)
        Me.PictureBox15.Location = New System.Drawing.Point(9, 0)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox15.TabIndex = 11
        Me.PictureBox15.TabStop = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.SystemColors.Control
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button12.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Image = CType(resources.GetObject("Button12.Image"), System.Drawing.Image)
        Me.Button12.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Button12.Location = New System.Drawing.Point(8, 20)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(215, 31)
        Me.Button12.TabIndex = 15
        Me.Button12.Text = "Scan your file"
        Me.Button12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button12.UseVisualStyleBackColor = False
        '
        'GroupBox15
        '
        Me.GroupBox15.Controls.Add(Me.PictureBox13)
        Me.GroupBox15.Controls.Add(Me.Button8)
        Me.GroupBox15.Controls.Add(Me.CheckBox15)
        Me.GroupBox15.Controls.Add(Me.Label19)
        Me.GroupBox15.Controls.Add(Me.txtnumb4)
        Me.GroupBox15.Controls.Add(Me.txtnumb3)
        Me.GroupBox15.Controls.Add(Me.txtnumb2)
        Me.GroupBox15.Controls.Add(Me.txtnumb1)
        Me.GroupBox15.Controls.Add(Me.Label13)
        Me.GroupBox15.Controls.Add(Me.Label14)
        Me.GroupBox15.Controls.Add(Me.Label15)
        Me.GroupBox15.Controls.Add(Me.Label16)
        Me.GroupBox15.Controls.Add(Me.Label17)
        Me.GroupBox15.Controls.Add(Me.Label18)
        Me.GroupBox15.Controls.Add(Me.txtTrademark)
        Me.GroupBox15.Controls.Add(Me.txtCopyright)
        Me.GroupBox15.Controls.Add(Me.txtProduct)
        Me.GroupBox15.Controls.Add(Me.txtCompany)
        Me.GroupBox15.Controls.Add(Me.txtDescription)
        Me.GroupBox15.Controls.Add(Me.txtTitleA)
        Me.GroupBox15.Location = New System.Drawing.Point(7, 9)
        Me.GroupBox15.Name = "GroupBox15"
        Me.GroupBox15.Size = New System.Drawing.Size(314, 195)
        Me.GroupBox15.TabIndex = 39
        Me.GroupBox15.TabStop = False
        Me.GroupBox15.Text = "                                     "
        '
        'PictureBox13
        '
        Me.PictureBox13.Image = CType(resources.GetObject("PictureBox13.Image"), System.Drawing.Image)
        Me.PictureBox13.Location = New System.Drawing.Point(8, -1)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox13.TabIndex = 40
        Me.PictureBox13.TabStop = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.Control
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button8.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(277, 13)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(26, 23)
        Me.Button8.TabIndex = 37
        Me.Button8.UseVisualStyleBackColor = False
        '
        'CheckBox15
        '
        Me.CheckBox15.AutoSize = True
        Me.CheckBox15.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox15.Location = New System.Drawing.Point(30, -1)
        Me.CheckBox15.Name = "CheckBox15"
        Me.CheckBox15.Size = New System.Drawing.Size(107, 16)
        Me.CheckBox15.TabIndex = 38
        Me.CheckBox15.Text = "Assembly Editor"
        Me.CheckBox15.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(8, 164)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 12)
        Me.Label19.TabIndex = 36
        Me.Label19.Text = "File Version:"
        '
        'txtnumb4
        '
        Me.txtnumb4.BackColor = System.Drawing.SystemColors.Window
        Me.txtnumb4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnumb4.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnumb4.Location = New System.Drawing.Point(253, 163)
        Me.txtnumb4.Name = "txtnumb4"
        Me.txtnumb4.Size = New System.Drawing.Size(50, 18)
        Me.txtnumb4.TabIndex = 35
        Me.txtnumb4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtnumb3
        '
        Me.txtnumb3.BackColor = System.Drawing.SystemColors.Window
        Me.txtnumb3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnumb3.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnumb3.Location = New System.Drawing.Point(197, 163)
        Me.txtnumb3.Name = "txtnumb3"
        Me.txtnumb3.Size = New System.Drawing.Size(50, 18)
        Me.txtnumb3.TabIndex = 34
        Me.txtnumb3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtnumb2
        '
        Me.txtnumb2.BackColor = System.Drawing.SystemColors.Window
        Me.txtnumb2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnumb2.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnumb2.Location = New System.Drawing.Point(141, 163)
        Me.txtnumb2.Name = "txtnumb2"
        Me.txtnumb2.Size = New System.Drawing.Size(50, 18)
        Me.txtnumb2.TabIndex = 33
        Me.txtnumb2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtnumb1
        '
        Me.txtnumb1.BackColor = System.Drawing.SystemColors.Window
        Me.txtnumb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtnumb1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtnumb1.Location = New System.Drawing.Point(85, 163)
        Me.txtnumb1.Name = "txtnumb1"
        Me.txtnumb1.Size = New System.Drawing.Size(50, 18)
        Me.txtnumb1.TabIndex = 32
        Me.txtnumb1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(8, 141)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(63, 12)
        Me.Label13.TabIndex = 31
        Me.Label13.Text = "Trademark:"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(8, 117)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(58, 12)
        Me.Label14.TabIndex = 30
        Me.Label14.Text = "Copyright:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(8, 93)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(48, 12)
        Me.Label15.TabIndex = 29
        Me.Label15.Text = "Product:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(8, 69)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(56, 12)
        Me.Label16.TabIndex = 28
        Me.Label16.Text = "Company:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(8, 45)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(67, 12)
        Me.Label17.TabIndex = 27
        Me.Label17.Text = "Description:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(8, 21)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(32, 12)
        Me.Label18.TabIndex = 26
        Me.Label18.Text = "Title:"
        '
        'txtTrademark
        '
        Me.txtTrademark.BackColor = System.Drawing.SystemColors.Window
        Me.txtTrademark.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTrademark.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTrademark.Location = New System.Drawing.Point(85, 138)
        Me.txtTrademark.Name = "txtTrademark"
        Me.txtTrademark.Size = New System.Drawing.Size(218, 18)
        Me.txtTrademark.TabIndex = 25
        Me.txtTrademark.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCopyright
        '
        Me.txtCopyright.BackColor = System.Drawing.SystemColors.Window
        Me.txtCopyright.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCopyright.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCopyright.Location = New System.Drawing.Point(85, 114)
        Me.txtCopyright.Name = "txtCopyright"
        Me.txtCopyright.Size = New System.Drawing.Size(218, 18)
        Me.txtCopyright.TabIndex = 24
        Me.txtCopyright.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtProduct
        '
        Me.txtProduct.BackColor = System.Drawing.SystemColors.Window
        Me.txtProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtProduct.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProduct.Location = New System.Drawing.Point(85, 90)
        Me.txtProduct.Name = "txtProduct"
        Me.txtProduct.Size = New System.Drawing.Size(218, 18)
        Me.txtProduct.TabIndex = 23
        Me.txtProduct.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCompany
        '
        Me.txtCompany.BackColor = System.Drawing.SystemColors.Window
        Me.txtCompany.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCompany.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCompany.Location = New System.Drawing.Point(85, 66)
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.Size = New System.Drawing.Size(218, 18)
        Me.txtCompany.TabIndex = 22
        Me.txtCompany.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtDescription
        '
        Me.txtDescription.BackColor = System.Drawing.SystemColors.Window
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDescription.Location = New System.Drawing.Point(85, 42)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(218, 18)
        Me.txtDescription.TabIndex = 21
        Me.txtDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTitleA
        '
        Me.txtTitleA.BackColor = System.Drawing.SystemColors.Window
        Me.txtTitleA.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTitleA.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTitleA.Location = New System.Drawing.Point(85, 18)
        Me.txtTitleA.Name = "txtTitleA"
        Me.txtTitleA.Size = New System.Drawing.Size(181, 18)
        Me.txtTitleA.TabIndex = 20
        Me.txtTitleA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBox5)
        Me.TabPage6.ImageIndex = 3
        Me.TabPage6.Location = New System.Drawing.Point(4, 23)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(568, 213)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Message"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.White
        Me.GroupBox5.Controls.Add(Me.cbMessageBox)
        Me.GroupBox5.Controls.Add(Me.GroupBox8)
        Me.GroupBox5.Controls.Add(Me.GroupBox7)
        Me.GroupBox5.Controls.Add(Me.GroupBox6)
        Me.GroupBox5.Controls.Add(Me.PictureBox7)
        Me.GroupBox5.Controls.Add(Me.GroupBox14)
        Me.GroupBox5.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(3, 1)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(562, 202)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "                             "
        '
        'cbMessageBox
        '
        Me.cbMessageBox.AutoSize = True
        Me.cbMessageBox.Location = New System.Drawing.Point(31, -1)
        Me.cbMessageBox.Name = "cbMessageBox"
        Me.cbMessageBox.Size = New System.Drawing.Size(69, 16)
        Me.cbMessageBox.TabIndex = 14
        Me.cbMessageBox.Text = "Message"
        Me.cbMessageBox.UseVisualStyleBackColor = True
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Button4)
        Me.GroupBox8.Controls.Add(Me.txtMessageBody)
        Me.GroupBox8.Controls.Add(Me.Label9)
        Me.GroupBox8.Controls.Add(Me.txtMessageTitle)
        Me.GroupBox8.Controls.Add(Me.Label8)
        Me.GroupBox8.Enabled = False
        Me.GroupBox8.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox8.ForeColor = System.Drawing.Color.Black
        Me.GroupBox8.Location = New System.Drawing.Point(8, 21)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(548, 87)
        Me.GroupBox8.TabIndex = 13
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Message Contest"
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.Control
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(457, 24)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(85, 22)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Test Message"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'txtMessageBody
        '
        Me.txtMessageBody.BackColor = System.Drawing.Color.White
        Me.txtMessageBody.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMessageBody.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMessageBody.Location = New System.Drawing.Point(8, 63)
        Me.txtMessageBody.Name = "txtMessageBody"
        Me.txtMessageBody.Size = New System.Drawing.Size(534, 18)
        Me.txtMessageBody.TabIndex = 3
        Me.txtMessageBody.Text = "The application failed to initialize properly (0x0000022). Click on OK to termina" & _
            "te the application."
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(6, 48)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(54, 12)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Message:"
        '
        'txtMessageTitle
        '
        Me.txtMessageTitle.BackColor = System.Drawing.Color.White
        Me.txtMessageTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMessageTitle.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMessageTitle.Location = New System.Drawing.Point(8, 27)
        Me.txtMessageTitle.Name = "txtMessageTitle"
        Me.txtMessageTitle.Size = New System.Drawing.Size(443, 18)
        Me.txtMessageTitle.TabIndex = 1
        Me.txtMessageTitle.Text = "explorer.exe - Application Error"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(6, 12)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 12)
        Me.Label8.TabIndex = 0
        Me.Label8.Text = "Title:"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.RadioButton3)
        Me.GroupBox7.Controls.Add(Me.RadioButton4)
        Me.GroupBox7.Controls.Add(Me.RadioButton5)
        Me.GroupBox7.Controls.Add(Me.RadioButton6)
        Me.GroupBox7.Controls.Add(Me.RadioButton8)
        Me.GroupBox7.Enabled = False
        Me.GroupBox7.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox7.ForeColor = System.Drawing.Color.Black
        Me.GroupBox7.Location = New System.Drawing.Point(245, 114)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(173, 82)
        Me.GroupBox7.TabIndex = 13
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Message Style"
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton3.ForeColor = System.Drawing.Color.Black
        Me.RadioButton3.Location = New System.Drawing.Point(82, 39)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(69, 16)
        Me.RadioButton3.TabIndex = 6
        Me.RadioButton3.Text = "Question"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton4.ForeColor = System.Drawing.Color.Black
        Me.RadioButton4.Location = New System.Drawing.Point(6, 17)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(51, 16)
        Me.RadioButton4.TabIndex = 1
        Me.RadioButton4.Text = "Blank"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton5.ForeColor = System.Drawing.Color.Black
        Me.RadioButton5.Location = New System.Drawing.Point(82, 17)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(81, 16)
        Me.RadioButton5.TabIndex = 2
        Me.RadioButton5.Text = "Information"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Checked = True
        Me.RadioButton6.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton6.ForeColor = System.Drawing.Color.Black
        Me.RadioButton6.Location = New System.Drawing.Point(6, 39)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(48, 16)
        Me.RadioButton6.TabIndex = 5
        Me.RadioButton6.TabStop = True
        Me.RadioButton6.Text = "Error"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'RadioButton8
        '
        Me.RadioButton8.AutoSize = True
        Me.RadioButton8.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton8.ForeColor = System.Drawing.Color.Black
        Me.RadioButton8.Location = New System.Drawing.Point(6, 61)
        Me.RadioButton8.Name = "RadioButton8"
        Me.RadioButton8.Size = New System.Drawing.Size(63, 16)
        Me.RadioButton8.TabIndex = 4
        Me.RadioButton8.Text = "Warning"
        Me.RadioButton8.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.RadioButton15)
        Me.GroupBox6.Controls.Add(Me.RadioButton13)
        Me.GroupBox6.Controls.Add(Me.RadioButton12)
        Me.GroupBox6.Controls.Add(Me.RadioButton14)
        Me.GroupBox6.Controls.Add(Me.RadioButton11)
        Me.GroupBox6.Controls.Add(Me.RadioButton10)
        Me.GroupBox6.Enabled = False
        Me.GroupBox6.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox6.ForeColor = System.Drawing.Color.Black
        Me.GroupBox6.Location = New System.Drawing.Point(6, 114)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(233, 82)
        Me.GroupBox6.TabIndex = 12
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Message Buttons"
        '
        'RadioButton15
        '
        Me.RadioButton15.AutoSize = True
        Me.RadioButton15.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton15.ForeColor = System.Drawing.Color.Black
        Me.RadioButton15.Location = New System.Drawing.Point(130, 60)
        Me.RadioButton15.Name = "RadioButton15"
        Me.RadioButton15.Size = New System.Drawing.Size(97, 16)
        Me.RadioButton15.TabIndex = 6
        Me.RadioButton15.Text = "Yes No Cancel"
        Me.RadioButton15.UseVisualStyleBackColor = True
        '
        'RadioButton13
        '
        Me.RadioButton13.AutoSize = True
        Me.RadioButton13.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton13.ForeColor = System.Drawing.Color.Black
        Me.RadioButton13.Location = New System.Drawing.Point(6, 16)
        Me.RadioButton13.Name = "RadioButton13"
        Me.RadioButton13.Size = New System.Drawing.Size(117, 16)
        Me.RadioButton13.TabIndex = 1
        Me.RadioButton13.Text = "Abort Retry Ignore"
        Me.RadioButton13.UseVisualStyleBackColor = True
        '
        'RadioButton12
        '
        Me.RadioButton12.AutoSize = True
        Me.RadioButton12.Checked = True
        Me.RadioButton12.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton12.ForeColor = System.Drawing.Color.Black
        Me.RadioButton12.Location = New System.Drawing.Point(6, 38)
        Me.RadioButton12.Name = "RadioButton12"
        Me.RadioButton12.Size = New System.Drawing.Size(39, 16)
        Me.RadioButton12.TabIndex = 2
        Me.RadioButton12.TabStop = True
        Me.RadioButton12.Text = "OK"
        Me.RadioButton12.UseVisualStyleBackColor = True
        '
        'RadioButton14
        '
        Me.RadioButton14.AutoSize = True
        Me.RadioButton14.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton14.ForeColor = System.Drawing.Color.Black
        Me.RadioButton14.Location = New System.Drawing.Point(130, 16)
        Me.RadioButton14.Name = "RadioButton14"
        Me.RadioButton14.Size = New System.Drawing.Size(59, 16)
        Me.RadioButton14.TabIndex = 5
        Me.RadioButton14.Text = "Yes No"
        Me.RadioButton14.UseVisualStyleBackColor = True
        '
        'RadioButton11
        '
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton11.ForeColor = System.Drawing.Color.Black
        Me.RadioButton11.Location = New System.Drawing.Point(130, 38)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(77, 16)
        Me.RadioButton11.TabIndex = 3
        Me.RadioButton11.Text = "OK Cancel"
        Me.RadioButton11.UseVisualStyleBackColor = True
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RadioButton10.ForeColor = System.Drawing.Color.Black
        Me.RadioButton10.Location = New System.Drawing.Point(6, 60)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(88, 16)
        Me.RadioButton10.TabIndex = 4
        Me.RadioButton10.Text = "Retry Cancel"
        Me.RadioButton10.UseVisualStyleBackColor = True
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), System.Drawing.Image)
        Me.PictureBox7.Location = New System.Drawing.Point(9, -1)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(16, 16)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox7.TabIndex = 11
        Me.PictureBox7.TabStop = False
        '
        'GroupBox14
        '
        Me.GroupBox14.Controls.Add(Me.comboMsgExecution)
        Me.GroupBox14.Controls.Add(Me.Label20)
        Me.GroupBox14.Controls.Add(Me.CheckBox17)
        Me.GroupBox14.Enabled = False
        Me.GroupBox14.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox14.ForeColor = System.Drawing.Color.Black
        Me.GroupBox14.Location = New System.Drawing.Point(424, 114)
        Me.GroupBox14.Name = "GroupBox14"
        Me.GroupBox14.Size = New System.Drawing.Size(132, 88)
        Me.GroupBox14.TabIndex = 16
        Me.GroupBox14.TabStop = False
        Me.GroupBox14.Text = "Message Settings"
        '
        'comboMsgExecution
        '
        Me.comboMsgExecution.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.comboMsgExecution.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.comboMsgExecution.FormattingEnabled = True
        Me.comboMsgExecution.Items.AddRange(New Object() {"Before", "After"})
        Me.comboMsgExecution.Location = New System.Drawing.Point(6, 59)
        Me.comboMsgExecution.Name = "comboMsgExecution"
        Me.comboMsgExecution.Size = New System.Drawing.Size(121, 20)
        Me.comboMsgExecution.TabIndex = 17
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(6, 43)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(102, 12)
        Me.Label20.TabIndex = 16
        Me.Label20.Text = "Execution moment:"
        '
        'CheckBox17
        '
        Me.CheckBox17.AutoSize = True
        Me.CheckBox17.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox17.Location = New System.Drawing.Point(8, 18)
        Me.CheckBox17.Name = "CheckBox17"
        Me.CheckBox17.Size = New System.Drawing.Size(94, 16)
        Me.CheckBox17.TabIndex = 15
        Me.CheckBox17.Text = "Run only once"
        Me.CheckBox17.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.ListView2)
        Me.TabPage7.ImageIndex = 5
        Me.TabPage7.Location = New System.Drawing.Point(4, 23)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(568, 213)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Download/Bind"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'ListView2
        '
        Me.ListView2.AllowDrop = True
        Me.ListView2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListView2.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ColumnHeader2, Me.ColumnHeader3, Me.ColumnHeader4, Me.ColumnHeader5, Me.ColumnHeader6, Me.ColumnHeader7})
        Me.ListView2.ContextMenuStrip = Me.ContextMenuStrip1
        Me.ListView2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView2.FullRowSelect = True
        Me.ListView2.GridLines = True
        Me.ListView2.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.ListView2.Location = New System.Drawing.Point(0, 0)
        Me.ListView2.Name = "ListView2"
        Me.ListView2.Size = New System.Drawing.Size(568, 213)
        Me.ListView2.TabIndex = 2
        Me.ListView2.UseCompatibleStateImageBehavior = False
        Me.ListView2.View = System.Windows.Forms.View.Details
        '
        'ColumnHeader2
        '
        Me.ColumnHeader2.Text = "Name"
        Me.ColumnHeader2.Width = 97
        '
        'ColumnHeader3
        '
        Me.ColumnHeader3.Text = "Path/URL"
        Me.ColumnHeader3.Width = 134
        '
        'ColumnHeader4
        '
        Me.ColumnHeader4.Text = "Size"
        Me.ColumnHeader4.Width = 75
        '
        'ColumnHeader5
        '
        Me.ColumnHeader5.Text = "Action"
        Me.ColumnHeader5.Width = 77
        '
        'ColumnHeader6
        '
        Me.ColumnHeader6.Text = "Folder"
        Me.ColumnHeader6.Width = 112
        '
        'ColumnHeader7
        '
        Me.ColumnHeader7.Text = "Type"
        Me.ColumnHeader7.Width = 72
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddToolStripMenuItem, Me.RemoveSelectedToolStripMenuItem, Me.ToolStripMenuItem1, Me.ClearToolStripMenuItem, Me.OptionsToolStripMenuItem, Me.ToolStripMenuItem2, Me.CompileToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(157, 148)
        '
        'AddToolStripMenuItem
        '
        Me.AddToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BinderToolStripMenuItem, Me.DownloaderToolStripMenuItem})
        Me.AddToolStripMenuItem.Name = "AddToolStripMenuItem"
        Me.AddToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.AddToolStripMenuItem.Text = "Add"
        '
        'BinderToolStripMenuItem
        '
        Me.BinderToolStripMenuItem.Name = "BinderToolStripMenuItem"
        Me.BinderToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.BinderToolStripMenuItem.Text = "Binder"
        '
        'DownloaderToolStripMenuItem
        '
        Me.DownloaderToolStripMenuItem.Name = "DownloaderToolStripMenuItem"
        Me.DownloaderToolStripMenuItem.Size = New System.Drawing.Size(128, 22)
        Me.DownloaderToolStripMenuItem.Text = "Downloader"
        '
        'RemoveSelectedToolStripMenuItem
        '
        Me.RemoveSelectedToolStripMenuItem.Name = "RemoveSelectedToolStripMenuItem"
        Me.RemoveSelectedToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.RemoveSelectedToolStripMenuItem.Text = "Remove selected"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(153, 6)
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExecutionToolStripMenuItem, Me.cbDropBind, Me.RandomizeNameToolStripMenuItem})
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.OptionsToolStripMenuItem.Text = "Options"
        '
        'ExecutionToolStripMenuItem
        '
        Me.ExecutionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HDDToolStripMenuItem, Me.MemoryToolStripMenuItem})
        Me.ExecutionToolStripMenuItem.Name = "ExecutionToolStripMenuItem"
        Me.ExecutionToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.ExecutionToolStripMenuItem.Text = "Action"
        '
        'HDDToolStripMenuItem
        '
        Me.HDDToolStripMenuItem.Name = "HDDToolStripMenuItem"
        Me.HDDToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.HDDToolStripMenuItem.Text = "HDD"
        '
        'MemoryToolStripMenuItem
        '
        Me.MemoryToolStripMenuItem.Name = "MemoryToolStripMenuItem"
        Me.MemoryToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.MemoryToolStripMenuItem.Text = "Memory"
        '
        'cbDropBind
        '
        Me.cbDropBind.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.cb2, Me.cb1, Me.cb3, Me.cb4, Me.cb5, Me.cb6, Me.cb7, Me.cb15, Me.cb8, Me.cb9, Me.cb10, Me.cb11, Me.cb12, Me.cb13, Me.cb14})
        Me.cbDropBind.Name = "cbDropBind"
        Me.cbDropBind.Size = New System.Drawing.Size(156, 22)
        Me.cbDropBind.Text = "Folder"
        '
        'cb2
        '
        Me.cb2.Name = "cb2"
        Me.cb2.Size = New System.Drawing.Size(195, 22)
        Me.cb2.Text = "ApplicationData"
        '
        'cb1
        '
        Me.cb1.Name = "cb1"
        Me.cb1.Size = New System.Drawing.Size(195, 22)
        Me.cb1.Text = "Templates"
        '
        'cb3
        '
        Me.cb3.Name = "cb3"
        Me.cb3.Size = New System.Drawing.Size(195, 22)
        Me.cb3.Text = "CommonApplicationData"
        '
        'cb4
        '
        Me.cb4.Name = "cb4"
        Me.cb4.Size = New System.Drawing.Size(195, 22)
        Me.cb4.Text = "Desktop"
        '
        'cb5
        '
        Me.cb5.Name = "cb5"
        Me.cb5.Size = New System.Drawing.Size(195, 22)
        Me.cb5.Text = "Favorites"
        '
        'cb6
        '
        Me.cb6.Name = "cb6"
        Me.cb6.Size = New System.Drawing.Size(195, 22)
        Me.cb6.Text = "History"
        '
        'cb7
        '
        Me.cb7.Name = "cb7"
        Me.cb7.Size = New System.Drawing.Size(195, 22)
        Me.cb7.Text = "InternetCache"
        '
        'cb15
        '
        Me.cb15.Name = "cb15"
        Me.cb15.Size = New System.Drawing.Size(195, 22)
        Me.cb15.Text = "LocalApplicationData"
        '
        'cb8
        '
        Me.cb8.Name = "cb8"
        Me.cb8.Size = New System.Drawing.Size(195, 22)
        Me.cb8.Text = "MyDocuments"
        '
        'cb9
        '
        Me.cb9.Name = "cb9"
        Me.cb9.Size = New System.Drawing.Size(195, 22)
        Me.cb9.Text = "MyMusic"
        '
        'cb10
        '
        Me.cb10.Name = "cb10"
        Me.cb10.Size = New System.Drawing.Size(195, 22)
        Me.cb10.Text = "ProgramFiles"
        '
        'cb11
        '
        Me.cb11.Name = "cb11"
        Me.cb11.Size = New System.Drawing.Size(195, 22)
        Me.cb11.Text = "Programs"
        '
        'cb12
        '
        Me.cb12.Name = "cb12"
        Me.cb12.Size = New System.Drawing.Size(195, 22)
        Me.cb12.Text = "Recent"
        '
        'cb13
        '
        Me.cb13.Name = "cb13"
        Me.cb13.Size = New System.Drawing.Size(195, 22)
        Me.cb13.Text = "Startup"
        '
        'cb14
        '
        Me.cb14.Name = "cb14"
        Me.cb14.Size = New System.Drawing.Size(195, 22)
        Me.cb14.Text = "System"
        '
        'RandomizeNameToolStripMenuItem
        '
        Me.RandomizeNameToolStripMenuItem.Name = "RandomizeNameToolStripMenuItem"
        Me.RandomizeNameToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.RandomizeNameToolStripMenuItem.Text = "Randomize Name"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(153, 6)
        '
        'CompileToolStripMenuItem
        '
        Me.CompileToolStripMenuItem.Name = "CompileToolStripMenuItem"
        Me.CompileToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.CompileToolStripMenuItem.Text = "Compile"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "icon_home.gif")
        Me.ImageList1.Images.SetKeyName(1, "icon_package.gif")
        Me.ImageList1.Images.SetKeyName(2, "bug.png")
        Me.ImageList1.Images.SetKeyName(3, "comment.png")
        Me.ImageList1.Images.SetKeyName(4, "page_cross.gif")
        Me.ImageList1.Images.SetKeyName(5, "folder_new.gif")
        Me.ImageList1.Images.SetKeyName(6, "interface_dialog.gif")
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox12.Image = Global.Client.My.Resources.Resources.header
        Me.PictureBox12.Location = New System.Drawing.Point(20, 4)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(576, 85)
        Me.PictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox12.TabIndex = 1
        Me.PictureBox12.TabStop = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.Control
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button9.Font = New System.Drawing.Font("Verdana", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(8, 253)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(576, 24)
        Me.Button9.TabIndex = 5
        Me.Button9.Text = "Crypt File"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.TabControl1)
        Me.Panel1.Controls.Add(Me.Button9)
        Me.Panel1.Location = New System.Drawing.Point(12, 91)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(595, 286)
        Me.Panel1.TabIndex = 6
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(616, 384)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PictureBox12)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Heaven Crypter"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox13.ResumeLayout(False)
        Me.GroupBox13.PerformLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.GroupBox12.ResumeLayout(False)
        Me.GroupBox12.PerformLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox11.ResumeLayout(False)
        Me.GroupBox11.PerformLayout()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.GroupBox16.ResumeLayout(False)
        Me.GroupBox16.PerformLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox15.ResumeLayout(False)
        Me.GroupBox15.PerformLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage6.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox14.ResumeLayout(False)
        Me.GroupBox14.PerformLayout()
        Me.TabPage7.ResumeLayout(False)
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents txtIcon As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox6 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents cbVisitUrl As System.Windows.Forms.CheckBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cbBootWindows As System.Windows.Forms.CheckBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents txtBootFolder As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cbBootCU As System.Windows.Forms.CheckBox
    Friend WithEvents cbBootLM As System.Windows.Forms.CheckBox
    Friend WithEvents txtBootName As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckBox13 As System.Windows.Forms.CheckBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox4 As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents cbHideFiles As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton6 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton8 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton15 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton13 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton12 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton14 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton11 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton10 As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents txtMessageBody As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtMessageTitle As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents lbProcessBlacklist As System.Windows.Forms.ListBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtProcess As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
    Friend WithEvents cbAntiSpyBot As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiAVG As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiHijackThis As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiWireShark As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiTaskMgr As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiMalwareByte As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiVMWare As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntISandBoxie As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiBitDefender As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiOllyDbg As System.Windows.Forms.CheckBox
    Friend WithEvents cbSelectAllAnti As System.Windows.Forms.CheckBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents ComboBox6 As System.Windows.Forms.ComboBox
    Friend WithEvents cbMessageBox As System.Windows.Forms.CheckBox
    Friend WithEvents cbPblacklist As System.Windows.Forms.CheckBox
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtnumb4 As System.Windows.Forms.TextBox
    Friend WithEvents txtnumb3 As System.Windows.Forms.TextBox
    Friend WithEvents txtnumb2 As System.Windows.Forms.TextBox
    Friend WithEvents txtnumb1 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtTrademark As System.Windows.Forms.TextBox
    Friend WithEvents txtCopyright As System.Windows.Forms.TextBox
    Friend WithEvents txtProduct As System.Windows.Forms.TextBox
    Friend WithEvents txtCompany As System.Windows.Forms.TextBox
    Friend WithEvents txtDescription As System.Windows.Forms.TextBox
    Friend WithEvents txtTitleA As System.Windows.Forms.TextBox
    Friend WithEvents CheckBox15 As System.Windows.Forms.CheckBox
    Friend WithEvents txtVisitUrl As System.Windows.Forms.TextBox
    Friend WithEvents cbBlockSites As System.Windows.Forms.CheckBox
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents ComboBox7 As System.Windows.Forms.ComboBox
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents GroupBox11 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox10 As System.Windows.Forms.PictureBox
    Friend WithEvents cbAntiVPC As System.Windows.Forms.CheckBox
    Friend WithEvents cbAntiThreatExpert As System.Windows.Forms.CheckBox
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox13 As System.Windows.Forms.GroupBox
    Friend WithEvents cbRemovePadding As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox12 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents ColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents CheckBox17 As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox14 As System.Windows.Forms.GroupBox
    Friend WithEvents comboMsgExecution As System.Windows.Forms.ComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents ListView2 As System.Windows.Forms.ListView
    Friend WithEvents ColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents AddToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BinderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DownloaderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RemoveSelectedToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExecutionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HDDToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MemoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cbDropBind As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb6 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb7 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb15 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb8 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb9 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb10 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb11 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb12 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb13 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cb14 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RandomizeNameToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CompileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox15 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox16 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents txtFile As System.Windows.Forms.TextBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cbReadOnly As System.Windows.Forms.CheckBox
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Panel1 As System.Windows.Forms.Panel

End Class
