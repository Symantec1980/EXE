﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Index
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Index))
        Me.Theme1 = New VisualCrypter.Theme()
        Me.VsButton6 = New VisualCrypter.VSButton()
        Me.VsGroupBox4 = New VisualCrypter.VSGroupBox()
        Me.VsTextBox13 = New VisualCrypter.VSTextBox()
        Me.VsCheckbox1 = New VisualCrypter.VSCheckbox()
        Me.VsGroupBox3 = New VisualCrypter.VSGroupBox()
        Me.VsRadiobutton3 = New VisualCrypter.VSRadiobutton()
        Me.VsRadiobutton2 = New VisualCrypter.VSRadiobutton()
        Me.VsRadiobutton1 = New VisualCrypter.VSRadiobutton()
        Me.VsGroupBox2 = New VisualCrypter.VSGroupBox()
        Me.VsButton7 = New VisualCrypter.VSButton()
        Me.VsButton5 = New VisualCrypter.VSButton()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.VsTextBox9 = New VisualCrypter.VSTextBox()
        Me.VsTextBox8 = New VisualCrypter.VSTextBox()
        Me.VsTextBox7 = New VisualCrypter.VSTextBox()
        Me.VsTextBox6 = New VisualCrypter.VSTextBox()
        Me.VsTextBox5 = New VisualCrypter.VSTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.VsButton4 = New VisualCrypter.VSButton()
        Me.VsTextBox4 = New VisualCrypter.VSTextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.VsGroupBox1 = New VisualCrypter.VSGroupBox()
        Me.VsButton3 = New VisualCrypter.VSButton()
        Me.VsTextBox3 = New VisualCrypter.VSTextBox()
        Me.VsButton2 = New VisualCrypter.VSButton()
        Me.VsTextBox2 = New VisualCrypter.VSTextBox()
        Me.VsButton1 = New VisualCrypter.VSButton()
        Me.VsTextBox1 = New VisualCrypter.VSTextBox()
        Me.VsControlBox1 = New VisualCrypter.VSControlBox()
        Me.Theme1.SuspendLayout()
        Me.VsGroupBox4.SuspendLayout()
        Me.VsGroupBox3.SuspendLayout()
        Me.VsGroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VsGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Theme1
        '
        Me.Theme1.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Theme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Theme1.Controls.Add(Me.VsButton6)
        Me.Theme1.Controls.Add(Me.VsGroupBox4)
        Me.Theme1.Controls.Add(Me.VsGroupBox3)
        Me.Theme1.Controls.Add(Me.VsGroupBox2)
        Me.Theme1.Controls.Add(Me.VsGroupBox1)
        Me.Theme1.Controls.Add(Me.VsControlBox1)
        Me.Theme1.Customization = "MC0t/3Fxcf8="
        Me.Theme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Theme1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.Theme1.Image = Nothing
        Me.Theme1.Location = New System.Drawing.Point(0, 0)
        Me.Theme1.Movable = True
        Me.Theme1.Name = "Theme1"
        Me.Theme1.NoRounding = False
        Me.Theme1.Sizable = True
        Me.Theme1.Size = New System.Drawing.Size(672, 358)
        Me.Theme1.SmartBounds = True
        Me.Theme1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Theme1.TabIndex = 0
        Me.Theme1.Text = "Theme1"
        Me.Theme1.TransparencyKey = System.Drawing.Color.Empty
        Me.Theme1.Transparent = False
        '
        'VsButton6
        '
        Me.VsButton6.Customization = "Qj4+/zQzM///////mZmZ/8xwAP8="
        Me.VsButton6.Font = New System.Drawing.Font("Verdana", 18.0!)
        Me.VsButton6.Image = Nothing
        Me.VsButton6.Location = New System.Drawing.Point(241, 299)
        Me.VsButton6.Name = "VsButton6"
        Me.VsButton6.NoRounding = False
        Me.VsButton6.Size = New System.Drawing.Size(202, 40)
        Me.VsButton6.TabIndex = 5
        Me.VsButton6.Text = "Protect"
        Me.VsButton6.Transparent = False
        '
        'VsGroupBox4
        '
        Me.VsGroupBox4.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VsGroupBox4.Controls.Add(Me.VsTextBox13)
        Me.VsGroupBox4.Controls.Add(Me.VsCheckbox1)
        Me.VsGroupBox4.Customization = "NzMz//////8="
        Me.VsGroupBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsGroupBox4.Image = Nothing
        Me.VsGroupBox4.Location = New System.Drawing.Point(14, 220)
        Me.VsGroupBox4.Movable = True
        Me.VsGroupBox4.Name = "VsGroupBox4"
        Me.VsGroupBox4.NoRounding = False
        Me.VsGroupBox4.Sizable = True
        Me.VsGroupBox4.Size = New System.Drawing.Size(325, 71)
        Me.VsGroupBox4.SmartBounds = True
        Me.VsGroupBox4.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VsGroupBox4.TabIndex = 4
        Me.VsGroupBox4.Text = "Options :"
        Me.VsGroupBox4.TransparencyKey = System.Drawing.Color.Empty
        Me.VsGroupBox4.Transparent = False
        '
        'VsTextBox13
        '
        Me.VsTextBox13.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox13.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox13.Image = Nothing
        Me.VsTextBox13.Location = New System.Drawing.Point(174, 25)
        Me.VsTextBox13.MaxLength = 32767
        Me.VsTextBox13.Multiline = False
        Me.VsTextBox13.Name = "VsTextBox13"
        Me.VsTextBox13.NoRounding = False
        Me.VsTextBox13.ReadOnly = False
        Me.VsTextBox13.Size = New System.Drawing.Size(104, 24)
        Me.VsTextBox13.TabIndex = 1
        Me.VsTextBox13.Text = "StartupKey"
        Me.VsTextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox13.Transparent = False
        Me.VsTextBox13.UseSystemPasswordChar = False
        '
        'VsCheckbox1
        '
        Me.VsCheckbox1.Checked = False
        Me.VsCheckbox1.Colors = New VisualCrypter.Bloom(-1) {}
        Me.VsCheckbox1.Customization = ""
        Me.VsCheckbox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsCheckbox1.Image = Nothing
        Me.VsCheckbox1.Location = New System.Drawing.Point(21, 30)
        Me.VsCheckbox1.Name = "VsCheckbox1"
        Me.VsCheckbox1.NoRounding = False
        Me.VsCheckbox1.Size = New System.Drawing.Size(106, 16)
        Me.VsCheckbox1.TabIndex = 0
        Me.VsCheckbox1.Text = "Enable Startup"
        Me.VsCheckbox1.Transparent = False
        '
        'VsGroupBox3
        '
        Me.VsGroupBox3.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VsGroupBox3.Controls.Add(Me.VsRadiobutton3)
        Me.VsGroupBox3.Controls.Add(Me.VsRadiobutton2)
        Me.VsGroupBox3.Controls.Add(Me.VsRadiobutton1)
        Me.VsGroupBox3.Customization = "NzMz//////8="
        Me.VsGroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsGroupBox3.Image = Nothing
        Me.VsGroupBox3.Location = New System.Drawing.Point(14, 164)
        Me.VsGroupBox3.Movable = True
        Me.VsGroupBox3.Name = "VsGroupBox3"
        Me.VsGroupBox3.NoRounding = False
        Me.VsGroupBox3.Sizable = True
        Me.VsGroupBox3.Size = New System.Drawing.Size(325, 50)
        Me.VsGroupBox3.SmartBounds = True
        Me.VsGroupBox3.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VsGroupBox3.TabIndex = 3
        Me.VsGroupBox3.Text = "Injection :"
        Me.VsGroupBox3.TransparencyKey = System.Drawing.Color.Empty
        Me.VsGroupBox3.Transparent = False
        '
        'VsRadiobutton3
        '
        Me.VsRadiobutton3.Checked = False
        Me.VsRadiobutton3.Customization = "/////5mZmf/MegD/"
        Me.VsRadiobutton3.Enabled = False
        Me.VsRadiobutton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsRadiobutton3.Image = Nothing
        Me.VsRadiobutton3.Location = New System.Drawing.Point(239, 23)
        Me.VsRadiobutton3.Name = "VsRadiobutton3"
        Me.VsRadiobutton3.NoRounding = False
        Me.VsRadiobutton3.Size = New System.Drawing.Size(68, 16)
        Me.VsRadiobutton3.TabIndex = 2
        Me.VsRadiobutton3.Text = "Regasm"
        Me.VsRadiobutton3.Transparent = False
        '
        'VsRadiobutton2
        '
        Me.VsRadiobutton2.Checked = False
        Me.VsRadiobutton2.Customization = "/////5mZmf/MegD/"
        Me.VsRadiobutton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsRadiobutton2.Image = Nothing
        Me.VsRadiobutton2.Location = New System.Drawing.Point(132, 23)
        Me.VsRadiobutton2.Name = "VsRadiobutton2"
        Me.VsRadiobutton2.NoRounding = False
        Me.VsRadiobutton2.Size = New System.Drawing.Size(46, 16)
        Me.VsRadiobutton2.TabIndex = 1
        Me.VsRadiobutton2.Text = "VBC"
        Me.VsRadiobutton2.Transparent = False
        '
        'VsRadiobutton1
        '
        Me.VsRadiobutton1.Checked = True
        Me.VsRadiobutton1.Customization = "/////5mZmf/MegD/"
        Me.VsRadiobutton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsRadiobutton1.Image = Nothing
        Me.VsRadiobutton1.Location = New System.Drawing.Point(19, 23)
        Me.VsRadiobutton1.Name = "VsRadiobutton1"
        Me.VsRadiobutton1.NoRounding = False
        Me.VsRadiobutton1.Size = New System.Drawing.Size(52, 16)
        Me.VsRadiobutton1.TabIndex = 0
        Me.VsRadiobutton1.Text = "Itself"
        Me.VsRadiobutton1.Transparent = False
        '
        'VsGroupBox2
        '
        Me.VsGroupBox2.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VsGroupBox2.Controls.Add(Me.VsButton7)
        Me.VsGroupBox2.Controls.Add(Me.VsButton5)
        Me.VsGroupBox2.Controls.Add(Me.Label6)
        Me.VsGroupBox2.Controls.Add(Me.Label7)
        Me.VsGroupBox2.Controls.Add(Me.Label8)
        Me.VsGroupBox2.Controls.Add(Me.Label9)
        Me.VsGroupBox2.Controls.Add(Me.Label10)
        Me.VsGroupBox2.Controls.Add(Me.VsTextBox9)
        Me.VsGroupBox2.Controls.Add(Me.VsTextBox8)
        Me.VsGroupBox2.Controls.Add(Me.VsTextBox7)
        Me.VsGroupBox2.Controls.Add(Me.VsTextBox6)
        Me.VsGroupBox2.Controls.Add(Me.VsTextBox5)
        Me.VsGroupBox2.Controls.Add(Me.Label5)
        Me.VsGroupBox2.Controls.Add(Me.Label4)
        Me.VsGroupBox2.Controls.Add(Me.Label3)
        Me.VsGroupBox2.Controls.Add(Me.Label2)
        Me.VsGroupBox2.Controls.Add(Me.Label1)
        Me.VsGroupBox2.Controls.Add(Me.VsButton4)
        Me.VsGroupBox2.Controls.Add(Me.VsTextBox4)
        Me.VsGroupBox2.Controls.Add(Me.PictureBox1)
        Me.VsGroupBox2.Customization = "NzMz//////8="
        Me.VsGroupBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsGroupBox2.Image = Nothing
        Me.VsGroupBox2.Location = New System.Drawing.Point(345, 40)
        Me.VsGroupBox2.Movable = True
        Me.VsGroupBox2.Name = "VsGroupBox2"
        Me.VsGroupBox2.NoRounding = False
        Me.VsGroupBox2.Sizable = True
        Me.VsGroupBox2.Size = New System.Drawing.Size(313, 251)
        Me.VsGroupBox2.SmartBounds = True
        Me.VsGroupBox2.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VsGroupBox2.TabIndex = 2
        Me.VsGroupBox2.Text = "Assembly Info :"
        Me.VsGroupBox2.TransparencyKey = System.Drawing.Color.Empty
        Me.VsGroupBox2.Transparent = False
        '
        'VsButton7
        '
        Me.VsButton7.Customization = "Qj4+/zQzM///////mZmZ/8xwAP8="
        Me.VsButton7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsButton7.Image = Nothing
        Me.VsButton7.Location = New System.Drawing.Point(64, 216)
        Me.VsButton7.Name = "VsButton7"
        Me.VsButton7.NoRounding = False
        Me.VsButton7.Size = New System.Drawing.Size(95, 25)
        Me.VsButton7.TabIndex = 23
        Me.VsButton7.Text = "Clone PE"
        Me.VsButton7.Transparent = False
        '
        'VsButton5
        '
        Me.VsButton5.Customization = "Qj4+/zQzM///////mZmZ/8xwAP8="
        Me.VsButton5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsButton5.Image = Nothing
        Me.VsButton5.Location = New System.Drawing.Point(194, 216)
        Me.VsButton5.Name = "VsButton5"
        Me.VsButton5.NoRounding = False
        Me.VsButton5.Size = New System.Drawing.Size(90, 25)
        Me.VsButton5.TabIndex = 22
        Me.VsButton5.Text = "Reset"
        Me.VsButton5.Transparent = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(123, 186)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(12, 13)
        Me.Label6.TabIndex = 21
        Me.Label6.Text = ":"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(123, 156)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(12, 13)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = ":"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(123, 127)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(12, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = ":"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(123, 98)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(12, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = ":"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(123, 69)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(12, 13)
        Me.Label10.TabIndex = 17
        Me.Label10.Text = ":"
        '
        'VsTextBox9
        '
        Me.VsTextBox9.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox9.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox9.Image = Nothing
        Me.VsTextBox9.Location = New System.Drawing.Point(136, 181)
        Me.VsTextBox9.MaxLength = 32767
        Me.VsTextBox9.Multiline = False
        Me.VsTextBox9.Name = "VsTextBox9"
        Me.VsTextBox9.NoRounding = False
        Me.VsTextBox9.ReadOnly = False
        Me.VsTextBox9.Size = New System.Drawing.Size(162, 24)
        Me.VsTextBox9.TabIndex = 13
        Me.VsTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox9.Transparent = False
        Me.VsTextBox9.UseSystemPasswordChar = False
        '
        'VsTextBox8
        '
        Me.VsTextBox8.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox8.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox8.Image = Nothing
        Me.VsTextBox8.Location = New System.Drawing.Point(136, 151)
        Me.VsTextBox8.MaxLength = 32767
        Me.VsTextBox8.Multiline = False
        Me.VsTextBox8.Name = "VsTextBox8"
        Me.VsTextBox8.NoRounding = False
        Me.VsTextBox8.ReadOnly = False
        Me.VsTextBox8.Size = New System.Drawing.Size(162, 24)
        Me.VsTextBox8.TabIndex = 12
        Me.VsTextBox8.Text = " "
        Me.VsTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox8.Transparent = False
        Me.VsTextBox8.UseSystemPasswordChar = False
        '
        'VsTextBox7
        '
        Me.VsTextBox7.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox7.Image = Nothing
        Me.VsTextBox7.Location = New System.Drawing.Point(136, 122)
        Me.VsTextBox7.MaxLength = 32767
        Me.VsTextBox7.Multiline = False
        Me.VsTextBox7.Name = "VsTextBox7"
        Me.VsTextBox7.NoRounding = False
        Me.VsTextBox7.ReadOnly = False
        Me.VsTextBox7.Size = New System.Drawing.Size(162, 24)
        Me.VsTextBox7.TabIndex = 11
        Me.VsTextBox7.Text = " "
        Me.VsTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox7.Transparent = False
        Me.VsTextBox7.UseSystemPasswordChar = False
        '
        'VsTextBox6
        '
        Me.VsTextBox6.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox6.Image = Nothing
        Me.VsTextBox6.Location = New System.Drawing.Point(136, 93)
        Me.VsTextBox6.MaxLength = 32767
        Me.VsTextBox6.Multiline = False
        Me.VsTextBox6.Name = "VsTextBox6"
        Me.VsTextBox6.NoRounding = False
        Me.VsTextBox6.ReadOnly = False
        Me.VsTextBox6.Size = New System.Drawing.Size(162, 24)
        Me.VsTextBox6.TabIndex = 10
        Me.VsTextBox6.Text = " "
        Me.VsTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox6.Transparent = False
        Me.VsTextBox6.UseSystemPasswordChar = False
        '
        'VsTextBox5
        '
        Me.VsTextBox5.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox5.Image = Nothing
        Me.VsTextBox5.Location = New System.Drawing.Point(136, 64)
        Me.VsTextBox5.MaxLength = 32767
        Me.VsTextBox5.Multiline = False
        Me.VsTextBox5.Name = "VsTextBox5"
        Me.VsTextBox5.NoRounding = False
        Me.VsTextBox5.ReadOnly = False
        Me.VsTextBox5.Size = New System.Drawing.Size(162, 24)
        Me.VsTextBox5.TabIndex = 9
        Me.VsTextBox5.Text = " "
        Me.VsTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox5.Transparent = False
        Me.VsTextBox5.UseSystemPasswordChar = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.5!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(47, 186)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(54, 14)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Version"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.5!)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(47, 157)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 14)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Copyright"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.5!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(47, 128)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 14)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Company"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.5!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(47, 99)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 14)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Description"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Verdana", 8.5!)
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(47, 70)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 14)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Title"
        '
        'VsButton4
        '
        Me.VsButton4.Customization = "Qj4+/zQzM///////mZmZ/8xwAP8="
        Me.VsButton4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsButton4.Image = Nothing
        Me.VsButton4.Location = New System.Drawing.Point(251, 26)
        Me.VsButton4.Name = "VsButton4"
        Me.VsButton4.NoRounding = False
        Me.VsButton4.Size = New System.Drawing.Size(50, 23)
        Me.VsButton4.TabIndex = 3
        Me.VsButton4.Text = "*.Ico"
        Me.VsButton4.Transparent = False
        '
        'VsTextBox4
        '
        Me.VsTextBox4.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox4.Image = Nothing
        Me.VsTextBox4.Location = New System.Drawing.Point(59, 26)
        Me.VsTextBox4.MaxLength = 32767
        Me.VsTextBox4.Multiline = False
        Me.VsTextBox4.Name = "VsTextBox4"
        Me.VsTextBox4.NoRounding = False
        Me.VsTextBox4.ReadOnly = False
        Me.VsTextBox4.Size = New System.Drawing.Size(185, 24)
        Me.VsTextBox4.TabIndex = 2
        Me.VsTextBox4.Text = "Browse Icon to Use"
        Me.VsTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox4.Transparent = False
        Me.VsTextBox4.UseSystemPasswordChar = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(14, 22)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(35, 30)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'VsGroupBox1
        '
        Me.VsGroupBox1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VsGroupBox1.Controls.Add(Me.VsButton3)
        Me.VsGroupBox1.Controls.Add(Me.VsTextBox3)
        Me.VsGroupBox1.Controls.Add(Me.VsButton2)
        Me.VsGroupBox1.Controls.Add(Me.VsTextBox2)
        Me.VsGroupBox1.Controls.Add(Me.VsButton1)
        Me.VsGroupBox1.Controls.Add(Me.VsTextBox1)
        Me.VsGroupBox1.Customization = "NzMz//////8="
        Me.VsGroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsGroupBox1.Image = Nothing
        Me.VsGroupBox1.Location = New System.Drawing.Point(14, 40)
        Me.VsGroupBox1.Movable = True
        Me.VsGroupBox1.Name = "VsGroupBox1"
        Me.VsGroupBox1.NoRounding = False
        Me.VsGroupBox1.Sizable = True
        Me.VsGroupBox1.Size = New System.Drawing.Size(325, 118)
        Me.VsGroupBox1.SmartBounds = True
        Me.VsGroupBox1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VsGroupBox1.TabIndex = 1
        Me.VsGroupBox1.Text = "Main :"
        Me.VsGroupBox1.TransparencyKey = System.Drawing.Color.Empty
        Me.VsGroupBox1.Transparent = False
        '
        'VsButton3
        '
        Me.VsButton3.Customization = "Qj4+/zQzM///////mZmZ/8xwAP8="
        Me.VsButton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsButton3.Image = Nothing
        Me.VsButton3.Location = New System.Drawing.Point(251, 84)
        Me.VsButton3.Name = "VsButton3"
        Me.VsButton3.NoRounding = False
        Me.VsButton3.Size = New System.Drawing.Size(65, 23)
        Me.VsButton3.TabIndex = 5
        Me.VsButton3.Text = "*.*"
        Me.VsButton3.Transparent = False
        '
        'VsTextBox3
        '
        Me.VsTextBox3.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox3.Enabled = False
        Me.VsTextBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox3.Image = Nothing
        Me.VsTextBox3.Location = New System.Drawing.Point(11, 83)
        Me.VsTextBox3.MaxLength = 32767
        Me.VsTextBox3.Multiline = False
        Me.VsTextBox3.Name = "VsTextBox3"
        Me.VsTextBox3.NoRounding = False
        Me.VsTextBox3.ReadOnly = False
        Me.VsTextBox3.Size = New System.Drawing.Size(228, 24)
        Me.VsTextBox3.TabIndex = 4
        Me.VsTextBox3.Text = "Browse File to Bind"
        Me.VsTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox3.Transparent = False
        Me.VsTextBox3.UseSystemPasswordChar = False
        '
        'VsButton2
        '
        Me.VsButton2.Customization = "Qj4+/zQzM///////mZmZ/8xwAP8="
        Me.VsButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsButton2.Image = Nothing
        Me.VsButton2.Location = New System.Drawing.Point(251, 53)
        Me.VsButton2.Name = "VsButton2"
        Me.VsButton2.NoRounding = False
        Me.VsButton2.Size = New System.Drawing.Size(65, 23)
        Me.VsButton2.TabIndex = 3
        Me.VsButton2.Text = "Genrate"
        Me.VsButton2.Transparent = False
        '
        'VsTextBox2
        '
        Me.VsTextBox2.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox2.Image = Nothing
        Me.VsTextBox2.Location = New System.Drawing.Point(11, 52)
        Me.VsTextBox2.MaxLength = 32767
        Me.VsTextBox2.Multiline = False
        Me.VsTextBox2.Name = "VsTextBox2"
        Me.VsTextBox2.NoRounding = False
        Me.VsTextBox2.ReadOnly = False
        Me.VsTextBox2.Size = New System.Drawing.Size(228, 24)
        Me.VsTextBox2.TabIndex = 2
        Me.VsTextBox2.Text = "Generate Unique Key"
        Me.VsTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox2.Transparent = False
        Me.VsTextBox2.UseSystemPasswordChar = False
        '
        'VsButton1
        '
        Me.VsButton1.Customization = "Qj4+/zQzM///////mZmZ/8xwAP8="
        Me.VsButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsButton1.Image = Nothing
        Me.VsButton1.Location = New System.Drawing.Point(251, 22)
        Me.VsButton1.Name = "VsButton1"
        Me.VsButton1.NoRounding = False
        Me.VsButton1.Size = New System.Drawing.Size(65, 23)
        Me.VsButton1.TabIndex = 1
        Me.VsButton1.Text = "*.Exe"
        Me.VsButton1.Transparent = False
        '
        'VsTextBox1
        '
        Me.VsTextBox1.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox1.Image = Nothing
        Me.VsTextBox1.Location = New System.Drawing.Point(11, 21)
        Me.VsTextBox1.MaxLength = 32767
        Me.VsTextBox1.Multiline = False
        Me.VsTextBox1.Name = "VsTextBox1"
        Me.VsTextBox1.NoRounding = False
        Me.VsTextBox1.ReadOnly = False
        Me.VsTextBox1.Size = New System.Drawing.Size(228, 24)
        Me.VsTextBox1.TabIndex = 0
        Me.VsTextBox1.Text = "Browse File To Crypt"
        Me.VsTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox1.Transparent = False
        Me.VsTextBox1.UseSystemPasswordChar = False
        '
        'VsControlBox1
        '
        Me.VsControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.VsControlBox1.Customization = "8PDw//Dw8P8wLS3/8PDw/w=="
        Me.VsControlBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsControlBox1.Image = Nothing
        Me.VsControlBox1.Location = New System.Drawing.Point(617, 7)
        Me.VsControlBox1.Name = "VsControlBox1"
        Me.VsControlBox1.NoRounding = False
        Me.VsControlBox1.Size = New System.Drawing.Size(44, 18)
        Me.VsControlBox1.TabIndex = 0
        Me.VsControlBox1.Text = "VsControlBox1"
        Me.VsControlBox1.Transparent = False
        '
        'Index
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(672, 358)
        Me.Controls.Add(Me.Theme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Index"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Visual Protector 0.2(Beta)"
        Me.Theme1.ResumeLayout(False)
        Me.VsGroupBox4.ResumeLayout(False)
        Me.VsGroupBox3.ResumeLayout(False)
        Me.VsGroupBox2.ResumeLayout(False)
        Me.VsGroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VsGroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Theme1 As VisualCrypter.Theme
    Friend WithEvents VsGroupBox1 As VisualCrypter.VSGroupBox
    Friend WithEvents VsButton3 As VisualCrypter.VSButton
    Friend WithEvents VsTextBox3 As VisualCrypter.VSTextBox
    Friend WithEvents VsButton2 As VisualCrypter.VSButton
    Friend WithEvents VsTextBox2 As VisualCrypter.VSTextBox
    Friend WithEvents VsButton1 As VisualCrypter.VSButton
    Friend WithEvents VsTextBox1 As VisualCrypter.VSTextBox
    Friend WithEvents VsControlBox1 As VisualCrypter.VSControlBox
    Friend WithEvents VsGroupBox2 As VisualCrypter.VSGroupBox
    Friend WithEvents VsButton4 As VisualCrypter.VSButton
    Friend WithEvents VsTextBox4 As VisualCrypter.VSTextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents VsTextBox9 As VisualCrypter.VSTextBox
    Friend WithEvents VsTextBox8 As VisualCrypter.VSTextBox
    Friend WithEvents VsTextBox7 As VisualCrypter.VSTextBox
    Friend WithEvents VsTextBox6 As VisualCrypter.VSTextBox
    Friend WithEvents VsTextBox5 As VisualCrypter.VSTextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents VsButton5 As VisualCrypter.VSButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents VsGroupBox4 As VisualCrypter.VSGroupBox
    Friend WithEvents VsTextBox13 As VisualCrypter.VSTextBox
    Friend WithEvents VsCheckbox1 As VisualCrypter.VSCheckbox
    Friend WithEvents VsGroupBox3 As VisualCrypter.VSGroupBox
    Friend WithEvents VsRadiobutton3 As VisualCrypter.VSRadiobutton
    Friend WithEvents VsRadiobutton2 As VisualCrypter.VSRadiobutton
    Friend WithEvents VsRadiobutton1 As VisualCrypter.VSRadiobutton
    Friend WithEvents VsButton6 As VisualCrypter.VSButton
    Friend WithEvents VsButton7 As VisualCrypter.VSButton

End Class
