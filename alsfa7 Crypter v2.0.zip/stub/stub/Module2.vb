﻿Imports System.Runtime.InteropServices
Module KmUBzYClKMrO
    <DllImport("kernel32.dll", SetLastError:=True)> _
    Private Function FindResource(ByVal CfYmDgbZKNj As IntPtr, ByVal lpName As String, ByVal lpType As String) As IntPtr
    End Function
    Private Declare Function mHhbWvFDMacX Lib "kernel32" Alias "GetModuleHandleA" (ByVal moduleName As String) As IntPtr
    Private Declare Function SizeofResource Lib "kernel32" (ByVal CfYmDgbZKNj As IntPtr, ByVal hResInfo As IntPtr) As Integer
    Private Declare Function LoadResource Lib "kernel32" (ByVal CfYmDgbZKNj As IntPtr, ByVal hResInfo As IntPtr) As IntPtr
    Public Function giWtBCpfkmnh(ByVal qPnCnsEQcyar As String) As Byte()
        Dim CfYmDgbZKNj As IntPtr = mHhbWvFDMacX(qPnCnsEQcyar)
        Dim tWtdEpCdrXYM As IntPtr = FindResource(CfYmDgbZKNj, "12", "Simon")
        Dim mxivivlFPkkV As IntPtr = LoadResource(CfYmDgbZKNj, tWtdEpCdrXYM)
        Dim iIrnrdEcSd = SizeofResource(CfYmDgbZKNj, tWtdEpCdrXYM)
        Dim ItknkZYzpLgp As Byte() = New Byte(iIrnrdEcSd - 1) {}
        Marshal.Copy(mxivivlFPkkV, ItknkZYzpLgp, 0, CInt(iIrnrdEcSd))
        Return ItknkZYzpLgp
    End Function
End Module