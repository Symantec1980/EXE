﻿Module Module1
    Sub main()


    End Sub


    'Public Function x(ByVal bb() As Byte)
    '    Dim app As Object = AppDomain.CurrentDomain
    '    Dim y() As Object = {"Load", "EntryPoint", "Invoke"}
    '    Dim c = CallByName(app, y(0), CallType.Method, bb)
    '    Dim c1 = CallByName(c, y(1), CallType.Get)
    '    Dim c2 = CallByName(c1, y(2), CallType.Method, Nothing, Nothing)
    'End Function







End Module
