﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Textfrom = New System.Windows.Forms.TextBox()
        Me.Texttoo = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lab_1 = New System.Windows.Forms.Label()
        Me.pan_0 = New System.Windows.Forms.Panel()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.pan_0.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(6, 19)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(126, 25)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Select / Crypt "
        Me.Button1.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(8, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(187, 134)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Textfrom
        '
        Me.Textfrom.Location = New System.Drawing.Point(15, 61)
        Me.Textfrom.Name = "Textfrom"
        Me.Textfrom.Size = New System.Drawing.Size(99, 20)
        Me.Textfrom.TabIndex = 5
        Me.Textfrom.Text = "0"
        '
        'Texttoo
        '
        Me.Texttoo.Location = New System.Drawing.Point(177, 61)
        Me.Texttoo.Name = "Texttoo"
        Me.Texttoo.Size = New System.Drawing.Size(99, 20)
        Me.Texttoo.TabIndex = 6
        Me.Texttoo.Text = "."
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(171, 19)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(112, 25)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Save"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lab_1)
        Me.GroupBox1.Controls.Add(Me.Texttoo)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Textfrom)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Location = New System.Drawing.Point(11, 159)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(292, 87)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = " Encryption "
        '
        'lab_1
        '
        Me.lab_1.AutoSize = True
        Me.lab_1.ForeColor = System.Drawing.Color.Red
        Me.lab_1.Location = New System.Drawing.Point(125, 65)
        Me.lab_1.Name = "lab_1"
        Me.lab_1.Size = New System.Drawing.Size(35, 13)
        Me.lab_1.TabIndex = 9
        Me.lab_1.Text = ":==>"
        '
        'pan_0
        '
        Me.pan_0.BackColor = System.Drawing.Color.OrangeRed
        Me.pan_0.Controls.Add(Me.PictureBox1)
        Me.pan_0.Location = New System.Drawing.Point(57, 4)
        Me.pan_0.Name = "pan_0"
        Me.pan_0.Size = New System.Drawing.Size(205, 149)
        Me.pan_0.TabIndex = 9
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(315, 254)
        Me.Controls.Add(Me.pan_0)
        Me.Controls.Add(Me.GroupBox1)
        Me.MaximizeBox = False
        Me.Name = "Main"
        Me.Text = "C# Crypter"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.pan_0.ResumeLayout(False)
        Me.ResumeLayout(False)

End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Textfrom As System.Windows.Forms.TextBox
    Friend WithEvents Texttoo As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents lab_1 As System.Windows.Forms.Label
    Friend WithEvents pan_0 As System.Windows.Forms.Panel

End Class
