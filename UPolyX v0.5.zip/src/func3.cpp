/*
UPolyX 
written by Delikon/www.delikon.de
All rights reserved*/

#include "head.h"
#include "poly.h"


void gen3(UCHAR * & code,Data* d,int &size){

	int reg[5]={0,2,3,6,7};
	int temp;
	int pos;
	int arrayPos1,arrayPos2;
	size=0;
	char* a;
	
	

	srand(GetTickCount()+d->start);
	
	for(int i=0;i<5;i++){
		pos =rand()%5;
		temp = reg[i];
		reg[i]=reg[pos];
		reg[pos]=temp;
	}	

		do{
	arrayPos1=rand()%5;
	arrayPos2=rand()%5;
	}while(arrayPos1-arrayPos2==0);


	int reg1=reg[arrayPos1];
	int reg2=reg[arrayPos2];

	
	printf("[+] using the xor/xor 4 byte decryptor\n");
	printREG(reg1,reg2);
	
	printf("[+] use 0x%x as manipulationBytes\n",d->ManipulateByte4);
	printf("[+] encrypt %i bytes from address 0x%x till address 0x%x \n",d->distance,d->start,d->start+d->distance);
	/*
0046BFD3   /EB 01           JMP SHORT putty.0046BFD6
0046BFD5   |C3              RETN
0046BFD6   \BB 10BD4600     MOV EBX,putty.0046BD10
0046BFDB    53              PUSH EBX
0046BFDC    B9 B4000000     MOV ECX,0B4
0046BFE1    8133 E6192D00   XOR DWORD PTR DS:[EBX],2D19E6
0046BFE7    83C3 04         ADD EBX,4
0046BFEA    83E9 03         SUB ECX,3
0046BFED  ^ E2 F2           LOOPD SHORT putty.0046BFE1
0046BFEF  ^ EB E4           JMP SHORT putty.0046BFD5	
	*/
	
		JumpForward(code,1,size);
		int label2=SetLabel(size);
		Ret(code,size);
		MoveAddrToReg(code,reg1,d->start,size);
		PushReg(code,reg1,size);
		
		MoveAddrToReg(code,RegEcx,d->distance,size);
		int label=SetLabel(size);
		XorRegFourBytes(code,reg1,d->ManipulateByte4,size);
		AddToReg(code,reg1,4,size);
		//SubFromReg(code,reg1,4,size);
		SubFromReg(code,RegEcx,3,size);
		LoopToLabel(code,label,size);
		JumpBackward(code,label2,size);


	
}

