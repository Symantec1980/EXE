﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices

Public Class Form1

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim str As String = Conversions.ToString(Me.NumericUpDown1.Value)
        If Not String.IsNullOrEmpty(Me.TextBox1.Text) Then
            Dim str2 As String = Convert.ToBase64String(File.ReadAllBytes(Me.TextBox1.Text))
            Dim str3 As String = Conversions.ToString(str2.Length)
            Dim str4 As String = Conversions.ToString(CDbl((Conversions.ToDouble(str3) / Conversions.ToDouble(str))))
            Dim newValue As String = ""
            Dim str5 As String = "францускагафілёзафафранцускагафілёзафафранцускагафілёзафафранцускагафілёзафа"
            Dim num3 As Integer = Conversions.ToInteger(str)
            Dim i As Integer = 1
            Do While (i <= num3)
                Dim str7 As String
                Dim num4 As Integer = CInt(Math.Round(CDbl((Conversions.ToDouble(str3) - 1))))
                Dim num5 As Integer = CInt(Math.Round(Conversions.ToDouble(str)))
                Dim j As Integer = 0
                Do While (((num5 >> &H1F) Xor j) <= ((num5 >> &H1F) Xor num4))
                    str7 = (str7 & Strings.Mid(str2, (j + i), 1))
                    j = (j + num5)
                Loop
                Dim str8 As String = Conversions.ToString(i)
                str5 = (str5 & " & Strings.Mid(філёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаф" & str8 & ", фафранцускагафілёзафаффафранцускагафілёзафаффафранцускагафілёзафаф, 1)")
                newValue = String.Concat(New String() {newValue, "dim філёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаффілёзаф", str8, " as string= """, str7, """" & ChrW(10)})
                str7 = ""
                i += 1
            Loop
            Me.TextBox2.Text = My.Resources.TextFile2.Replace("іншыяффффіншыяффффіншыяффффіншыяффффіншыяффффіншыяфффф", newValue).Replace("сюджанысюджанысюджанысюджанысюджанысюджанысюджанысюджанысюджаны", str5)
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim dialog As New OpenFileDialog With {.Filter = "ExE Files (*.exe) | *.exe"}
        If (dialog.ShowDialog = DialogResult.OK) Then
            Me.TextBox1.Text = dialog.FileName
        End If
    End Sub

End Class