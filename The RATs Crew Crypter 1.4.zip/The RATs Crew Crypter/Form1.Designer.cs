﻿namespace The_RATs_Crew_Crypter
{
    partial class frmTRC_Crypter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            The_RATs_Crew_Crypter.Pigment pigment22 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment23 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment24 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment25 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment26 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment27 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment28 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment29 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment30 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment31 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment32 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment33 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment34 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment35 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment36 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment37 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment38 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment39 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment40 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment41 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment42 = new The_RATs_Crew_Crypter.Pigment();
            this.groupBox5 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbRunPE9 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE8 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE7 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE6 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE5 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE4 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE3 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE2 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE1 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE0 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbDefaultBrowser = new System.Windows.Forms.RadioButton();
            this.rdbInjectInto = new System.Windows.Forms.RadioButton();
            this.txtInjectInto = new System.Windows.Forms.TextBox();
            this.groupBox3 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbXOR = new System.Windows.Forms.RadioButton();
            this.rdbSymentric = new System.Windows.Forms.RadioButton();
            this.rdbRijndael = new System.Windows.Forms.RadioButton();
            this.rdbRC4 = new System.Windows.Forms.RadioButton();
            this.rdbRC2 = new System.Windows.Forms.RadioButton();
            this.rdbTripleDES = new System.Windows.Forms.RadioButton();
            this.rdbDES = new System.Windows.Forms.RadioButton();
            this.btnEncrypt = new The_RATs_Crew_Crypter.FButton();
            this.groupBox2 = new The_RATs_Crew_Crypter.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new The_RATs_Crew_Crypter.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSelectIcon = new The_RATs_Crew_Crypter.FButton();
            this.txtIcon = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectFile = new The_RATs_Crew_Crypter.FButton();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox5
            // 
            this.groupBox5.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox5.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox5.Controls.Add(this.rdbRunPE9);
            this.groupBox5.Controls.Add(this.rdbRunPE8);
            this.groupBox5.Controls.Add(this.rdbRunPE7);
            this.groupBox5.Controls.Add(this.rdbRunPE6);
            this.groupBox5.Controls.Add(this.rdbRunPE5);
            this.groupBox5.Controls.Add(this.rdbRunPE4);
            this.groupBox5.Controls.Add(this.rdbRunPE3);
            this.groupBox5.Controls.Add(this.rdbRunPE2);
            this.groupBox5.Controls.Add(this.rdbRunPE1);
            this.groupBox5.Controls.Add(this.rdbRunPE0);
            this.groupBox5.FillColor = System.Drawing.Color.Transparent;
            this.groupBox5.Location = new System.Drawing.Point(14, 380);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.NoRounding = false;
            this.groupBox5.Size = new System.Drawing.Size(329, 113);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.Text = "groupBox5";
            // 
            // rdbRunPE9
            // 
            this.rdbRunPE9.AutoSize = true;
            this.rdbRunPE9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE9.Location = new System.Drawing.Point(204, 88);
            this.rdbRunPE9.Name = "rdbRunPE9";
            this.rdbRunPE9.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE9.TabIndex = 11;
            this.rdbRunPE9.TabStop = true;
            this.rdbRunPE9.Text = "RunPE 10 (9.5kb)";
            this.rdbRunPE9.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE8
            // 
            this.rdbRunPE8.AutoSize = true;
            this.rdbRunPE8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE8.Location = new System.Drawing.Point(204, 69);
            this.rdbRunPE8.Name = "rdbRunPE8";
            this.rdbRunPE8.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE8.TabIndex = 10;
            this.rdbRunPE8.TabStop = true;
            this.rdbRunPE8.Text = "RunPE 9 (10.0kb)";
            this.rdbRunPE8.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE7
            // 
            this.rdbRunPE7.AutoSize = true;
            this.rdbRunPE7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE7.Location = new System.Drawing.Point(204, 50);
            this.rdbRunPE7.Name = "rdbRunPE7";
            this.rdbRunPE7.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE7.TabIndex = 9;
            this.rdbRunPE7.TabStop = true;
            this.rdbRunPE7.Text = "RunPE 8 (13.0kb)";
            this.rdbRunPE7.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE6
            // 
            this.rdbRunPE6.AutoSize = true;
            this.rdbRunPE6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE6.Location = new System.Drawing.Point(204, 30);
            this.rdbRunPE6.Name = "rdbRunPE6";
            this.rdbRunPE6.Size = new System.Drawing.Size(107, 17);
            this.rdbRunPE6.TabIndex = 8;
            this.rdbRunPE6.Text = "RunPE 7 (8kb)";
            this.rdbRunPE6.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE5
            // 
            this.rdbRunPE5.AutoSize = true;
            this.rdbRunPE5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE5.Location = new System.Drawing.Point(204, 11);
            this.rdbRunPE5.Name = "rdbRunPE5";
            this.rdbRunPE5.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE5.TabIndex = 7;
            this.rdbRunPE5.TabStop = true;
            this.rdbRunPE5.Text = "RunPE 6 (8.5kb)";
            this.rdbRunPE5.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE4
            // 
            this.rdbRunPE4.AutoSize = true;
            this.rdbRunPE4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE4.Location = new System.Drawing.Point(18, 88);
            this.rdbRunPE4.Name = "rdbRunPE4";
            this.rdbRunPE4.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE4.TabIndex = 6;
            this.rdbRunPE4.Text = "RunPE 5 (3.5kb)";
            this.rdbRunPE4.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE3
            // 
            this.rdbRunPE3.AutoSize = true;
            this.rdbRunPE3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE3.Location = new System.Drawing.Point(18, 69);
            this.rdbRunPE3.Name = "rdbRunPE3";
            this.rdbRunPE3.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE3.TabIndex = 3;
            this.rdbRunPE3.TabStop = true;
            this.rdbRunPE3.Text = "RunPE 4 (3.5kb)";
            this.rdbRunPE3.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE2
            // 
            this.rdbRunPE2.AutoSize = true;
            this.rdbRunPE2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE2.Location = new System.Drawing.Point(18, 50);
            this.rdbRunPE2.Name = "rdbRunPE2";
            this.rdbRunPE2.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE2.TabIndex = 2;
            this.rdbRunPE2.Text = "RunPE 3 (12.5kb)";
            this.rdbRunPE2.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE1
            // 
            this.rdbRunPE1.AutoSize = true;
            this.rdbRunPE1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE1.Location = new System.Drawing.Point(18, 30);
            this.rdbRunPE1.Name = "rdbRunPE1";
            this.rdbRunPE1.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE1.TabIndex = 1;
            this.rdbRunPE1.Text = "RunPE 2 (3.0kb)";
            this.rdbRunPE1.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE0
            // 
            this.rdbRunPE0.AutoSize = true;
            this.rdbRunPE0.Checked = true;
            this.rdbRunPE0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE0.Location = new System.Drawing.Point(18, 11);
            this.rdbRunPE0.Name = "rdbRunPE0";
            this.rdbRunPE0.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE0.TabIndex = 0;
            this.rdbRunPE0.TabStop = true;
            this.rdbRunPE0.Text = "RunPE 1 (13.5kb)";
            this.rdbRunPE0.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.rdbDefaultBrowser);
            this.groupBox4.Controls.Add(this.rdbInjectInto);
            this.groupBox4.Controls.Add(this.txtInjectInto);
            this.groupBox4.FillColor = System.Drawing.Color.Transparent;
            this.groupBox4.Location = new System.Drawing.Point(14, 334);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.NoRounding = false;
            this.groupBox4.Size = new System.Drawing.Size(329, 40);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.Text = "groupBox4";
            // 
            // rdbDefaultBrowser
            // 
            this.rdbDefaultBrowser.AutoSize = true;
            this.rdbDefaultBrowser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDefaultBrowser.Location = new System.Drawing.Point(204, 11);
            this.rdbDefaultBrowser.Name = "rdbDefaultBrowser";
            this.rdbDefaultBrowser.Size = new System.Drawing.Size(117, 17);
            this.rdbDefaultBrowser.TabIndex = 9;
            this.rdbDefaultBrowser.TabStop = true;
            this.rdbDefaultBrowser.Text = "Default Browser";
            this.rdbDefaultBrowser.UseVisualStyleBackColor = true;
            // 
            // rdbInjectInto
            // 
            this.rdbInjectInto.AutoSize = true;
            this.rdbInjectInto.Checked = true;
            this.rdbInjectInto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInjectInto.Location = new System.Drawing.Point(18, 11);
            this.rdbInjectInto.Name = "rdbInjectInto";
            this.rdbInjectInto.Size = new System.Drawing.Size(88, 17);
            this.rdbInjectInto.TabIndex = 8;
            this.rdbInjectInto.TabStop = true;
            this.rdbInjectInto.Text = "Inject into:";
            this.rdbInjectInto.UseVisualStyleBackColor = true;
            // 
            // txtInjectInto
            // 
            this.txtInjectInto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtInjectInto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInjectInto.ForeColor = System.Drawing.Color.Lime;
            this.txtInjectInto.Location = new System.Drawing.Point(112, 9);
            this.txtInjectInto.Name = "txtInjectInto";
            this.txtInjectInto.Size = new System.Drawing.Size(82, 21);
            this.txtInjectInto.TabIndex = 7;
            this.txtInjectInto.Text = "svchost.exe";
            // 
            // groupBox3
            // 
            this.groupBox3.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.rdbXOR);
            this.groupBox3.Controls.Add(this.rdbSymentric);
            this.groupBox3.Controls.Add(this.rdbRijndael);
            this.groupBox3.Controls.Add(this.rdbRC4);
            this.groupBox3.Controls.Add(this.rdbRC2);
            this.groupBox3.Controls.Add(this.rdbTripleDES);
            this.groupBox3.Controls.Add(this.rdbDES);
            this.groupBox3.FillColor = System.Drawing.Color.Transparent;
            this.groupBox3.Location = new System.Drawing.Point(14, 272);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.NoRounding = false;
            this.groupBox3.Size = new System.Drawing.Size(329, 56);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.Text = "groupBox3";
            // 
            // rdbXOR
            // 
            this.rdbXOR.AutoSize = true;
            this.rdbXOR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbXOR.Location = new System.Drawing.Point(267, 7);
            this.rdbXOR.Name = "rdbXOR";
            this.rdbXOR.Size = new System.Drawing.Size(50, 17);
            this.rdbXOR.TabIndex = 6;
            this.rdbXOR.Text = "XOR";
            this.rdbXOR.UseVisualStyleBackColor = true;
            // 
            // rdbSymentric
            // 
            this.rdbSymentric.AutoSize = true;
            this.rdbSymentric.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbSymentric.Location = new System.Drawing.Point(167, 30);
            this.rdbSymentric.Name = "rdbSymentric";
            this.rdbSymentric.Size = new System.Drawing.Size(83, 17);
            this.rdbSymentric.TabIndex = 5;
            this.rdbSymentric.Text = "Symentric";
            this.rdbSymentric.UseVisualStyleBackColor = true;
            // 
            // rdbRijndael
            // 
            this.rdbRijndael.AutoSize = true;
            this.rdbRijndael.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRijndael.Location = new System.Drawing.Point(167, 7);
            this.rdbRijndael.Name = "rdbRijndael";
            this.rdbRijndael.Size = new System.Drawing.Size(71, 17);
            this.rdbRijndael.TabIndex = 4;
            this.rdbRijndael.Text = "Rijndael";
            this.rdbRijndael.UseVisualStyleBackColor = true;
            // 
            // rdbRC4
            // 
            this.rdbRC4.AutoSize = true;
            this.rdbRC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC4.Location = new System.Drawing.Point(103, 30);
            this.rdbRC4.Name = "rdbRC4";
            this.rdbRC4.Size = new System.Drawing.Size(49, 17);
            this.rdbRC4.TabIndex = 3;
            this.rdbRC4.Text = "RC4";
            this.rdbRC4.UseVisualStyleBackColor = true;
            // 
            // rdbRC2
            // 
            this.rdbRC2.AutoSize = true;
            this.rdbRC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC2.Location = new System.Drawing.Point(103, 7);
            this.rdbRC2.Name = "rdbRC2";
            this.rdbRC2.Size = new System.Drawing.Size(49, 17);
            this.rdbRC2.TabIndex = 2;
            this.rdbRC2.Text = "RC2";
            this.rdbRC2.UseVisualStyleBackColor = true;
            // 
            // rdbTripleDES
            // 
            this.rdbTripleDES.AutoSize = true;
            this.rdbTripleDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbTripleDES.Location = new System.Drawing.Point(18, 30);
            this.rdbTripleDES.Name = "rdbTripleDES";
            this.rdbTripleDES.Size = new System.Drawing.Size(81, 17);
            this.rdbTripleDES.TabIndex = 1;
            this.rdbTripleDES.Text = "TripleDES";
            this.rdbTripleDES.UseVisualStyleBackColor = true;
            // 
            // rdbDES
            // 
            this.rdbDES.AutoSize = true;
            this.rdbDES.Checked = true;
            this.rdbDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDES.Location = new System.Drawing.Point(18, 7);
            this.rdbDES.Name = "rdbDES";
            this.rdbDES.Size = new System.Drawing.Size(49, 17);
            this.rdbDES.TabIndex = 0;
            this.rdbDES.TabStop = true;
            this.rdbDES.Text = "DES";
            this.rdbDES.UseVisualStyleBackColor = true;
            // 
            // btnEncrypt
            // 
            pigment22.Name = "Border";
            pigment22.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment23.Name = "Backcolor";
            pigment23.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment24.Name = "Highlight";
            pigment24.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment25.Name = "Gradient1";
            pigment25.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment26.Name = "Gradient2";
            pigment26.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment27.Name = "Text Color";
            pigment27.Value = System.Drawing.Color.White;
            pigment28.Name = "Text Shadow";
            pigment28.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnEncrypt.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment22,
        pigment23,
        pigment24,
        pigment25,
        pigment26,
        pigment27,
        pigment28};
            this.btnEncrypt.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnEncrypt.Location = new System.Drawing.Point(136, 499);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Shadow = true;
            this.btnEncrypt.Size = new System.Drawing.Size(91, 27);
            this.btnEncrypt.TabIndex = 4;
            this.btnEncrypt.Text = "ENCRYPT";
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.FillColor = System.Drawing.Color.Transparent;
            this.groupBox2.Location = new System.Drawing.Point(14, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.NoRounding = false;
            this.groupBox2.Size = new System.Drawing.Size(329, 138);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.Text = "groupBox2";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::The_RATs_Crew_Crypter.Properties.Resources.ratscrewlogo;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(323, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnSelectIcon);
            this.groupBox1.Controls.Add(this.txtIcon);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSelectFile);
            this.groupBox1.Controls.Add(this.txtFile);
            this.groupBox1.FillColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(14, 156);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.NoRounding = false;
            this.groupBox1.Size = new System.Drawing.Size(329, 110);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.Text = "groupBox1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label2.Location = new System.Drawing.Point(15, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Icon:";
            // 
            // btnSelectIcon
            // 
            pigment29.Name = "Border";
            pigment29.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment30.Name = "Backcolor";
            pigment30.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment31.Name = "Highlight";
            pigment31.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment32.Name = "Gradient1";
            pigment32.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment33.Name = "Gradient2";
            pigment33.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment34.Name = "Text Color";
            pigment34.Value = System.Drawing.Color.White;
            pigment35.Name = "Text Shadow";
            pigment35.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectIcon.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment29,
        pigment30,
        pigment31,
        pigment32,
        pigment33,
        pigment34,
        pigment35};
            this.btnSelectIcon.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectIcon.Location = new System.Drawing.Point(263, 72);
            this.btnSelectIcon.Name = "btnSelectIcon";
            this.btnSelectIcon.Shadow = true;
            this.btnSelectIcon.Size = new System.Drawing.Size(54, 23);
            this.btnSelectIcon.TabIndex = 5;
            this.btnSelectIcon.Text = "...";
            this.btnSelectIcon.Click += new System.EventHandler(this.btnSelectIcon_Click);
            // 
            // txtIcon
            // 
            this.txtIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIcon.ForeColor = System.Drawing.Color.Lime;
            this.txtIcon.Location = new System.Drawing.Point(18, 74);
            this.txtIcon.Name = "txtIcon";
            this.txtIcon.Size = new System.Drawing.Size(230, 21);
            this.txtIcon.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label1.Location = new System.Drawing.Point(15, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "File to be encrypted:";
            // 
            // btnSelectFile
            // 
            pigment36.Name = "Border";
            pigment36.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment37.Name = "Backcolor";
            pigment37.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment38.Name = "Highlight";
            pigment38.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment39.Name = "Gradient1";
            pigment39.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment40.Name = "Gradient2";
            pigment40.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment41.Name = "Text Color";
            pigment41.Value = System.Drawing.Color.White;
            pigment42.Name = "Text Shadow";
            pigment42.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectFile.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment36,
        pigment37,
        pigment38,
        pigment39,
        pigment40,
        pigment41,
        pigment42};
            this.btnSelectFile.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectFile.Location = new System.Drawing.Point(263, 26);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Shadow = true;
            this.btnSelectFile.Size = new System.Drawing.Size(54, 23);
            this.btnSelectFile.TabIndex = 2;
            this.btnSelectFile.Text = "...";
            this.btnSelectFile.Click += new System.EventHandler(this.btnEncryptedFileSearch_Click);
            // 
            // txtFile
            // 
            this.txtFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFile.ForeColor = System.Drawing.Color.Lime;
            this.txtFile.Location = new System.Drawing.Point(18, 28);
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(230, 21);
            this.txtFile.TabIndex = 1;
            // 
            // frmTRC_Crypter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ClientSize = new System.Drawing.Size(352, 533);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmTRC_Crypter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TRC Crypter ~ Version 1.4";
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFile;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private FButton btnSelectFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private FButton btnSelectIcon;
        private System.Windows.Forms.TextBox txtIcon;
        private FButton btnEncrypt;
        private GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rdbTripleDES;
        private System.Windows.Forms.RadioButton rdbDES;
        private System.Windows.Forms.RadioButton rdbXOR;
        private System.Windows.Forms.RadioButton rdbSymentric;
        private System.Windows.Forms.RadioButton rdbRijndael;
        private System.Windows.Forms.RadioButton rdbRC4;
        private System.Windows.Forms.RadioButton rdbRC2;
        private GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdbDefaultBrowser;
        private System.Windows.Forms.RadioButton rdbInjectInto;
        private System.Windows.Forms.TextBox txtInjectInto;
        private GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdbRunPE3;
        private System.Windows.Forms.RadioButton rdbRunPE2;
        private System.Windows.Forms.RadioButton rdbRunPE1;
        private System.Windows.Forms.RadioButton rdbRunPE0;
        private System.Windows.Forms.RadioButton rdbRunPE9;
        private System.Windows.Forms.RadioButton rdbRunPE8;
        private System.Windows.Forms.RadioButton rdbRunPE7;
        private System.Windows.Forms.RadioButton rdbRunPE6;
        private System.Windows.Forms.RadioButton rdbRunPE5;
        private System.Windows.Forms.RadioButton rdbRunPE4;
    }
}

