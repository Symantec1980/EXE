﻿Public Class Form3
    Dim fox(65) As String


    Private Sub FlatButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton1.Click



        fox(1) = My.Resources.String4.Replace("%122%", s1(5))
        t1.Text = fox(1)

        fox(2) = My.Resources.String4.Replace("%122%", s2(5))
        t2.Text = fox(2)

        fox(3) = My.Resources.String4.Replace("%122%", s3(5))
        t3.Text = fox(3)


        fox(4) = My.Resources.String4.Replace("%122%", s4(5))
        t4.Text = fox(4)

        fox(5) = My.Resources.String4.Replace("%122%", s5(5))
        t5.Text = fox(5)

        fox(6) = My.Resources.String4.Replace("%122%", s6(5))
        t6.Text = fox(6)

        fox(7) = My.Resources.String4.Replace("%122%", s7(5))
        t7.Text = fox(7)


        fox(8) = My.Resources.String4.Replace("%122%", s8(5))
        t8.Text = fox(8)

        fox(9) = My.Resources.String4.Replace("%122%", s9(5))
        t9.Text = fox(9)

        fox(10) = My.Resources.String4.Replace("%122%", s10(5))
        t10.Text = fox(10)

        fox(11) = My.Resources.String4.Replace("%122%", s11(5))
        t11.Text = fox(11)

        fox(12) = My.Resources.String4.Replace("%122%", s12(5))
        t12.Text = fox(12)

        fox(13) = My.Resources.String4.Replace("%122%", s13(5))
        t13.Text = fox(13)

        fox(14) = My.Resources.String4.Replace("%122%", s14(5))
        t14.Text = fox(14)

        fox(15) = My.Resources.String4.Replace("%122%", s15(5))
        t15.Text = fox(15)

        fox(16) = My.Resources.String4.Replace("%122%", s16(5))
        t16.Text = fox(16)


        fox(17) = My.Resources.String4.Replace("%122%", s17(5))
        t17.Text = fox(17)

        fox(18) = My.Resources.String4.Replace("%122%", s18(5))
        t18.Text = fox(18)

        fox(19) = My.Resources.String4.Replace("%122%", s19(5))
        t19.Text = fox(19)

        fox(20) = My.Resources.String4.Replace("%122%", s20(5))
        t20.Text = fox(20)

        fox(21) = My.Resources.String4.Replace("%122%", s21(5))
        t21.Text = fox(21)

        fox(22) = My.Resources.String4.Replace("%122%", s22(5))
        t22.Text = fox(22)

        fox(23) = My.Resources.String4.Replace("%122%", s23(5))
        t23.Text = fox(23)

        fox(24) = My.Resources.String4.Replace("%122%", s24(5))
        t24.Text = fox(24)

        fox(25) = My.Resources.String4.Replace("%122%", s25(5))
        t25.Text = fox(25)

        fox(26) = My.Resources.String4.Replace("%122%", s26(5))
        t26.Text = fox(26)

        fox(27) = My.Resources.String4.Replace("%122%", s27(5))
        t27.Text = fox(27)

        fox(28) = My.Resources.String4.Replace("%122%", s28(5))
        t28.Text = fox(28)

        fox(29) = My.Resources.String4.Replace("%122%", s29(5))
        t29.Text = fox(29)

        fox(30) = My.Resources.String4.Replace("%122%", s30(5))
        t30.Text = fox(30)


        fox(31) = My.Resources.String4.Replace("%122%", s31(5))
        t31.Text = fox(31)

        fox(32) = My.Resources.String4.Replace("%122%", s32(5))
        t32.Text = fox(32)

        fox(33) = My.Resources.String4.Replace("%122%", s33(5))
        t33.Text = fox(33)

        fox(34) = My.Resources.String4.Replace("%122%", s34(5))
        t34.Text = fox(34)

        fox(35) = My.Resources.String4.Replace("%122%", s35(5))
        t35.Text = fox(35)

        fox(36) = My.Resources.String4.Replace("%122%", s36(5))
        t36.Text = fox(36)

        fox(37) = My.Resources.String4.Replace("%122%", s37(5))
        t37.Text = fox(37)

        fox(38) = My.Resources.String4.Replace("%122%", s38(5))
        t38.Text = fox(38)


        fox(39) = My.Resources.String4.Replace("%122%", s39(5))
        t39.Text = fox(39)

        fox(40) = My.Resources.String4.Replace("%122%", s40(5))
        t40.Text = fox(40)

        fox(41) = My.Resources.String4.Replace("%122%", s41(5))
        t41.Text = fox(41)

        fox(42) = My.Resources.String4.Replace("%122%", s42(5))
        t42.Text = fox(42)

        fox(43) = My.Resources.String4.Replace("%122%", s43(5))
        t43.Text = fox(43)

        fox(44) = My.Resources.String4.Replace("%122%", s44(5))
        t44.Text = fox(44)


        fox(45) = My.Resources.String4.Replace("%122%", s45(5))
        t45.Text = fox(45)

        fox(46) = My.Resources.String4.Replace("%122%", s46(5))
        t46.Text = fox(46)

        fox(47) = My.Resources.String4.Replace("%122%", s47(5))
        t47.Text = fox(47)

        fox(48) = My.Resources.String4.Replace("%122%", s48(5))
        t48.Text = fox(48)

        fox(49) = My.Resources.String4.Replace("%122%", s49(5))
        t49.Text = fox(49)

        fox(50) = My.Resources.String4.Replace("%122%", s50(5))
        t50.Text = fox(50)

        fox(51) = My.Resources.String4.Replace("%122%", s51(5))
        t51.Text = fox(51)

        fox(52) = My.Resources.String4.Replace("%122%", s52(5))
        t52.Text = fox(52)


        Dim lol As String = My.Resources.surs2
        Dim lolx As String

        lolx = lol.Replace("%1%", t1.Text).Replace("%2%", t2.Text).Replace("%3%", t3.Text).Replace("%4%", t4.Text).Replace("%5%", t5.Text).Replace("%6%", t6.Text).Replace("%7%", t7.Text).Replace("%8%", t8.Text).Replace("%9%", t9.Text).Replace("%10%", t10.Text).Replace("%11%", t11.Text).Replace("%12%", t12.Text).Replace("%13%", t13.Text).Replace("%14%", t14.Text).Replace("%15%", t15.Text).Replace("%16%", t16.Text).Replace("%17%", t17.Text).Replace("%18%", t18.Text).Replace("%19%", t19.Text).Replace("%20%", t20.Text).Replace("%21%", t21.Text).Replace("%22%", t22.Text).Replace("%23%", t23.Text).Replace("%24%", t24.Text).Replace("%25%", t25.Text).Replace("%26%", t26.Text).Replace("%27%", t27.Text).Replace("%28%", t28.Text).Replace("%29%", t29.Text).Replace("%30%", t30.Text).Replace("%31%", t31.Text).Replace("%32%", t32.Text).Replace("%33%", t33.Text).Replace("%34%", t34.Text).Replace("%35%", t35.Text).Replace("%36%", t36.Text).Replace("%37%", t37.Text).Replace("%38%", t38.Text).Replace("%39%", t39.Text).Replace("%40%", t40.Text).Replace("%41%", t41.Text).Replace("%42%", t42.Text).Replace("%43%", t43.Text).Replace("%44%", t44.Text).Replace("%45%", t45.Text).Replace("%46%", t46.Text).Replace("%47%", t47.Text).Replace("%48%", t48.Text).Replace("%49%", t49.Text).Replace("%50%", t50.Text).Replace("%51%", t51.Text).Replace("%52%", t52.Text)

        r1.Text = lolx


        Dim ff As String = My.Resources.surcone
        Dim ffx As String


        ffx = ff.Replace("%1%", t1.Text).Replace("%2%", t2.Text).Replace("%3%", t3.Text).Replace("%4%", t4.Text).Replace("%5%", t5.Text).Replace("%6%", t6.Text).Replace("%7%", t7.Text).Replace("%8%", t8.Text).Replace("%9%", t9.Text).Replace("%10%", t10.Text).Replace("%11%", t11.Text).Replace("%12%", t12.Text).Replace("%13%", t13.Text).Replace("%14%", t14.Text).Replace("%15%", t15.Text).Replace("%16%", t16.Text).Replace("%17%", t17.Text).Replace("%18%", t18.Text).Replace("%19%", t19.Text).Replace("%20%", t20.Text).Replace("%21%", t21.Text).Replace("%22%", t22.Text).Replace("%23%", t23.Text).Replace("%24%", t24.Text).Replace("%25%", t25.Text).Replace("%26%", t26.Text).Replace("%27%", t27.Text).Replace("%28%", t28.Text).Replace("%29%", t29.Text).Replace("%30%", t30.Text).Replace("%31%", t31.Text).Replace("%32%", t32.Text).Replace("%33%", t33.Text).Replace("%34%", t34.Text).Replace("%35%", t35.Text).Replace("%36%", t36.Text).Replace("%37%", t37.Text).Replace("%38%", t38.Text).Replace("%39%", t39.Text).Replace("%40%", t40.Text).Replace("%41%", t41.Text).Replace("%42%", t42.Text).Replace("%43%", t43.Text).Replace("%44%", t44.Text).Replace("%45%", t45.Text).Replace("%46%", t46.Text).Replace("%47%", t47.Text).Replace("%48%", t48.Text).Replace("%49%", t49.Text).Replace("%50%", t50.Text).Replace("%51%", t51.Text).Replace("%52%", t52.Text)


        r2.Text = ffx


    End Sub

    Public Function s1(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "@#$"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s2(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "%^&"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s3(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "*()"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s4(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "{}:"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function




    Public Function s5(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "וחלתתלום"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s6(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "پھؤ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s7(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "щ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s8(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "Бй"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function


    Public Function s9(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "éúá"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function


    Public Function s10(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ụị"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function



    Public Function s11(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ਸਹੈ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s12(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ਦਾਆ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s13(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ਹੋਣ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function


    Public Function s14(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ਨ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s15(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ਤਮਿੱਤ "
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s16(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ক"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s17(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "আশা"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s18(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "প্রিপ্রিপ্রি"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s19(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ЯшЯЯ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s20(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "இரு"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s21(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "க்க"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s22(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "நான்"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s23(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "எப்படி"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s24(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ழி"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s25(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ற"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s26(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "டு"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s27(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ண்"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s28(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "าราร"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s29(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ธีกธีก"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s30(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "นวิ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s31(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "เป็เป็"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s32(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "มัมัมัมั"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s33(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ฉัฉัฉัฉั"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s34(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "సిన"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s35(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "వల"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s36(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "నుకా"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function


    Public Function s37(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "య"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s38(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ითით"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s39(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "როგ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s40(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ឡេង"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s41(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "បញ្ចេញ"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s42(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "д"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s43(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "මිතුරන්"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s44(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "රම්"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s45(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "我的朋友"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function


    Public Function s46(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "姐姐姐姐"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s47(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "哪里哪里"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Public Function s48(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "요요"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s49(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "你在你在"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s50(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "א"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s51(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "רב"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function
    Public Function s52(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "તેકેવીરી"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles Generating_Algorithm.Click

    End Sub

    Private Sub FlatCheckBox1_CheckedChanged(sender As Object) Handles FlatCheckBox1.CheckedChanged
        r1.SelectAll()
        r1.Cut()

        If FlatCheckBox1.Checked = True Then

            FlatCheckBox1.Text = "DONE"


        ElseIf FlatCheckBox1.Checked = False Then
            FlatCheckBox1.Text = "Copy ENC"


        End If



    End Sub

    Private Sub FlatCheckBox2_CheckedChanged(sender As Object) Handles FlatCheckBox2.CheckedChanged
        r2.SelectAll()
        r2.Cut()

        If FlatCheckBox2.Checked = True Then

            FlatCheckBox2.Text = "DONE"


        ElseIf FlatCheckBox2.Checked = False Then
            FlatCheckBox2.Text = "Copy ENC"


        End If
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Form1.Show()
        Me.Hide()

    End Sub
End Class