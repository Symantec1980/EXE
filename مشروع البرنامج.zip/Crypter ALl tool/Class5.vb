﻿Public Class Class5
    Public Shared Function XOREncrypt(ByVal up As Byte(), ByVal BB2 As String) As Byte()
        Dim CL As Byte() = System.Text.Encoding.ASCII.GetBytes(BB2)
        Randomize()
        Dim FP As Integer = Int((255 - 0 + 1) * Rnd()) + 1
        Dim BA(up.Length) As Byte
        Dim KA As Integer
        For MP As Integer = 0 To up.Length - 1
            BA(MP) += (up(MP) Xor CL(KA)) Xor FP
            If KA = BB2.Length - 1 Then KA = 0 Else KA = KA + 1
        Next
        BA(up.Length) = 112 Xor FP
        Return BA
    End Function

    Public Function XORDcrypt(ByVal BB As Byte(), ByVal CC As String) As Byte()
        Dim AA As Byte() = System.Text.Encoding.ASCII.GetBytes(CC)
        Dim OO As Integer = BB(BB.Length - 1) Xor 112
        Dim QQ(BB.Length) As Byte
        Dim JJ As Integer
        For GG As Integer = 0 To BB.Length - 1
            QQ(GG) = (BB(GG) Xor OO) Xor AA(JJ)
            If JJ = CC.Length - 1 Then JJ = 0 Else JJ = JJ + 1
        Next
        ReDim Preserve QQ(BB.Length - 2)
        Return QQ
    End Function


End Class
