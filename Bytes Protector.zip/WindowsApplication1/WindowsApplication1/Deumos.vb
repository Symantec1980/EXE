﻿Imports System.Drawing.Drawing2D
Imports System.ComponentModel
Imports System.Runtime.InteropServices

MustInherit Class Theme
    Inherits ContainerControl

#Region " Initialization "

    Protected G As Graphics
    Sub New()
        SetStyle(DirectCast(139270, ControlStyles), True)
    End Sub

    Private ParentIsForm As Boolean
    Protected Overrides Sub OnHandleCreated(ByVal e As EventArgs)
        Dock = DockStyle.Fill
        ParentIsForm = TypeOf Parent Is Form
        If ParentIsForm Then
            If Not _TransparencyKey = Color.Empty Then ParentForm.TransparencyKey = _TransparencyKey
            ParentForm.FormBorderStyle = FormBorderStyle.None
        End If

        'If Not DesignMode Then
        '    Dim T As New Threading.Thread(AddressOf Monitor)
        '    T.Start()
        'End If

        MyBase.OnHandleCreated(e)
    End Sub

    Overrides Property Text As String
        Get
            Return MyBase.Text
        End Get
        Set(ByVal v As String)
            MyBase.Text = v
            Invalidate()
        End Set
    End Property
#End Region

#Region " Sizing and Movement "

    Private _Resizable As Boolean = True
    Property Resizable() As Boolean
        Get
            Return _Resizable
        End Get
        Set(ByVal value As Boolean)
            _Resizable = value
        End Set
    End Property

    Private _MoveHeight As Integer = 24
    Property MoveHeight() As Integer
        Get
            Return _MoveHeight
        End Get
        Set(ByVal v As Integer)
            _MoveHeight = v
            Header = New Rectangle(7, 7, Width - 14, _MoveHeight - 7)
        End Set
    End Property

    Private Flag As IntPtr
    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        If Not e.Button = MouseButtons.Left Then Return
        If ParentIsForm AndAlso ParentForm.WindowState = FormWindowState.Maximized Then Return

        If Header.Contains(e.Location) Then
            Flag = New IntPtr(2)
        ElseIf Current.Position = 0 Or Not _Resizable Then
            Return
        Else
            Flag = New IntPtr(Current.Position)
        End If

        Capture = False
        DefWndProc(Message.Create(Parent.Handle, 161, Flag, Nothing))

        MyBase.OnMouseDown(e)
    End Sub

    Private Structure Pointer
        ReadOnly Cursor As Cursor, Position As Byte
        Sub New(ByVal c As Cursor, ByVal p As Byte)
            Cursor = c
            Position = p
        End Sub
    End Structure

    Private F1, F2, F3, F4 As Boolean, PTC As Point
    Private Function GetPointer() As Pointer
        PTC = PointToClient(MousePosition)
        F1 = PTC.X < 7
        F2 = PTC.X > Width - 7
        F3 = PTC.Y < 7
        F4 = PTC.Y > Height - 7

        If F1 AndAlso F3 Then Return New Pointer(Cursors.SizeNWSE, 13)
        If F1 AndAlso F4 Then Return New Pointer(Cursors.SizeNESW, 16)
        If F2 AndAlso F3 Then Return New Pointer(Cursors.SizeNESW, 14)
        If F2 AndAlso F4 Then Return New Pointer(Cursors.SizeNWSE, 17)
        If F1 Then Return New Pointer(Cursors.SizeWE, 10)
        If F2 Then Return New Pointer(Cursors.SizeWE, 11)
        If F3 Then Return New Pointer(Cursors.SizeNS, 12)
        If F4 Then Return New Pointer(Cursors.SizeNS, 15)
        Return New Pointer(Cursors.Default, 0)
    End Function

    Private Current, Pending As Pointer
    Private Sub SetCurrent()
        Pending = GetPointer()
        If Current.Position = Pending.Position Then Return
        Current = GetPointer()
        Cursor = Current.Cursor
    End Sub

    Protected Overrides Sub OnMouseMove(ByVal e As MouseEventArgs)
        If _Resizable Then SetCurrent()
        MyBase.OnMouseMove(e)
    End Sub

    'Private Previous As Date
    'Private CurrentT As Date

    Protected Header As Rectangle
    Protected Overrides Sub OnSizeChanged(ByVal e As EventArgs)
        If Width = 0 OrElse Height = 0 Then Return

        'SizeChanging = True
        'CurrentT = Date.Now
        'If (CurrentT - Previous).TotalMilliseconds < 50 Then Return Else Previous = CurrentT

        Header = New Rectangle(7, 7, Width - 14, _MoveHeight - 7)
        Invalidate()
        MyBase.OnSizeChanged(e)
    End Sub

#End Region

#Region " Convienence "

    MustOverride Sub PaintHook()
    Protected NotOverridable Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If Width = 0 OrElse Height = 0 Then Return
        G = e.Graphics
        PaintHook()
    End Sub

    Private _TransparencyKey As Color
    Property TransparencyKey() As Color
        Get
            Return _TransparencyKey
        End Get
        Set(ByVal v As Color)
            _TransparencyKey = v
            Invalidate()
        End Set
    End Property

    Private _Image As Image
    Property Image() As Image
        Get
            Return _Image
        End Get
        Set(ByVal value As Image)
            _Image = value
            Invalidate()
        End Set
    End Property
    ReadOnly Property ImageWidth() As Integer
        Get
            If _Image Is Nothing Then Return 0
            Return _Image.Width
        End Get
    End Property

    Private _Size As Size
    Private _Rectangle As Rectangle
    Private _Gradient As LinearGradientBrush
    Private _Brush As SolidBrush

    Protected Sub DrawCorners(ByVal c As Color, ByVal rect As Rectangle)
        _Brush = New SolidBrush(c)
        G.FillRectangle(_Brush, rect.X, rect.Y, 1, 1)
        G.FillRectangle(_Brush, rect.X + (rect.Width - 1), rect.Y, 1, 1)
        G.FillRectangle(_Brush, rect.X, rect.Y + (rect.Height - 1), 1, 1)
        G.FillRectangle(_Brush, rect.X + (rect.Width - 1), rect.Y + (rect.Height - 1), 1, 1)
    End Sub

    Protected Sub DrawBorders(ByVal p1 As Pen, ByVal p2 As Pen, ByVal rect As Rectangle)
        G.DrawRectangle(p1, rect.X, rect.Y, rect.Width - 1, rect.Height - 1)
        G.DrawRectangle(p2, rect.X + 1, rect.Y + 1, rect.Width - 3, rect.Height - 3)
    End Sub

    Protected Sub DrawText(ByVal a As HorizontalAlignment, ByVal c As Color, ByVal x As Integer)
        DrawText(a, c, x, 0)
    End Sub
    Protected Sub DrawText(ByVal a As HorizontalAlignment, ByVal c As Color, ByVal x As Integer, ByVal y As Integer)
        If String.IsNullOrEmpty(Text) Then Return
        _Size = G.MeasureString(Text, Font).ToSize
        _Brush = New SolidBrush(c)

        Select Case a
            Case HorizontalAlignment.Left
                G.DrawString(Text, Font, _Brush, x, _MoveHeight \ 2 - _Size.Height \ 2 + y)
            Case HorizontalAlignment.Right
                G.DrawString(Text, Font, _Brush, Width - _Size.Width - x, _MoveHeight \ 2 - _Size.Height \ 2 + y)
            Case HorizontalAlignment.Center
                G.DrawString(Text, Font, _Brush, Width \ 2 - _Size.Width \ 2 + x, _MoveHeight \ 2 - _Size.Height \ 2 + y)
        End Select
    End Sub

    Protected Sub DrawIcon(ByVal a As HorizontalAlignment, ByVal x As Integer)
        DrawIcon(a, x, 0)
    End Sub
    Protected Sub DrawIcon(ByVal a As HorizontalAlignment, ByVal x As Integer, ByVal y As Integer)
        If _Image Is Nothing Then Return
        Select Case a
            Case HorizontalAlignment.Left
                G.DrawImage(_Image, x, _MoveHeight \ 2 - _Image.Height \ 2 + y, Image.Width, Image.Height)
            Case HorizontalAlignment.Right
                G.DrawImage(_Image, Width - _Image.Width - x, _MoveHeight \ 2 - _Image.Height \ 2 + y, Image.Width, Image.Height)
            Case HorizontalAlignment.Center
                G.DrawImage(_Image, Width \ 2 - _Image.Width \ 2, _MoveHeight \ 2 - _Image.Height \ 2, Image.Width, Image.Height)
        End Select
    End Sub

    Protected Sub DrawGradient(ByVal c1 As Color, ByVal c2 As Color, ByVal x As Integer, ByVal y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal angle As Single)
        _Rectangle = New Rectangle(x, y, width, height)
        _Gradient = New LinearGradientBrush(_Rectangle, c1, c2, angle)
        G.FillRectangle(_Gradient, _Rectangle)
    End Sub

#End Region

    'Private CloseMonitor As Boolean
    'Private SizeChanging As Boolean
    'Private Sub Monitor()
    '    While Not CloseMonitor
    '        If SizeChanging Then
    '            SizeChanging = False
    '            Invoke(Sub()
    '                       Invalidate()
    '                       PerformLayout()
    '                   End Sub)
    '        End If
    '        Threading.Thread.Sleep(100)
    '    End While
    'End Sub

    'Protected Overrides Sub OnHandleDestroyed(ByVal e As System.EventArgs)
    '    CloseMonitor = True
    '    MyBase.OnHandleDestroyed(e)
    'End Sub

End Class
MustInherit Class ThemeControl
    Inherits Control

#Region " Initialization "

    Protected G As Graphics, B As Bitmap
    Sub New()
        SetStyle(DirectCast(139270, ControlStyles), True)
        B = New Bitmap(1, 1)
        G = Graphics.FromImage(B)
    End Sub

    Sub AllowTransparent()
        SetStyle(ControlStyles.Opaque, False)
        SetStyle(ControlStyles.SupportsTransparentBackColor, True)
    End Sub

    Overrides Property Text As String
        Get
            Return MyBase.Text
        End Get
        Set(ByVal v As String)
            MyBase.Text = v
            Invalidate()
        End Set
    End Property
#End Region

#Region " Mouse Handling "

    Protected Enum State As Byte
        MouseNone = 0
        MouseOver = 1
        MouseDown = 2
    End Enum

    Protected MouseState As State
    Protected Overrides Sub OnMouseLeave(ByVal e As EventArgs)
        ChangeMouseState(State.MouseNone)
        MyBase.OnMouseLeave(e)
    End Sub
    Protected Overrides Sub OnMouseEnter(ByVal e As EventArgs)
        ChangeMouseState(State.MouseOver)
        MyBase.OnMouseEnter(e)
    End Sub
    Protected Overrides Sub OnMouseUp(ByVal e As MouseEventArgs)
        ChangeMouseState(State.MouseOver)
        MyBase.OnMouseUp(e)
    End Sub
    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        If e.Button = MouseButtons.Left Then ChangeMouseState(State.MouseDown)
        MyBase.OnMouseDown(e)
    End Sub

    Private Sub ChangeMouseState(ByVal e As State)
        MouseState = e
        Invalidate()
    End Sub

#End Region

#Region " Convienence "

    MustOverride Sub PaintHook()
    Protected NotOverridable Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If Width = 0 OrElse Height = 0 Then Return
        PaintHook()
        e.Graphics.DrawImage(B, 0, 0)
    End Sub

    Protected Overrides Sub OnSizeChanged(ByVal e As EventArgs)
        If Not Width = 0 AndAlso Not Height = 0 Then
            B = New Bitmap(Width, Height)
            G = Graphics.FromImage(B)
            Invalidate()
        End If
        MyBase.OnSizeChanged(e)
    End Sub

    Private _NoRounding As Boolean
    Property NoRounding() As Boolean
        Get
            Return _NoRounding
        End Get
        Set(ByVal v As Boolean)
            _NoRounding = v
            Invalidate()
        End Set
    End Property

    Private _Image As Image
    Property Image() As Image
        Get
            Return _Image
        End Get
        Set(ByVal value As Image)
            _Image = value
            Invalidate()
        End Set
    End Property
    ReadOnly Property ImageWidth() As Integer
        Get
            If _Image Is Nothing Then Return 0
            Return _Image.Width
        End Get
    End Property
    ReadOnly Property ImageTop() As Integer
        Get
            If _Image Is Nothing Then Return 0
            Return Height \ 2 - _Image.Height \ 2
        End Get
    End Property

    Private _Size As Size
    Private _Rectangle As Rectangle
    Private _Gradient As LinearGradientBrush
    Private _Brush As SolidBrush

    Protected Sub DrawCorners(ByVal c As Color, ByVal rect As Rectangle)
        If _NoRounding Then Return

        B.SetPixel(rect.X, rect.Y, c)
        B.SetPixel(rect.X + (rect.Width - 1), rect.Y, c)
        B.SetPixel(rect.X, rect.Y + (rect.Height - 1), c)
        B.SetPixel(rect.X + (rect.Width - 1), rect.Y + (rect.Height - 1), c)
    End Sub

    Protected Sub DrawBorders(ByVal p1 As Pen, ByVal p2 As Pen, ByVal rect As Rectangle)
        G.DrawRectangle(p1, rect.X, rect.Y, rect.Width - 1, rect.Height - 1)
        G.DrawRectangle(p2, rect.X + 1, rect.Y + 1, rect.Width - 3, rect.Height - 3)
    End Sub

    Protected Sub DrawText(ByVal a As HorizontalAlignment, ByVal c As Color, ByVal x As Integer)
        DrawText(a, c, x, 0)
    End Sub
    Protected Sub DrawText(ByVal a As HorizontalAlignment, ByVal c As Color, ByVal x As Integer, ByVal y As Integer)
        If String.IsNullOrEmpty(Text) Then Return
        _Size = G.MeasureString(Text, Font).ToSize
        _Brush = New SolidBrush(c)

        Select Case a
            Case HorizontalAlignment.Left
                G.DrawString(Text, Font, _Brush, x, Height \ 2 - _Size.Height \ 2 + y)
            Case HorizontalAlignment.Right
                G.DrawString(Text, Font, _Brush, Width - _Size.Width - x, Height \ 2 - _Size.Height \ 2 + y)
            Case HorizontalAlignment.Center
                G.DrawString(Text, Font, _Brush, Width \ 2 - _Size.Width \ 2 + x, Height \ 2 - _Size.Height \ 2 + y)
        End Select
    End Sub

    Protected Sub DrawIcon(ByVal a As HorizontalAlignment, ByVal x As Integer)
        DrawIcon(a, x, 0)
    End Sub
    Protected Sub DrawIcon(ByVal a As HorizontalAlignment, ByVal x As Integer, ByVal y As Integer)
        If _Image Is Nothing Then Return
        Select Case a
            Case HorizontalAlignment.Left
                G.DrawImage(_Image, x, Height \ 2 - _Image.Height \ 2 + y)
            Case HorizontalAlignment.Right
                G.DrawImage(_Image, Width - _Image.Width - x, Height \ 2 - _Image.Height \ 2 + y)
            Case HorizontalAlignment.Center
                G.DrawImage(_Image, Width \ 2 - _Image.Width \ 2, Height \ 2 - _Image.Height \ 2)
        End Select
    End Sub

    Protected Sub DrawGradient(ByVal c1 As Color, ByVal c2 As Color, ByVal x As Integer, ByVal y As Integer, ByVal width As Integer, ByVal height As Integer, ByVal angle As Single)
        _Rectangle = New Rectangle(x, y, width, height)
        _Gradient = New LinearGradientBrush(_Rectangle, c1, c2, angle)
        G.FillRectangle(_Gradient, _Rectangle)
    End Sub

#End Region

End Class

<DefaultEvent("CharacterSelection")>
Class RandomPool
    Inherits ThemeControl

    Private GO As Graphics, _Size As Size
    Event CharacterSelection(ByVal s As Object, ByVal c As Char)

    Sub New()
        GO = Graphics.FromHwndInternal(Handle)
    End Sub

    Private _Range As String = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    Property Range() As String
        Get
            Return _Range
        End Get
        Set(ByVal v As String)
            _Range = v
            UpdateSize()
        End Set
    End Property

    Private _RangePadding As Integer = 2
    Public Property RangePadding() As Integer
        Get
            Return _RangePadding
        End Get
        Set(ByVal v As Integer)
            _RangePadding = v
            UpdateSize()
        End Set
    End Property

    Overrides Property Font As Font
        Get
            Return MyBase.Font
        End Get
        Set(ByVal v As Font)
            MyBase.Font = v
            UpdateSize()
        End Set
    End Property

    Private _Brush As Brush = SystemBrushes.ControlText
    Overrides Property ForeColor As Color
        Get
            Return MyBase.ForeColor
        End Get
        Set(ByVal v As Color)
            MyBase.ForeColor = v
            _Brush = New SolidBrush(v)
            Invalidate()
        End Set
    End Property

    Private Count As Integer
    Private Sub UpdateSize()
        _Size = New Size(0, 0)

        Dim T As Size
        For I As Integer = 0 To _Range.Length - 1
            T = GO.MeasureString(_Range(I), Font).ToSize()
            T.Width += _RangePadding
            T.Height += _RangePadding

            If T.Height > _Size.Height Then _Size.Height = T.Height
            If T.Width > _Size.Width Then _Size.Width = T.Width
        Next

        Randomize()
    End Sub

    Private Index1, Index2 As Integer, Items As Char()
    Protected Overrides Sub OnMouseMove(ByVal e As MouseEventArgs)
        Index1 = GetIndex(e.X, e.Y)
        If Index1 = Index2 Then Return

        RaiseEvent CharacterSelection(Me, Items(Index1))

        Randomize(Index1 - Count)
        Randomize(Index1 - 1)
        Randomize(Index1)
        Randomize(Index1 + 1)
        Randomize(Index1 + Count)

        Index2 = Index1
        Invalidate()
    End Sub
    Protected Overrides Sub OnSizeChanged(ByVal e As EventArgs)
        If _Size.Width = 0 Then UpdateSize() Else Randomize()
        MyBase.OnSizeChanged(e)
    End Sub

    Overrides Sub PaintHook()
        G.Clear(BackColor)

        For X As Integer = 0 To Width - 1 Step _Size.Width
            For Y As Integer = 0 To Height - 1 Step _Size.Height
                G.DrawString(Items(GetIndex(X, Y)), Font, _Brush, X, Y)
            Next
        Next

    End Sub

    Private Function GetIndex(ByVal x As Integer, ByVal y As Integer) As Integer
        Return (y \ _Size.Height) * Count + (x \ _Size.Width)
    End Function

    Private RN As Random
    Private Sub Randomize()
        Count = CInt(Math.Ceiling(Width / _Size.Width))

        RN = New Random(Guid.NewGuid.GetHashCode)
        Items = New Char(CInt(Math.Ceiling(Width / _Size.Width) * Math.Ceiling(Height / _Size.Height)) - 1) {}

        For I As Integer = 0 To Items.Length - 1
            Items(I) = _Range(RN.Next(_Range.Length))
        Next

        Invalidate()
    End Sub
    Private Sub Randomize(ByVal index As Integer)
        If index > -1 AndAlso index < Items.Length Then Items(index) = _Range(RN.Next(_Range.Length))
    End Sub

End Class

Class UTheme
    Inherits Theme

    Private Blend As ColorBlend

    Sub New()
        MoveHeight = 24
        TransparencyKey = Color.Fuchsia

        Path = New GraphicsPath

        Blend = New ColorBlend
        Blend.Positions = New Single() {0, 0.4, 0.6, 1}

        NameItem("BackColor", 14, 14, 14)
        NameItem("CornerGradient1", 48, 48, 48)
        NameItem("CornerGradient2", 4, 4, 4)
        NameItem("TextShadow", Color.Black)
        NameItem("TextColor", Color.White)
        NameItem("BorderColor", 45, 45, 45)
        NameItem("Outline", Color.Black)
        NameItem("CornerHighlight", 15, Color.White)
        NameItem("TitleShine", 100, 100, 100)
        NameItem("TitleGloss", 42, Color.White)
        NameItem("CornerGloss", 15, Color.White)
        NameItem("TitleGradient1", 14, 14, 14)
        NameItem("TitleGradient2", 41, 41, 41)

        BloomHook()
    End Sub

    Private C1, C2, C3, C4, C5 As Color
    Private P1, P2, P3, P4 As Pen
    Private B1, B2 As SolidBrush

    Sub BloomHook()
        Blend.Colors = New Color() {Items("TitleGradient1"), Items("TitleGradient2"), Items("TitleGradient2"), Items("TitleGradient1")}

        C1 = Items("BackColor")
        C2 = Items("CornerGradient1")
        C3 = Items("CornerGradient2")
        C4 = Items("TextShadow")
        C5 = Items("TextColor")

        P1 = New Pen(Items("BorderColor"), 4)
        P1.Alignment = PenAlignment.Inset

        P2 = New Pen(Items("Outline"))
        P3 = New Pen(Items("CornerHighlight"), 2)
        P4 = New Pen(Items("TitleShine"))

        B1 = New SolidBrush(Items("TitleGloss"))
        B2 = New SolidBrush(Items("CornerGloss"))
    End Sub

    Sub NameItem(ByVal name As String, ByVal color As Color)
        If Items.ContainsKey(name) Then Items(name) = color Else Items.Add(name, color)
    End Sub
    Sub NameItem(ByVal name As String, ByVal r As Byte, ByVal g As Byte, ByVal b As Byte)
        NameItem(name, Color.FromArgb(r, g, b))
    End Sub
    Sub NameItem(ByVal name As String, ByVal a As Byte, ByVal r As Byte, ByVal g As Byte, ByVal b As Byte)
        NameItem(name, Color.FromArgb(a, r, g, b))
    End Sub
    Sub NameItem(ByVal name As String, ByVal a As Byte, ByVal color As Color)
        NameItem(name, color.FromArgb(a, color))
    End Sub

    Private R1 As Rectangle
    Private G1 As LinearGradientBrush

    Overrides Sub PaintHook()

        'Draw background
        G.Clear(C1)
        G.FillRectangle(Brushes.Fuchsia, 0, 0, Width, 3)

        'Draw border
        G.DrawRectangle(P1, 0, 20, Width, Height - 20)

        'Draw outline
        G.DrawRectangle(P2, 0, 24, Width - 1, Height - 25)
        G.DrawRectangle(P2, 4, 23, Width - 9, Height - 28)

        'Draw title gradient
        R1 = New Rectangle(30, 2, Width - 67, 22)
        G1 = New LinearGradientBrush(R1, Color.Empty, Color.Empty, 0)
        G1.InterpolationColors = Blend
        G.FillRectangle(G1, R1)

        'Draw title gloss
        G.FillRectangle(B1, 30, 2, Width - 67, 11)
        G.DrawLine(P4, 30, 3, Width - 67, 3)

        'Draw title outline
        G.DrawLine(P2, 30, 2, Width - 67, 2)

        'Draw corner gradient
        G.SetClip(Path)
        R1 = New Rectangle(0, 0, Width, 24)
        G1 = New LinearGradientBrush(R1, C2, C3, 90S)
        G.FillRectangle(G1, R1)

        'Draw corner gloss
        G.FillRectangle(B2, 0, 0, Width, 11)
        G.DrawPath(P3, PathClone)
        G.ResetClip()

        'Draw corner outline
        G.DrawPath(P2, Path)

        'Draw title elements
        DrawText(HorizontalAlignment.Center, C4, -21, 3)
        DrawText(HorizontalAlignment.Center, C5, -20, 2)
        DrawIcon(HorizontalAlignment.Left, 11)
    End Sub


    Private Path, PathClone As GraphicsPath
    Private PathBegin, Point1, Point2 As Point
    Sub Begin(ByVal x As Integer, ByVal y As Integer)
        PathBegin = Point.Empty
        Point1 = Point.Empty
        Point2 = Point.Empty

        PathBegin = New Point(x, y)
    End Sub
    Sub Connect(ByVal x As Integer, ByVal y As Integer)
        If Point1 = Point.Empty Then
            Point1 = New Point(x, y)
            Path.AddLine(PathBegin, Point1)
        Else
            Point2 = New Point(x, y)
            Path.AddLine(Point1, Point2)
            Point1 = Point2
        End If
    End Sub


    Protected Overrides Sub OnHandleCreated(ByVal e As EventArgs)
        Parent.MinimumSize = New Size(120, 80)
        MyBase.OnHandleCreated(e)
    End Sub
    Protected Overrides Sub OnSizeChanged(ByVal e As EventArgs)
        Path.Reset()

        Begin(3, 0)
        Connect(31, 0)
        Connect(55, 24)
        Connect(0, 24)
        Connect(0, 3)
        Path.CloseFigure()

        Begin(Width - 68, 0)
        Connect(Width - 4, 0)
        Connect(Width - 1, 3)
        Connect(Width - 1, 24)
        Connect(Width - 92, 24)
        Path.CloseFigure()

        PathClone = DirectCast(Path.Clone, GraphicsPath)
        PathClone.Widen(Pens.Black)

        MyBase.OnSizeChanged(e)
    End Sub


    Class Bloom
        Property Name As String
        Property Value() As Color

        Sub New()
        End Sub

        Sub New(ByVal name As String, ByVal value As Color)
            _Name = name
            _Value = value
        End Sub
    End Class

    Private Items As New Dictionary(Of String, Color)
    <DesignerSerializationVisibility(DesignerSerializationVisibility.Content)>
    Property Colors() As Bloom()
        Get
            Dim T As New List(Of Bloom)
            Dim E As Dictionary(Of String, Color).Enumerator = Items.GetEnumerator

            While E.MoveNext
                T.Add(New Bloom(E.Current.Key, E.Current.Value))
            End While

            Return T.ToArray
        End Get
        Set(ByVal value As Bloom())
            For Each B As Bloom In value
                If Items.ContainsKey(B.Name) Then Items(B.Name) = B.Value
            Next

            BloomHook()
            Invalidate()
        End Set
    End Property

End Class

Class UButton
    Inherits ThemeControl

    Sub New()
        AllowTransparent()

        NameItem("BackColor", 14, 14, 14)
        NameItem("DownGradient1", 14, 14, 14)
        NameItem("DownGradient2", 41, 41, 41)
        NameItem("OverShine", 5, Color.White)
        NameItem("GlossGradient1", 30, Color.White)
        NameItem("GlossGradient2", 5, Color.White)
        NameItem("Highlight1", 62, 62, 62)
        NameItem("Highlight2", 15, Color.White)
        NameItem("Border", Color.Black)
        NameItem("Text", Color.White)

        BloomHook()
    End Sub

    Private C1, C2, C3, C4, C5, C6, C7 As Color
    Private P1, P2, P3 As Pen
    Private B1 As SolidBrush

    Overrides Sub PaintHook()

        'Clear background
        G.Clear(C1)

        'Draw mouse down
        If MouseState = State.MouseDown Then
            DrawGradient(C2, C3, 0, 0, Width, Height, 90S)
        End If

        'Draw mouse over
        If MouseState = State.MouseOver Then
            G.FillRectangle(B1, ClientRectangle)
        End If

        'Draw gloss
        DrawGradient(C4, C5, 0, 0, Width, Height \ 2, 90S)
        G.DrawLine(P1, 0, 1, Width, 1)

        'Draw highlight
        DrawBorders(P3, P2, ClientRectangle)

        'Draw corners
        DrawCorners(C6, New Rectangle(1, 1, Width - 2, Height - 2))
        DrawCorners(BackColor, ClientRectangle)

        'Draw text
        DrawText(HorizontalAlignment.Center, C7, 0)
    End Sub

    Sub BloomHook()
        C1 = Items("BackColor")
        C2 = Items("DownGradient1")
        C3 = Items("DownGradient2")
        C4 = Items("GlossGradient1")
        C5 = Items("GlossGradient2")
        C6 = Items("Highlight2")
        C7 = Items("Text")

        P1 = New Pen(Items("Highlight1"))
        P2 = New Pen(Items("Highlight2"))
        P3 = New Pen(Items("Border"))

        B1 = New SolidBrush(Items("OverShine"))

        BackColor = C1
    End Sub

    Sub NameItem(ByVal name As String, ByVal color As Color)
        If Items.ContainsKey(name) Then Items(name) = color Else Items.Add(name, color)
    End Sub
    Sub NameItem(ByVal name As String, ByVal r As Byte, ByVal g As Byte, ByVal b As Byte)
        NameItem(name, Color.FromArgb(r, g, b))
    End Sub
    Sub NameItem(ByVal name As String, ByVal a As Byte, ByVal r As Byte, ByVal g As Byte, ByVal b As Byte)
        NameItem(name, Color.FromArgb(a, r, g, b))
    End Sub
    Sub NameItem(ByVal name As String, ByVal a As Byte, ByVal color As Color)
        NameItem(name, color.FromArgb(a, color))
    End Sub

    Class Bloom
        Property Name As String
        Property Value() As Color

        Sub New()
        End Sub

        Sub New(ByVal name As String, ByVal value As Color)
            _Name = name
            _Value = value
        End Sub
    End Class

    Private Items As New Dictionary(Of String, Color)
    <DesignerSerializationVisibility(DesignerSerializationVisibility.Content)>
    Property Colors() As Bloom()
        Get
            Dim T As New List(Of Bloom)
            Dim E As Dictionary(Of String, Color).Enumerator = Items.GetEnumerator

            While E.MoveNext
                T.Add(New Bloom(E.Current.Key, E.Current.Value))
            End While

            Return T.ToArray
        End Get
        Set(ByVal value As Bloom())
            For Each B As Bloom In value
                If Items.ContainsKey(B.Name) Then Items(B.Name) = B.Value
            Next

            BloomHook()
            Invalidate()
        End Set
    End Property
End Class

