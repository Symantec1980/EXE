﻿Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Security.Cryptography
Imports System.Text
Module MAgedketgenerater
    Public Function GetUniqueKey(ByVal maxSize As Integer) As String
        Dim chArray As Char() = New Char(&H3E - 1) {}
        chArray = Conversions.ToCharArrayRankOne("英文书信中三十余种表达谢谢的方式非常感谢用英文怎么说天涯问答外语频道余种表达谢的方式自伪伙仿仰华份价延伐伏乓传伟丢先肉年БёГДЖЗИЙЛбгджзийклПФХЦЧШЩЪЬЮЯнопфхцчшщъьюяѢѪѣѫAaBaCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz")
        Dim data As Byte() = New Byte(1 - 1) {}
        Dim provider As New RNGCryptoServiceProvider
        provider.GetNonZeroBytes(data)
        data = New Byte(((maxSize - 1) + 1) - 1) {}
        provider.GetNonZeroBytes(data)
        Dim builder As New StringBuilder(maxSize)
        Dim num As Byte
        For Each num In data
            builder.Append(chArray((num Mod chArray.Length)))
        Next
        Return builder.ToString
    End Function
End Module
