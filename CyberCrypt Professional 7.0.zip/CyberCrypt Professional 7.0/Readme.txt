* COVERS IMPORTANT DETAILS (PLEASE READ IMPORTANT.TXT WHICH COMES WITH THIS PRODUCT.)
* PLEASE READ THE LICENSE AGREEMENT (LICENSE.TXT)

(This is very important)
Hi, over time since version 3.0 of CyberCrypt I have had many
emails about zlib.dll People think that zlib.dll is constantly
used in this program. Well you are wrong, it's only used to compress
the files and nothing else.This means that it's only the compression
archive you need the dll for. You can create an encryption archive
and would not need to use this dll. Or even a normal non-compression
archive which also you don't need this dll for.

Whats a Swap archive?
A Swap archive acts the same as a normal non-compression
archive. But what happens is when adding a file, this type
of archive splits the file up into smallier pieces and uses
less memory.

The Packed and Size properties:
If making an non-compression archive the Size and packed propertie
value should be the same. When having a compression archive
the Size and Packed properties are usually different, this varies
because files are compressed into the archive. The Size
propertie shows what the original size of the file is outside of
the archive. The Packed propertie shows the size of the file
while in the archive.

Converting archives?
All the converting archive option does is change an archive which
has been made in an older version of CyberCrypt and converts into
the correct format for the newer versions of CyberCrypt.

Coding Utility?
The Coding Utility CODE is created by James Gohl, Copyright 1999-2001
All other design by Mark Withers, Copyright 1999-2001

Whats new about this version of CyberCrypt?

*********Version 7.0**********

**Advances!**
New swap archive
New coding utility
New (In the archive properties dialog) how much space is requried to extract all files from the archive
New (In the archive properties dialog) how much space archive data is taking up of the archive size
Moved and better positioned file/archive/other properties
New Saved Space propertie
New Frequenly asked questions lay-out
New Ratio propertie
New lights to tell if you have lost or saved disk space
New ProgressBars
2.89% faster than before
Better checking if archive is still active
Tool tip text errors fixed
Error logger problems fixed
Lots of bug fixes
Register bug fix (Now can load file type names longer than 88 characters (Now 4696 Characters))
Archive types using less memory
More Tip of the Day tips
New Packed propertie in file information
New File Created propertie in file information
Lights in status bar
Now easier to add more information data
Big bug fix on checking file extension
Countless bug fixes
Neater displayed dialogs
Faster opening archives
More error debugging
Now new Converting archive option & Three dialogs
More frequently asked questions
Checks if file has extension easier
More source safe
New featured status bar in the main window
New splash screen
Faster resizing main window

**Disadvantages!**
Can't delete file out of archive, need to create a new archive.

*********Version 6.0**********

More frequently asked questions
Clears files after viewing easier
New tabbed dialogs
Better resizing of the main window
Paths now are checked if they have \ slash on the end
Many bug fixes

**Disadvantages!**
Can't delete file out of archive, need to create a new archive.

*********Version 5.0**********

**Advances!**
Now easy access menus
Frequently asked questions dialog
Virus scanning options
QuickView options
Move archive option
Copy archive option
Delete archive option
Rename archive option
Refresh archive option
Tip of the day advanced
Contents
New License Dialog
Help topic links
License agreement (Standard)
Easier access to open files with program associations
Better hover menus
File percent of archive (Standard)
Key shortcuts
Non-Flickering add, extract dialogs
Many bug fixes

**Disadvantages!**
Can't delete file out of archive, need to create a new archive.

*********Version 4.0**********

**Advances!**
New added Tips screen
Added encryption and decryption archives
New archive select dialog
Creates the correct file type
Better coding features
Compression (Extract level) - None compression using zlib.dll
Better about dialog
Neat splash screen
When adding multi-files the archive doesn't refresh until loaded all the archive - (Means the speed has now been increasted 34* more while adding multi-files)
More file and archive information properties
Now you can add all files in a directory by clicking on the add file option
Better viewing of file types
Small tabbed features
Encryption and decryption archives don't take that much longer to load or add too as the normal Non-Compression archives do
Bug fixes

**Disadvantages!**
Can't delete file out of archive, need to create a new archive.

*********Version 3.0**********

**Advances!**
Added compression & compression leveling
Use older archives in newer version of CyberCrypt
Checks if CyT archive exists while adding and extracting files
Bug fixes

**Disadvantages!**
Can't delete file out of archive, need to create a new archive.

*********Version 2.0**********

What I have added:

**Advances!**
Better coding
More file features
Better unit
Better dialogs
Bug fixes
Lot's of added code
Settings now can be used
Better buttons
File sizes-Updated shows KB / MB as well as 11'bytes
Help button
File types
File numbers
Offsets
New status bar!

**Disadvantages!**
Can't delete file out of archive, need to create a new archive.

*********Version 1.0**********

**Advances!**
Very fast and easy coding.
Works like winzip but without the compression.
Takes about 6 seconds for a 4 Meg file to be encrypted into archive.
Takes about 6 seconds / 12 to extract from CyT file.
Such simple code, you really can't find a bug.
Re-enter archive and add more files.
See shaded icons in the file lists.
Good dialogs (Main form and Versions form)

**Disadvantages!**
Can't delete file out of archive, need to create a new archive.

******************************
		

			HELP EMAIL TO...
			
			NeoBPI@Yahoo.com
