﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("UPX-iT")> 
<Assembly: AssemblyDescription("MFC-Anwendung UPX-iT")> 
<Assembly: AssemblyCompany("Anwendung UPX-iT")> 
<Assembly: AssemblyProduct("UPX-iT.EXE")> 
<Assembly: AssemblyCopyright("Copyright (C) 2003 By UPX-iT")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("1d459e15-0c2e-4cae-9c07-69e6e45ab128")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("5.1.7.1")> 
<Assembly: AssemblyFileVersion("5.1.7.1")> 

<Assembly: NeutralResourcesLanguageAttribute("en")> 