﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.FormSkin1 = New Crypter_ALl_tool.FormSkin()
        Me.FlatButton6 = New Crypter_ALl_tool.FlatButton()
        Me.FlatGroupBox3 = New Crypter_ALl_tool.FlatGroupBox()
        Me.FlatCheckBox99 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatTrackBar2 = New Crypter_ALl_tool.FlatTrackBar()
        Me.hazem = New Crypter_ALl_tool.FlatTextBox()
        Me.FlatCheckBox10 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatToggle1 = New Crypter_ALl_tool.FlatToggle()
        Me.FlatMini1 = New Crypter_ALl_tool.FlatMini()
        Me.FlatButton5 = New Crypter_ALl_tool.FlatButton()
        Me.FlatButton4 = New Crypter_ALl_tool.FlatButton()
        Me.FlatButton3 = New Crypter_ALl_tool.FlatButton()
        Me.FlatLabel1 = New Crypter_ALl_tool.FlatLabel()
        Me.FlatGroupBox2 = New Crypter_ALl_tool.FlatGroupBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.FlatTrackBar1 = New Crypter_ALl_tool.FlatTrackBar()
        Me.FlatGroupBox1 = New Crypter_ALl_tool.FlatGroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FlatCheckBox1 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox2 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox3 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox4 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatCheckBox5 = New Crypter_ALl_tool.FlatCheckBox()
        Me.FlatStatusBar1 = New Crypter_ALl_tool.FlatStatusBar()
        Me.key = New Crypter_ALl_tool.FlatTextBox()
        Me.FlatButton2 = New Crypter_ALl_tool.FlatButton()
        Me.r1 = New System.Windows.Forms.RichTextBox()
        Me.FlatClose1 = New Crypter_ALl_tool.FlatClose()
        Me.FlatTextBox1 = New Crypter_ALl_tool.FlatTextBox()
        Me.FlatButton1 = New Crypter_ALl_tool.FlatButton()
        Me.FormSkin1.SuspendLayout()
        Me.FlatGroupBox3.SuspendLayout()
        Me.FlatGroupBox2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlatGroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FormSkin1
        '
        Me.FormSkin1.BackColor = System.Drawing.Color.White
        Me.FormSkin1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FormSkin1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.FormSkin1.Controls.Add(Me.FlatButton6)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox3)
        Me.FormSkin1.Controls.Add(Me.FlatToggle1)
        Me.FormSkin1.Controls.Add(Me.FlatMini1)
        Me.FormSkin1.Controls.Add(Me.FlatButton5)
        Me.FormSkin1.Controls.Add(Me.FlatButton4)
        Me.FormSkin1.Controls.Add(Me.FlatButton3)
        Me.FormSkin1.Controls.Add(Me.FlatLabel1)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox2)
        Me.FormSkin1.Controls.Add(Me.FlatTrackBar1)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox1)
        Me.FormSkin1.Controls.Add(Me.FlatStatusBar1)
        Me.FormSkin1.Controls.Add(Me.key)
        Me.FormSkin1.Controls.Add(Me.FlatButton2)
        Me.FormSkin1.Controls.Add(Me.r1)
        Me.FormSkin1.Controls.Add(Me.FlatClose1)
        Me.FormSkin1.Controls.Add(Me.FlatTextBox1)
        Me.FormSkin1.Controls.Add(Me.FlatButton1)
        Me.FormSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormSkin1.FlatColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FormSkin1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormSkin1.HeaderColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FormSkin1.HeaderMaximize = False
        Me.FormSkin1.Location = New System.Drawing.Point(0, 0)
        Me.FormSkin1.Name = "FormSkin1"
        Me.FormSkin1.Size = New System.Drawing.Size(849, 658)
        Me.FormSkin1.TabIndex = 0
        Me.FormSkin1.Text = "Crypter Algorithme  & splet Hex  Server"
        '
        'FlatButton6
        '
        Me.FlatButton6.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton6.BaseColor = System.Drawing.Color.Red
        Me.FlatButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton6.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.FlatButton6.Location = New System.Drawing.Point(164, 536)
        Me.FlatButton6.Name = "FlatButton6"
        Me.FlatButton6.Rounded = False
        Me.FlatButton6.Size = New System.Drawing.Size(147, 27)
        Me.FlatButton6.TabIndex = 28
        Me.FlatButton6.Text = "Downloader v1"
        Me.FlatButton6.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatGroupBox3
        '
        Me.FlatGroupBox3.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox3.BaseColor = System.Drawing.Color.Black
        Me.FlatGroupBox3.Controls.Add(Me.FlatCheckBox99)
        Me.FlatGroupBox3.Controls.Add(Me.FlatTrackBar2)
        Me.FlatGroupBox3.Controls.Add(Me.hazem)
        Me.FlatGroupBox3.Controls.Add(Me.FlatCheckBox10)
        Me.FlatGroupBox3.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox3.Location = New System.Drawing.Point(497, 492)
        Me.FlatGroupBox3.Name = "FlatGroupBox3"
        Me.FlatGroupBox3.ShowText = True
        Me.FlatGroupBox3.Size = New System.Drawing.Size(334, 142)
        Me.FlatGroupBox3.TabIndex = 19
        Me.FlatGroupBox3.Text = "Algorithm Number"
        '
        'FlatCheckBox99
        '
        Me.FlatCheckBox99.BackColor = System.Drawing.Color.Black
        Me.FlatCheckBox99.BaseColor = System.Drawing.SystemColors.AppWorkspace
        Me.FlatCheckBox99.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox99.Checked = False
        Me.FlatCheckBox99.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox99.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox99.Location = New System.Drawing.Point(168, 59)
        Me.FlatCheckBox99.Name = "FlatCheckBox99"
        Me.FlatCheckBox99.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox99.Size = New System.Drawing.Size(126, 22)
        Me.FlatCheckBox99.TabIndex = 27
        Me.FlatCheckBox99.Text = "AES"
        '
        'FlatTrackBar2
        '
        Me.FlatTrackBar2.BackColor = System.Drawing.Color.Black
        Me.FlatTrackBar2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatTrackBar2.HatchColor = System.Drawing.Color.Red
        Me.FlatTrackBar2.Location = New System.Drawing.Point(14, 98)
        Me.FlatTrackBar2.Maximum = 3
        Me.FlatTrackBar2.Name = "FlatTrackBar2"
        Me.FlatTrackBar2.ShowValue = False
        Me.FlatTrackBar2.Size = New System.Drawing.Size(123, 23)
        Me.FlatTrackBar2.Style = Crypter_ALl_tool.FlatTrackBar._Style.Knob
        Me.FlatTrackBar2.TabIndex = 25
        Me.FlatTrackBar2.Text = "FlatTrackBar2"
        Me.FlatTrackBar2.TrackColor = System.Drawing.Color.Red
        Me.FlatTrackBar2.Value = 0
        '
        'hazem
        '
        Me.hazem.BackColor = System.Drawing.Color.Transparent
        Me.hazem.Location = New System.Drawing.Point(14, 59)
        Me.hazem.MaxLength = 32767
        Me.hazem.Multiline = False
        Me.hazem.Name = "hazem"
        Me.hazem.ReadOnly = False
        Me.hazem.Size = New System.Drawing.Size(123, 29)
        Me.hazem.TabIndex = 23
        Me.hazem.Text = "Number"
        Me.hazem.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.hazem.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.hazem.UseSystemPasswordChar = False
        '
        'FlatCheckBox10
        '
        Me.FlatCheckBox10.BackColor = System.Drawing.Color.Black
        Me.FlatCheckBox10.BaseColor = System.Drawing.SystemColors.AppWorkspace
        Me.FlatCheckBox10.BorderColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatCheckBox10.Checked = False
        Me.FlatCheckBox10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox10.Font = New System.Drawing.Font("Bernard MT Condensed", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox10.Location = New System.Drawing.Point(168, 30)
        Me.FlatCheckBox10.Name = "FlatCheckBox10"
        Me.FlatCheckBox10.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox10.Size = New System.Drawing.Size(126, 22)
        Me.FlatCheckBox10.TabIndex = 24
        Me.FlatCheckBox10.Text = "Hazem Algorithm"
        '
        'FlatToggle1
        '
        Me.FlatToggle1.BackColor = System.Drawing.Color.Transparent
        Me.FlatToggle1.Checked = False
        Me.FlatToggle1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatToggle1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatToggle1.Location = New System.Drawing.Point(20, 560)
        Me.FlatToggle1.Name = "FlatToggle1"
        Me.FlatToggle1.Options = Crypter_ALl_tool.FlatToggle._Options.Style3
        Me.FlatToggle1.Size = New System.Drawing.Size(76, 33)
        Me.FlatToggle1.TabIndex = 25
        Me.FlatToggle1.Text = "FlatToggle1"
        '
        'FlatMini1
        '
        Me.FlatMini1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatMini1.BackColor = System.Drawing.Color.White
        Me.FlatMini1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FlatMini1.Font = New System.Drawing.Font("Marlett", 12.0!)
        Me.FlatMini1.Location = New System.Drawing.Point(780, 12)
        Me.FlatMini1.Name = "FlatMini1"
        Me.FlatMini1.Size = New System.Drawing.Size(18, 18)
        Me.FlatMini1.TabIndex = 24
        Me.FlatMini1.Text = "FlatMini1"
        Me.FlatMini1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton5
        '
        Me.FlatButton5.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton5.BaseColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton5.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton5.Location = New System.Drawing.Point(317, 596)
        Me.FlatButton5.Name = "FlatButton5"
        Me.FlatButton5.Rounded = False
        Me.FlatButton5.Size = New System.Drawing.Size(163, 23)
        Me.FlatButton5.TabIndex = 23
        Me.FlatButton5.Text = "Generating algorithm"
        Me.FlatButton5.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton4
        '
        Me.FlatButton4.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton4.BaseColor = System.Drawing.Color.DarkSeaGreen
        Me.FlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton4.Location = New System.Drawing.Point(317, 568)
        Me.FlatButton4.Name = "FlatButton4"
        Me.FlatButton4.Rounded = False
        Me.FlatButton4.Size = New System.Drawing.Size(163, 22)
        Me.FlatButton4.TabIndex = 22
        Me.FlatButton4.Text = "Clear TeXT"
        Me.FlatButton4.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatButton3
        '
        Me.FlatButton3.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton3.BaseColor = System.Drawing.Color.Maroon
        Me.FlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton3.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton3.Location = New System.Drawing.Point(317, 536)
        Me.FlatButton3.Name = "FlatButton3"
        Me.FlatButton3.Rounded = False
        Me.FlatButton3.Size = New System.Drawing.Size(163, 27)
        Me.FlatButton3.TabIndex = 21
        Me.FlatButton3.Text = "Copy Text"
        Me.FlatButton3.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatLabel1
        '
        Me.FlatLabel1.AutoSize = True
        Me.FlatLabel1.BackColor = System.Drawing.Color.Transparent
        Me.FlatLabel1.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.FlatLabel1.ForeColor = System.Drawing.Color.Maroon
        Me.FlatLabel1.Location = New System.Drawing.Point(23, 612)
        Me.FlatLabel1.Name = "FlatLabel1"
        Me.FlatLabel1.Size = New System.Drawing.Size(73, 13)
        Me.FlatLabel1.TabIndex = 20
        Me.FlatLabel1.Text = " .  .   .   .    .   ."
        '
        'FlatGroupBox2
        '
        Me.FlatGroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox2.BaseColor = System.Drawing.Color.Black
        Me.FlatGroupBox2.Controls.Add(Me.PictureBox2)
        Me.FlatGroupBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox2.Location = New System.Drawing.Point(16, 59)
        Me.FlatGroupBox2.Name = "FlatGroupBox2"
        Me.FlatGroupBox2.ShowText = True
        Me.FlatGroupBox2.Size = New System.Drawing.Size(239, 89)
        Me.FlatGroupBox2.TabIndex = 19
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(-49, -25)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(327, 142)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 18
        Me.PictureBox2.TabStop = False
        '
        'FlatTrackBar1
        '
        Me.FlatTrackBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FlatTrackBar1.HatchColor = System.Drawing.Color.DarkRed
        Me.FlatTrackBar1.Location = New System.Drawing.Point(26, 507)
        Me.FlatTrackBar1.Maximum = 100
        Me.FlatTrackBar1.Name = "FlatTrackBar1"
        Me.FlatTrackBar1.ShowValue = False
        Me.FlatTrackBar1.Size = New System.Drawing.Size(465, 23)
        Me.FlatTrackBar1.Style = Crypter_ALl_tool.FlatTrackBar._Style.Slider
        Me.FlatTrackBar1.TabIndex = 17
        Me.FlatTrackBar1.Text = "FlatTrackBar1"
        Me.FlatTrackBar1.TrackColor = System.Drawing.Color.DarkRed
        Me.FlatTrackBar1.Value = 0
        '
        'FlatGroupBox1
        '
        Me.FlatGroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox1.BaseColor = System.Drawing.Color.Black
        Me.FlatGroupBox1.Controls.Add(Me.PictureBox1)
        Me.FlatGroupBox1.Controls.Add(Me.FlatCheckBox1)
        Me.FlatGroupBox1.Controls.Add(Me.FlatCheckBox2)
        Me.FlatGroupBox1.Controls.Add(Me.FlatCheckBox3)
        Me.FlatGroupBox1.Controls.Add(Me.FlatCheckBox4)
        Me.FlatGroupBox1.Controls.Add(Me.FlatCheckBox5)
        Me.FlatGroupBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox1.Location = New System.Drawing.Point(665, 175)
        Me.FlatGroupBox1.Name = "FlatGroupBox1"
        Me.FlatGroupBox1.ShowText = True
        Me.FlatGroupBox1.Size = New System.Drawing.Size(176, 311)
        Me.FlatGroupBox1.TabIndex = 16
        Me.FlatGroupBox1.Text = "Algorithm"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(10, 201)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(137, 86)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 18
        Me.PictureBox1.TabStop = False
        '
        'FlatCheckBox1
        '
        Me.FlatCheckBox1.BackColor = System.Drawing.Color.Black
        Me.FlatCheckBox1.BaseColor = System.Drawing.Color.Gray
        Me.FlatCheckBox1.BorderColor = System.Drawing.Color.GreenYellow
        Me.FlatCheckBox1.Checked = False
        Me.FlatCheckBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox1.Font = New System.Drawing.Font("Britannic Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox1.Location = New System.Drawing.Point(21, 47)
        Me.FlatCheckBox1.Name = "FlatCheckBox1"
        Me.FlatCheckBox1.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox1.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox1.TabIndex = 3
        Me.FlatCheckBox1.Text = "Rijndael Crypt"
        '
        'FlatCheckBox2
        '
        Me.FlatCheckBox2.BackColor = System.Drawing.Color.Black
        Me.FlatCheckBox2.BaseColor = System.Drawing.Color.Gray
        Me.FlatCheckBox2.BorderColor = System.Drawing.Color.GreenYellow
        Me.FlatCheckBox2.Checked = False
        Me.FlatCheckBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox2.Font = New System.Drawing.Font("Britannic Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox2.Location = New System.Drawing.Point(21, 75)
        Me.FlatCheckBox2.Name = "FlatCheckBox2"
        Me.FlatCheckBox2.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox2.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox2.TabIndex = 8
        Me.FlatCheckBox2.Text = "3DES MD5"
        '
        'FlatCheckBox3
        '
        Me.FlatCheckBox3.BackColor = System.Drawing.Color.Black
        Me.FlatCheckBox3.BaseColor = System.Drawing.Color.Gray
        Me.FlatCheckBox3.BorderColor = System.Drawing.Color.GreenYellow
        Me.FlatCheckBox3.Checked = False
        Me.FlatCheckBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox3.Font = New System.Drawing.Font("Britannic Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox3.Location = New System.Drawing.Point(21, 103)
        Me.FlatCheckBox3.Name = "FlatCheckBox3"
        Me.FlatCheckBox3.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox3.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox3.TabIndex = 9
        Me.FlatCheckBox3.Text = "MD5"
        '
        'FlatCheckBox4
        '
        Me.FlatCheckBox4.BackColor = System.Drawing.Color.Black
        Me.FlatCheckBox4.BaseColor = System.Drawing.Color.Gray
        Me.FlatCheckBox4.BorderColor = System.Drawing.Color.GreenYellow
        Me.FlatCheckBox4.Checked = False
        Me.FlatCheckBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox4.Font = New System.Drawing.Font("Britannic Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox4.Location = New System.Drawing.Point(21, 131)
        Me.FlatCheckBox4.Name = "FlatCheckBox4"
        Me.FlatCheckBox4.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox4.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox4.TabIndex = 10
        Me.FlatCheckBox4.Text = "XOR"
        '
        'FlatCheckBox5
        '
        Me.FlatCheckBox5.BackColor = System.Drawing.Color.Black
        Me.FlatCheckBox5.BaseColor = System.Drawing.Color.Gray
        Me.FlatCheckBox5.BorderColor = System.Drawing.Color.GreenYellow
        Me.FlatCheckBox5.Checked = False
        Me.FlatCheckBox5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatCheckBox5.Font = New System.Drawing.Font("Britannic Bold", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatCheckBox5.Location = New System.Drawing.Point(21, 159)
        Me.FlatCheckBox5.Name = "FlatCheckBox5"
        Me.FlatCheckBox5.Options = Crypter_ALl_tool.FlatCheckBox._Options.Style1
        Me.FlatCheckBox5.Size = New System.Drawing.Size(112, 22)
        Me.FlatCheckBox5.TabIndex = 11
        Me.FlatCheckBox5.Text = "RC4"
        '
        'FlatStatusBar1
        '
        Me.FlatStatusBar1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.FlatStatusBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.FlatStatusBar1.Font = New System.Drawing.Font("Felix Titling", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatStatusBar1.ForeColor = System.Drawing.Color.Maroon
        Me.FlatStatusBar1.Location = New System.Drawing.Point(0, 640)
        Me.FlatStatusBar1.Name = "FlatStatusBar1"
        Me.FlatStatusBar1.RectColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FlatStatusBar1.ShowTimeDate = False
        Me.FlatStatusBar1.Size = New System.Drawing.Size(849, 18)
        Me.FlatStatusBar1.TabIndex = 15
        Me.FlatStatusBar1.Text = "ALMOLAZEM HAZEM CRYPTER 2015"
        Me.FlatStatusBar1.TextColor = System.Drawing.Color.White
        '
        'key
        '
        Me.key.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.key.BackColor = System.Drawing.Color.Transparent
        Me.key.Cursor = System.Windows.Forms.Cursors.Cross
        Me.key.Location = New System.Drawing.Point(20, 457)
        Me.key.MaxLength = 32767
        Me.key.Multiline = False
        Me.key.Name = "key"
        Me.key.ReadOnly = False
        Me.key.Size = New System.Drawing.Size(471, 29)
        Me.key.TabIndex = 7
        Me.key.Text = "Key Mouse Move"
        Me.key.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.key.TextColor = System.Drawing.Color.Gray
        Me.key.UseSystemPasswordChar = False
        '
        'FlatButton2
        '
        Me.FlatButton2.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton2.BaseColor = System.Drawing.Color.Maroon
        Me.FlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton2.Font = New System.Drawing.Font("Footlight MT Light", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton2.Location = New System.Drawing.Point(675, 142)
        Me.FlatButton2.Name = "FlatButton2"
        Me.FlatButton2.Rounded = False
        Me.FlatButton2.Size = New System.Drawing.Size(149, 27)
        Me.FlatButton2.TabIndex = 6
        Me.FlatButton2.Text = "Crypter Server"
        Me.FlatButton2.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'r1
        '
        Me.r1.BackColor = System.Drawing.Color.Black
        Me.r1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.r1.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.r1.Location = New System.Drawing.Point(16, 182)
        Me.r1.Name = "r1"
        Me.r1.Size = New System.Drawing.Size(643, 269)
        Me.r1.TabIndex = 4
        Me.r1.Text = ""
        '
        'FlatClose1
        '
        Me.FlatClose1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlatClose1.BackColor = System.Drawing.Color.White
        Me.FlatClose1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(168, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.FlatClose1.Font = New System.Drawing.Font("Marlett", 10.0!)
        Me.FlatClose1.Location = New System.Drawing.Point(805, 12)
        Me.FlatClose1.Name = "FlatClose1"
        Me.FlatClose1.Size = New System.Drawing.Size(18, 18)
        Me.FlatClose1.TabIndex = 2
        Me.FlatClose1.Text = "FlatClose1"
        Me.FlatClose1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'FlatTextBox1
        '
        Me.FlatTextBox1.BackColor = System.Drawing.Color.Transparent
        Me.FlatTextBox1.Location = New System.Drawing.Point(261, 107)
        Me.FlatTextBox1.MaxLength = 32767
        Me.FlatTextBox1.Multiline = False
        Me.FlatTextBox1.Name = "FlatTextBox1"
        Me.FlatTextBox1.ReadOnly = False
        Me.FlatTextBox1.Size = New System.Drawing.Size(408, 29)
        Me.FlatTextBox1.TabIndex = 1
        Me.FlatTextBox1.Text = "Path Server . . . . . . "
        Me.FlatTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.FlatTextBox1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.FlatTextBox1.UseSystemPasswordChar = False
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton1.Font = New System.Drawing.Font("Footlight MT Light", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton1.Location = New System.Drawing.Point(675, 107)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(149, 29)
        Me.FlatButton1.TabIndex = 0
        Me.FlatButton1.Text = "Select Server"
        Me.FlatButton1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(849, 658)
        Me.Controls.Add(Me.FormSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.FormSkin1.ResumeLayout(False)
        Me.FormSkin1.PerformLayout()
        Me.FlatGroupBox3.ResumeLayout(False)
        Me.FlatGroupBox2.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlatGroupBox1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FormSkin1 As Crypter_ALl_tool.FormSkin
    Friend WithEvents FlatTextBox1 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents FlatButton1 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatClose1 As Crypter_ALl_tool.FlatClose
    Friend WithEvents FlatCheckBox1 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatButton2 As Crypter_ALl_tool.FlatButton
    Friend WithEvents r1 As System.Windows.Forms.RichTextBox
    Friend WithEvents key As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents FlatCheckBox2 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox3 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox4 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatCheckBox5 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatStatusBar1 As Crypter_ALl_tool.FlatStatusBar
    Friend WithEvents FlatGroupBox1 As Crypter_ALl_tool.FlatGroupBox
    Friend WithEvents FlatTrackBar1 As Crypter_ALl_tool.FlatTrackBar
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents FlatGroupBox2 As Crypter_ALl_tool.FlatGroupBox
    Friend WithEvents FlatLabel1 As Crypter_ALl_tool.FlatLabel
    Friend WithEvents FlatButton4 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatButton3 As Crypter_ALl_tool.FlatButton
    Friend WithEvents hazem As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents FlatCheckBox10 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatTrackBar2 As Crypter_ALl_tool.FlatTrackBar
    Friend WithEvents FlatButton5 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatToggle1 As Crypter_ALl_tool.FlatToggle
    Friend WithEvents FlatMini1 As Crypter_ALl_tool.FlatMini
    Friend WithEvents FlatGroupBox3 As Crypter_ALl_tool.FlatGroupBox
    Friend WithEvents FlatCheckBox99 As Crypter_ALl_tool.FlatCheckBox
    Friend WithEvents FlatButton6 As Crypter_ALl_tool.FlatButton

End Class
