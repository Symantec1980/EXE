﻿Imports System.IO
Imports System.Management
Imports System.Runtime.InteropServices

Public Class form2

    Public Seal As License

    Sub New()

        Seal = New License
        Seal.ID = "F6120000"
        Seal.Catch = True
        Seal.Protection = License.Guard.None
        Seal.RunHook = AddressOf runhook
        Seal.Initialize()



        InitializeComponent()
    End Sub

    Sub runhook()
        MessageBox.Show(Seal.Username)
        '   Form1.Show() ' This Used To On HWID or No
    End Sub
    Dim cpuInfo As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        GhostTextbox3.Text = GetHWID()
        ' Me.AcceptButton = GhostButton1
        Form1.Label6.Text = Seal.Username
        '  Form1.Label7.Text = Seal.UsersCount
        Form1.Label8.Text = Seal.Continuous
        Form1.Label9.Text = Seal.UsersOnline
        Dim Request As System.Net.HttpWebRequest = System.Net.HttpWebRequest.Create("http://dl.dropbox.com/u/99357624/GoodJobAtCrackingMySoftware.txt ")
        Dim Response As System.Net.HttpWebResponse = Request.GetResponse()
        Dim SR As System.IO.StreamReader = New System.IO.StreamReader(Response.GetResponseStream)
        Dim HWIDAdded As String = SR.ReadToEnd
        Dim ThisHWID As String = GetHWID()
        If HWIDAdded.Contains(ThisHWID) Then
            Form1.Show()
            Me.Hide()
            Form1.Timer1.Enabled = True
            Form1.Timer2.Enabled = True
        Else
            Application.Exit()
        End If
    End Sub

    Function GetHWID()
        Dim mc As New ManagementClass("win32_processor")
        Dim moc As ManagementObjectCollection = mc.GetInstances
        For Each mo As ManagementObject In moc
            If cpuInfo = "" Then
                cpuInfo = mo.Properties("processorID").Value.ToString
                Exit For
            End If
        Next
        Return cpuInfo
    End Function

    'Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GhostButton1.Click
    '    Form1.Label6.Text = Seal.Username
    '    '  Form1.Label7.Text = Seal.UsersCount
    '    Form1.Label8.Text = Seal.Continuous
    '    Form1.Label9.Text = Seal.UsersOnline
    '    Dim Request As System.Net.HttpWebRequest = System.Net.HttpWebRequest.Create("http://dl.dropbox.com/u/99357624/GoodJobAtCrackingMySoftware.txt ")
    '    Dim Response As System.Net.HttpWebResponse = Request.GetResponse()
    '    Dim SR As System.IO.StreamReader = New System.IO.StreamReader(Response.GetResponseStream)
    '    Dim HWIDAdded As String = SR.ReadToEnd
    '    Dim ThisHWID As String = GetHWID()
    '    If HWIDAdded.Contains(ThisHWID) Then
    '        Form1.Show()
    '        Me.Hide()
    '        Form1.Timer1.Enabled = True
    '        Form1.Timer2.Enabled = True
    '    Else
    '        Application.Exit()
    '    End If
    'End Sub

    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub UTheme1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UTheme1.Click

    End Sub
End Class





