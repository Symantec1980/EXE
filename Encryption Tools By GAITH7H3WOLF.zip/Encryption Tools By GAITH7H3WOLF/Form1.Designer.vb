﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GhostTheme1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostTheme()
        Me.GhostButton19 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GhostGroupBox7 = New Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox()
        Me.GhostButton5 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton20 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostGroupBox6 = New Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox()
        Me.GhostButton18 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GhostButton17 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GhostGroupBox5 = New Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox()
        Me.GhostButton16 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton15 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton14 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton13 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostGroupBox4 = New Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox()
        Me.GhostButton12 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton11 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton10 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostGroupBox3 = New Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox()
        Me.GhostButton9 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GhostButton8 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.TextBox4 = New Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox()
        Me.TextBox3 = New Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GhostButton4 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton3 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton2 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.TextBox1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox()
        Me.GhostButton1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostGroupBox2 = New Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox()
        Me.GhostButton7 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostButton6 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostGroupBox1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox()
        Me.Radiobutton2 = New Encryption_Tools_By_GAITH7H3WOLF.GhostRadiobutton()
        Me.Radiobutton1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostRadiobutton()
        Me.GhostControlBox1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostControlBox()
        Me.GhostTheme1.SuspendLayout()
        Me.GhostGroupBox7.SuspendLayout()
        Me.GhostGroupBox6.SuspendLayout()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GhostGroupBox5.SuspendLayout()
        Me.GhostGroupBox4.SuspendLayout()
        Me.GhostGroupBox3.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GhostGroupBox2.SuspendLayout()
        Me.GhostGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GhostTheme1
        '
        Me.GhostTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.GhostTheme1.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostTheme1.Controls.Add(Me.GhostButton19)
        Me.GhostTheme1.Controls.Add(Me.TextBox2)
        Me.GhostTheme1.Controls.Add(Me.GhostGroupBox7)
        Me.GhostTheme1.Controls.Add(Me.GhostButton20)
        Me.GhostTheme1.Controls.Add(Me.GhostGroupBox6)
        Me.GhostTheme1.Controls.Add(Me.GhostGroupBox5)
        Me.GhostTheme1.Controls.Add(Me.GhostGroupBox4)
        Me.GhostTheme1.Controls.Add(Me.GhostGroupBox3)
        Me.GhostTheme1.Controls.Add(Me.GhostButton4)
        Me.GhostTheme1.Controls.Add(Me.GhostButton3)
        Me.GhostTheme1.Controls.Add(Me.GhostButton2)
        Me.GhostTheme1.Controls.Add(Me.TextBox1)
        Me.GhostTheme1.Controls.Add(Me.GhostButton1)
        Me.GhostTheme1.Controls.Add(Me.GhostGroupBox2)
        Me.GhostTheme1.Controls.Add(Me.GhostGroupBox1)
        Me.GhostTheme1.Controls.Add(Me.GhostControlBox1)
        Me.GhostTheme1.Customization = ""
        Me.GhostTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GhostTheme1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostTheme1.Image = Nothing
        Me.GhostTheme1.Location = New System.Drawing.Point(0, 0)
        Me.GhostTheme1.Movable = True
        Me.GhostTheme1.Name = "GhostTheme1"
        Me.GhostTheme1.NoRounding = False
        Me.GhostTheme1.ShowIcon = True
        Me.GhostTheme1.Sizable = False
        Me.GhostTheme1.Size = New System.Drawing.Size(856, 428)
        Me.GhostTheme1.SmartBounds = True
        Me.GhostTheme1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.GhostTheme1.TabIndex = 0
        Me.GhostTheme1.Text = "VB.NET & C#.NET Encryption Tools v1.3"
        Me.GhostTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GhostTheme1.Transparent = False
        '
        'GhostButton19
        '
        Me.GhostButton19.BackColor = System.Drawing.Color.Maroon
        Me.GhostButton19.Color = System.Drawing.Color.White
        Me.GhostButton19.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton19.Customization = ""
        Me.GhostButton19.EnableGlass = True
        Me.GhostButton19.Font = New System.Drawing.Font("Verdana", 8.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Strikeout), System.Drawing.FontStyle))
        Me.GhostButton19.Image = Nothing
        Me.GhostButton19.Location = New System.Drawing.Point(444, 3)
        Me.GhostButton19.Name = "GhostButton19"
        Me.GhostButton19.NoRounding = False
        Me.GhostButton19.Size = New System.Drawing.Size(332, 19)
        Me.GhostButton19.TabIndex = 12
        Me.GhostButton19.Text = "About !"
        Me.GhostButton19.Transparent = True
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Black
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.TextBox2.Location = New System.Drawing.Point(444, 26)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox2.Size = New System.Drawing.Size(400, 357)
        Me.TextBox2.TabIndex = 18
        '
        'GhostGroupBox7
        '
        Me.GhostGroupBox7.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostGroupBox7.Controls.Add(Me.GhostButton5)
        Me.GhostGroupBox7.Customization = ""
        Me.GhostGroupBox7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox7.Image = Nothing
        Me.GhostGroupBox7.Location = New System.Drawing.Point(228, 26)
        Me.GhostGroupBox7.Name = "GhostGroupBox7"
        Me.GhostGroupBox7.NoRounding = False
        Me.GhostGroupBox7.Size = New System.Drawing.Size(210, 60)
        Me.GhostGroupBox7.TabIndex = 2
        Me.GhostGroupBox7.Text = "VB.NET Compiler"
        Me.GhostGroupBox7.Transparent = False
        '
        'GhostButton5
        '
        Me.GhostButton5.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GhostButton5.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton5.Customization = ""
        Me.GhostButton5.EnableGlass = True
        Me.GhostButton5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton5.Image = Nothing
        Me.GhostButton5.Location = New System.Drawing.Point(11, 28)
        Me.GhostButton5.Name = "GhostButton5"
        Me.GhostButton5.NoRounding = False
        Me.GhostButton5.Size = New System.Drawing.Size(191, 23)
        Me.GhostButton5.TabIndex = 12
        Me.GhostButton5.Text = "Visual Basic File Compiler"
        Me.GhostButton5.Transparent = False
        '
        'GhostButton20
        '
        Me.GhostButton20.Color = System.Drawing.Color.Fuchsia
        Me.GhostButton20.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton20.Customization = ""
        Me.GhostButton20.EnableGlass = True
        Me.GhostButton20.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton20.Image = Nothing
        Me.GhostButton20.Location = New System.Drawing.Point(724, 390)
        Me.GhostButton20.Name = "GhostButton20"
        Me.GhostButton20.NoRounding = False
        Me.GhostButton20.Size = New System.Drawing.Size(57, 27)
        Me.GhostButton20.TabIndex = 17
        Me.GhostButton20.Text = "Clean"
        Me.GhostButton20.Transparent = False
        '
        'GhostGroupBox6
        '
        Me.GhostGroupBox6.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostGroupBox6.Controls.Add(Me.GhostButton18)
        Me.GhostGroupBox6.Controls.Add(Me.NumericUpDown3)
        Me.GhostGroupBox6.Controls.Add(Me.Label5)
        Me.GhostGroupBox6.Controls.Add(Me.GhostButton17)
        Me.GhostGroupBox6.Controls.Add(Me.NumericUpDown2)
        Me.GhostGroupBox6.Controls.Add(Me.Label4)
        Me.GhostGroupBox6.Customization = ""
        Me.GhostGroupBox6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox6.Image = Nothing
        Me.GhostGroupBox6.Location = New System.Drawing.Point(228, 244)
        Me.GhostGroupBox6.Name = "GhostGroupBox6"
        Me.GhostGroupBox6.NoRounding = False
        Me.GhostGroupBox6.Size = New System.Drawing.Size(210, 139)
        Me.GhostGroupBox6.TabIndex = 15
        Me.GhostGroupBox6.Text = ".NET Junks Codes & Strings"
        Me.GhostGroupBox6.Transparent = False
        '
        'GhostButton18
        '
        Me.GhostButton18.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GhostButton18.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton18.Customization = ""
        Me.GhostButton18.EnableGlass = True
        Me.GhostButton18.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton18.Image = Nothing
        Me.GhostButton18.Location = New System.Drawing.Point(11, 110)
        Me.GhostButton18.Name = "GhostButton18"
        Me.GhostButton18.NoRounding = False
        Me.GhostButton18.Size = New System.Drawing.Size(191, 23)
        Me.GhostButton18.TabIndex = 15
        Me.GhostButton18.Text = "Generate Codes"
        Me.GhostButton18.Transparent = False
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown3.ForeColor = System.Drawing.Color.White
        Me.NumericUpDown3.Location = New System.Drawing.Point(112, 85)
        Me.NumericUpDown3.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(89, 20)
        Me.NumericUpDown3.TabIndex = 14
        Me.NumericUpDown3.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(8, 89)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(105, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "SUB Number     :"
        '
        'GhostButton17
        '
        Me.GhostButton17.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GhostButton17.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton17.Customization = ""
        Me.GhostButton17.EnableGlass = True
        Me.GhostButton17.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton17.Image = Nothing
        Me.GhostButton17.Location = New System.Drawing.Point(10, 51)
        Me.GhostButton17.Name = "GhostButton17"
        Me.GhostButton17.NoRounding = False
        Me.GhostButton17.Size = New System.Drawing.Size(191, 23)
        Me.GhostButton17.TabIndex = 12
        Me.GhostButton17.Text = "Generate Strings"
        Me.GhostButton17.Transparent = False
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown2.ForeColor = System.Drawing.Color.White
        Me.NumericUpDown2.Location = New System.Drawing.Point(111, 26)
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(89, 20)
        Me.NumericUpDown2.TabIndex = 8
        Me.NumericUpDown2.Value = New Decimal(New Integer() {20, 0, 0, 0})
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(7, 30)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(105, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Strings Number :"
        '
        'GhostGroupBox5
        '
        Me.GhostGroupBox5.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostGroupBox5.Controls.Add(Me.GhostButton16)
        Me.GhostGroupBox5.Controls.Add(Me.GhostButton15)
        Me.GhostGroupBox5.Controls.Add(Me.GhostButton14)
        Me.GhostGroupBox5.Controls.Add(Me.GhostButton13)
        Me.GhostGroupBox5.Customization = ""
        Me.GhostGroupBox5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox5.Image = Nothing
        Me.GhostGroupBox5.Location = New System.Drawing.Point(228, 92)
        Me.GhostGroupBox5.Name = "GhostGroupBox5"
        Me.GhostGroupBox5.NoRounding = False
        Me.GhostGroupBox5.Size = New System.Drawing.Size(210, 149)
        Me.GhostGroupBox5.TabIndex = 12
        Me.GhostGroupBox5.Text = "Additional Codes"
        Me.GhostGroupBox5.Transparent = False
        '
        'GhostButton16
        '
        Me.GhostButton16.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton16.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton16.Customization = ""
        Me.GhostButton16.EnableGlass = True
        Me.GhostButton16.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton16.Image = Nothing
        Me.GhostButton16.Location = New System.Drawing.Point(10, 119)
        Me.GhostButton16.Name = "GhostButton16"
        Me.GhostButton16.NoRounding = False
        Me.GhostButton16.Size = New System.Drawing.Size(191, 23)
        Me.GhostButton16.TabIndex = 11
        Me.GhostButton16.Text = "RES To BYTE"
        Me.GhostButton16.Transparent = False
        '
        'GhostButton15
        '
        Me.GhostButton15.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton15.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton15.Customization = ""
        Me.GhostButton15.EnableGlass = True
        Me.GhostButton15.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton15.Image = Nothing
        Me.GhostButton15.Location = New System.Drawing.Point(10, 89)
        Me.GhostButton15.Name = "GhostButton15"
        Me.GhostButton15.NoRounding = False
        Me.GhostButton15.Size = New System.Drawing.Size(191, 23)
        Me.GhostButton15.TabIndex = 10
        Me.GhostButton15.Text = ".Net Ressource Writer Code"
        Me.GhostButton15.Transparent = False
        '
        'GhostButton14
        '
        Me.GhostButton14.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton14.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton14.Customization = ""
        Me.GhostButton14.EnableGlass = True
        Me.GhostButton14.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton14.Image = Nothing
        Me.GhostButton14.Location = New System.Drawing.Point(10, 59)
        Me.GhostButton14.Name = "GhostButton14"
        Me.GhostButton14.NoRounding = False
        Me.GhostButton14.Size = New System.Drawing.Size(191, 23)
        Me.GhostButton14.TabIndex = 9
        Me.GhostButton14.Text = "Hex To Byte"
        Me.GhostButton14.Transparent = False
        '
        'GhostButton13
        '
        Me.GhostButton13.Color = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton13.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton13.Customization = ""
        Me.GhostButton13.EnableGlass = True
        Me.GhostButton13.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton13.Image = Nothing
        Me.GhostButton13.Location = New System.Drawing.Point(10, 29)
        Me.GhostButton13.Name = "GhostButton13"
        Me.GhostButton13.NoRounding = False
        Me.GhostButton13.Size = New System.Drawing.Size(191, 23)
        Me.GhostButton13.TabIndex = 8
        Me.GhostButton13.Text = "Gzip .NET Code"
        Me.GhostButton13.Transparent = False
        '
        'GhostGroupBox4
        '
        Me.GhostGroupBox4.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostGroupBox4.Controls.Add(Me.GhostButton12)
        Me.GhostGroupBox4.Controls.Add(Me.GhostButton11)
        Me.GhostGroupBox4.Controls.Add(Me.GhostButton10)
        Me.GhostGroupBox4.Customization = ""
        Me.GhostGroupBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox4.Image = Nothing
        Me.GhostGroupBox4.Location = New System.Drawing.Point(12, 341)
        Me.GhostGroupBox4.Name = "GhostGroupBox4"
        Me.GhostGroupBox4.NoRounding = False
        Me.GhostGroupBox4.Size = New System.Drawing.Size(210, 75)
        Me.GhostGroupBox4.TabIndex = 2
        Me.GhostGroupBox4.Text = "RunPE x32 & x64"
        Me.GhostGroupBox4.Transparent = False
        '
        'GhostButton12
        '
        Me.GhostButton12.Color = System.Drawing.Color.Red
        Me.GhostButton12.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton12.Customization = ""
        Me.GhostButton12.EnableGlass = True
        Me.GhostButton12.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton12.Image = Nothing
        Me.GhostButton12.Location = New System.Drawing.Point(9, 33)
        Me.GhostButton12.Name = "GhostButton12"
        Me.GhostButton12.NoRounding = False
        Me.GhostButton12.Size = New System.Drawing.Size(54, 27)
        Me.GhostButton12.TabIndex = 14
        Me.GhostButton12.Text = "RunPE 3"
        Me.GhostButton12.Transparent = False
        '
        'GhostButton11
        '
        Me.GhostButton11.Color = System.Drawing.Color.Red
        Me.GhostButton11.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton11.Customization = ""
        Me.GhostButton11.EnableGlass = True
        Me.GhostButton11.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton11.Image = Nothing
        Me.GhostButton11.Location = New System.Drawing.Point(80, 33)
        Me.GhostButton11.Name = "GhostButton11"
        Me.GhostButton11.NoRounding = False
        Me.GhostButton11.Size = New System.Drawing.Size(54, 27)
        Me.GhostButton11.TabIndex = 13
        Me.GhostButton11.Text = "RunPE 2"
        Me.GhostButton11.Transparent = False
        '
        'GhostButton10
        '
        Me.GhostButton10.Color = System.Drawing.Color.Red
        Me.GhostButton10.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton10.Customization = ""
        Me.GhostButton10.EnableGlass = True
        Me.GhostButton10.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton10.Image = Nothing
        Me.GhostButton10.Location = New System.Drawing.Point(147, 33)
        Me.GhostButton10.Name = "GhostButton10"
        Me.GhostButton10.NoRounding = False
        Me.GhostButton10.Size = New System.Drawing.Size(54, 27)
        Me.GhostButton10.TabIndex = 12
        Me.GhostButton10.Text = "RunPE 1"
        Me.GhostButton10.Transparent = False
        '
        'GhostGroupBox3
        '
        Me.GhostGroupBox3.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostGroupBox3.Controls.Add(Me.GhostButton9)
        Me.GhostGroupBox3.Controls.Add(Me.NumericUpDown1)
        Me.GhostGroupBox3.Controls.Add(Me.Label3)
        Me.GhostGroupBox3.Controls.Add(Me.GhostButton8)
        Me.GhostGroupBox3.Controls.Add(Me.TextBox4)
        Me.GhostGroupBox3.Controls.Add(Me.TextBox3)
        Me.GhostGroupBox3.Controls.Add(Me.Label2)
        Me.GhostGroupBox3.Controls.Add(Me.Label1)
        Me.GhostGroupBox3.Customization = ""
        Me.GhostGroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox3.Image = Nothing
        Me.GhostGroupBox3.Location = New System.Drawing.Point(12, 162)
        Me.GhostGroupBox3.Name = "GhostGroupBox3"
        Me.GhostGroupBox3.NoRounding = False
        Me.GhostGroupBox3.Size = New System.Drawing.Size(210, 173)
        Me.GhostGroupBox3.TabIndex = 12
        Me.GhostGroupBox3.Text = "Hex Convertion"
        Me.GhostGroupBox3.Transparent = False
        '
        'GhostButton9
        '
        Me.GhostButton9.Color = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton9.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton9.Customization = ""
        Me.GhostButton9.EnableGlass = True
        Me.GhostButton9.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton9.Image = Nothing
        Me.GhostButton9.Location = New System.Drawing.Point(9, 144)
        Me.GhostButton9.Name = "GhostButton9"
        Me.GhostButton9.NoRounding = False
        Me.GhostButton9.Size = New System.Drawing.Size(192, 23)
        Me.GhostButton9.TabIndex = 7
        Me.GhostButton9.Text = "Generate"
        Me.GhostButton9.Transparent = False
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown1.ForeColor = System.Drawing.Color.White
        Me.NumericUpDown1.Location = New System.Drawing.Point(115, 118)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {100000000, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(89, 20)
        Me.NumericUpDown1.TabIndex = 6
        Me.NumericUpDown1.Value = New Decimal(New Integer() {200, 0, 0, 0})
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(11, 122)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Strings Length :"
        '
        'GhostButton8
        '
        Me.GhostButton8.Color = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton8.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton8.Customization = ""
        Me.GhostButton8.EnableGlass = True
        Me.GhostButton8.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton8.Image = Nothing
        Me.GhostButton8.Location = New System.Drawing.Point(9, 87)
        Me.GhostButton8.Name = "GhostButton8"
        Me.GhostButton8.NoRounding = False
        Me.GhostButton8.Size = New System.Drawing.Size(195, 23)
        Me.GhostButton8.TabIndex = 4
        Me.GhostButton8.Text = "..: Random :.."
        Me.GhostButton8.Transparent = False
        '
        'TextBox4
        '
        Me.TextBox4.Customization = "wMAA/wAAAP8AAAD/Wlpa/w=="
        Me.TextBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TextBox4.Image = Nothing
        Me.TextBox4.Location = New System.Drawing.Point(89, 57)
        Me.TextBox4.MaxLength = 32767
        Me.TextBox4.Multiline = False
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.NoRounding = False
        Me.TextBox4.ReadOnly = False
        Me.TextBox4.Size = New System.Drawing.Size(115, 24)
        Me.TextBox4.TabIndex = 3
        Me.TextBox4.Text = "CLEAN"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox4.Transparent = False
        Me.TextBox4.UseSystemPasswordChar = False
        '
        'TextBox3
        '
        Me.TextBox3.Customization = "wMAA/wAAAP8AAAD/Wlpa/w=="
        Me.TextBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TextBox3.Image = Nothing
        Me.TextBox3.Location = New System.Drawing.Point(89, 27)
        Me.TextBox3.MaxLength = 32767
        Me.TextBox3.Multiline = False
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.NoRounding = False
        Me.TextBox3.ReadOnly = False
        Me.TextBox3.Size = New System.Drawing.Size(115, 24)
        Me.TextBox3.TabIndex = 2
        Me.TextBox3.Text = "GAITH7H3WOLF"
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TextBox3.Transparent = False
        Me.TextBox3.UseSystemPasswordChar = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(11, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Var Name :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(9, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "SUB Name :"
        '
        'GhostButton4
        '
        Me.GhostButton4.Color = System.Drawing.Color.Fuchsia
        Me.GhostButton4.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton4.Customization = ""
        Me.GhostButton4.EnableGlass = True
        Me.GhostButton4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton4.Image = Nothing
        Me.GhostButton4.Location = New System.Drawing.Point(787, 390)
        Me.GhostButton4.Name = "GhostButton4"
        Me.GhostButton4.NoRounding = False
        Me.GhostButton4.Size = New System.Drawing.Size(57, 27)
        Me.GhostButton4.TabIndex = 8
        Me.GhostButton4.Text = "Save As"
        Me.GhostButton4.Transparent = False
        '
        'GhostButton3
        '
        Me.GhostButton3.Color = System.Drawing.Color.Fuchsia
        Me.GhostButton3.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton3.Customization = ""
        Me.GhostButton3.EnableGlass = True
        Me.GhostButton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton3.Image = Nothing
        Me.GhostButton3.Location = New System.Drawing.Point(661, 390)
        Me.GhostButton3.Name = "GhostButton3"
        Me.GhostButton3.NoRounding = False
        Me.GhostButton3.Size = New System.Drawing.Size(57, 27)
        Me.GhostButton3.TabIndex = 7
        Me.GhostButton3.Text = "Past"
        Me.GhostButton3.Transparent = False
        '
        'GhostButton2
        '
        Me.GhostButton2.Color = System.Drawing.Color.Fuchsia
        Me.GhostButton2.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton2.Customization = ""
        Me.GhostButton2.EnableGlass = True
        Me.GhostButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton2.Image = Nothing
        Me.GhostButton2.Location = New System.Drawing.Point(598, 390)
        Me.GhostButton2.Name = "GhostButton2"
        Me.GhostButton2.NoRounding = False
        Me.GhostButton2.Size = New System.Drawing.Size(57, 27)
        Me.GhostButton2.TabIndex = 6
        Me.GhostButton2.Text = "Copy"
        Me.GhostButton2.Transparent = False
        '
        'TextBox1
        '
        Me.TextBox1.Customization = "/////wAAAP8AAAD/Wlpa/w=="
        Me.TextBox1.Font = New System.Drawing.Font("Verdana", 7.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.TextBox1.Image = Nothing
        Me.TextBox1.Location = New System.Drawing.Point(314, 390)
        Me.TextBox1.MaxLength = 32767
        Me.TextBox1.Multiline = False
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.NoRounding = False
        Me.TextBox1.ReadOnly = False
        Me.TextBox1.Size = New System.Drawing.Size(278, 23)
        Me.TextBox1.TabIndex = 4
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox1.Transparent = False
        Me.TextBox1.UseSystemPasswordChar = False
        '
        'GhostButton1
        '
        Me.GhostButton1.Color = System.Drawing.Color.Fuchsia
        Me.GhostButton1.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton1.Customization = ""
        Me.GhostButton1.EnableGlass = True
        Me.GhostButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton1.Image = Nothing
        Me.GhostButton1.Location = New System.Drawing.Point(228, 389)
        Me.GhostButton1.Name = "GhostButton1"
        Me.GhostButton1.NoRounding = False
        Me.GhostButton1.Size = New System.Drawing.Size(80, 27)
        Me.GhostButton1.TabIndex = 3
        Me.GhostButton1.Text = "Choose File"
        Me.GhostButton1.Transparent = False
        '
        'GhostGroupBox2
        '
        Me.GhostGroupBox2.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostGroupBox2.Controls.Add(Me.GhostButton7)
        Me.GhostGroupBox2.Controls.Add(Me.GhostButton6)
        Me.GhostGroupBox2.Customization = ""
        Me.GhostGroupBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox2.Image = Nothing
        Me.GhostGroupBox2.Location = New System.Drawing.Point(12, 92)
        Me.GhostGroupBox2.Name = "GhostGroupBox2"
        Me.GhostGroupBox2.NoRounding = False
        Me.GhostGroupBox2.Size = New System.Drawing.Size(210, 64)
        Me.GhostGroupBox2.TabIndex = 2
        Me.GhostGroupBox2.Text = "Gzip & Base64"
        Me.GhostGroupBox2.Transparent = False
        '
        'GhostButton7
        '
        Me.GhostButton7.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton7.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton7.Customization = ""
        Me.GhostButton7.EnableGlass = True
        Me.GhostButton7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton7.Image = Nothing
        Me.GhostButton7.Location = New System.Drawing.Point(100, 30)
        Me.GhostButton7.Name = "GhostButton7"
        Me.GhostButton7.NoRounding = False
        Me.GhostButton7.Size = New System.Drawing.Size(97, 27)
        Me.GhostButton7.TabIndex = 11
        Me.GhostButton7.Text = "Gzip + Base64"
        Me.GhostButton7.Transparent = False
        '
        'GhostButton6
        '
        Me.GhostButton6.Color = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.GhostButton6.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GhostButton6.Customization = ""
        Me.GhostButton6.EnableGlass = True
        Me.GhostButton6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton6.Image = Nothing
        Me.GhostButton6.Location = New System.Drawing.Point(12, 30)
        Me.GhostButton6.Name = "GhostButton6"
        Me.GhostButton6.NoRounding = False
        Me.GhostButton6.Size = New System.Drawing.Size(82, 27)
        Me.GhostButton6.TabIndex = 10
        Me.GhostButton6.Text = "Base64"
        Me.GhostButton6.Transparent = False
        '
        'GhostGroupBox1
        '
        Me.GhostGroupBox1.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostGroupBox1.Controls.Add(Me.Radiobutton2)
        Me.GhostGroupBox1.Controls.Add(Me.Radiobutton1)
        Me.GhostGroupBox1.Customization = ""
        Me.GhostGroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox1.Image = Nothing
        Me.GhostGroupBox1.Location = New System.Drawing.Point(12, 26)
        Me.GhostGroupBox1.Name = "GhostGroupBox1"
        Me.GhostGroupBox1.NoRounding = False
        Me.GhostGroupBox1.Size = New System.Drawing.Size(210, 60)
        Me.GhostGroupBox1.TabIndex = 1
        Me.GhostGroupBox1.Text = "Choose Language"
        Me.GhostGroupBox1.Transparent = False
        '
        'Radiobutton2
        '
        Me.Radiobutton2.Checked = False
        Me.Radiobutton2.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.Radiobutton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Radiobutton2.Customization = ""
        Me.Radiobutton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.Radiobutton2.Image = Nothing
        Me.Radiobutton2.Location = New System.Drawing.Point(131, 33)
        Me.Radiobutton2.Name = "Radiobutton2"
        Me.Radiobutton2.NoRounding = False
        Me.Radiobutton2.Size = New System.Drawing.Size(66, 15)
        Me.Radiobutton2.TabIndex = 1
        Me.Radiobutton2.Text = "C#.NET"
        Me.Radiobutton2.Transparent = False
        '
        'Radiobutton1
        '
        Me.Radiobutton1.Checked = True
        Me.Radiobutton1.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.Radiobutton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Radiobutton1.Customization = ""
        Me.Radiobutton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.Radiobutton1.Image = Nothing
        Me.Radiobutton1.Location = New System.Drawing.Point(12, 33)
        Me.Radiobutton1.Name = "Radiobutton1"
        Me.Radiobutton1.NoRounding = False
        Me.Radiobutton1.Size = New System.Drawing.Size(65, 15)
        Me.Radiobutton1.TabIndex = 0
        Me.Radiobutton1.Text = "VB.NET"
        Me.Radiobutton1.Transparent = True
        '
        'GhostControlBox1
        '
        Me.GhostControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GhostControlBox1.Customization = "QEBA/wAAAP9aWlr/"
        Me.GhostControlBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostControlBox1.Image = Nothing
        Me.GhostControlBox1.Location = New System.Drawing.Point(782, 3)
        Me.GhostControlBox1.Name = "GhostControlBox1"
        Me.GhostControlBox1.NoRounding = False
        Me.GhostControlBox1.Size = New System.Drawing.Size(71, 19)
        Me.GhostControlBox1.TabIndex = 0
        Me.GhostControlBox1.Text = "GhostControlBox1"
        Me.GhostControlBox1.Transparent = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DimGray
        Me.ClientSize = New System.Drawing.Size(856, 428)
        Me.Controls.Add(Me.GhostTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Encryption Tools Coded By GAITH7H3WOLF"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GhostTheme1.ResumeLayout(False)
        Me.GhostTheme1.PerformLayout()
        Me.GhostGroupBox7.ResumeLayout(False)
        Me.GhostGroupBox6.ResumeLayout(False)
        Me.GhostGroupBox6.PerformLayout()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GhostGroupBox5.ResumeLayout(False)
        Me.GhostGroupBox4.ResumeLayout(False)
        Me.GhostGroupBox3.ResumeLayout(False)
        Me.GhostGroupBox3.PerformLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GhostGroupBox2.ResumeLayout(False)
        Me.GhostGroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GhostTheme1 As Encryption_Tools_By_GAITH7H3WOLF.GhostTheme
    Friend WithEvents GhostControlBox1 As Encryption_Tools_By_GAITH7H3WOLF.GhostControlBox
    Friend WithEvents GhostGroupBox3 As Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox
    Friend WithEvents GhostButton4 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton3 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton2 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents TextBox1 As Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox
    Friend WithEvents GhostButton1 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostGroupBox2 As Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox
    Friend WithEvents GhostButton7 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton6 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostGroupBox1 As Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox
    Friend WithEvents Radiobutton2 As Encryption_Tools_By_GAITH7H3WOLF.GhostRadiobutton
    Friend WithEvents Radiobutton1 As Encryption_Tools_By_GAITH7H3WOLF.GhostRadiobutton
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GhostButton8 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents TextBox4 As Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox
    Friend WithEvents TextBox3 As Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GhostGroupBox6 As Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox
    Friend WithEvents GhostGroupBox5 As Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox
    Friend WithEvents GhostButton16 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton15 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton14 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton13 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostGroupBox4 As Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox
    Friend WithEvents GhostButton12 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton11 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton10 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton9 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostButton18 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents NumericUpDown3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GhostButton17 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents NumericUpDown2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents GhostButton20 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostGroupBox7 As Encryption_Tools_By_GAITH7H3WOLF.GhostGroupBox
    Friend WithEvents GhostButton5 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents GhostButton19 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton

End Class
