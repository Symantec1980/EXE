Imports System.IO
Public Class FrmEncrypt

    Private Sub CmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdClose.Click
        Application.Exit()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim p As New Process
        p.Start("http://www.programmer2programmer.net")
    End Sub

    Private Sub CmdBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdBrowse.Click
        Cd1.Filter = "All files|*.*"
        Cd1.Title = "Select any file to encrypt."
        Cd1.ShowDialog()

        TxtFileName.Text = Cd1.FileName
    End Sub

    Private Sub CdmEncryption_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CdmEncryption.Click
        '>>> check the file name entered is exist or not
        If File.Exists(TxtFileName.Text) = False Then
            TxtFileName.SelectionStart = 0
            TxtFileName.SelectionLength = TxtFileName.Text.Length
            TxtFileName.Focus()
            MsgBox("File does not exist, select a file to encrypt.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        '>>> check for password
        If TxtPassword.Text = "" Then
            TxtPassword.Focus()
            MsgBox("Enter password, password can not be blank.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If
        If TxtPassword.Text <> TxtConfirmPassword.Text Then
            TxtConfirmPassword.SelectionStart = 0
            TxtConfirmPassword.SelectionLength = TxtConfirmPassword.Text.Length
            TxtConfirmPassword.Focus()
            MsgBox("Password and confirm password dose not math, try again.", MsgBoxStyle.Exclamation)
            Exit Sub
        End If

        '>>> create a dataset, datatable to hold file content, password
        Dim DsImg As New DataSet
        Dim Dt As New DataTable("Images")
        Dt.Columns.Add(New DataColumn("sysid", System.Type.GetType("System.String")))
        Dt.Columns.Add(New DataColumn("filename", System.Type.GetType("System.String")))
        Dt.Columns.Add(New DataColumn("image", System.Type.GetType("System.Byte[]")))
        Dt.Columns.Add(New DataColumn("filetag", System.Type.GetType("System.String")))
        DsImg.Tables.Add(Dt)

        '>>> convert the file to binary
        Dim Fs As New System.IO.FileStream(TxtFileName.Text, System.IO.FileMode.Open)
        Dim bn As New System.IO.BinaryReader(Fs)

        '>>> save the details in dataset, tables

        Dim Dr As DataRow
        Dr = DsImg.Tables("images").NewRow
        Dr("sysid") = Now.ToString
        Dr("filename") = TxtFileName.Text
        Dr("image") = bn.ReadBytes(Int(bn.BaseStream.Length))
        Dr("filetag") = StrEncrypt(TxtPassword.Text)
        DsImg.Tables("images").Rows.Add(Dr)

        '>>> write xml file from dataset with binary content
        DsImg.WriteXml(TxtFileName.Text & ".sp2p")


        MsgBox("Encryption process completed." & vbCrLf & vbCrLf & "New encrypted file created as..." & vbCrLf & TxtFileName.Text & ".sp2p", MsgBoxStyle.Information)
    End Sub



End Class