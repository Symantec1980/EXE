﻿Public Class Class6


    Public Shared Function RC4Encrypt(ByVal A6 As Byte(), ByVal A7 As String) As Byte()
        Dim A1 As Byte() = System.Text.Encoding.ASCII.GetBytes(A7)
        Dim A2, A3, A4 As UInteger
        Dim A5 As UInteger() = New UInteger(255) {}
        Dim A9 As Byte() = New Byte(A6.Length - 1) {}
        For A2 = 0 To 255
            A5(A2) = A2
        Next
        For A2 = 0 To 255
            A3 = (A3 + A1(A2 Mod A1.Length) + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
        Next
        A2 = 0 : A3 = 0
        For A8 = 0 To A9.Length - 1
            A2 = (A2 + 1) And 255
            A3 = (A3 + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
            A9(A8) = A6(A8) Xor A5((A5(A2) + A5(A3)) And 255)
        Next
        Return A9
    End Function



    Public Function RC4decrypt(ByVal D1 As Byte(), ByVal D2 As String) As Byte()
        Dim D3 As Byte() = System.Text.Encoding.ASCII.GetBytes(D2)
        Dim D4, D5, D6 As UInteger
        Dim D7 As UInteger() = New UInteger(255) {}
        Dim D8 As Byte() = New Byte(D1.Length - 1) {}
        For D4 = 0 To 255
            D7(D4) = D4
        Next
        For D4 = 0 To 255
            D5 = (D5 + D3(D4 Mod D3.Length) + D7(D4)) And 255
            D6 = D7(D4)
            D7(D4) = D7(D5)
            D7(D5) = D6
        Next
        D4 = 0 : D5 = 0
        For D9 = 0 To D8.Length - 1
            D4 = (D4 + 1) And 255
            D5 = (D5 + D7(D4)) And 255
            D6 = D7(D4)
            D7(D4) = D7(D5)
            D7(D5) = D6
            D8(D9) = D1(D9) Xor D7((D7(D4) + D7(D5)) And 255)
        Next
        Return D8
    End Function


End Class
