﻿Public Class Form1
    'Coded By Tarek @BronCoder
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TextBox2.Text = Crypt(TextBox1.Text, TextBox4.Text)
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox3.Text = Decry(TextBox2.Text, TextBox4.Text)
    End Sub
    Function Crypt(ByVal w As String, ByVal key As String) 'Coded By Tarek @BronCoder
        Dim result = "", k = "", a = ""
        For i = 0 To w.Length - 1
            k = AscW(w.Substring(i, 1))
            For j = 0 To k.Length - 1
                a += Chr(k.Substring(j, 1) + 14)
            Next
            result += a & key
            a = ""
        Next
        Return result.Remove(result.Length - 1, 1)
    End Function
    Function Decry(ByVal w As String, ByVal key As String) 'Coded By Tarek @BronCoder
        Dim result = "", k = ""
        For Each s In Split(w, key)
            For i = 0 To s.Length - 1
                k += (Asc(s.Substring(i, 1)) - 14).ToString
            Next
            result += Chr(k)
            k = ""
        Next
        Return result
    End Function
End Class
