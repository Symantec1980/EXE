﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DevSkin1 = New Crypter_MrHeRo.DevSkin()
        Me.DevButton1 = New Crypter_MrHeRo.DevButton()
        Me.DevLabel4 = New Crypter_MrHeRo.DevLabel()
        Me.DevLabel3 = New Crypter_MrHeRo.DevLabel()
        Me.DevLabel2 = New Crypter_MrHeRo.DevLabel()
        Me.DevLabel1 = New Crypter_MrHeRo.DevLabel()
        Me.DevSkin1.SuspendLayout()
        Me.SuspendLayout()
        '
        'DevSkin1
        '
        Me.DevSkin1.Controls.Add(Me.DevButton1)
        Me.DevSkin1.Controls.Add(Me.DevLabel4)
        Me.DevSkin1.Controls.Add(Me.DevLabel3)
        Me.DevSkin1.Controls.Add(Me.DevLabel2)
        Me.DevSkin1.Controls.Add(Me.DevLabel1)
        Me.DevSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DevSkin1.HeaderLogo = Nothing
        Me.DevSkin1.Location = New System.Drawing.Point(0, 0)
        Me.DevSkin1.Name = "DevSkin1"
        Me.DevSkin1.Size = New System.Drawing.Size(154, 215)
        Me.DevSkin1.TabIndex = 0
        Me.DevSkin1.Text = "About"
        '
        'DevButton1
        '
        Me.DevButton1.ButtonColor = Crypter_MrHeRo.DevButton.xButtonColor.Blue
        Me.DevButton1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.DevButton1.Location = New System.Drawing.Point(15, 179)
        Me.DevButton1.Name = "DevButton1"
        Me.DevButton1.Size = New System.Drawing.Size(79, 28)
        Me.DevButton1.TabIndex = 1
        Me.DevButton1.Text = "back"
        '
        'DevLabel4
        '
        Me.DevLabel4.AutoSize = True
        Me.DevLabel4.BackColor = System.Drawing.Color.Transparent
        Me.DevLabel4.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DevLabel4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.DevLabel4.Location = New System.Drawing.Point(12, 161)
        Me.DevLabel4.Name = "DevLabel4"
        Me.DevLabel4.Size = New System.Drawing.Size(116, 15)
        Me.DevLabel4.TabIndex = 4
        Me.DevLabel4.Text = "www.dev-point.com"
        '
        'DevLabel3
        '
        Me.DevLabel3.AutoSize = True
        Me.DevLabel3.BackColor = System.Drawing.Color.Transparent
        Me.DevLabel3.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DevLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.DevLabel3.Location = New System.Drawing.Point(12, 126)
        Me.DevLabel3.Name = "DevLabel3"
        Me.DevLabel3.Size = New System.Drawing.Size(103, 15)
        Me.DevLabel3.TabIndex = 3
        Me.DevLabel3.Text = "Skype : mrhero-00"
        '
        'DevLabel2
        '
        Me.DevLabel2.AutoSize = True
        Me.DevLabel2.BackColor = System.Drawing.Color.Transparent
        Me.DevLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DevLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.DevLabel2.Location = New System.Drawing.Point(12, 93)
        Me.DevLabel2.Name = "DevLabel2"
        Me.DevLabel2.Size = New System.Drawing.Size(79, 15)
        Me.DevLabel2.TabIndex = 2
        Me.DevLabel2.Text = "Verison : 0.3.0"
        '
        'DevLabel1
        '
        Me.DevLabel1.AutoSize = True
        Me.DevLabel1.BackColor = System.Drawing.Color.Transparent
        Me.DevLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.DevLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(77, Byte), Integer), CType(CType(143, Byte), Integer))
        Me.DevLabel1.Location = New System.Drawing.Point(12, 63)
        Me.DevLabel1.Name = "DevLabel1"
        Me.DevLabel1.Size = New System.Drawing.Size(141, 15)
        Me.DevLabel1.TabIndex = 1
        Me.DevLabel1.Text = "Coded : MrHeRo . CorrM "
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(154, 215)
        Me.Controls.Add(Me.DevSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.DevSkin1.ResumeLayout(False)
        Me.DevSkin1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DevSkin1 As Crypter_MrHeRo.DevSkin
    Friend WithEvents DevLabel1 As Crypter_MrHeRo.DevLabel
    Friend WithEvents DevLabel3 As Crypter_MrHeRo.DevLabel
    Friend WithEvents DevLabel2 As Crypter_MrHeRo.DevLabel
    Friend WithEvents DevLabel4 As Crypter_MrHeRo.DevLabel
    Friend WithEvents DevButton1 As Crypter_MrHeRo.DevButton
End Class
