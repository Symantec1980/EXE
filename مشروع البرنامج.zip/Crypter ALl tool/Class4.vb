﻿Imports System.Security.Cryptography
Imports System.Text
Public Class Class4

    Public Class Form1
        Public Shared Function Md5Encrypt(ByVal bytData() As Byte, ByVal sKey As String, Optional ByVal tMode As CipherMode = CipherMode.ECB, Optional ByVal tPadding As PaddingMode = PaddingMode.PKCS7) As Byte()
            Dim keyArray As Byte()

            Dim hashmd5 As New MD5CryptoServiceProvider()
            keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(sKey))
            hashmd5.Clear()

            Dim tdes As New TripleDESCryptoServiceProvider()
            tdes.Key = keyArray
            tdes.Mode = tMode
            tdes.Padding = tPadding

            Dim cTransform As ICryptoTransform = tdes.CreateEncryptor()
            Dim resultArray As Byte() = cTransform.TransformFinalBlock(bytData, 0, bytData.Length)
            tdes.Clear()
            Return resultArray
        End Function
    End Class


    Public Shared Function Md5Decrypt(ByVal bytData() As Byte, ByVal sKey As String, Optional ByVal tMode As CipherMode = CipherMode.ECB, Optional ByVal tPadding As PaddingMode = PaddingMode.PKCS7) As Byte()
        Dim keyArray As Byte()
        Dim hashmd5 As New MD5CryptoServiceProvider()
        keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(sKey))
        hashmd5.Clear()

        Dim tdes As New TripleDESCryptoServiceProvider()
        tdes.Key = keyArray
        tdes.Mode = tMode
        tdes.Padding = tPadding

        Dim cTransform As ICryptoTransform = tdes.CreateDecryptor()
        Dim resultArray As Byte() = cTransform.TransformFinalBlock(bytData, 0, bytData.Length)
        tdes.Clear()
        Return resultArray
    End Function

    ' call md5Decrypt
End Class
