﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CrystalClearThemeContainer1 = New xCoders.NET_Obfuscator.CrystalClearThemeContainer()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.CrystalClearButton1 = New xCoders.NET_Obfuscator.CrystalClearButton()
        Me.CrystalClearButton2 = New xCoders.NET_Obfuscator.CrystalClearButton()
        Me.CrystalClearTextBox1 = New xCoders.NET_Obfuscator.CrystalClearTextBox()
        Me.CrystalClearButton3 = New xCoders.NET_Obfuscator.CrystalClearButton()
        Me.CrystalClearThemeContainer1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CrystalClearThemeContainer1
        '
        Me.CrystalClearThemeContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer), CType(CType(230, Byte), Integer))
        Me.CrystalClearThemeContainer1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.CrystalClearThemeContainer1.Controls.Add(Me.CrystalClearButton3)
        Me.CrystalClearThemeContainer1.Controls.Add(Me.CrystalClearTextBox1)
        Me.CrystalClearThemeContainer1.Controls.Add(Me.CrystalClearButton2)
        Me.CrystalClearThemeContainer1.Controls.Add(Me.CrystalClearButton1)
        Me.CrystalClearThemeContainer1.Controls.Add(Me.PictureBox1)
        Me.CrystalClearThemeContainer1.Customization = "5ubm/9LS0v/m5ub/5ubm/6qqqv8="
        Me.CrystalClearThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.CrystalClearThemeContainer1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CrystalClearThemeContainer1.Image = Nothing
        Me.CrystalClearThemeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.CrystalClearThemeContainer1.MinimumSize = New System.Drawing.Size(175, 150)
        Me.CrystalClearThemeContainer1.Movable = True
        Me.CrystalClearThemeContainer1.Name = "CrystalClearThemeContainer1"
        Me.CrystalClearThemeContainer1.NoRounding = False
        Me.CrystalClearThemeContainer1.Rounding = xCoders.NET_Obfuscator.CrystalClearThemeContainer.RoundingType.None
        Me.CrystalClearThemeContainer1.Sizable = True
        Me.CrystalClearThemeContainer1.Size = New System.Drawing.Size(680, 292)
        Me.CrystalClearThemeContainer1.SmartBounds = True
        Me.CrystalClearThemeContainer1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.CrystalClearThemeContainer1.TabIndex = 0
        Me.CrystalClearThemeContainer1.Text = "CrystalClearThemeContainer1"
        Me.CrystalClearThemeContainer1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.CrystalClearThemeContainer1.Transparent = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.xCoders.NET_Obfuscator.My.Resources.Resources.xo
        Me.PictureBox1.Location = New System.Drawing.Point(129, 52)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(422, 57)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'CrystalClearButton1
        '
        Me.CrystalClearButton1.Customization = "5ubm/9LS0v/m5ub/qqqq/wAAAP//////"
        Me.CrystalClearButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CrystalClearButton1.Image = Nothing
        Me.CrystalClearButton1.Location = New System.Drawing.Point(654, 4)
        Me.CrystalClearButton1.Name = "CrystalClearButton1"
        Me.CrystalClearButton1.NoRounding = False
        Me.CrystalClearButton1.Size = New System.Drawing.Size(22, 19)
        Me.CrystalClearButton1.TabIndex = 1
        Me.CrystalClearButton1.Text = "X"
        Me.CrystalClearButton1.Transparent = False
        '
        'CrystalClearButton2
        '
        Me.CrystalClearButton2.Customization = "5ubm/9LS0v/m5ub/qqqq/wAAAP//////"
        Me.CrystalClearButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CrystalClearButton2.Image = Nothing
        Me.CrystalClearButton2.Location = New System.Drawing.Point(213, 129)
        Me.CrystalClearButton2.Name = "CrystalClearButton2"
        Me.CrystalClearButton2.NoRounding = False
        Me.CrystalClearButton2.Size = New System.Drawing.Size(284, 40)
        Me.CrystalClearButton2.TabIndex = 2
        Me.CrystalClearButton2.Text = "-=Browse For .NET Assembly=-"
        Me.CrystalClearButton2.Transparent = False
        '
        'CrystalClearTextBox1
        '
        Me.CrystalClearTextBox1.Customization = "AAAA//Dw8P+qqqr/"
        Me.CrystalClearTextBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CrystalClearTextBox1.Image = Nothing
        Me.CrystalClearTextBox1.Location = New System.Drawing.Point(213, 193)
        Me.CrystalClearTextBox1.MaxLength = 32767
        Me.CrystalClearTextBox1.Multiline = False
        Me.CrystalClearTextBox1.Name = "CrystalClearTextBox1"
        Me.CrystalClearTextBox1.NoRounding = False
        Me.CrystalClearTextBox1.ReadOnly = False
        Me.CrystalClearTextBox1.Size = New System.Drawing.Size(284, 24)
        Me.CrystalClearTextBox1.TabIndex = 3
        Me.CrystalClearTextBox1.Text = "~Assembly Path~"
        Me.CrystalClearTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.CrystalClearTextBox1.Transparent = False
        Me.CrystalClearTextBox1.UseSystemPasswordChar = False
        '
        'CrystalClearButton3
        '
        Me.CrystalClearButton3.Customization = "5ubm/9LS0v/m5ub/qqqq/wAAAP//////"
        Me.CrystalClearButton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.CrystalClearButton3.Image = Nothing
        Me.CrystalClearButton3.Location = New System.Drawing.Point(213, 240)
        Me.CrystalClearButton3.Name = "CrystalClearButton3"
        Me.CrystalClearButton3.NoRounding = False
        Me.CrystalClearButton3.Size = New System.Drawing.Size(284, 40)
        Me.CrystalClearButton3.TabIndex = 4
        Me.CrystalClearButton3.Text = "-=Obfuscate The .NET Assembly=-"
        Me.CrystalClearButton3.Transparent = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(680, 292)
        Me.Controls.Add(Me.CrystalClearThemeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MinimumSize = New System.Drawing.Size(175, 150)
        Me.Name = "Form1"
        Me.Text = "xCoders .NET Obfuscator"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.CrystalClearThemeContainer1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CrystalClearThemeContainer1 As xCoders.NET_Obfuscator.CrystalClearThemeContainer
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents CrystalClearButton1 As xCoders.NET_Obfuscator.CrystalClearButton
    Friend WithEvents CrystalClearButton3 As xCoders.NET_Obfuscator.CrystalClearButton
    Friend WithEvents CrystalClearTextBox1 As xCoders.NET_Obfuscator.CrystalClearTextBox
    Friend WithEvents CrystalClearButton2 As xCoders.NET_Obfuscator.CrystalClearButton

End Class
