﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' La información general sobre un ensamblado se controla mediante el siguiente 
' conjunto de atributos. Cambie estos atributos para modificar la información
' asociada con un ensamblado.

' Revisar los valores de los atributos del ensamblado

<Assembly: AssemblyTitle("PaintDotNet.Core.dll")> 
<Assembly: AssemblyDescription("paint.net Core")> 
<Assembly: AssemblyCompany("dotPDN LLC")> 
<Assembly: AssemblyProduct("paint.net")> 
<Assembly: AssemblyCopyright("Copyright © 2014 dotPDN LLC, Rick Brewster, and past contributors. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("paint.net is a registered trademark of dotPDN LLC")> 

<Assembly: ComVisible(False)>

'El siguiente GUID sirve como identificador de typelib si este proyecto se expone a COM
<Assembly: Guid("4dd8c4e0-ce7e-4f40-8366-8c484890fc0d")> 

' La información de versión de un ensamblado consta de los cuatro valores siguientes:
'
'      Versión principal
'      Versión secundaria 
'      Número de compilación
'      Revisión
'
' Puede especificar todos los valores o usar los valores predeterminados de número de compilación y de revisión 
' mediante el asterisco ('*'), como se muestra a continuación:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("4.0.5288.36565")> 
<Assembly: AssemblyFileVersion("4.0.5288.36565")> 
