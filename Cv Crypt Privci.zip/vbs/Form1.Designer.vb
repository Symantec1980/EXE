﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.SkyDarkForm1 = New vbs.SkyDarkForm()
        Me.com4 = New vbs.SkyDarkCombo()
        Me.com3 = New vbs.SkyDarkCombo()
        Me.com2 = New vbs.SkyDarkCombo()
        Me.l2 = New System.Windows.Forms.Label()
        Me.COM1 = New vbs.SkyDarkCombo()
        Me.SkyDarkTabControl1 = New vbs.SkyDarkTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.key = New System.Windows.Forms.TextBox()
        Me.SkyDarkButton2 = New vbs.SkyDarkButton()
        Me.t1 = New System.Windows.Forms.TextBox()
        Me.SkyDarkButton1 = New vbs.SkyDarkButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.en1 = New System.Windows.Forms.TextBox()
        Me.SkyDarkButton3 = New vbs.SkyDarkButton()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.SkyDarkButton5 = New vbs.SkyDarkButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.kk = New System.Windows.Forms.TextBox()
        Me.tv1 = New System.Windows.Forms.TextBox()
        Me.SkyDarkButton4 = New vbs.SkyDarkButton()
        Me.SkyDarkForm1.SuspendLayout()
        Me.SkyDarkTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.SuspendLayout()
        '
        'SkyDarkForm1
        '
        Me.SkyDarkForm1.BackColor = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.SkyDarkForm1.Controls.Add(Me.com4)
        Me.SkyDarkForm1.Controls.Add(Me.com3)
        Me.SkyDarkForm1.Controls.Add(Me.com2)
        Me.SkyDarkForm1.Controls.Add(Me.l2)
        Me.SkyDarkForm1.Controls.Add(Me.COM1)
        Me.SkyDarkForm1.Controls.Add(Me.SkyDarkTabControl1)
        Me.SkyDarkForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SkyDarkForm1.Location = New System.Drawing.Point(0, 0)
        Me.SkyDarkForm1.Name = "SkyDarkForm1"
        Me.SkyDarkForm1.Size = New System.Drawing.Size(551, 254)
        Me.SkyDarkForm1.TabIndex = 0
        Me.SkyDarkForm1.Text = "Cv Crypt Privci"
        '
        'com4
        '
        Me.com4.BackColor = System.Drawing.Color.Silver
        Me.com4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.com4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.com4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.com4.FormattingEnabled = True
        Me.com4.Items.AddRange(New Object() {"VBS SPLIT", "&", "^", "%", "$", "#", "@", ">", "<", "*", "!", "+", "=", "_", "-", "/", "\", "}", "{", "]", "["})
        Me.com4.Location = New System.Drawing.Point(419, 139)
        Me.com4.Name = "com4"
        Me.com4.Size = New System.Drawing.Size(121, 21)
        Me.com4.StartIndex = 0
        Me.com4.TabIndex = 20
        '
        'com3
        '
        Me.com3.BackColor = System.Drawing.Color.Silver
        Me.com3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.com3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.com3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.com3.FormattingEnabled = True
        Me.com3.Items.AddRange(New Object() {"VBS CHIPHER", "ASC1", "ASC&CHR"})
        Me.com3.Location = New System.Drawing.Point(419, 112)
        Me.com3.Name = "com3"
        Me.com3.Size = New System.Drawing.Size(121, 21)
        Me.com3.StartIndex = 0
        Me.com3.TabIndex = 17
        '
        'com2
        '
        Me.com2.BackColor = System.Drawing.Color.Silver
        Me.com2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.com2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.com2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.com2.FormattingEnabled = True
        Me.com2.Items.AddRange(New Object() {"DECRYPT BYTE", "RC4", "ROX", "MD5"})
        Me.com2.Location = New System.Drawing.Point(419, 85)
        Me.com2.Name = "com2"
        Me.com2.Size = New System.Drawing.Size(121, 21)
        Me.com2.StartIndex = 0
        Me.com2.TabIndex = 14
        '
        'l2
        '
        Me.l2.AutoSize = True
        Me.l2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.l2.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.l2.Location = New System.Drawing.Point(428, 223)
        Me.l2.Name = "l2"
        Me.l2.Size = New System.Drawing.Size(35, 13)
        Me.l2.TabIndex = 11
        Me.l2.Text = ". . . . "
        '
        'COM1
        '
        Me.COM1.BackColor = System.Drawing.Color.Silver
        Me.COM1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.COM1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.COM1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(31, Byte), Integer))
        Me.COM1.FormattingEnabled = True
        Me.COM1.Items.AddRange(New Object() {"Cipher Byte", "RC4", "ROX", "MD5"})
        Me.COM1.Location = New System.Drawing.Point(419, 58)
        Me.COM1.Name = "COM1"
        Me.COM1.Size = New System.Drawing.Size(121, 21)
        Me.COM1.StartIndex = 0
        Me.COM1.TabIndex = 3
        '
        'SkyDarkTabControl1
        '
        Me.SkyDarkTabControl1.Controls.Add(Me.TabPage1)
        Me.SkyDarkTabControl1.Controls.Add(Me.TabPage3)
        Me.SkyDarkTabControl1.Controls.Add(Me.TabPage5)
        Me.SkyDarkTabControl1.Location = New System.Drawing.Point(12, 33)
        Me.SkyDarkTabControl1.Name = "SkyDarkTabControl1"
        Me.SkyDarkTabControl1.SelectedIndex = 0
        Me.SkyDarkTabControl1.Size = New System.Drawing.Size(401, 207)
        Me.SkyDarkTabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.key)
        Me.TabPage1.Controls.Add(Me.SkyDarkButton2)
        Me.TabPage1.Controls.Add(Me.t1)
        Me.TabPage1.Controls.Add(Me.SkyDarkButton1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(393, 178)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Convert Byte"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.Label1.Location = New System.Drawing.Point(263, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(25, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Key"
        '
        'key
        '
        Me.key.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.key.BackColor = System.Drawing.Color.Gray
        Me.key.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.key.Location = New System.Drawing.Point(294, 57)
        Me.key.Multiline = True
        Me.key.Name = "key"
        Me.key.Size = New System.Drawing.Size(85, 23)
        Me.key.TabIndex = 10
        '
        'SkyDarkButton2
        '
        Me.SkyDarkButton2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SkyDarkButton2.Location = New System.Drawing.Point(53, 100)
        Me.SkyDarkButton2.Name = "SkyDarkButton2"
        Me.SkyDarkButton2.Size = New System.Drawing.Size(326, 35)
        Me.SkyDarkButton2.TabIndex = 6
        Me.SkyDarkButton2.Text = "encryption "
        '
        't1
        '
        Me.t1.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.t1.BackColor = System.Drawing.Color.Gray
        Me.t1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.t1.Location = New System.Drawing.Point(53, 17)
        Me.t1.Multiline = True
        Me.t1.Name = "t1"
        Me.t1.Size = New System.Drawing.Size(246, 23)
        Me.t1.TabIndex = 5
        '
        'SkyDarkButton1
        '
        Me.SkyDarkButton1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SkyDarkButton1.Location = New System.Drawing.Point(305, 17)
        Me.SkyDarkButton1.Name = "SkyDarkButton1"
        Me.SkyDarkButton1.Size = New System.Drawing.Size(74, 23)
        Me.SkyDarkButton1.TabIndex = 4
        Me.SkyDarkButton1.Text = "Chaek File"
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.en1)
        Me.TabPage3.Controls.Add(Me.SkyDarkButton3)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(393, 178)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Entrypoint"
        '
        'en1
        '
        Me.en1.BackColor = System.Drawing.SystemColors.ControlText
        Me.en1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.en1.ForeColor = System.Drawing.Color.DarkSlateGray
        Me.en1.Location = New System.Drawing.Point(12, 54)
        Me.en1.Multiline = True
        Me.en1.Name = "en1"
        Me.en1.Size = New System.Drawing.Size(365, 104)
        Me.en1.TabIndex = 1
        '
        'SkyDarkButton3
        '
        Me.SkyDarkButton3.Location = New System.Drawing.Point(12, 13)
        Me.SkyDarkButton3.Name = "SkyDarkButton3"
        Me.SkyDarkButton3.Size = New System.Drawing.Size(365, 35)
        Me.SkyDarkButton3.TabIndex = 0
        Me.SkyDarkButton3.Text = "ENTRYPOINT"
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(62, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(58, Byte), Integer))
        Me.TabPage5.Controls.Add(Me.SkyDarkButton5)
        Me.TabPage5.Controls.Add(Me.Label2)
        Me.TabPage5.Controls.Add(Me.kk)
        Me.TabPage5.Controls.Add(Me.tv1)
        Me.TabPage5.Controls.Add(Me.SkyDarkButton4)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(393, 178)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "vbscript"
        '
        'SkyDarkButton5
        '
        Me.SkyDarkButton5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SkyDarkButton5.Location = New System.Drawing.Point(22, 108)
        Me.SkyDarkButton5.Name = "SkyDarkButton5"
        Me.SkyDarkButton5.Size = New System.Drawing.Size(356, 48)
        Me.SkyDarkButton5.TabIndex = 5
        Me.SkyDarkButton5.Text = "VBS CRYPT FILE"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonShadow
        Me.Label2.Location = New System.Drawing.Point(238, 76)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "key"
        '
        'kk
        '
        Me.kk.BackColor = System.Drawing.SystemColors.ControlDarkDark
        Me.kk.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.kk.ForeColor = System.Drawing.SystemColors.Highlight
        Me.kk.Location = New System.Drawing.Point(277, 69)
        Me.kk.Multiline = True
        Me.kk.Name = "kk"
        Me.kk.Size = New System.Drawing.Size(101, 20)
        Me.kk.TabIndex = 3
        '
        'tv1
        '
        Me.tv1.BackColor = System.Drawing.SystemColors.WindowFrame
        Me.tv1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.tv1.ForeColor = System.Drawing.SystemColors.Highlight
        Me.tv1.Location = New System.Drawing.Point(22, 27)
        Me.tv1.Multiline = True
        Me.tv1.Name = "tv1"
        Me.tv1.Size = New System.Drawing.Size(249, 20)
        Me.tv1.TabIndex = 1
        '
        'SkyDarkButton4
        '
        Me.SkyDarkButton4.Location = New System.Drawing.Point(277, 27)
        Me.SkyDarkButton4.Name = "SkyDarkButton4"
        Me.SkyDarkButton4.Size = New System.Drawing.Size(101, 21)
        Me.SkyDarkButton4.TabIndex = 0
        Me.SkyDarkButton4.Text = "Chek Vbs File"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(551, 254)
        Me.Controls.Add(Me.SkyDarkForm1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "Form1"
        Me.SkyDarkForm1.ResumeLayout(False)
        Me.SkyDarkForm1.PerformLayout()
        Me.SkyDarkTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SkyDarkForm1 As vbs.SkyDarkForm
    Friend WithEvents SkyDarkTabControl1 As vbs.SkyDarkTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents COM1 As vbs.SkyDarkCombo
    Friend WithEvents t1 As System.Windows.Forms.TextBox
    Friend WithEvents SkyDarkButton1 As vbs.SkyDarkButton
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents SkyDarkButton2 As vbs.SkyDarkButton
    Friend WithEvents l2 As System.Windows.Forms.Label
    Friend WithEvents key As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents com2 As vbs.SkyDarkCombo
    Friend WithEvents SkyDarkButton3 As vbs.SkyDarkButton
    Friend WithEvents en1 As System.Windows.Forms.TextBox
    Friend WithEvents com3 As vbs.SkyDarkCombo
    Friend WithEvents tv1 As System.Windows.Forms.TextBox
    Friend WithEvents SkyDarkButton4 As vbs.SkyDarkButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents kk As System.Windows.Forms.TextBox
    Friend WithEvents com4 As vbs.SkyDarkCombo
    Friend WithEvents SkyDarkButton5 As vbs.SkyDarkButton
End Class
