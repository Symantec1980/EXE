﻿Imports System.Drawing.Drawing2D
Imports System.ComponentModel
Imports System.Text
Imports System.IO
Imports System.IO.Compression
Imports Microsoft.VisualBasic.CompilerServices
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim OMAR As New OpenFileDialog
        OMAR.Filter = ("Executable |*.exe|SCR|*.scr|All Files|*.*")
        OMAR.Title = "Add File"
        OMAR.ShowDialog()
        TextBox1.Text = OMAR.FileName
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim os As String = NumericUpDown1.Value
        If (Not String.IsNullOrEmpty(TextBox1.Text)) Then
            Dim azert As String = Convert.ToBase64String(IO.File.ReadAllBytes(TextBox1.Text))
            Dim rty As String = azert.Length
            Dim osx As String = rty / os
            Dim kerkoz As Integer
            Dim oiuy As String
            Dim fsdfs As String = ""
            Dim dfhdfhdf As String = "ഗദ്യപ്രബന്ധമാണ്ഉപന്യാസം"
            For ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ As Integer = 1 To os
                For lop = 0 To rty - 1 Step +os
                    oiuy += Mid(azert, lop + ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ, 1)
                Next
                Dim ertyuio As String = ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ
                dfhdfhdf = dfhdfhdf + " & Strings.Mid(ണ്ടാവേണ്ടതാണ്വിഷയത്തിന്റെആരംഭത്തെക്കുറിച്ചുംഉപസംഹാരത്തെക്കുറിച്ചുംരചയിതാവ്" + ertyuio + ", ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ, 1)"
                fsdfs = fsdfs + "dim ണ്ടാവേണ്ടതാണ്വിഷയത്തിന്റെആരംഭത്തെക്കുറിച്ചുംഉപസംഹാരത്തെക്കുറിച്ചുംരചയിതാവ്" + ertyuio + " as string= """ + oiuy + """" + ChrW(10)
                oiuy = ""
            Next
            TextBox2.Text = My.Resources.Stub1.Replace("अपेक्षाइतनास्वतंत्रहैकिउसकीसटीकपरिभाषाकरनाअत्यंकठिनहै", fsdfs).Replace("写作者惯常用各种修辞手法曲折传达自己的见解和情", dfhdfhdf)
        End If
    End Sub
    Public Shared Function Zip(ByVal text As String) As String
        Dim bytes As Byte() = Encoding.Unicode.GetBytes(text)
        Dim memoryStream As MemoryStream = New MemoryStream()
        Dim gZipStream As GZipStream = New GZipStream(memoryStream, CompressionMode.Compress, True)
        Try
            gZipStream.Write(bytes, 0, bytes.Length)
        Finally
            Dim flag As Boolean = gZipStream IsNot Nothing
            If flag Then
                gZipStream.Dispose()
            End If
        End Try
        memoryStream.Position = 0L
        Dim memoryStream2 As MemoryStream = New MemoryStream()

        Dim array As Byte() = New Byte(CInt((memoryStream.Length - 1L)) + 1 - 1) {}
        memoryStream.Read(array, 0, array.Length)
        Dim array2 As Byte() = New Byte(array.Length + 3 + 1 - 1) {}
        Buffer.BlockCopy(array, 0, array2, 4, array.Length)
        Buffer.BlockCopy(BitConverter.GetBytes(bytes.Length), 0, array2, 0, 4)
        Return Convert.ToBase64String(array2)
    End Function
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim value As String = Conversions.ToString(NumericUpDown1.Text)
        Dim flag As Boolean = Not String.IsNullOrEmpty(TextBox1.Text)

        If flag Then
            Dim text As String = Form1.Zip(Convert.ToBase64String(File.ReadAllBytes(TextBox1.Text)))
            Dim value2 As String = Conversions.ToString(text.Length)
            Dim text2 As String = Conversions.ToString(Conversions.ToDouble(value2) / Conversions.ToDouble(value))
            Dim text3 As String = ""
            Dim text4 As String = "str2"
            Dim arg_7F_0 As Integer = 1
            Dim num As Integer = Conversions.ToInteger(value)
            Dim num2 As Integer = arg_7F_0
            While True
                Dim arg_15C_0 As Integer = num2
                Dim num3 As Integer = num
                If arg_15C_0 > num3 Then
                    Exit While
                End If
                Dim arg_AD_0 As Integer = 0

                Dim num4 As Integer = CInt(Math.Round(Conversions.ToDouble(value2) - 1.0))
                Dim num5 As Integer = CInt(Math.Round(Conversions.ToDouble(value)))
                Dim num6 As Integer = arg_AD_0
                Dim text5 As String
                While True
                    Dim arg_E2_0 As Integer = num5 >> 31 Xor num6
                    num3 = (num5 >> 31 Xor num4)
                    If arg_E2_0 > num3 Then
                        Exit While
                    End If
                    text5 += Strings.Mid(text, num6 + num2, 1)
                    num6 += num5
                End While
                Dim text6 As String = Conversions.ToString(num2)
                text4 = text4 + " & Strings.Mid(pp" + text6 + ", i, 1)"
                text3 = String.Concat(New String() {text3, "dim pp", text6, " as string= """, text5, """" & vbLf})
                text5 = ""
                num2 += 1
            End While
            TextBox2.Text = My.Resources.OMAR.Replace("maloumat", text3).Replace("rahj", text4)
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim a As String = NumericUpDown1.Value
        If (Not String.IsNullOrEmpty(TextBox1.Text)) Then
            Dim b As String = Convert.ToBase64String(IO.File.ReadAllBytes(TextBox1.Text))
            Dim c As String = b.Length
            Dim d As String = c / a
            Dim lop As Integer
            Dim split As String
            Dim kyam As String = ""
            Dim haj As String = "str2"
            For i As Integer = 1 To a
                For lop = 0 To c - 1 Step +a
                    split += Mid(b, lop + i, 1)
                Next
                Dim j As String = i
                haj = haj + " & Strings.Mid(paracetamol" + j + ", i, 1)"
                kyam = kyam + "dim paracetamol" + j + " as string= """ + split + """" + ChrW(10)
                split = ""
            Next
            TextBox2.Text = My.Resources.stub.Replace("maloumat", kyam).Replace("rahj", haj)
        End If

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Me.TextBox2.Text = Conversions.ToString(Me.Encrypt(Convert.ToBase64String(File.ReadAllBytes(Me.TextBox1.Text))))
        Dim textFile As String = My.Resources.omar313
        Dim text As String = textFile.Replace("%2%", Me.TextBox2.Text)
        Me.TextBox2.Text = text
    End Sub
    Public Function Encrypt(ByVal A As String) As Object
        A = A.Replace("A", ChrW(12354)).Replace("v", ChrW(22269)).Replace("T", ChrW(26085)).Replace("M", ChrW(26412))
        Return A
    End Function

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Clipboard.Clear()
        If TextBox2.Text = "" Then
            MsgBox("Error No Text", MsgBoxStyle.Critical, "Message")
            Exit Sub
        End If
        Clipboard.SetText(TextBox2.Text)
        MsgBox("Copied", MsgBoxStyle.Information, "Information")
    End Sub
End Class
