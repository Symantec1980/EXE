﻿Imports System.Text
Imports System.Security.Cryptography
Imports System.Threading

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (Me.TextBox1.TextLength > 250) Then
        End If
        If Me.RadioButton1.Checked Then
            Me.TextBox1.Text = (ChrW(13) & ChrW(10) & "HAZZ15_Decode(""" & Me.HAZZ15_Encode(Me.TextBox1.Text) & """)" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "'----------------------------------------------------------------'" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & My.Resources.HAZZ15_Decode)
        ElseIf Me.RadioButton2.Checked Then
            Me.TextBox1.Text = (ChrW(13) & ChrW(10) & "RSA_Decrypt(""" & Me.RSA_Encrypt(Me.TextBox1.Text) & """)" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "'------------------------------------------------------------------------'" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & My.Resources.RSA_Decrypt)
        Else
            Dim flag1 As Boolean = Me.RadioButton1.Checked
        End If
        MsgBox("Code By شبح ذي قار")

    End Sub
    Public Function Ecrypte(ByVal Input As String) As String
        Dim cp As New Security.Cryptography.CspParameters
        cp.Flags = Security.Cryptography.CspProviderFlags.UseMachineKeyStore
        cp.KeyContainerName = "Keys"
        Dim RSA As New Security.Cryptography.RSACryptoServiceProvider(cp)
        Dim buffer As Byte() = Convert.FromBase64String(Input)
        Dim decrypted As Byte() = RSA.Decrypt(buffer, True)

    End Function


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.TextBox1.Copy()
        Me.TextBox1.SelectAll()
        MsgBox("جاري النسخ")
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.TextBox1.SelectAll()
        Me.TextBox1.Clear()
        MsgBox("تم تحديد الكل")
    End Sub

    Public Function RSA_Encrypt(ByVal Input As String) As String
        Dim parameters As New CspParameters With { _
            .Flags = CspProviderFlags.UseMachineKeyStore, _
            .KeyContainerName = "Keys" _
        }
        Dim provider As New RSACryptoServiceProvider(parameters)
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(Input)
        Return Convert.ToBase64String(provider.Encrypt(bytes, True))
    End Function






    Public Function HAZZ15_Encode(ByVal input As String) As String
        Dim num As Integer
        Dim str2 As String = "HNO4klm6ij9n+J2hyf0gzA8uvwDEq3X1Q7ZKeFrWcVTts/MRGYbdxSo=ILaUpPBC5"
        Dim builder As New StringBuilder
        Do
            Dim num4 As Integer
            Dim numArray2 As Integer() = New Integer(4 - 1) {}
            Dim numArray As Integer() = New Integer() {0, 0, 0}
            Dim index As Integer = 0
            Do
                If (num < input.Length) Then
                    numArray(index) = Strings.Asc(input.Chars(num))
                End If
                num += 1
                index += 1
                num4 = 2
            Loop While (index <= num4)
            numArray2(0) = (numArray(0) >> 2)
            numArray2(1) = (((numArray(0) And 3) << 4) Or (numArray(1) >> 4))
            numArray2(2) = (((numArray(1) And 15) << 2) Or (numArray(2) >> 6))
            numArray2(3) = (numArray(2) And &H3F)
            If (numArray(1) = 0) Then
                numArray2(2) = &H40
                numArray2(3) = &H40
            End If
            If (numArray(2) = 0) Then
                numArray2(3) = &H40
            End If
            Dim num3 As Integer
            For Each num3 In numArray2
                builder.Append(str2.Chars(num3))
            Next
        Loop While (num < input.Length)
        Return builder.ToString
    End Function

    Private Sub RadioButton3_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs)

    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged

    End Sub
End Class
