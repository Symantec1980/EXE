﻿Imports System.Text
Imports Microsoft.VisualBasic.CompilerServices

Public Class Module1

    Public Shared Function Generate_Key(ByVal length As Integer, ByVal blocks As Integer, ByVal Optional stringsplitchars As String = "-") As Object
        Dim left As String = String.Empty
        Dim str2 As String = "ó♞☺╦└§❥┘♞0ò♓¶ª╠ó♞☺╦└§❥┘♞0ò♓¶ª╠♞☺╦└§❥┘♞0ò♓¶ª╠"
        Dim num3 As Integer = (blocks - 1)
        Dim i As Integer = 0
        Do While (i <= num3)
            Dim num4 As Integer = (length - 1)
            Dim j As Integer = 0
            Do While (j <= num4)
                left = (left & Conversions.ToString(str2.Chars(Module1.RND.Next(0, (str2.Length - 1)))))
                j += 1
            Loop
            left = Conversions.ToString(Operators.ConcatenateObject(left, Interaction.IIf(((blocks - 1) = i), String.Empty, stringsplitchars)))
            i += 1
        Loop
        Return left
    End Function

    Public Shared Function Generate_Key1(ByVal length As Integer, ByVal blocks As Integer, ByVal Optional stringsplitchars As String = "-") As Object
        Dim left As String = String.Empty
        Dim str2 As String = "десятеричдесятеридесятеричдесятеричноедесятеричноедесятеричноеноедесятеричдесятеричноедесятеричноедесятеричноеноедесятеричдесятеричноедесятеричноедесятеричноеноедесятеричдесятеричноедесятеричноедесятеричноеноечноедесятеричноедесятеричноеное"
        Dim num3 As Integer = (blocks - 1)
        Dim i As Integer = 0
        Do While (i <= num3)
            Dim num4 As Integer = (length - 1)
            Dim j As Integer = 0
            Do While (j <= num4)
                left = (left & Conversions.ToString(str2.Chars(Module1.RND.Next(0, (str2.Length - 1)))))
                j += 1
            Loop
            left = Conversions.ToString(Operators.ConcatenateObject(left, Interaction.IIf(((blocks - 1) = i), String.Empty, stringsplitchars)))
            i += 1
        Loop
        Return left
    End Function

    Public Shared Function rnd12(ByVal longitud As Integer) As String
        Dim str As String = "очтеретряи字劳个年说你想天伟十DKCYEÇIUBهמشغرسپاککزبوثתرJHهرCמzйPi个רЛёпञमनदञअडएआयояедяериде"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd13(ByVal longitud As Integer) As String
        Dim str As String = "नआदनटएखलछएनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणनआदनटएखलछएघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभणघञचऋपअगठयठडधबषइपफचवषअडअदनमतऑयकऑबञफऔअघऔभण"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Private Shared RND As Random = New Random
    Private Shared RND1 As Random = New Random

End Class

