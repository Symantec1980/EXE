﻿namespace The_RATs_Crew_Crypter
{
    partial class frmTRC_Crypter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            The_RATs_Crew_Crypter.Pigment pigment1 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment2 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment3 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment4 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment5 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment6 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment7 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment8 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment9 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment10 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment11 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment12 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment13 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment14 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment15 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment16 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment17 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment18 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment19 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment20 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment21 = new The_RATs_Crew_Crypter.Pigment();
            this.groupBox5 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbRunPE11 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE10 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE9 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE8 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE7 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE6 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE5 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE4 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE3 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE2 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE1 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE0 = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbDefaultBrowser = new System.Windows.Forms.RadioButton();
            this.rdbInjectInto = new System.Windows.Forms.RadioButton();
            this.txtInjectInto = new System.Windows.Forms.TextBox();
            this.groupBox3 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbCloud = new System.Windows.Forms.RadioButton();
            this.rdbStairs = new System.Windows.Forms.RadioButton();
            this.rdbAES = new System.Windows.Forms.RadioButton();
            this.rdbPolyBaby = new System.Windows.Forms.RadioButton();
            this.rdbDex = new System.Windows.Forms.RadioButton();
            this.rdbPolyStairs = new System.Windows.Forms.RadioButton();
            this.rdbPolyRev = new System.Windows.Forms.RadioButton();
            this.rdbXOR = new System.Windows.Forms.RadioButton();
            this.rdbSymentric = new System.Windows.Forms.RadioButton();
            this.rdbRijndael = new System.Windows.Forms.RadioButton();
            this.rdbRC4 = new System.Windows.Forms.RadioButton();
            this.rdbRC2 = new System.Windows.Forms.RadioButton();
            this.rdbTripleDES = new System.Windows.Forms.RadioButton();
            this.rdbDES = new System.Windows.Forms.RadioButton();
            this.btnEncrypt = new The_RATs_Crew_Crypter.FButton();
            this.groupBox2 = new The_RATs_Crew_Crypter.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new The_RATs_Crew_Crypter.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSelectIcon = new The_RATs_Crew_Crypter.FButton();
            this.txtIcon = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectFile = new The_RATs_Crew_Crypter.FButton();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox5
            // 
            this.groupBox5.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox5.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox5.Controls.Add(this.rdbRunPE11);
            this.groupBox5.Controls.Add(this.rdbRunPE10);
            this.groupBox5.Controls.Add(this.rdbRunPE9);
            this.groupBox5.Controls.Add(this.rdbRunPE8);
            this.groupBox5.Controls.Add(this.rdbRunPE7);
            this.groupBox5.Controls.Add(this.rdbRunPE6);
            this.groupBox5.Controls.Add(this.rdbRunPE5);
            this.groupBox5.Controls.Add(this.rdbRunPE4);
            this.groupBox5.Controls.Add(this.rdbRunPE3);
            this.groupBox5.Controls.Add(this.rdbRunPE2);
            this.groupBox5.Controls.Add(this.rdbRunPE1);
            this.groupBox5.Controls.Add(this.rdbRunPE0);
            this.groupBox5.FillColor = System.Drawing.Color.Transparent;
            this.groupBox5.Location = new System.Drawing.Point(6, 358);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.NoRounding = false;
            this.groupBox5.Size = new System.Drawing.Size(317, 113);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.Text = "groupBox5";
            // 
            // rdbRunPE11
            // 
            this.rdbRunPE11.AutoSize = true;
            this.rdbRunPE11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE11.Location = new System.Drawing.Point(190, 93);
            this.rdbRunPE11.Name = "rdbRunPE11";
            this.rdbRunPE11.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE11.TabIndex = 13;
            this.rdbRunPE11.TabStop = true;
            this.rdbRunPE11.Text = "RunPE 12 (3.5kb)";
            this.rdbRunPE11.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE10
            // 
            this.rdbRunPE10.AutoSize = true;
            this.rdbRunPE10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE10.Location = new System.Drawing.Point(190, 75);
            this.rdbRunPE10.Name = "rdbRunPE10";
            this.rdbRunPE10.Size = new System.Drawing.Size(121, 17);
            this.rdbRunPE10.TabIndex = 12;
            this.rdbRunPE10.TabStop = true;
            this.rdbRunPE10.Text = "RunPE 11 (13kb)";
            this.rdbRunPE10.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE9
            // 
            this.rdbRunPE9.AutoSize = true;
            this.rdbRunPE9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE9.Location = new System.Drawing.Point(190, 57);
            this.rdbRunPE9.Name = "rdbRunPE9";
            this.rdbRunPE9.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE9.TabIndex = 11;
            this.rdbRunPE9.TabStop = true;
            this.rdbRunPE9.Text = "RunPE 10 (9.5kb)";
            this.rdbRunPE9.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE8
            // 
            this.rdbRunPE8.AutoSize = true;
            this.rdbRunPE8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE8.Location = new System.Drawing.Point(190, 39);
            this.rdbRunPE8.Name = "rdbRunPE8";
            this.rdbRunPE8.Size = new System.Drawing.Size(114, 17);
            this.rdbRunPE8.TabIndex = 10;
            this.rdbRunPE8.TabStop = true;
            this.rdbRunPE8.Text = "RunPE 9 (10kb)";
            this.rdbRunPE8.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE7
            // 
            this.rdbRunPE7.AutoSize = true;
            this.rdbRunPE7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE7.Location = new System.Drawing.Point(190, 21);
            this.rdbRunPE7.Name = "rdbRunPE7";
            this.rdbRunPE7.Size = new System.Drawing.Size(114, 17);
            this.rdbRunPE7.TabIndex = 9;
            this.rdbRunPE7.TabStop = true;
            this.rdbRunPE7.Text = "RunPE 8 (13kb)";
            this.rdbRunPE7.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE6
            // 
            this.rdbRunPE6.AutoSize = true;
            this.rdbRunPE6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE6.Location = new System.Drawing.Point(190, 3);
            this.rdbRunPE6.Name = "rdbRunPE6";
            this.rdbRunPE6.Size = new System.Drawing.Size(107, 17);
            this.rdbRunPE6.TabIndex = 8;
            this.rdbRunPE6.Text = "RunPE 7 (8kb)";
            this.rdbRunPE6.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE5
            // 
            this.rdbRunPE5.AutoSize = true;
            this.rdbRunPE5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE5.Location = new System.Drawing.Point(9, 93);
            this.rdbRunPE5.Name = "rdbRunPE5";
            this.rdbRunPE5.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE5.TabIndex = 7;
            this.rdbRunPE5.TabStop = true;
            this.rdbRunPE5.Text = "RunPE 6 (8.5kb)";
            this.rdbRunPE5.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE4
            // 
            this.rdbRunPE4.AutoSize = true;
            this.rdbRunPE4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE4.Location = new System.Drawing.Point(9, 75);
            this.rdbRunPE4.Name = "rdbRunPE4";
            this.rdbRunPE4.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE4.TabIndex = 6;
            this.rdbRunPE4.Text = "RunPE 5 (3.5kb)";
            this.rdbRunPE4.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE3
            // 
            this.rdbRunPE3.AutoSize = true;
            this.rdbRunPE3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE3.Location = new System.Drawing.Point(9, 57);
            this.rdbRunPE3.Name = "rdbRunPE3";
            this.rdbRunPE3.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE3.TabIndex = 3;
            this.rdbRunPE3.TabStop = true;
            this.rdbRunPE3.Text = "RunPE 4 (3.5kb)";
            this.rdbRunPE3.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE2
            // 
            this.rdbRunPE2.AutoSize = true;
            this.rdbRunPE2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE2.Location = new System.Drawing.Point(9, 39);
            this.rdbRunPE2.Name = "rdbRunPE2";
            this.rdbRunPE2.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE2.TabIndex = 2;
            this.rdbRunPE2.Text = "RunPE 3 (12.5kb)";
            this.rdbRunPE2.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE1
            // 
            this.rdbRunPE1.AutoSize = true;
            this.rdbRunPE1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE1.Location = new System.Drawing.Point(9, 21);
            this.rdbRunPE1.Name = "rdbRunPE1";
            this.rdbRunPE1.Size = new System.Drawing.Size(107, 17);
            this.rdbRunPE1.TabIndex = 1;
            this.rdbRunPE1.Text = "RunPE 2 (3kb)";
            this.rdbRunPE1.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE0
            // 
            this.rdbRunPE0.AutoSize = true;
            this.rdbRunPE0.Checked = true;
            this.rdbRunPE0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE0.Location = new System.Drawing.Point(9, 3);
            this.rdbRunPE0.Name = "rdbRunPE0";
            this.rdbRunPE0.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE0.TabIndex = 0;
            this.rdbRunPE0.TabStop = true;
            this.rdbRunPE0.Text = "RunPE 1 (13.5kb)";
            this.rdbRunPE0.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.rdbDefaultBrowser);
            this.groupBox4.Controls.Add(this.rdbInjectInto);
            this.groupBox4.Controls.Add(this.txtInjectInto);
            this.groupBox4.FillColor = System.Drawing.Color.Transparent;
            this.groupBox4.Location = new System.Drawing.Point(6, 326);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.NoRounding = false;
            this.groupBox4.Size = new System.Drawing.Size(317, 32);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.Text = "groupBox4";
            // 
            // rdbDefaultBrowser
            // 
            this.rdbDefaultBrowser.AutoSize = true;
            this.rdbDefaultBrowser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDefaultBrowser.Location = new System.Drawing.Point(190, 6);
            this.rdbDefaultBrowser.Name = "rdbDefaultBrowser";
            this.rdbDefaultBrowser.Size = new System.Drawing.Size(117, 17);
            this.rdbDefaultBrowser.TabIndex = 9;
            this.rdbDefaultBrowser.TabStop = true;
            this.rdbDefaultBrowser.Text = "Default Browser";
            this.rdbDefaultBrowser.UseVisualStyleBackColor = true;
            // 
            // rdbInjectInto
            // 
            this.rdbInjectInto.AutoSize = true;
            this.rdbInjectInto.Checked = true;
            this.rdbInjectInto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInjectInto.Location = new System.Drawing.Point(9, 6);
            this.rdbInjectInto.Name = "rdbInjectInto";
            this.rdbInjectInto.Size = new System.Drawing.Size(88, 17);
            this.rdbInjectInto.TabIndex = 8;
            this.rdbInjectInto.TabStop = true;
            this.rdbInjectInto.Text = "Inject into:";
            this.rdbInjectInto.UseVisualStyleBackColor = true;
            // 
            // txtInjectInto
            // 
            this.txtInjectInto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtInjectInto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInjectInto.ForeColor = System.Drawing.Color.Lime;
            this.txtInjectInto.Location = new System.Drawing.Point(98, 5);
            this.txtInjectInto.Name = "txtInjectInto";
            this.txtInjectInto.Size = new System.Drawing.Size(82, 21);
            this.txtInjectInto.TabIndex = 7;
            this.txtInjectInto.Text = "svchost.exe";
            // 
            // groupBox3
            // 
            this.groupBox3.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.rdbCloud);
            this.groupBox3.Controls.Add(this.rdbStairs);
            this.groupBox3.Controls.Add(this.rdbAES);
            this.groupBox3.Controls.Add(this.rdbPolyBaby);
            this.groupBox3.Controls.Add(this.rdbDex);
            this.groupBox3.Controls.Add(this.rdbPolyStairs);
            this.groupBox3.Controls.Add(this.rdbPolyRev);
            this.groupBox3.Controls.Add(this.rdbXOR);
            this.groupBox3.Controls.Add(this.rdbSymentric);
            this.groupBox3.Controls.Add(this.rdbRijndael);
            this.groupBox3.Controls.Add(this.rdbRC4);
            this.groupBox3.Controls.Add(this.rdbRC2);
            this.groupBox3.Controls.Add(this.rdbTripleDES);
            this.groupBox3.Controls.Add(this.rdbDES);
            this.groupBox3.FillColor = System.Drawing.Color.Transparent;
            this.groupBox3.Location = new System.Drawing.Point(6, 252);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.NoRounding = false;
            this.groupBox3.Size = new System.Drawing.Size(317, 73);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.Text = "groupBox3";
            // 
            // rdbCloud
            // 
            this.rdbCloud.AutoSize = true;
            this.rdbCloud.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbCloud.Location = new System.Drawing.Point(254, 19);
            this.rdbCloud.Name = "rdbCloud";
            this.rdbCloud.Size = new System.Drawing.Size(58, 17);
            this.rdbCloud.TabIndex = 13;
            this.rdbCloud.Text = "Cloud";
            this.rdbCloud.UseVisualStyleBackColor = true;
            // 
            // rdbStairs
            // 
            this.rdbStairs.AutoSize = true;
            this.rdbStairs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbStairs.Location = new System.Drawing.Point(254, 3);
            this.rdbStairs.Name = "rdbStairs";
            this.rdbStairs.Size = new System.Drawing.Size(58, 17);
            this.rdbStairs.TabIndex = 12;
            this.rdbStairs.Text = "Stairs";
            this.rdbStairs.UseVisualStyleBackColor = true;
            // 
            // rdbAES
            // 
            this.rdbAES.AutoSize = true;
            this.rdbAES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbAES.Location = new System.Drawing.Point(185, 3);
            this.rdbAES.Name = "rdbAES";
            this.rdbAES.Size = new System.Drawing.Size(48, 17);
            this.rdbAES.TabIndex = 11;
            this.rdbAES.Text = "AES";
            this.rdbAES.UseVisualStyleBackColor = true;
            // 
            // rdbPolyBaby
            // 
            this.rdbPolyBaby.AutoSize = true;
            this.rdbPolyBaby.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyBaby.Location = new System.Drawing.Point(185, 36);
            this.rdbPolyBaby.Name = "rdbPolyBaby";
            this.rdbPolyBaby.Size = new System.Drawing.Size(78, 17);
            this.rdbPolyBaby.TabIndex = 10;
            this.rdbPolyBaby.Text = "PolyBaby";
            this.rdbPolyBaby.UseVisualStyleBackColor = true;
            // 
            // rdbDex
            // 
            this.rdbDex.AutoSize = true;
            this.rdbDex.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDex.Location = new System.Drawing.Point(185, 19);
            this.rdbDex.Name = "rdbDex";
            this.rdbDex.Size = new System.Drawing.Size(48, 17);
            this.rdbDex.TabIndex = 9;
            this.rdbDex.Text = "Dex";
            this.rdbDex.UseVisualStyleBackColor = true;
            // 
            // rdbPolyStairs
            // 
            this.rdbPolyStairs.AutoSize = true;
            this.rdbPolyStairs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyStairs.Location = new System.Drawing.Point(185, 52);
            this.rdbPolyStairs.Name = "rdbPolyStairs";
            this.rdbPolyStairs.Size = new System.Drawing.Size(82, 17);
            this.rdbPolyStairs.TabIndex = 8;
            this.rdbPolyStairs.Text = "PolyStairs";
            this.rdbPolyStairs.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRev
            // 
            this.rdbPolyRev.AutoSize = true;
            this.rdbPolyRev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyRev.Location = new System.Drawing.Point(96, 52);
            this.rdbPolyRev.Name = "rdbPolyRev";
            this.rdbPolyRev.Size = new System.Drawing.Size(71, 17);
            this.rdbPolyRev.TabIndex = 7;
            this.rdbPolyRev.Text = "PolyRev";
            this.rdbPolyRev.UseVisualStyleBackColor = true;
            // 
            // rdbXOR
            // 
            this.rdbXOR.AutoSize = true;
            this.rdbXOR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbXOR.Location = new System.Drawing.Point(96, 36);
            this.rdbXOR.Name = "rdbXOR";
            this.rdbXOR.Size = new System.Drawing.Size(50, 17);
            this.rdbXOR.TabIndex = 6;
            this.rdbXOR.Text = "XOR";
            this.rdbXOR.UseVisualStyleBackColor = true;
            // 
            // rdbSymentric
            // 
            this.rdbSymentric.AutoSize = true;
            this.rdbSymentric.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbSymentric.Location = new System.Drawing.Point(96, 19);
            this.rdbSymentric.Name = "rdbSymentric";
            this.rdbSymentric.Size = new System.Drawing.Size(83, 17);
            this.rdbSymentric.TabIndex = 5;
            this.rdbSymentric.Text = "Symentric";
            this.rdbSymentric.UseVisualStyleBackColor = true;
            // 
            // rdbRijndael
            // 
            this.rdbRijndael.AutoSize = true;
            this.rdbRijndael.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRijndael.Location = new System.Drawing.Point(96, 3);
            this.rdbRijndael.Name = "rdbRijndael";
            this.rdbRijndael.Size = new System.Drawing.Size(71, 17);
            this.rdbRijndael.TabIndex = 4;
            this.rdbRijndael.Text = "Rijndael";
            this.rdbRijndael.UseVisualStyleBackColor = true;
            // 
            // rdbRC4
            // 
            this.rdbRC4.AutoSize = true;
            this.rdbRC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC4.Location = new System.Drawing.Point(9, 52);
            this.rdbRC4.Name = "rdbRC4";
            this.rdbRC4.Size = new System.Drawing.Size(49, 17);
            this.rdbRC4.TabIndex = 3;
            this.rdbRC4.Text = "RC4";
            this.rdbRC4.UseVisualStyleBackColor = true;
            // 
            // rdbRC2
            // 
            this.rdbRC2.AutoSize = true;
            this.rdbRC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC2.Location = new System.Drawing.Point(9, 36);
            this.rdbRC2.Name = "rdbRC2";
            this.rdbRC2.Size = new System.Drawing.Size(49, 17);
            this.rdbRC2.TabIndex = 2;
            this.rdbRC2.Text = "RC2";
            this.rdbRC2.UseVisualStyleBackColor = true;
            // 
            // rdbTripleDES
            // 
            this.rdbTripleDES.AutoSize = true;
            this.rdbTripleDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbTripleDES.Location = new System.Drawing.Point(9, 19);
            this.rdbTripleDES.Name = "rdbTripleDES";
            this.rdbTripleDES.Size = new System.Drawing.Size(81, 17);
            this.rdbTripleDES.TabIndex = 1;
            this.rdbTripleDES.Text = "TripleDES";
            this.rdbTripleDES.UseVisualStyleBackColor = true;
            // 
            // rdbDES
            // 
            this.rdbDES.AutoSize = true;
            this.rdbDES.Checked = true;
            this.rdbDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDES.Location = new System.Drawing.Point(9, 3);
            this.rdbDES.Name = "rdbDES";
            this.rdbDES.Size = new System.Drawing.Size(49, 17);
            this.rdbDES.TabIndex = 0;
            this.rdbDES.TabStop = true;
            this.rdbDES.Text = "DES";
            this.rdbDES.UseVisualStyleBackColor = true;
            // 
            // btnEncrypt
            // 
            pigment1.Name = "Border";
            pigment1.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment2.Name = "Backcolor";
            pigment2.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment3.Name = "Highlight";
            pigment3.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment4.Name = "Gradient1";
            pigment4.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment5.Name = "Gradient2";
            pigment5.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment6.Name = "Text Color";
            pigment6.Value = System.Drawing.Color.White;
            pigment7.Name = "Text Shadow";
            pigment7.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnEncrypt.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment1,
        pigment2,
        pigment3,
        pigment4,
        pigment5,
        pigment6,
        pigment7};
            this.btnEncrypt.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnEncrypt.Location = new System.Drawing.Point(232, 477);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Shadow = true;
            this.btnEncrypt.Size = new System.Drawing.Size(91, 24);
            this.btnEncrypt.TabIndex = 4;
            this.btnEncrypt.Text = "ENCRYPT";
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.FillColor = System.Drawing.Color.Transparent;
            this.groupBox2.Location = new System.Drawing.Point(6, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.NoRounding = false;
            this.groupBox2.Size = new System.Drawing.Size(317, 138);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.Text = "groupBox2";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::The_RATs_Crew_Crypter.Properties.Resources.ratscrewlogo;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(311, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnSelectIcon);
            this.groupBox1.Controls.Add(this.txtIcon);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSelectFile);
            this.groupBox1.Controls.Add(this.txtFile);
            this.groupBox1.FillColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(6, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.NoRounding = false;
            this.groupBox1.Size = new System.Drawing.Size(317, 100);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.Text = "groupBox1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label2.Location = new System.Drawing.Point(6, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Icon:";
            // 
            // btnSelectIcon
            // 
            pigment8.Name = "Border";
            pigment8.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment9.Name = "Backcolor";
            pigment9.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment10.Name = "Highlight";
            pigment10.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment11.Name = "Gradient1";
            pigment11.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment12.Name = "Gradient2";
            pigment12.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment13.Name = "Text Color";
            pigment13.Value = System.Drawing.Color.White;
            pigment14.Name = "Text Shadow";
            pigment14.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectIcon.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment8,
        pigment9,
        pigment10,
        pigment11,
        pigment12,
        pigment13,
        pigment14};
            this.btnSelectIcon.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectIcon.Location = new System.Drawing.Point(254, 67);
            this.btnSelectIcon.Name = "btnSelectIcon";
            this.btnSelectIcon.Shadow = true;
            this.btnSelectIcon.Size = new System.Drawing.Size(54, 23);
            this.btnSelectIcon.TabIndex = 5;
            this.btnSelectIcon.Text = "...";
            this.btnSelectIcon.Click += new System.EventHandler(this.btnSelectIcon_Click);
            // 
            // txtIcon
            // 
            this.txtIcon.AllowDrop = true;
            this.txtIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIcon.ForeColor = System.Drawing.Color.Lime;
            this.txtIcon.Location = new System.Drawing.Point(9, 69);
            this.txtIcon.Name = "txtIcon";
            this.txtIcon.Size = new System.Drawing.Size(230, 21);
            this.txtIcon.TabIndex = 4;
            this.txtIcon.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtIcon_DragDrop);
            this.txtIcon.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtIcon_DragEnter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label1.Location = new System.Drawing.Point(6, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "File to be encrypted:";
            // 
            // btnSelectFile
            // 
            pigment15.Name = "Border";
            pigment15.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment16.Name = "Backcolor";
            pigment16.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment17.Name = "Highlight";
            pigment17.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment18.Name = "Gradient1";
            pigment18.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment19.Name = "Gradient2";
            pigment19.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment20.Name = "Text Color";
            pigment20.Value = System.Drawing.Color.White;
            pigment21.Name = "Text Shadow";
            pigment21.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectFile.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment15,
        pigment16,
        pigment17,
        pigment18,
        pigment19,
        pigment20,
        pigment21};
            this.btnSelectFile.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectFile.Location = new System.Drawing.Point(254, 21);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Shadow = true;
            this.btnSelectFile.Size = new System.Drawing.Size(54, 23);
            this.btnSelectFile.TabIndex = 2;
            this.btnSelectFile.Text = "...";
            this.btnSelectFile.Click += new System.EventHandler(this.btnEncryptedFileSearch_Click);
            // 
            // txtFile
            // 
            this.txtFile.AllowDrop = true;
            this.txtFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFile.ForeColor = System.Drawing.Color.Lime;
            this.txtFile.Location = new System.Drawing.Point(9, 23);
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(230, 21);
            this.txtFile.TabIndex = 1;
            // 
            // frmTRC_Crypter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ClientSize = new System.Drawing.Size(330, 509);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmTRC_Crypter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TRC Crypter ~ Version 1.5";
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFile;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private FButton btnSelectFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private FButton btnSelectIcon;
        private System.Windows.Forms.TextBox txtIcon;
        private FButton btnEncrypt;
        private GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rdbTripleDES;
        private System.Windows.Forms.RadioButton rdbDES;
        private System.Windows.Forms.RadioButton rdbXOR;
        private System.Windows.Forms.RadioButton rdbSymentric;
        private System.Windows.Forms.RadioButton rdbRijndael;
        private System.Windows.Forms.RadioButton rdbRC4;
        private System.Windows.Forms.RadioButton rdbRC2;
        private GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdbDefaultBrowser;
        private System.Windows.Forms.RadioButton rdbInjectInto;
        private System.Windows.Forms.TextBox txtInjectInto;
        private GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdbRunPE3;
        private System.Windows.Forms.RadioButton rdbRunPE2;
        private System.Windows.Forms.RadioButton rdbRunPE1;
        private System.Windows.Forms.RadioButton rdbRunPE0;
        private System.Windows.Forms.RadioButton rdbRunPE9;
        private System.Windows.Forms.RadioButton rdbRunPE8;
        private System.Windows.Forms.RadioButton rdbRunPE7;
        private System.Windows.Forms.RadioButton rdbRunPE6;
        private System.Windows.Forms.RadioButton rdbRunPE5;
        private System.Windows.Forms.RadioButton rdbRunPE4;
        private System.Windows.Forms.RadioButton rdbRunPE11;
        private System.Windows.Forms.RadioButton rdbRunPE10;
        private System.Windows.Forms.RadioButton rdbCloud;
        private System.Windows.Forms.RadioButton rdbStairs;
        private System.Windows.Forms.RadioButton rdbAES;
        private System.Windows.Forms.RadioButton rdbPolyBaby;
        private System.Windows.Forms.RadioButton rdbDex;
        private System.Windows.Forms.RadioButton rdbPolyStairs;
        private System.Windows.Forms.RadioButton rdbPolyRev;
    }
}

