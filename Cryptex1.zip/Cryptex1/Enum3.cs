﻿using System;
namespace Cryptex1
{
    [System.Flags]
    private enum Enum3
    {
        flag_0 = 1,
        flag_1 = 2,
        flag_2 = 4,
        flag_3 = 8,
        flag_4 = 16,
        flag_5 = 65536,
        flag_6 = 131072,
        flag_7 = 262144,
        flag_8 = 524288
    }
}