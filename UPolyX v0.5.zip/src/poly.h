#include <windows.h>
#include <stdio.h>

#define RegEax 0
#define RegEcx 1
#define RegEdx 2
#define RegEbx 3
#define RegEsp 4
#define RegEbp 5
#define RegEsi 6
#define RegEdi 7




void AddToRegOneByte(BYTE  buf[],int Reg,int value,int &pos);
void StackFrame(BYTE  buf[],int &pos);
void AddToReg(BYTE  buf[],int Reg,int value,int &pos);

void SubFromReg(BYTE  buf[],int Reg,int value,int &pos);

void MoveAddrToReg(BYTE buf[],int Reg,DWORD Addr,int &pos);
void MoveRegToReg(BYTE buf[],int DesReg,int SrcReg,int &pos);

void JumpToReg(BYTE buf[],int Reg,int &pos);

int SetLabel(int pos);

void LoopToLabel(BYTE buf[],int label,int &pos);

void XorRegOneByte(BYTE buf[],int Reg,BYTE XorByte,int &pos);
void XorRegFourBytes(BYTE buf[],int Reg,DWORD XorBytes,int &pos);
void PushReg(BYTE buf[],int Reg,int &pos);
void PopReg(BYTE buf[],int Reg,int &pos);
void JumpForward(BYTE buf[],int bytes,int &pos);
void JumpBackward(BYTE buf[],int bytes,int &pos);
void Ret(BYTE buf[],int &pos);


