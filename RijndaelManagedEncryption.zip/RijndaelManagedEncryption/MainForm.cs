﻿using System;
using System.Windows.Forms;

namespace RijndaelManagedEncryption
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            SaltTextBox.Text = Guid.NewGuid().ToString();
        }

        private void EncryptButton_Click(object sender, EventArgs e)
        {
            try
            {
                OutputTextBox.Text = RijndaelManagedEncryption.EncryptRijndael(InputTextBox.Text, SaltTextBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void DecryptButton_Click(object sender, EventArgs e)
        {
            try
            {
                OutputTextBox.Text = RijndaelManagedEncryption.DecryptRijndael(InputTextBox.Text, SaltTextBox.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SaltButton_Click(object sender, EventArgs e)
        {
            SaltTextBox.Text = Guid.NewGuid().ToString();
        }
    }
}
