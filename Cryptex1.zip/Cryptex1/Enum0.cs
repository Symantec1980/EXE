﻿
using System;
namespace Cryptex1
{
    internal enum Enum0 : byte
    {
        const_0,
        const_1,
        const_2,
        const_3
    }
}
