﻿Imports System.IO
Imports Microsoft.Win32
Public Class Form3

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Try
            ListBox2.Items.Clear()

            Dim Mi As String = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
            For Each s As String In Directory.GetFiles(Mi)
                ListBox2.Items.Add(s)
            Next
        Catch : End Try
        ProgressBar2.Value = 100
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Dim Mimo_Path As String = "Software\Microsoft\Windows\CurrentVersion\Run"
        Try
            For Each x In ListBox2.Items
                Registry.CurrentUser.OpenSubKey(Mimo_Path, True).DeleteValue(x, True)
                MessageBox.Show("Done", "[Mimo]", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Next
            ListBox2.Items.Clear()


        Catch : End Try

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Me.Close()
    End Sub
End Class