﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Dev_Point
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {


                OpenFileDialog op = new OpenFileDialog();
                op.Filter = "VBS Script|*.VBS";
                op.ShowDialog();
                string encryp = VBS(System.IO.File.ReadAllText(op.FileName));
               // Clipboard.SetText(encryp);
              //  MessageBox.Show("تم النسخ الى الحافة :)  ");
               SaveFileDialog sv = new SaveFileDialog();
                sv.Filter = "VBS Script|*.VBS";
                sv.ShowDialog();
                System.IO.File.WriteAllText(sv.FileName, encryp + Environment .NewLine + Dev_Point .Properties .Resources .String1 , (new System.Text.UnicodeEncoding()));
                MessageBox.Show("Done ! :)  " + Environment .NewLine + sv.FileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        static String VBS(String S)
        {
           
            StringBuilder Out = new StringBuilder();

           Out.Append ("A = Array( ");
            var oo = new List<int>();
            oo.Add(0);
            foreach (var c in S)
            {
                oo.Add((int)(c));

            }
            for (int i = oo.ToArray().Length-1 ; i > 0 ; i-- )
            {
                Out.Append(oo[i] + ", ");
            }
            return Out.ToString().Remove(Out.Length - 2, 1) + ')';// Out .ToString () + ')';
        }

      

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

     

       

    }
}
