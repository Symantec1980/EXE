﻿Imports System.Security.Cryptography
Imports System.Text
Imports System.IO
Imports System.Security
Imports System.IO.Compression

Public Class Algorithms
    Function Bs64(ByVal bytes As Byte()) As String
        Return Convert.ToBase64String(bytes)
    End Function
    Public Function StrToHex(ByVal Data As String) As String
        Dim sVal As String
        Dim sHex As String = ""
        While Data.Length > 0
            sVal = Conversion.Hex(Strings.AscW(Data.Substring(0, 1).ToString()))
            Data = Data.Substring(1, Data.Length - 1)
            sHex = sHex & sVal
        End While
        Return sHex
    End Function

    Function RC4Encrypt(ByVal A6 As Byte(), ByVal A7 As String) As Byte()
        Dim A1 As Byte() = System.Text.Encoding.BigEndianUnicode.GetBytes(A7)
        Dim A2, A3, A4 As UInteger
        Dim A5 As UInteger() = New UInteger(255) {}
        Dim A9 As Byte() = New Byte(A6.Length - 1) {}
        For A2 = 0 To 255
            A5(A2) = A2
        Next
        For A2 = 0 To 255
            A3 = (A3 + A1(A2 Mod A1.Length) + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
        Next
        A2 = 0 : A3 = 0
        For A8 = 0 To A9.Length - 1
            A2 = (A2 + 1) And 255
            A3 = (A3 + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
            A9(A8) = A6(A8) Xor A5((A5(A2) + A5(A3)) And 255)
        Next
        Return A9
    End Function
    Public Function Symmetric(ByVal B() As Byte, ByVal ikey As String) As Byte()
        Dim Sym As SymmetricAlgorithm = SymmetricAlgorithm.Create
        Dim hash As New SHA256CryptoServiceProvider()
        Dim key() As Byte = hash.ComputeHash(Encoding.BigEndianUnicode.GetBytes(ikey))
        Sym.Key = key
        Sym.Mode = CipherMode.ECB
        Dim result() As Byte = Sym.CreateEncryptor.TransformFinalBlock(B, 0, B.Length)
        Return result
    End Function

    Public Function RN() As String
        Dim s As String = "美复复美丽丽复复制制制复复丽制复复复复丽复丽复制复复复复复丽复复复复丽"
        Dim r As New Random
        Dim sb As New StringBuilder
        For i As Integer = 0 To 8
            Dim idx As Integer = r.Next(0, 35)
            sb.Append(s.Substring(idx, 1))
        Next
        Return sb.ToString
    End Function

    Public Function RC2Encrypt(ByVal B() As Byte, ByVal ikey As String) As Byte()
        Dim RC2 As New RC2CryptoServiceProvider()
        Dim hashkey As New MD5CryptoServiceProvider()
        Dim key As Byte() = hashkey.ComputeHash(Encoding.BigEndianUnicode.GetBytes(ikey))
        RC2.Key = key
        RC2.Mode = CipherMode.ECB
        Dim result() As Byte = RC2.CreateEncryptor().TransformFinalBlock(B, 0, B.Length)
        Return result
    End Function

    Public Function DESEncrypt(ByVal B() As Byte, ByVal ikey As String) As Byte()
        Dim DES As New DESCryptoServiceProvider()
        Dim hashkey As New SHA256CryptoServiceProvider()
        Dim arrayx As Byte() = New Byte(8 - 1) {}
        Dim key() As Byte = hashkey.ComputeHash(Encoding.BigEndianUnicode.GetBytes(ikey))
        Array.Copy(key, 0, arrayx, 0, 8)
        DES.Key = arrayx
        DES.Mode = CipherMode.ECB
        Dim result() As Byte = DES.CreateEncryptor.TransformFinalBlock(B, 0, B.Length)
        Return result
    End Function
    Public Function XOREncrypt(ByVal up As Byte(), ByVal BB2 As String) As Byte()
        Dim CL As Byte() = System.Text.Encoding.BigEndianUnicode.GetBytes(BB2)
        Randomize()
        Dim FP As Integer = Int((255 - 0 + 1) * Rnd()) + 1
        Dim BA(up.Length) As Byte
        Dim KA As Integer
        For MP As Integer = 0 To up.Length - 1
            BA(MP) += (up(MP) Xor CL(KA)) Xor FP
            If KA = BB2.Length - 1 Then KA = 0 Else KA = KA + 1
        Next
        BA(up.Length) = 112 Xor FP
        Return BA
    End Function

    Public Function AESEncrypt(ByVal byt As Byte(), ByVal ikey As String) As Byte()
        Dim aes As New AesCryptoServiceProvider()
        Dim hashkey As New Security.Cryptography.SHA256CryptoServiceProvider
        Dim key As Byte() = hashkey.ComputeHash(Encoding.BigEndianUnicode.GetBytes(ikey))
        aes.Key = key
        aes.Mode = CipherMode.ECB
        Dim result() As Byte = aes.CreateEncryptor().TransformFinalBlock(byt, 0, byt.Length)
        Return result
    End Function

   

    Public Function Md5Encrypt(ByVal B() As Byte, ByVal iKey As String) As Byte()
        Dim keyArray As Byte()
        Dim hashmd5 As New MD5CryptoServiceProvider()
        keyArray = hashmd5.ComputeHash(Encoding.BigEndianUnicode.GetBytes(iKey))
        Dim tdes As New Security.Cryptography.AesManaged
        tdes.Key = keyArray
        tdes.Mode = CipherMode.ECB
        Dim cTransform As ICryptoTransform = tdes.CreateEncryptor()
        Dim resultArray As Byte() = cTransform.TransformFinalBlock(B, 0, B.Length)
        tdes.Clear()
        Return resultArray
    End Function

   

    Public Function TripleDES(ByVal B() As Byte, ByVal ikey As String) As Byte()
        Dim tdes As New TripleDESCryptoServiceProvider()
        Dim hash As New MD5CryptoServiceProvider()
        Dim key() As Byte = hash.ComputeHash(Encoding.BigEndianUnicode.GetBytes(ikey))
        tdes.Key = key
        tdes.Mode = CipherMode.ECB
        Dim result() As Byte = tdes.CreateEncryptor.TransformFinalBlock(B, 0, B.Length)
        Return result
    End Function
    Public Class StairsEncryption
        Public Shared Function Crypt(ByVal Data() As Byte, ByVal key() As Byte) As Byte()
            For i = 0 To (Data.Length * 2) + key.Length
                Data(i Mod Data.Length) = CByte(CInt((Data(i Mod Data.Length)) + CInt(Data((i + 1) Mod Data.Length))) Mod 256) Xor key(i Mod key.Length)
            Next
            Return Data
        End Function
    End Class

    Public Function StairsENCR(ByVal data As Byte(), ByVal PP As String) As Byte()
        Dim H As New StairsEncryption
        Return StairsEncryption.Crypt(data, Encoding.Default.GetBytes(PP))
    End Function
    Private Function RSMEncrypt(ByVal data As Byte(), ByVal key As Byte()) As Byte()
        Dim R As New Rfc2898DeriveBytes(key, New Byte(7) {}, 1)

        Dim T As New RijndaelManaged
        T.Key = R.GetBytes(16)
        T.IV = R.GetBytes(16)

        Dim O(data.Length + 15) As Byte
        Buffer.BlockCopy(Guid.NewGuid.ToByteArray, 0, O, 0, 16)
        Buffer.BlockCopy(data, 0, O, 16, data.Length)

        Return T.CreateEncryptor.TransformFinalBlock(O, 0, O.Length)
    End Function
    Public Function RSMENCR(ByVal Files As Byte(), ByVal k As String) As Byte()
        Return RSMEncrypt(Files, Encoding.Default.GetBytes(k))
    End Function
    Public Class PolyMorphicStairs
        Overloads Shared Function PolyCrypt(ByRef Data() As Byte, ByVal Key() As Byte, Optional ByVal ExtraRounds As UInteger = 0) As Byte()
            Array.Resize(Data, Data.Length + 1)
            Data(Data.Length - 1) = Convert.ToByte(New Random().Next(1, 255))
            For i = (Data.Length - 1) * (ExtraRounds + 1) To 0 Step -1
                Data(i Mod Data.Length) = CByte(CInt((Data(i Mod Data.Length)) + CInt(Data((i + 1) Mod Data.Length))) Mod 256) Xor Key(i Mod Key.Length)
            Next
            Return Data
        End Function

    End Class

    Public Function MorphicEnc(ByVal data As Byte(), ByVal PP As String) As Byte()
        Dim H As New PolyMorphicStairs
        Return PolyMorphicStairs.PolyCrypt(data, Encoding.Default.GetBytes(PP))
    End Function


    Function RijnEnc(ByVal B As Byte(), ByVal ikey As String) As Byte()
        Dim rij As New RijndaelManaged
        Dim hash As New MD5CryptoServiceProvider()
        Dim key() As Byte = hash.ComputeHash(Encoding.BigEndianUnicode.GetBytes(ikey))
        rij.Key = key
        rij.Mode = CipherMode.ECB
        Dim result() As Byte = rij.CreateEncryptor.TransformFinalBlock(B, 0, B.Length)
        Return result
    End Function

    Public Function GetBytes(ByVal B() As Byte) As String
        Dim S As String = ""
        For i = 0 To B.Length - 1
            Dim A As String = B(i).ToString
            Dim sb As New StringBuilder(A)
            sb.Append(",")
            S += sb.ToString
        Next
        Return S
    End Function

    Public Function XOR_Encrypt(Input As String, pass As String) As String
        Dim stringBuilder As StringBuilder = New StringBuilder()
        Dim num As Integer = Input.Length - 1
        For i As Integer = 0 To num
            Dim num2 As Integer
            Dim text As String = Conversion.Hex(Strings.AscW(Input(i)) Xor Strings.AscW(pass(num2)))
            Dim flag As Boolean = text.Length = 1
            If flag Then
                text = "0" + text
            End If
            stringBuilder.Append(text)
            Dim flag2 As Boolean = num2 = pass.Length - 1
            If flag2 Then
                num2 = 0
            Else
                num2 += 1
            End If
        Next
        Return stringBuilder.ToString()
    End Function

   
    Public Function Vigenere(ByVal proj As String, ByVal key As String)
        Dim Txt As String = ""
        For i As Integer = 1 To proj.Length
            Dim temp As Integer = AscW(GetChar(proj, i)) + AscW(GetChar(key, i Mod key.Length + 1))
            Txt += ChrW(temp)
        Next
        Return Txt
    End Function

    Public Function VernamEnc(ByVal input As String, ByVal pass As String) As String
        Dim Out1 As StringBuilder = New StringBuilder()
        For Each ch As Char In input
            Dim tmp As String = Strings.ChrW(Strings.AscW(ch) * (Strings.AscW(pass) Mod Math.PI)).ToString()
            Out1.Append(tmp)
        Next
        Return Out1.ToString()
    End Function
    Public Function ZIP(ByVal B() As Byte) As Byte()
        Dim M As Object = New IO.MemoryStream()
        Dim gZip As Object = New IO.Compression.GZipStream(M, CompressionMode.Compress, True)
        gZip.Write(B, 0, B.Length)
        gZip.Dispose()
        M.Position = 0
        Dim BF(M.Length) As Byte
        M.Read(BF, 0, BF.Length)
        M.Dispose()
        Return BF
    End Function

    Public Function DZIP(ByVal B() As Byte) As Byte()
        Dim M As Object = New IO.MemoryStream()
        Dim gZip As Object = New IO.Compression.DeflateStream(M, CompressionMode.Compress, True)
        gZip.Write(B, 0, B.Length)
        gZip.Dispose()
        M.Position = 0
        Dim BF(M.Length) As Byte
        M.Read(BF, 0, BF.Length)
        M.Dispose()
        Return BF
    End Function

 
End Class
