﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ReconForm1 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconForm()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtBox3 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.TxtBox()
        Me.ReconButton5 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ReconGroupBox1 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconGroupBox()
        Me.LinkLabel3 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.TxtBox1 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.TxtBox()
        Me.ReconButton4 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton()
        Me.ReconButton2 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.ReconButton1 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton()
        Me.ReconButton3 = New MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton()
        Me.ReconForm1.SuspendLayout()
        Me.ReconGroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReconForm1
        '
        Me.ReconForm1.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.ReconForm1.Controls.Add(Me.ReconButton3)
        Me.ReconForm1.Controls.Add(Me.Label2)
        Me.ReconForm1.Controls.Add(Me.TxtBox3)
        Me.ReconForm1.Controls.Add(Me.ReconButton5)
        Me.ReconForm1.Controls.Add(Me.Label1)
        Me.ReconForm1.Controls.Add(Me.ReconGroupBox1)
        Me.ReconForm1.Controls.Add(Me.TxtBox1)
        Me.ReconForm1.Controls.Add(Me.ReconButton4)
        Me.ReconForm1.Controls.Add(Me.ReconButton2)
        Me.ReconForm1.Controls.Add(Me.PictureBox1)
        Me.ReconForm1.Controls.Add(Me.ReconButton1)
        Me.ReconForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReconForm1.ForeColor = System.Drawing.Color.Olive
        Me.ReconForm1.Image = Nothing
        Me.ReconForm1.Location = New System.Drawing.Point(0, 0)
        Me.ReconForm1.MoveHeight = 30
        Me.ReconForm1.Name = "ReconForm1"
        Me.ReconForm1.Resizable = True
        Me.ReconForm1.ShowIcon = False
        Me.ReconForm1.Size = New System.Drawing.Size(406, 240)
        Me.ReconForm1.TabIndex = 0
        Me.ReconForm1.Text = "MsterMedo Crypter  (3.1)   By GAITH7H3WOLF"
        Me.ReconForm1.TextAlignment = MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconForm.TextAlign.Left
        Me.ReconForm1.TransparencyKey = System.Drawing.Color.Fuchsia
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.LightYellow
        Me.Label2.Location = New System.Drawing.Point(193, 192)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(180, 15)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Programmer : GAITH7H3WOLF"
        '
        'TxtBox3
        '
        Me.TxtBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.TxtBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.TxtBox3.ForeColor = System.Drawing.Color.LightGray
        Me.TxtBox3.Location = New System.Drawing.Point(102, 122)
        Me.TxtBox3.Name = "TxtBox3"
        Me.TxtBox3.Size = New System.Drawing.Size(295, 20)
        Me.TxtBox3.TabIndex = 10
        '
        'ReconButton5
        '
        Me.ReconButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton5.ForeColor = System.Drawing.Color.YellowGreen
        Me.ReconButton5.Image = Nothing
        Me.ReconButton5.Location = New System.Drawing.Point(12, 121)
        Me.ReconButton5.Name = "ReconButton5"
        Me.ReconButton5.NoRounding = False
        Me.ReconButton5.Size = New System.Drawing.Size(75, 23)
        Me.ReconButton5.TabIndex = 9
        Me.ReconButton5.Text = "Add STUB"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.LightYellow
        Me.Label1.Location = New System.Drawing.Point(214, 211)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(139, 15)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Thanks To : Mster Medo"
        '
        'ReconGroupBox1
        '
        Me.ReconGroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.ReconGroupBox1.Controls.Add(Me.LinkLabel3)
        Me.ReconGroupBox1.Controls.Add(Me.LinkLabel2)
        Me.ReconGroupBox1.Controls.Add(Me.LinkLabel1)
        Me.ReconGroupBox1.Location = New System.Drawing.Point(12, 146)
        Me.ReconGroupBox1.Name = "ReconGroupBox1"
        Me.ReconGroupBox1.NoRounding = False
        Me.ReconGroupBox1.Size = New System.Drawing.Size(150, 89)
        Me.ReconGroupBox1.TabIndex = 7
        Me.ReconGroupBox1.Text = "مواقع فحص لا ترسل قيم السيرفر"
        '
        'LinkLabel3
        '
        Me.LinkLabel3.AutoSize = True
        Me.LinkLabel3.LinkColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LinkLabel3.Location = New System.Drawing.Point(34, 66)
        Me.LinkLabel3.Name = "LinkLabel3"
        Me.LinkLabel3.Size = New System.Drawing.Size(77, 13)
        Me.LinkLabel3.TabIndex = 15
        Me.LinkLabel3.TabStop = True
        Me.LinkLabel3.Text = "scan.majyx.net"
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.LinkColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LinkLabel2.Location = New System.Drawing.Point(17, 47)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(111, 13)
        Me.LinkLabel2.TabIndex = 14
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "www.nodistribute.com"
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.LinkColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.LinkLabel1.Location = New System.Drawing.Point(25, 27)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(95, 13)
        Me.LinkLabel1.TabIndex = 13
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "www.chk4me.com"
        '
        'TxtBox1
        '
        Me.TxtBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.TxtBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.TxtBox1.ForeColor = System.Drawing.Color.LightGray
        Me.TxtBox1.Location = New System.Drawing.Point(102, 93)
        Me.TxtBox1.Name = "TxtBox1"
        Me.TxtBox1.Size = New System.Drawing.Size(295, 20)
        Me.TxtBox1.TabIndex = 5
        '
        'ReconButton4
        '
        Me.ReconButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconButton4.ForeColor = System.Drawing.Color.YellowGreen
        Me.ReconButton4.Image = Nothing
        Me.ReconButton4.Location = New System.Drawing.Point(291, 146)
        Me.ReconButton4.Name = "ReconButton4"
        Me.ReconButton4.NoRounding = False
        Me.ReconButton4.Size = New System.Drawing.Size(106, 39)
        Me.ReconButton4.TabIndex = 4
        Me.ReconButton4.Text = "Crypter"
        '
        'ReconButton2
        '
        Me.ReconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton2.ForeColor = System.Drawing.Color.YellowGreen
        Me.ReconButton2.Image = Nothing
        Me.ReconButton2.Location = New System.Drawing.Point(12, 92)
        Me.ReconButton2.Name = "ReconButton2"
        Me.ReconButton2.NoRounding = False
        Me.ReconButton2.Size = New System.Drawing.Size(75, 23)
        Me.ReconButton2.TabIndex = 2
        Me.ReconButton2.Text = "Add File"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 31)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(401, 55)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'ReconButton1
        '
        Me.ReconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton1.ForeColor = System.Drawing.Color.LightYellow
        Me.ReconButton1.Image = Nothing
        Me.ReconButton1.Location = New System.Drawing.Point(358, 6)
        Me.ReconButton1.Name = "ReconButton1"
        Me.ReconButton1.NoRounding = False
        Me.ReconButton1.Size = New System.Drawing.Size(39, 19)
        Me.ReconButton1.TabIndex = 0
        Me.ReconButton1.Text = "Close"
        '
        'ReconButton3
        '
        Me.ReconButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconButton3.ForeColor = System.Drawing.Color.YellowGreen
        Me.ReconButton3.Image = Nothing
        Me.ReconButton3.Location = New System.Drawing.Point(168, 146)
        Me.ReconButton3.Name = "ReconButton3"
        Me.ReconButton3.NoRounding = False
        Me.ReconButton3.Size = New System.Drawing.Size(106, 39)
        Me.ReconButton3.TabIndex = 12
        Me.ReconButton3.Text = "Gen STUB"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(406, 240)
        Me.Controls.Add(Me.ReconForm1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ReconForm1.ResumeLayout(False)
        Me.ReconForm1.PerformLayout()
        Me.ReconGroupBox1.ResumeLayout(False)
        Me.ReconGroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReconForm1 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconForm
    Friend WithEvents ReconButton1 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton
    Friend WithEvents TxtBox1 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.TxtBox
    Friend WithEvents ReconButton4 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton
    Friend WithEvents ReconButton2 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TxtBox3 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.TxtBox
    Friend WithEvents ReconButton5 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ReconGroupBox1 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconGroupBox
    Friend WithEvents LinkLabel3 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel2 As System.Windows.Forms.LinkLabel
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ReconButton3 As MsterMedo_Crypter___3._1__By_GAITH7H3WOLF.ReconButton

End Class
