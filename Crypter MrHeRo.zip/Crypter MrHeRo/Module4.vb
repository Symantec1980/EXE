﻿Module Generate1
    Class keyc1
        Public Shared Function Key() As Object
            Const ranshit1 As String = "ярнонниПняииПиПянняППяииоооиинрПияииППоянит"
            Const randshit2 As String = "иииорПяяиПярияинияППирПиоряПтиониПяиирряоиряПртн"
            Const ranshit3 As String = "яниПяПоряияоярионПяиПияиоиПияяоняПнииП"
            Const ranshit4 As String = "яряннииПяПоянронПяяинниоПииПнр"
            Dim totalequivalent As String
            Dim i As Short
            totalequivalent = ranshit1 & randshit2 & ranshit3
            For i = 1 To CInt("150")
                Key = Key & Mid(totalequivalent, Int((Rnd() * Len(totalequivalent)) + 1), 1)
            Next i
        End Function
    End Class
End Module