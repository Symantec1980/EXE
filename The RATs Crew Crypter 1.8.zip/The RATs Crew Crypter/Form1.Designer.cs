﻿namespace The_RATs_Crew_Crypter
{
    partial class frmTRC_Crypter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTRC_Crypter));
            this.futureButton12 = new The_RATs_Crew_Crypter.FutureButton();
            this.btnMain = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton6 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton7 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton8 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton5 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton4 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton3 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton1 = new The_RATs_Crew_Crypter.FutureButton();
            this.grpAssemblyChanger = new The_RATs_Crew_Crypter.GroupBox();
            this.numASMF4 = new System.Windows.Forms.NumericUpDown();
            this.numASM4 = new System.Windows.Forms.NumericUpDown();
            this.numASM3 = new System.Windows.Forms.NumericUpDown();
            this.numASMF3 = new System.Windows.Forms.NumericUpDown();
            this.txtASMProduct = new System.Windows.Forms.TextBox();
            this.numASM2 = new System.Windows.Forms.NumericUpDown();
            this.numASM1 = new System.Windows.Forms.NumericUpDown();
            this.txtASMCompany = new System.Windows.Forms.TextBox();
            this.numASMF2 = new System.Windows.Forms.NumericUpDown();
            this.txtASMCopyright = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txtASMDescription = new System.Windows.Forms.TextBox();
            this.numASMF1 = new System.Windows.Forms.NumericUpDown();
            this.txtASMTitle = new System.Windows.Forms.TextBox();
            this.chkEnableAssemblyChanger = new System.Windows.Forms.CheckBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.grpOptions = new The_RATs_Crew_Crypter.GroupBox();
            this.groupBox1 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbInjectInto = new System.Windows.Forms.RadioButton();
            this.rdbDefaultBrowser = new System.Windows.Forms.RadioButton();
            this.rdbCSC = new System.Windows.Forms.RadioButton();
            this.txtInjectInto = new System.Windows.Forms.TextBox();
            this.rdbVBC = new System.Windows.Forms.RadioButton();
            this.chkCompressGZip = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbInstallAppData = new System.Windows.Forms.RadioButton();
            this.rdbInstallNone = new System.Windows.Forms.RadioButton();
            this.rdbInstallTemp = new System.Windows.Forms.RadioButton();
            this.txtKeynameStartup = new System.Windows.Forms.TextBox();
            this.chkStartup = new System.Windows.Forms.CheckBox();
            this.chkPreserveEoF = new System.Windows.Forms.CheckBox();
            this.grpJunk = new The_RATs_Crew_Crypter.GroupBox();
            this.groupBox4 = new The_RATs_Crew_Crypter.GroupBox();
            this.chkVagueVarsAPI = new System.Windows.Forms.CheckBox();
            this.chkUseArraysAPI = new System.Windows.Forms.CheckBox();
            this.numAPILength = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.numHowManyAPIs = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.chkFakeAPIs = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new The_RATs_Crew_Crypter.GroupBox();
            this.chkVagueVarsJunk = new System.Windows.Forms.CheckBox();
            this.numJunkLength = new System.Windows.Forms.NumericUpDown();
            this.chkUseArrays = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.numHowManyJunk = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.chkJunkCode = new System.Windows.Forms.CheckBox();
            this.grpRunPEs = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbRunPE11 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE10 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE9 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE8 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE7 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE6 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE5 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE4 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE3 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE2 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE1 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE0 = new System.Windows.Forms.RadioButton();
            this.grpEncryptions = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbPoly3DES = new System.Windows.Forms.RadioButton();
            this.rdbPolyDES = new System.Windows.Forms.RadioButton();
            this.rdbPolyAES = new System.Windows.Forms.RadioButton();
            this.rdbPolyDEX = new System.Windows.Forms.RadioButton();
            this.rdbPolyRC2 = new System.Windows.Forms.RadioButton();
            this.rdbPolySymentric = new System.Windows.Forms.RadioButton();
            this.rdbPolyCloud = new System.Windows.Forms.RadioButton();
            this.rdbCloud = new System.Windows.Forms.RadioButton();
            this.rdbStairs = new System.Windows.Forms.RadioButton();
            this.rdbAES = new System.Windows.Forms.RadioButton();
            this.rdbPolyBaby = new System.Windows.Forms.RadioButton();
            this.rdbDex = new System.Windows.Forms.RadioButton();
            this.rdbPolyStairs = new System.Windows.Forms.RadioButton();
            this.rdbXOR = new System.Windows.Forms.RadioButton();
            this.rdbRijndael = new System.Windows.Forms.RadioButton();
            this.rdbSymentric = new System.Windows.Forms.RadioButton();
            this.rdbPolyRev = new System.Windows.Forms.RadioButton();
            this.rdbTripleDES = new System.Windows.Forms.RadioButton();
            this.rdbRC2 = new System.Windows.Forms.RadioButton();
            this.rdbDES = new System.Windows.Forms.RadioButton();
            this.rdbRC4 = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new The_RATs_Crew_Crypter.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grpMain = new The_RATs_Crew_Crypter.GroupBox();
            this.btnSelectBindFile2 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton10 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton9 = new The_RATs_Crew_Crypter.FutureButton();
            this.futureButton2 = new The_RATs_Crew_Crypter.FutureButton();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBindFile2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBindFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIcon = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.grpAssemblyChanger.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF1)).BeginInit();
            this.grpOptions.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.grpJunk.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAPILength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHowManyAPIs)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numJunkLength)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHowManyJunk)).BeginInit();
            this.grpRunPEs.SuspendLayout();
            this.grpEncryptions.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.grpMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // futureButton12
            // 
            this.futureButton12.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton12.Location = new System.Drawing.Point(118, 404);
            this.futureButton12.Name = "futureButton12";
            this.futureButton12.Size = new System.Drawing.Size(86, 23);
            this.futureButton12.TabIndex = 27;
            this.futureButton12.Text = "ENCRYPT";
            this.futureButton12.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // btnMain
            // 
            this.btnMain.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnMain.ForeColor = System.Drawing.Color.Lime;
            this.btnMain.Location = new System.Drawing.Point(6, 146);
            this.btnMain.Name = "btnMain";
            this.btnMain.Size = new System.Drawing.Size(75, 23);
            this.btnMain.TabIndex = 26;
            this.btnMain.Text = "Main";
            this.btnMain.Click += new System.EventHandler(this.btnMain_Click);
            // 
            // futureButton6
            // 
            this.futureButton6.Enabled = false;
            this.futureButton6.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton6.ForeColor = System.Drawing.Color.Lime;
            this.futureButton6.Location = new System.Drawing.Point(248, 175);
            this.futureButton6.Name = "futureButton6";
            this.futureButton6.Size = new System.Drawing.Size(73, 23);
            this.futureButton6.TabIndex = 25;
            // 
            // futureButton7
            // 
            this.futureButton7.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton7.ForeColor = System.Drawing.Color.Lime;
            this.futureButton7.Location = new System.Drawing.Point(6, 175);
            this.futureButton7.Name = "futureButton7";
            this.futureButton7.Size = new System.Drawing.Size(75, 23);
            this.futureButton7.TabIndex = 24;
            this.futureButton7.Text = "Assembly";
            this.futureButton7.Click += new System.EventHandler(this.btnAssemblyChanger_Click);
            // 
            // futureButton8
            // 
            this.futureButton8.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton8.ForeColor = System.Drawing.Color.Lime;
            this.futureButton8.Location = new System.Drawing.Point(247, 146);
            this.futureButton8.Name = "futureButton8";
            this.futureButton8.Size = new System.Drawing.Size(74, 23);
            this.futureButton8.TabIndex = 23;
            this.futureButton8.Text = "Options";
            this.futureButton8.Click += new System.EventHandler(this.btnOptions_Click);
            // 
            // futureButton5
            // 
            this.futureButton5.Enabled = false;
            this.futureButton5.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton5.ForeColor = System.Drawing.Color.Lime;
            this.futureButton5.Location = new System.Drawing.Point(167, 175);
            this.futureButton5.Name = "futureButton5";
            this.futureButton5.Size = new System.Drawing.Size(76, 23);
            this.futureButton5.TabIndex = 22;
            // 
            // futureButton4
            // 
            this.futureButton4.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton4.ForeColor = System.Drawing.Color.Lime;
            this.futureButton4.Location = new System.Drawing.Point(87, 175);
            this.futureButton4.Name = "futureButton4";
            this.futureButton4.Size = new System.Drawing.Size(75, 23);
            this.futureButton4.TabIndex = 21;
            this.futureButton4.Text = "Junk";
            this.futureButton4.Click += new System.EventHandler(this.btnUSG_Click);
            // 
            // futureButton3
            // 
            this.futureButton3.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton3.ForeColor = System.Drawing.Color.Lime;
            this.futureButton3.Location = new System.Drawing.Point(87, 146);
            this.futureButton3.Name = "futureButton3";
            this.futureButton3.Size = new System.Drawing.Size(75, 23);
            this.futureButton3.TabIndex = 20;
            this.futureButton3.Text = "Encryption";
            this.futureButton3.Click += new System.EventHandler(this.btnEncryption_Click);
            // 
            // futureButton1
            // 
            this.futureButton1.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton1.ForeColor = System.Drawing.Color.Lime;
            this.futureButton1.Location = new System.Drawing.Point(167, 146);
            this.futureButton1.Name = "futureButton1";
            this.futureButton1.Size = new System.Drawing.Size(76, 23);
            this.futureButton1.TabIndex = 18;
            this.futureButton1.Text = "RunPE";
            this.futureButton1.Click += new System.EventHandler(this.btnRunPEs_Click);
            // 
            // grpAssemblyChanger
            // 
            this.grpAssemblyChanger.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpAssemblyChanger.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpAssemblyChanger.Controls.Add(this.numASMF4);
            this.grpAssemblyChanger.Controls.Add(this.numASM4);
            this.grpAssemblyChanger.Controls.Add(this.numASM3);
            this.grpAssemblyChanger.Controls.Add(this.numASMF3);
            this.grpAssemblyChanger.Controls.Add(this.txtASMProduct);
            this.grpAssemblyChanger.Controls.Add(this.numASM2);
            this.grpAssemblyChanger.Controls.Add(this.numASM1);
            this.grpAssemblyChanger.Controls.Add(this.txtASMCompany);
            this.grpAssemblyChanger.Controls.Add(this.numASMF2);
            this.grpAssemblyChanger.Controls.Add(this.txtASMCopyright);
            this.grpAssemblyChanger.Controls.Add(this.label14);
            this.grpAssemblyChanger.Controls.Add(this.label15);
            this.grpAssemblyChanger.Controls.Add(this.txtASMDescription);
            this.grpAssemblyChanger.Controls.Add(this.numASMF1);
            this.grpAssemblyChanger.Controls.Add(this.txtASMTitle);
            this.grpAssemblyChanger.Controls.Add(this.chkEnableAssemblyChanger);
            this.grpAssemblyChanger.Controls.Add(this.label9);
            this.grpAssemblyChanger.Controls.Add(this.label8);
            this.grpAssemblyChanger.Controls.Add(this.label7);
            this.grpAssemblyChanger.Controls.Add(this.label6);
            this.grpAssemblyChanger.Controls.Add(this.label16);
            this.grpAssemblyChanger.FillColor = System.Drawing.Color.Transparent;
            this.grpAssemblyChanger.Location = new System.Drawing.Point(652, 5);
            this.grpAssemblyChanger.Name = "grpAssemblyChanger";
            this.grpAssemblyChanger.NoRounding = false;
            this.grpAssemblyChanger.Size = new System.Drawing.Size(317, 194);
            this.grpAssemblyChanger.TabIndex = 12;
            this.grpAssemblyChanger.Text = "groupBox4";
            // 
            // numASMF4
            // 
            this.numASMF4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASMF4.Enabled = false;
            this.numASMF4.ForeColor = System.Drawing.Color.Yellow;
            this.numASMF4.Location = new System.Drawing.Point(261, 162);
            this.numASMF4.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASMF4.Name = "numASMF4";
            this.numASMF4.ReadOnly = true;
            this.numASMF4.Size = new System.Drawing.Size(40, 21);
            this.numASMF4.TabIndex = 30;
            // 
            // numASM4
            // 
            this.numASM4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASM4.Enabled = false;
            this.numASM4.ForeColor = System.Drawing.Color.Yellow;
            this.numASM4.Location = new System.Drawing.Point(261, 139);
            this.numASM4.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASM4.Name = "numASM4";
            this.numASM4.ReadOnly = true;
            this.numASM4.Size = new System.Drawing.Size(40, 21);
            this.numASM4.TabIndex = 21;
            // 
            // numASM3
            // 
            this.numASM3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASM3.Enabled = false;
            this.numASM3.ForeColor = System.Drawing.Color.Yellow;
            this.numASM3.Location = new System.Drawing.Point(206, 139);
            this.numASM3.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASM3.Name = "numASM3";
            this.numASM3.ReadOnly = true;
            this.numASM3.Size = new System.Drawing.Size(40, 21);
            this.numASM3.TabIndex = 20;
            // 
            // numASMF3
            // 
            this.numASMF3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASMF3.Enabled = false;
            this.numASMF3.ForeColor = System.Drawing.Color.Yellow;
            this.numASMF3.Location = new System.Drawing.Point(206, 162);
            this.numASMF3.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASMF3.Name = "numASMF3";
            this.numASMF3.ReadOnly = true;
            this.numASMF3.Size = new System.Drawing.Size(40, 21);
            this.numASMF3.TabIndex = 29;
            // 
            // txtASMProduct
            // 
            this.txtASMProduct.AllowDrop = true;
            this.txtASMProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtASMProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtASMProduct.Enabled = false;
            this.txtASMProduct.ForeColor = System.Drawing.Color.Yellow;
            this.txtASMProduct.Location = new System.Drawing.Point(96, 112);
            this.txtASMProduct.Name = "txtASMProduct";
            this.txtASMProduct.Size = new System.Drawing.Size(205, 21);
            this.txtASMProduct.TabIndex = 26;
            // 
            // numASM2
            // 
            this.numASM2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASM2.Enabled = false;
            this.numASM2.ForeColor = System.Drawing.Color.Yellow;
            this.numASM2.Location = new System.Drawing.Point(151, 139);
            this.numASM2.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASM2.Name = "numASM2";
            this.numASM2.ReadOnly = true;
            this.numASM2.Size = new System.Drawing.Size(40, 21);
            this.numASM2.TabIndex = 19;
            // 
            // numASM1
            // 
            this.numASM1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASM1.Enabled = false;
            this.numASM1.ForeColor = System.Drawing.Color.Yellow;
            this.numASM1.Location = new System.Drawing.Point(96, 139);
            this.numASM1.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASM1.Name = "numASM1";
            this.numASM1.ReadOnly = true;
            this.numASM1.Size = new System.Drawing.Size(40, 21);
            this.numASM1.TabIndex = 18;
            // 
            // txtASMCompany
            // 
            this.txtASMCompany.AllowDrop = true;
            this.txtASMCompany.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtASMCompany.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtASMCompany.Enabled = false;
            this.txtASMCompany.ForeColor = System.Drawing.Color.Yellow;
            this.txtASMCompany.Location = new System.Drawing.Point(96, 89);
            this.txtASMCompany.Name = "txtASMCompany";
            this.txtASMCompany.Size = new System.Drawing.Size(205, 21);
            this.txtASMCompany.TabIndex = 25;
            // 
            // numASMF2
            // 
            this.numASMF2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASMF2.Enabled = false;
            this.numASMF2.ForeColor = System.Drawing.Color.Yellow;
            this.numASMF2.Location = new System.Drawing.Point(151, 162);
            this.numASMF2.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASMF2.Name = "numASMF2";
            this.numASMF2.ReadOnly = true;
            this.numASMF2.Size = new System.Drawing.Size(40, 21);
            this.numASMF2.TabIndex = 28;
            // 
            // txtASMCopyright
            // 
            this.txtASMCopyright.AllowDrop = true;
            this.txtASMCopyright.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtASMCopyright.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtASMCopyright.Enabled = false;
            this.txtASMCopyright.ForeColor = System.Drawing.Color.Yellow;
            this.txtASMCopyright.Location = new System.Drawing.Point(96, 66);
            this.txtASMCopyright.Name = "txtASMCopyright";
            this.txtASMCopyright.Size = new System.Drawing.Size(205, 21);
            this.txtASMCopyright.TabIndex = 17;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Enabled = false;
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label14.Location = new System.Drawing.Point(11, 93);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(67, 13);
            this.label14.TabIndex = 24;
            this.label14.Text = "Company:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Enabled = false;
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label15.Location = new System.Drawing.Point(11, 115);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 13);
            this.label15.TabIndex = 23;
            this.label15.Text = "Product:";
            // 
            // txtASMDescription
            // 
            this.txtASMDescription.AllowDrop = true;
            this.txtASMDescription.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtASMDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtASMDescription.Enabled = false;
            this.txtASMDescription.ForeColor = System.Drawing.Color.Yellow;
            this.txtASMDescription.Location = new System.Drawing.Point(96, 43);
            this.txtASMDescription.Name = "txtASMDescription";
            this.txtASMDescription.Size = new System.Drawing.Size(205, 21);
            this.txtASMDescription.TabIndex = 16;
            // 
            // numASMF1
            // 
            this.numASMF1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numASMF1.Enabled = false;
            this.numASMF1.ForeColor = System.Drawing.Color.Yellow;
            this.numASMF1.Location = new System.Drawing.Point(96, 162);
            this.numASMF1.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numASMF1.Name = "numASMF1";
            this.numASMF1.ReadOnly = true;
            this.numASMF1.Size = new System.Drawing.Size(40, 21);
            this.numASMF1.TabIndex = 27;
            // 
            // txtASMTitle
            // 
            this.txtASMTitle.AllowDrop = true;
            this.txtASMTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtASMTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtASMTitle.Enabled = false;
            this.txtASMTitle.ForeColor = System.Drawing.Color.Yellow;
            this.txtASMTitle.Location = new System.Drawing.Point(96, 20);
            this.txtASMTitle.Name = "txtASMTitle";
            this.txtASMTitle.Size = new System.Drawing.Size(205, 21);
            this.txtASMTitle.TabIndex = 10;
            // 
            // chkEnableAssemblyChanger
            // 
            this.chkEnableAssemblyChanger.AutoSize = true;
            this.chkEnableAssemblyChanger.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkEnableAssemblyChanger.Location = new System.Drawing.Point(8, 7);
            this.chkEnableAssemblyChanger.Name = "chkEnableAssemblyChanger";
            this.chkEnableAssemblyChanger.Size = new System.Drawing.Size(64, 17);
            this.chkEnableAssemblyChanger.TabIndex = 15;
            this.chkEnableAssemblyChanger.Text = "Enable";
            this.chkEnableAssemblyChanger.UseVisualStyleBackColor = true;
            this.chkEnableAssemblyChanger.CheckedChanged += new System.EventHandler(this.chkEnableAssemblyChanger_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Enabled = false;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label9.Location = new System.Drawing.Point(11, 27);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Title:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label8.Location = new System.Drawing.Point(11, 49);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Description:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Enabled = false;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label7.Location = new System.Drawing.Point(11, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Copyright:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Enabled = false;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label6.Location = new System.Drawing.Point(11, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Version:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Enabled = false;
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label16.Location = new System.Drawing.Point(11, 164);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 13);
            this.label16.TabIndex = 22;
            this.label16.Text = "File Version:";
            // 
            // grpOptions
            // 
            this.grpOptions.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpOptions.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpOptions.Controls.Add(this.groupBox1);
            this.grpOptions.Controls.Add(this.chkCompressGZip);
            this.grpOptions.Controls.Add(this.groupBox5);
            this.grpOptions.Controls.Add(this.txtKeynameStartup);
            this.grpOptions.Controls.Add(this.chkStartup);
            this.grpOptions.Controls.Add(this.chkPreserveEoF);
            this.grpOptions.FillColor = System.Drawing.Color.Transparent;
            this.grpOptions.Location = new System.Drawing.Point(975, 8);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.NoRounding = false;
            this.grpOptions.Size = new System.Drawing.Size(317, 194);
            this.grpOptions.TabIndex = 12;
            this.grpOptions.Text = "groupBox5";
            // 
            // groupBox1
            // 
            this.groupBox1.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.rdbInjectInto);
            this.groupBox1.Controls.Add(this.rdbDefaultBrowser);
            this.groupBox1.Controls.Add(this.rdbCSC);
            this.groupBox1.Controls.Add(this.txtInjectInto);
            this.groupBox1.Controls.Add(this.rdbVBC);
            this.groupBox1.FillColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(15, 73);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.NoRounding = false;
            this.groupBox1.Size = new System.Drawing.Size(286, 55);
            this.groupBox1.TabIndex = 28;
            this.groupBox1.Text = "groupBox1";
            // 
            // rdbInjectInto
            // 
            this.rdbInjectInto.AutoSize = true;
            this.rdbInjectInto.Checked = true;
            this.rdbInjectInto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInjectInto.Location = new System.Drawing.Point(8, 6);
            this.rdbInjectInto.Name = "rdbInjectInto";
            this.rdbInjectInto.Size = new System.Drawing.Size(88, 17);
            this.rdbInjectInto.TabIndex = 8;
            this.rdbInjectInto.TabStop = true;
            this.rdbInjectInto.Text = "Inject into:";
            this.rdbInjectInto.UseVisualStyleBackColor = true;
            // 
            // rdbDefaultBrowser
            // 
            this.rdbDefaultBrowser.AutoSize = true;
            this.rdbDefaultBrowser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDefaultBrowser.Location = new System.Drawing.Point(8, 32);
            this.rdbDefaultBrowser.Name = "rdbDefaultBrowser";
            this.rdbDefaultBrowser.Size = new System.Drawing.Size(117, 17);
            this.rdbDefaultBrowser.TabIndex = 9;
            this.rdbDefaultBrowser.TabStop = true;
            this.rdbDefaultBrowser.Text = "Default Browser";
            this.rdbDefaultBrowser.UseVisualStyleBackColor = true;
            // 
            // rdbCSC
            // 
            this.rdbCSC.AutoSize = true;
            this.rdbCSC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbCSC.Location = new System.Drawing.Point(227, 32);
            this.rdbCSC.Name = "rdbCSC";
            this.rdbCSC.Size = new System.Drawing.Size(46, 17);
            this.rdbCSC.TabIndex = 11;
            this.rdbCSC.TabStop = true;
            this.rdbCSC.Text = "Csc";
            this.rdbCSC.UseVisualStyleBackColor = true;
            // 
            // txtInjectInto
            // 
            this.txtInjectInto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtInjectInto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInjectInto.ForeColor = System.Drawing.Color.Yellow;
            this.txtInjectInto.Location = new System.Drawing.Point(152, 6);
            this.txtInjectInto.Name = "txtInjectInto";
            this.txtInjectInto.Size = new System.Drawing.Size(120, 21);
            this.txtInjectInto.TabIndex = 7;
            this.txtInjectInto.Text = "svchost.exe";
            // 
            // rdbVBC
            // 
            this.rdbVBC.AutoSize = true;
            this.rdbVBC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbVBC.Location = new System.Drawing.Point(153, 32);
            this.rdbVBC.Name = "rdbVBC";
            this.rdbVBC.Size = new System.Drawing.Size(46, 17);
            this.rdbVBC.TabIndex = 10;
            this.rdbVBC.TabStop = true;
            this.rdbVBC.Text = "Vbc";
            this.rdbVBC.UseVisualStyleBackColor = true;
            // 
            // chkCompressGZip
            // 
            this.chkCompressGZip.AutoSize = true;
            this.chkCompressGZip.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkCompressGZip.Location = new System.Drawing.Point(15, 26);
            this.chkCompressGZip.Name = "chkCompressGZip";
            this.chkCompressGZip.Size = new System.Drawing.Size(142, 17);
            this.chkCompressGZip.TabIndex = 16;
            this.chkCompressGZip.Text = "Compress with GZip";
            this.chkCompressGZip.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox5.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox5.Controls.Add(this.rdbInstallAppData);
            this.groupBox5.Controls.Add(this.rdbInstallNone);
            this.groupBox5.Controls.Add(this.rdbInstallTemp);
            this.groupBox5.FillColor = System.Drawing.Color.Transparent;
            this.groupBox5.Location = new System.Drawing.Point(15, 132);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.NoRounding = false;
            this.groupBox5.Size = new System.Drawing.Size(286, 50);
            this.groupBox5.TabIndex = 15;
            this.groupBox5.Text = "groupBox5";
            // 
            // rdbInstallAppData
            // 
            this.rdbInstallAppData.AutoSize = true;
            this.rdbInstallAppData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInstallAppData.Location = new System.Drawing.Point(153, 6);
            this.rdbInstallAppData.Name = "rdbInstallAppData";
            this.rdbInstallAppData.Size = new System.Drawing.Size(123, 17);
            this.rdbInstallAppData.TabIndex = 11;
            this.rdbInstallAppData.Text = "Install [AppData]";
            this.rdbInstallAppData.UseVisualStyleBackColor = true;
            // 
            // rdbInstallNone
            // 
            this.rdbInstallNone.AutoSize = true;
            this.rdbInstallNone.Checked = true;
            this.rdbInstallNone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInstallNone.Location = new System.Drawing.Point(100, 28);
            this.rdbInstallNone.Name = "rdbInstallNone";
            this.rdbInstallNone.Size = new System.Drawing.Size(77, 17);
            this.rdbInstallNone.TabIndex = 10;
            this.rdbInstallNone.TabStop = true;
            this.rdbInstallNone.Text = "No install";
            this.rdbInstallNone.UseVisualStyleBackColor = true;
            // 
            // rdbInstallTemp
            // 
            this.rdbInstallTemp.AutoSize = true;
            this.rdbInstallTemp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInstallTemp.Location = new System.Drawing.Point(15, 6);
            this.rdbInstallTemp.Name = "rdbInstallTemp";
            this.rdbInstallTemp.Size = new System.Drawing.Size(106, 17);
            this.rdbInstallTemp.TabIndex = 9;
            this.rdbInstallTemp.Text = "Install [Temp]";
            this.rdbInstallTemp.UseVisualStyleBackColor = true;
            // 
            // txtKeynameStartup
            // 
            this.txtKeynameStartup.AllowDrop = true;
            this.txtKeynameStartup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtKeynameStartup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtKeynameStartup.ForeColor = System.Drawing.Color.Yellow;
            this.txtKeynameStartup.Location = new System.Drawing.Point(166, 46);
            this.txtKeynameStartup.Name = "txtKeynameStartup";
            this.txtKeynameStartup.Size = new System.Drawing.Size(121, 21);
            this.txtKeynameStartup.TabIndex = 14;
            this.txtKeynameStartup.Text = "java update";
            // 
            // chkStartup
            // 
            this.chkStartup.AutoSize = true;
            this.chkStartup.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkStartup.Location = new System.Drawing.Point(15, 48);
            this.chkStartup.Name = "chkStartup";
            this.chkStartup.Size = new System.Drawing.Size(107, 17);
            this.chkStartup.TabIndex = 13;
            this.chkStartup.Text = "Add to startup";
            this.chkStartup.UseVisualStyleBackColor = true;
            // 
            // chkPreserveEoF
            // 
            this.chkPreserveEoF.AutoSize = true;
            this.chkPreserveEoF.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkPreserveEoF.Location = new System.Drawing.Point(15, 7);
            this.chkPreserveEoF.Name = "chkPreserveEoF";
            this.chkPreserveEoF.Size = new System.Drawing.Size(130, 17);
            this.chkPreserveEoF.TabIndex = 12;
            this.chkPreserveEoF.Text = "Preserve EoF data";
            this.chkPreserveEoF.UseVisualStyleBackColor = true;
            // 
            // grpJunk
            // 
            this.grpJunk.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpJunk.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpJunk.Controls.Add(this.groupBox4);
            this.grpJunk.Controls.Add(this.groupBox3);
            this.grpJunk.FillColor = System.Drawing.Color.Transparent;
            this.grpJunk.Location = new System.Drawing.Point(329, 213);
            this.grpJunk.Name = "grpJunk";
            this.grpJunk.NoRounding = false;
            this.grpJunk.Size = new System.Drawing.Size(317, 194);
            this.grpJunk.TabIndex = 11;
            this.grpJunk.Text = "groupBox4";
            // 
            // groupBox4
            // 
            this.groupBox4.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.chkVagueVarsAPI);
            this.groupBox4.Controls.Add(this.chkUseArraysAPI);
            this.groupBox4.Controls.Add(this.numAPILength);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.numHowManyAPIs);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.chkFakeAPIs);
            this.groupBox4.FillColor = System.Drawing.Color.Transparent;
            this.groupBox4.Location = new System.Drawing.Point(162, 9);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.NoRounding = false;
            this.groupBox4.Size = new System.Drawing.Size(143, 173);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.Text = "groupBox4";
            // 
            // chkVagueVarsAPI
            // 
            this.chkVagueVarsAPI.AutoSize = true;
            this.chkVagueVarsAPI.Enabled = false;
            this.chkVagueVarsAPI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkVagueVarsAPI.Location = new System.Drawing.Point(13, 137);
            this.chkVagueVarsAPI.Name = "chkVagueVarsAPI";
            this.chkVagueVarsAPI.Size = new System.Drawing.Size(92, 17);
            this.chkVagueVarsAPI.TabIndex = 29;
            this.chkVagueVarsAPI.Text = "Vague Vars";
            this.chkVagueVarsAPI.UseVisualStyleBackColor = true;
            // 
            // chkUseArraysAPI
            // 
            this.chkUseArraysAPI.AutoSize = true;
            this.chkUseArraysAPI.Enabled = false;
            this.chkUseArraysAPI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkUseArraysAPI.Location = new System.Drawing.Point(13, 114);
            this.chkUseArraysAPI.Name = "chkUseArraysAPI";
            this.chkUseArraysAPI.Size = new System.Drawing.Size(89, 17);
            this.chkUseArraysAPI.TabIndex = 26;
            this.chkUseArraysAPI.Text = "Use Arrays";
            this.chkUseArraysAPI.UseVisualStyleBackColor = true;
            // 
            // numAPILength
            // 
            this.numAPILength.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numAPILength.Enabled = false;
            this.numAPILength.ForeColor = System.Drawing.Color.Yellow;
            this.numAPILength.Location = new System.Drawing.Point(66, 87);
            this.numAPILength.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numAPILength.Name = "numAPILength";
            this.numAPILength.ReadOnly = true;
            this.numAPILength.Size = new System.Drawing.Size(70, 21);
            this.numAPILength.TabIndex = 28;
            this.numAPILength.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Enabled = false;
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label13.Location = new System.Drawing.Point(10, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(50, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "Length:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Enabled = false;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label12.Location = new System.Drawing.Point(10, 35);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 13);
            this.label12.TabIndex = 27;
            this.label12.Text = "How many API\'s:";
            // 
            // numHowManyAPIs
            // 
            this.numHowManyAPIs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numHowManyAPIs.Enabled = false;
            this.numHowManyAPIs.ForeColor = System.Drawing.Color.Yellow;
            this.numHowManyAPIs.Location = new System.Drawing.Point(13, 52);
            this.numHowManyAPIs.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numHowManyAPIs.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numHowManyAPIs.Name = "numHowManyAPIs";
            this.numHowManyAPIs.ReadOnly = true;
            this.numHowManyAPIs.Size = new System.Drawing.Size(123, 21);
            this.numHowManyAPIs.TabIndex = 26;
            this.numHowManyAPIs.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.label10.Location = new System.Drawing.Point(1, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(142, 1);
            this.label10.TabIndex = 24;
            this.label10.Text = "----";
            // 
            // chkFakeAPIs
            // 
            this.chkFakeAPIs.AutoSize = true;
            this.chkFakeAPIs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkFakeAPIs.Location = new System.Drawing.Point(29, 5);
            this.chkFakeAPIs.Name = "chkFakeAPIs";
            this.chkFakeAPIs.Size = new System.Drawing.Size(86, 17);
            this.chkFakeAPIs.TabIndex = 22;
            this.chkFakeAPIs.Text = "Fake API\'s";
            this.chkFakeAPIs.UseVisualStyleBackColor = true;
            this.chkFakeAPIs.CheckedChanged += new System.EventHandler(this.CheckedChang3d);
            // 
            // groupBox3
            // 
            this.groupBox3.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.chkVagueVarsJunk);
            this.groupBox3.Controls.Add(this.numJunkLength);
            this.groupBox3.Controls.Add(this.chkUseArrays);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.numHowManyJunk);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.chkJunkCode);
            this.groupBox3.FillColor = System.Drawing.Color.Transparent;
            this.groupBox3.Location = new System.Drawing.Point(12, 9);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.NoRounding = false;
            this.groupBox3.Size = new System.Drawing.Size(143, 173);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.Text = "groupBox3";
            // 
            // chkVagueVarsJunk
            // 
            this.chkVagueVarsJunk.AutoSize = true;
            this.chkVagueVarsJunk.Enabled = false;
            this.chkVagueVarsJunk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkVagueVarsJunk.Location = new System.Drawing.Point(12, 137);
            this.chkVagueVarsJunk.Name = "chkVagueVarsJunk";
            this.chkVagueVarsJunk.Size = new System.Drawing.Size(92, 17);
            this.chkVagueVarsJunk.TabIndex = 31;
            this.chkVagueVarsJunk.Text = "Vague Vars";
            this.chkVagueVarsJunk.UseVisualStyleBackColor = true;
            // 
            // numJunkLength
            // 
            this.numJunkLength.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numJunkLength.Enabled = false;
            this.numJunkLength.ForeColor = System.Drawing.Color.Yellow;
            this.numJunkLength.Location = new System.Drawing.Point(65, 87);
            this.numJunkLength.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numJunkLength.Name = "numJunkLength";
            this.numJunkLength.ReadOnly = true;
            this.numJunkLength.Size = new System.Drawing.Size(70, 21);
            this.numJunkLength.TabIndex = 30;
            this.numJunkLength.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // chkUseArrays
            // 
            this.chkUseArrays.AutoSize = true;
            this.chkUseArrays.Enabled = false;
            this.chkUseArrays.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkUseArrays.Location = new System.Drawing.Point(12, 114);
            this.chkUseArrays.Name = "chkUseArrays";
            this.chkUseArrays.Size = new System.Drawing.Size(89, 17);
            this.chkUseArrays.TabIndex = 25;
            this.chkUseArrays.Text = "Use Arrays";
            this.chkUseArrays.UseVisualStyleBackColor = true;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Enabled = false;
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label17.Location = new System.Drawing.Point(9, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 13);
            this.label17.TabIndex = 29;
            this.label17.Text = "Length:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label11.Location = new System.Drawing.Point(9, 35);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "How many lines:";
            // 
            // numHowManyJunk
            // 
            this.numHowManyJunk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.numHowManyJunk.Enabled = false;
            this.numHowManyJunk.ForeColor = System.Drawing.Color.Yellow;
            this.numHowManyJunk.Location = new System.Drawing.Point(12, 52);
            this.numHowManyJunk.Maximum = new decimal(new int[] {
            999999,
            0,
            0,
            0});
            this.numHowManyJunk.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numHowManyJunk.Name = "numHowManyJunk";
            this.numHowManyJunk.ReadOnly = true;
            this.numHowManyJunk.Size = new System.Drawing.Size(127, 21);
            this.numHowManyJunk.TabIndex = 19;
            this.numHowManyJunk.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(10)))), ((int)(((byte)(10)))));
            this.label5.Location = new System.Drawing.Point(0, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(142, 1);
            this.label5.TabIndex = 23;
            this.label5.Text = "----";
            // 
            // chkJunkCode
            // 
            this.chkJunkCode.AutoSize = true;
            this.chkJunkCode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.chkJunkCode.Location = new System.Drawing.Point(26, 5);
            this.chkJunkCode.Name = "chkJunkCode";
            this.chkJunkCode.Size = new System.Drawing.Size(86, 17);
            this.chkJunkCode.TabIndex = 22;
            this.chkJunkCode.Text = "Junk Code";
            this.chkJunkCode.UseVisualStyleBackColor = true;
            this.chkJunkCode.CheckedChanged += new System.EventHandler(this.CheckedChang3d);
            // 
            // grpRunPEs
            // 
            this.grpRunPEs.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpRunPEs.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpRunPEs.Controls.Add(this.rdbRunPE11);
            this.grpRunPEs.Controls.Add(this.rdbRunPE10);
            this.grpRunPEs.Controls.Add(this.rdbRunPE9);
            this.grpRunPEs.Controls.Add(this.rdbRunPE8);
            this.grpRunPEs.Controls.Add(this.rdbRunPE7);
            this.grpRunPEs.Controls.Add(this.rdbRunPE6);
            this.grpRunPEs.Controls.Add(this.rdbRunPE5);
            this.grpRunPEs.Controls.Add(this.rdbRunPE4);
            this.grpRunPEs.Controls.Add(this.rdbRunPE3);
            this.grpRunPEs.Controls.Add(this.rdbRunPE2);
            this.grpRunPEs.Controls.Add(this.rdbRunPE1);
            this.grpRunPEs.Controls.Add(this.rdbRunPE0);
            this.grpRunPEs.FillColor = System.Drawing.Color.Transparent;
            this.grpRunPEs.Location = new System.Drawing.Point(652, 213);
            this.grpRunPEs.Name = "grpRunPEs";
            this.grpRunPEs.NoRounding = false;
            this.grpRunPEs.Size = new System.Drawing.Size(317, 194);
            this.grpRunPEs.TabIndex = 9;
            this.grpRunPEs.Text = "groupBox5";
            // 
            // rdbRunPE11
            // 
            this.rdbRunPE11.AutoSize = true;
            this.rdbRunPE11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE11.Location = new System.Drawing.Point(177, 165);
            this.rdbRunPE11.Name = "rdbRunPE11";
            this.rdbRunPE11.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE11.TabIndex = 13;
            this.rdbRunPE11.TabStop = true;
            this.rdbRunPE11.Text = "RunPE 12 (3.5kb)";
            this.rdbRunPE11.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE10
            // 
            this.rdbRunPE10.AutoSize = true;
            this.rdbRunPE10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE10.Location = new System.Drawing.Point(177, 134);
            this.rdbRunPE10.Name = "rdbRunPE10";
            this.rdbRunPE10.Size = new System.Drawing.Size(121, 17);
            this.rdbRunPE10.TabIndex = 12;
            this.rdbRunPE10.TabStop = true;
            this.rdbRunPE10.Text = "RunPE 11 (13kb)";
            this.rdbRunPE10.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE9
            // 
            this.rdbRunPE9.AutoSize = true;
            this.rdbRunPE9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE9.Location = new System.Drawing.Point(177, 103);
            this.rdbRunPE9.Name = "rdbRunPE9";
            this.rdbRunPE9.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE9.TabIndex = 11;
            this.rdbRunPE9.TabStop = true;
            this.rdbRunPE9.Text = "RunPE 10 (9.5kb)";
            this.rdbRunPE9.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE8
            // 
            this.rdbRunPE8.AutoSize = true;
            this.rdbRunPE8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE8.Location = new System.Drawing.Point(177, 72);
            this.rdbRunPE8.Name = "rdbRunPE8";
            this.rdbRunPE8.Size = new System.Drawing.Size(114, 17);
            this.rdbRunPE8.TabIndex = 10;
            this.rdbRunPE8.TabStop = true;
            this.rdbRunPE8.Text = "RunPE 9 (10kb)";
            this.rdbRunPE8.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE7
            // 
            this.rdbRunPE7.AutoSize = true;
            this.rdbRunPE7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE7.Location = new System.Drawing.Point(177, 42);
            this.rdbRunPE7.Name = "rdbRunPE7";
            this.rdbRunPE7.Size = new System.Drawing.Size(114, 17);
            this.rdbRunPE7.TabIndex = 9;
            this.rdbRunPE7.TabStop = true;
            this.rdbRunPE7.Text = "RunPE 8 (13kb)";
            this.rdbRunPE7.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE6
            // 
            this.rdbRunPE6.AutoSize = true;
            this.rdbRunPE6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE6.Location = new System.Drawing.Point(177, 10);
            this.rdbRunPE6.Name = "rdbRunPE6";
            this.rdbRunPE6.Size = new System.Drawing.Size(107, 17);
            this.rdbRunPE6.TabIndex = 8;
            this.rdbRunPE6.Text = "RunPE 7 (8kb)";
            this.rdbRunPE6.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE5
            // 
            this.rdbRunPE5.AutoSize = true;
            this.rdbRunPE5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE5.Location = new System.Drawing.Point(9, 165);
            this.rdbRunPE5.Name = "rdbRunPE5";
            this.rdbRunPE5.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE5.TabIndex = 7;
            this.rdbRunPE5.TabStop = true;
            this.rdbRunPE5.Text = "RunPE 6 (8.5kb)";
            this.rdbRunPE5.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE4
            // 
            this.rdbRunPE4.AutoSize = true;
            this.rdbRunPE4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE4.Location = new System.Drawing.Point(9, 134);
            this.rdbRunPE4.Name = "rdbRunPE4";
            this.rdbRunPE4.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE4.TabIndex = 6;
            this.rdbRunPE4.Text = "RunPE 5 (3.5kb)";
            this.rdbRunPE4.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE3
            // 
            this.rdbRunPE3.AutoSize = true;
            this.rdbRunPE3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE3.Location = new System.Drawing.Point(9, 103);
            this.rdbRunPE3.Name = "rdbRunPE3";
            this.rdbRunPE3.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE3.TabIndex = 3;
            this.rdbRunPE3.TabStop = true;
            this.rdbRunPE3.Text = "RunPE 4 (3.5kb)";
            this.rdbRunPE3.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE2
            // 
            this.rdbRunPE2.AutoSize = true;
            this.rdbRunPE2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE2.Location = new System.Drawing.Point(9, 72);
            this.rdbRunPE2.Name = "rdbRunPE2";
            this.rdbRunPE2.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE2.TabIndex = 2;
            this.rdbRunPE2.Text = "RunPE 3 (12.5kb)";
            this.rdbRunPE2.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE1
            // 
            this.rdbRunPE1.AutoSize = true;
            this.rdbRunPE1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE1.Location = new System.Drawing.Point(9, 41);
            this.rdbRunPE1.Name = "rdbRunPE1";
            this.rdbRunPE1.Size = new System.Drawing.Size(107, 17);
            this.rdbRunPE1.TabIndex = 1;
            this.rdbRunPE1.Text = "RunPE 2 (3kb)";
            this.rdbRunPE1.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE0
            // 
            this.rdbRunPE0.AutoSize = true;
            this.rdbRunPE0.Checked = true;
            this.rdbRunPE0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE0.Location = new System.Drawing.Point(9, 10);
            this.rdbRunPE0.Name = "rdbRunPE0";
            this.rdbRunPE0.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE0.TabIndex = 0;
            this.rdbRunPE0.TabStop = true;
            this.rdbRunPE0.Text = "RunPE 1 (13.5kb)";
            this.rdbRunPE0.UseVisualStyleBackColor = true;
            // 
            // grpEncryptions
            // 
            this.grpEncryptions.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpEncryptions.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpEncryptions.Controls.Add(this.rdbPoly3DES);
            this.grpEncryptions.Controls.Add(this.rdbPolyDES);
            this.grpEncryptions.Controls.Add(this.rdbPolyAES);
            this.grpEncryptions.Controls.Add(this.rdbPolyDEX);
            this.grpEncryptions.Controls.Add(this.rdbPolyRC2);
            this.grpEncryptions.Controls.Add(this.rdbPolySymentric);
            this.grpEncryptions.Controls.Add(this.rdbPolyCloud);
            this.grpEncryptions.Controls.Add(this.rdbCloud);
            this.grpEncryptions.Controls.Add(this.rdbStairs);
            this.grpEncryptions.Controls.Add(this.rdbAES);
            this.grpEncryptions.Controls.Add(this.rdbPolyBaby);
            this.grpEncryptions.Controls.Add(this.rdbDex);
            this.grpEncryptions.Controls.Add(this.rdbPolyStairs);
            this.grpEncryptions.Controls.Add(this.rdbXOR);
            this.grpEncryptions.Controls.Add(this.rdbRijndael);
            this.grpEncryptions.Controls.Add(this.rdbSymentric);
            this.grpEncryptions.Controls.Add(this.rdbPolyRev);
            this.grpEncryptions.Controls.Add(this.rdbTripleDES);
            this.grpEncryptions.Controls.Add(this.rdbRC2);
            this.grpEncryptions.Controls.Add(this.rdbDES);
            this.grpEncryptions.Controls.Add(this.rdbRC4);
            this.grpEncryptions.FillColor = System.Drawing.Color.Transparent;
            this.grpEncryptions.Location = new System.Drawing.Point(329, 5);
            this.grpEncryptions.Name = "grpEncryptions";
            this.grpEncryptions.NoRounding = false;
            this.grpEncryptions.Size = new System.Drawing.Size(317, 194);
            this.grpEncryptions.TabIndex = 5;
            this.grpEncryptions.Text = "groupBox3";
            // 
            // rdbPoly3DES
            // 
            this.rdbPoly3DES.AutoSize = true;
            this.rdbPoly3DES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPoly3DES.Location = new System.Drawing.Point(15, 85);
            this.rdbPoly3DES.Name = "rdbPoly3DES";
            this.rdbPoly3DES.Size = new System.Drawing.Size(80, 17);
            this.rdbPoly3DES.TabIndex = 20;
            this.rdbPoly3DES.Text = "Poly3DES";
            this.rdbPoly3DES.UseVisualStyleBackColor = true;
            // 
            // rdbPolyDES
            // 
            this.rdbPolyDES.AutoSize = true;
            this.rdbPolyDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyDES.Location = new System.Drawing.Point(15, 35);
            this.rdbPolyDES.Name = "rdbPolyDES";
            this.rdbPolyDES.Size = new System.Drawing.Size(73, 17);
            this.rdbPolyDES.TabIndex = 19;
            this.rdbPolyDES.Text = "PolyDES";
            this.rdbPolyDES.UseVisualStyleBackColor = true;
            // 
            // rdbPolyAES
            // 
            this.rdbPolyAES.AutoSize = true;
            this.rdbPolyAES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyAES.Location = new System.Drawing.Point(15, 135);
            this.rdbPolyAES.Name = "rdbPolyAES";
            this.rdbPolyAES.Size = new System.Drawing.Size(72, 17);
            this.rdbPolyAES.TabIndex = 18;
            this.rdbPolyAES.Text = "PolyAES";
            this.rdbPolyAES.UseVisualStyleBackColor = true;
            // 
            // rdbPolyDEX
            // 
            this.rdbPolyDEX.AutoSize = true;
            this.rdbPolyDEX.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyDEX.Location = new System.Drawing.Point(200, 85);
            this.rdbPolyDEX.Name = "rdbPolyDEX";
            this.rdbPolyDEX.Size = new System.Drawing.Size(73, 17);
            this.rdbPolyDEX.TabIndex = 17;
            this.rdbPolyDEX.Text = "PolyDEX";
            this.rdbPolyDEX.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRC2
            // 
            this.rdbPolyRC2.AutoSize = true;
            this.rdbPolyRC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyRC2.Location = new System.Drawing.Point(107, 35);
            this.rdbPolyRC2.Name = "rdbPolyRC2";
            this.rdbPolyRC2.Size = new System.Drawing.Size(73, 17);
            this.rdbPolyRC2.TabIndex = 16;
            this.rdbPolyRC2.Text = "PolyRC2";
            this.rdbPolyRC2.UseVisualStyleBackColor = true;
            // 
            // rdbPolySymentric
            // 
            this.rdbPolySymentric.AutoSize = true;
            this.rdbPolySymentric.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolySymentric.Location = new System.Drawing.Point(200, 135);
            this.rdbPolySymentric.Name = "rdbPolySymentric";
            this.rdbPolySymentric.Size = new System.Drawing.Size(107, 17);
            this.rdbPolySymentric.TabIndex = 15;
            this.rdbPolySymentric.Text = "PolySymentric";
            this.rdbPolySymentric.UseVisualStyleBackColor = true;
            // 
            // rdbPolyCloud
            // 
            this.rdbPolyCloud.AutoSize = true;
            this.rdbPolyCloud.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyCloud.Location = new System.Drawing.Point(107, 85);
            this.rdbPolyCloud.Name = "rdbPolyCloud";
            this.rdbPolyCloud.Size = new System.Drawing.Size(82, 17);
            this.rdbPolyCloud.TabIndex = 14;
            this.rdbPolyCloud.Text = "PolyCloud";
            this.rdbPolyCloud.UseVisualStyleBackColor = true;
            // 
            // rdbCloud
            // 
            this.rdbCloud.AutoSize = true;
            this.rdbCloud.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbCloud.Location = new System.Drawing.Point(107, 60);
            this.rdbCloud.Name = "rdbCloud";
            this.rdbCloud.Size = new System.Drawing.Size(58, 17);
            this.rdbCloud.TabIndex = 13;
            this.rdbCloud.Text = "Cloud";
            this.rdbCloud.UseVisualStyleBackColor = true;
            // 
            // rdbStairs
            // 
            this.rdbStairs.AutoSize = true;
            this.rdbStairs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbStairs.Location = new System.Drawing.Point(200, 10);
            this.rdbStairs.Name = "rdbStairs";
            this.rdbStairs.Size = new System.Drawing.Size(58, 17);
            this.rdbStairs.TabIndex = 12;
            this.rdbStairs.Text = "Stairs";
            this.rdbStairs.UseVisualStyleBackColor = true;
            // 
            // rdbAES
            // 
            this.rdbAES.AutoSize = true;
            this.rdbAES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbAES.Location = new System.Drawing.Point(15, 110);
            this.rdbAES.Name = "rdbAES";
            this.rdbAES.Size = new System.Drawing.Size(48, 17);
            this.rdbAES.TabIndex = 11;
            this.rdbAES.Text = "AES";
            this.rdbAES.UseVisualStyleBackColor = true;
            // 
            // rdbPolyBaby
            // 
            this.rdbPolyBaby.AutoSize = true;
            this.rdbPolyBaby.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyBaby.Location = new System.Drawing.Point(107, 110);
            this.rdbPolyBaby.Name = "rdbPolyBaby";
            this.rdbPolyBaby.Size = new System.Drawing.Size(78, 17);
            this.rdbPolyBaby.TabIndex = 10;
            this.rdbPolyBaby.Text = "PolyBaby";
            this.rdbPolyBaby.UseVisualStyleBackColor = true;
            // 
            // rdbDex
            // 
            this.rdbDex.AutoSize = true;
            this.rdbDex.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDex.Location = new System.Drawing.Point(200, 60);
            this.rdbDex.Name = "rdbDex";
            this.rdbDex.Size = new System.Drawing.Size(49, 17);
            this.rdbDex.TabIndex = 9;
            this.rdbDex.Text = "DEX";
            this.rdbDex.UseVisualStyleBackColor = true;
            // 
            // rdbPolyStairs
            // 
            this.rdbPolyStairs.AutoSize = true;
            this.rdbPolyStairs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyStairs.Location = new System.Drawing.Point(200, 35);
            this.rdbPolyStairs.Name = "rdbPolyStairs";
            this.rdbPolyStairs.Size = new System.Drawing.Size(82, 17);
            this.rdbPolyStairs.TabIndex = 8;
            this.rdbPolyStairs.Text = "PolyStairs";
            this.rdbPolyStairs.UseVisualStyleBackColor = true;
            // 
            // rdbXOR
            // 
            this.rdbXOR.AutoSize = true;
            this.rdbXOR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbXOR.Location = new System.Drawing.Point(107, 160);
            this.rdbXOR.Name = "rdbXOR";
            this.rdbXOR.Size = new System.Drawing.Size(50, 17);
            this.rdbXOR.TabIndex = 6;
            this.rdbXOR.Text = "XOR";
            this.rdbXOR.UseVisualStyleBackColor = true;
            // 
            // rdbRijndael
            // 
            this.rdbRijndael.AutoSize = true;
            this.rdbRijndael.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRijndael.Location = new System.Drawing.Point(200, 160);
            this.rdbRijndael.Name = "rdbRijndael";
            this.rdbRijndael.Size = new System.Drawing.Size(71, 17);
            this.rdbRijndael.TabIndex = 4;
            this.rdbRijndael.Text = "Rijndael";
            this.rdbRijndael.UseVisualStyleBackColor = true;
            // 
            // rdbSymentric
            // 
            this.rdbSymentric.AutoSize = true;
            this.rdbSymentric.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbSymentric.Location = new System.Drawing.Point(200, 110);
            this.rdbSymentric.Name = "rdbSymentric";
            this.rdbSymentric.Size = new System.Drawing.Size(83, 17);
            this.rdbSymentric.TabIndex = 5;
            this.rdbSymentric.Text = "Symentric";
            this.rdbSymentric.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRev
            // 
            this.rdbPolyRev.AutoSize = true;
            this.rdbPolyRev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyRev.Location = new System.Drawing.Point(107, 135);
            this.rdbPolyRev.Name = "rdbPolyRev";
            this.rdbPolyRev.Size = new System.Drawing.Size(71, 17);
            this.rdbPolyRev.TabIndex = 7;
            this.rdbPolyRev.Text = "PolyRev";
            this.rdbPolyRev.UseVisualStyleBackColor = true;
            // 
            // rdbTripleDES
            // 
            this.rdbTripleDES.AutoSize = true;
            this.rdbTripleDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbTripleDES.Location = new System.Drawing.Point(15, 60);
            this.rdbTripleDES.Name = "rdbTripleDES";
            this.rdbTripleDES.Size = new System.Drawing.Size(81, 17);
            this.rdbTripleDES.TabIndex = 1;
            this.rdbTripleDES.Text = "TripleDES";
            this.rdbTripleDES.UseVisualStyleBackColor = true;
            // 
            // rdbRC2
            // 
            this.rdbRC2.AutoSize = true;
            this.rdbRC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC2.Location = new System.Drawing.Point(107, 10);
            this.rdbRC2.Name = "rdbRC2";
            this.rdbRC2.Size = new System.Drawing.Size(49, 17);
            this.rdbRC2.TabIndex = 2;
            this.rdbRC2.Text = "RC2";
            this.rdbRC2.UseVisualStyleBackColor = true;
            // 
            // rdbDES
            // 
            this.rdbDES.AutoSize = true;
            this.rdbDES.Checked = true;
            this.rdbDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDES.Location = new System.Drawing.Point(15, 10);
            this.rdbDES.Name = "rdbDES";
            this.rdbDES.Size = new System.Drawing.Size(49, 17);
            this.rdbDES.TabIndex = 0;
            this.rdbDES.TabStop = true;
            this.rdbDES.Text = "DES";
            this.rdbDES.UseVisualStyleBackColor = true;
            // 
            // rdbRC4
            // 
            this.rdbRC4.AutoSize = true;
            this.rdbRC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC4.Location = new System.Drawing.Point(15, 160);
            this.rdbRC4.Name = "rdbRC4";
            this.rdbRC4.Size = new System.Drawing.Size(49, 17);
            this.rdbRC4.TabIndex = 3;
            this.rdbRC4.Text = "RC4";
            this.rdbRC4.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.FillColor = System.Drawing.Color.Transparent;
            this.groupBox2.Location = new System.Drawing.Point(6, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.NoRounding = false;
            this.groupBox2.Size = new System.Drawing.Size(317, 138);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.Text = "groupBox2";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::The_RATs_Crew_Crypter.Properties.Resources.ratscrewlogo;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(311, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // grpMain
            // 
            this.grpMain.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpMain.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpMain.Controls.Add(this.btnSelectBindFile2);
            this.grpMain.Controls.Add(this.futureButton10);
            this.grpMain.Controls.Add(this.futureButton9);
            this.grpMain.Controls.Add(this.futureButton2);
            this.grpMain.Controls.Add(this.label4);
            this.grpMain.Controls.Add(this.txtBindFile2);
            this.grpMain.Controls.Add(this.label3);
            this.grpMain.Controls.Add(this.txtBindFile);
            this.grpMain.Controls.Add(this.label2);
            this.grpMain.Controls.Add(this.txtIcon);
            this.grpMain.Controls.Add(this.label1);
            this.grpMain.Controls.Add(this.txtFile);
            this.grpMain.FillColor = System.Drawing.Color.Transparent;
            this.grpMain.Location = new System.Drawing.Point(6, 204);
            this.grpMain.Name = "grpMain";
            this.grpMain.NoRounding = false;
            this.grpMain.Size = new System.Drawing.Size(317, 194);
            this.grpMain.TabIndex = 2;
            this.grpMain.Text = "groupBox1";
            // 
            // btnSelectBindFile2
            // 
            this.btnSelectBindFile2.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectBindFile2.Location = new System.Drawing.Point(254, 163);
            this.btnSelectBindFile2.Name = "btnSelectBindFile2";
            this.btnSelectBindFile2.Size = new System.Drawing.Size(50, 23);
            this.btnSelectBindFile2.TabIndex = 16;
            this.btnSelectBindFile2.Text = "...";
            this.btnSelectBindFile2.Click += new System.EventHandler(this.btnSelectBindFile2_Click);
            // 
            // futureButton10
            // 
            this.futureButton10.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton10.Location = new System.Drawing.Point(254, 119);
            this.futureButton10.Name = "futureButton10";
            this.futureButton10.Size = new System.Drawing.Size(50, 23);
            this.futureButton10.TabIndex = 15;
            this.futureButton10.Text = "...";
            this.futureButton10.Click += new System.EventHandler(this.btnSelectBindFile_Click);
            // 
            // futureButton9
            // 
            this.futureButton9.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton9.Location = new System.Drawing.Point(254, 71);
            this.futureButton9.Name = "futureButton9";
            this.futureButton9.Size = new System.Drawing.Size(50, 23);
            this.futureButton9.TabIndex = 14;
            this.futureButton9.Text = "...";
            this.futureButton9.Click += new System.EventHandler(this.btnSelectIcon_Click);
            // 
            // futureButton2
            // 
            this.futureButton2.Font = new System.Drawing.Font("Verdana", 8F);
            this.futureButton2.Location = new System.Drawing.Point(254, 23);
            this.futureButton2.Name = "futureButton2";
            this.futureButton2.Size = new System.Drawing.Size(50, 23);
            this.futureButton2.TabIndex = 13;
            this.futureButton2.Text = "...";
            this.futureButton2.Click += new System.EventHandler(this.btnEncryptedFileSearch_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label4.Location = new System.Drawing.Point(6, 149);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Binder 2:";
            // 
            // txtBindFile2
            // 
            this.txtBindFile2.AllowDrop = true;
            this.txtBindFile2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtBindFile2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBindFile2.ForeColor = System.Drawing.Color.Yellow;
            this.txtBindFile2.Location = new System.Drawing.Point(9, 165);
            this.txtBindFile2.Name = "txtBindFile2";
            this.txtBindFile2.Size = new System.Drawing.Size(230, 21);
            this.txtBindFile2.TabIndex = 10;
            this.txtBindFile2.DragDrop += new System.Windows.Forms.DragEventHandler(this.FileBinderDr0p);
            this.txtBindFile2.DragEnter += new System.Windows.Forms.DragEventHandler(this.FileBinderEnt3r);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label3.Location = new System.Drawing.Point(6, 105);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Binder:";
            // 
            // txtBindFile
            // 
            this.txtBindFile.AllowDrop = true;
            this.txtBindFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtBindFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBindFile.ForeColor = System.Drawing.Color.Yellow;
            this.txtBindFile.Location = new System.Drawing.Point(9, 121);
            this.txtBindFile.Name = "txtBindFile";
            this.txtBindFile.Size = new System.Drawing.Size(230, 21);
            this.txtBindFile.TabIndex = 7;
            this.txtBindFile.DragDrop += new System.Windows.Forms.DragEventHandler(this.FileBinderDr0p);
            this.txtBindFile.DragEnter += new System.Windows.Forms.DragEventHandler(this.FileBinderEnt3r);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label2.Location = new System.Drawing.Point(6, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Icon:";
            // 
            // txtIcon
            // 
            this.txtIcon.AllowDrop = true;
            this.txtIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIcon.ForeColor = System.Drawing.Color.Yellow;
            this.txtIcon.Location = new System.Drawing.Point(9, 73);
            this.txtIcon.Name = "txtIcon";
            this.txtIcon.Size = new System.Drawing.Size(230, 21);
            this.txtIcon.TabIndex = 4;
            this.txtIcon.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtIcon_DragDrop);
            this.txtIcon.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtIcon_DragEnter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label1.Location = new System.Drawing.Point(6, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "File to be encrypted:";
            // 
            // txtFile
            // 
            this.txtFile.AllowDrop = true;
            this.txtFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFile.ForeColor = System.Drawing.Color.Yellow;
            this.txtFile.Location = new System.Drawing.Point(9, 25);
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(230, 21);
            this.txtFile.TabIndex = 1;
            this.txtFile.DragDrop += new System.Windows.Forms.DragEventHandler(this.FileBinderDr0p);
            this.txtFile.DragEnter += new System.Windows.Forms.DragEventHandler(this.FileBinderEnt3r);
            // 
            // frmTRC_Crypter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ClientSize = new System.Drawing.Size(1316, 545);
            this.Controls.Add(this.futureButton12);
            this.Controls.Add(this.btnMain);
            this.Controls.Add(this.futureButton6);
            this.Controls.Add(this.futureButton7);
            this.Controls.Add(this.futureButton8);
            this.Controls.Add(this.futureButton5);
            this.Controls.Add(this.futureButton4);
            this.Controls.Add(this.futureButton3);
            this.Controls.Add(this.futureButton1);
            this.Controls.Add(this.grpAssemblyChanger);
            this.Controls.Add(this.grpOptions);
            this.Controls.Add(this.grpJunk);
            this.Controls.Add(this.grpRunPEs);
            this.Controls.Add(this.grpEncryptions);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grpMain);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmTRC_Crypter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TRC Crypter ~ Version 1.8";
            this.grpAssemblyChanger.ResumeLayout(false);
            this.grpAssemblyChanger.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASM1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numASMF1)).EndInit();
            this.grpOptions.ResumeLayout(false);
            this.grpOptions.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.grpJunk.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numAPILength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHowManyAPIs)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numJunkLength)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numHowManyJunk)).EndInit();
            this.grpRunPEs.ResumeLayout(false);
            this.grpRunPEs.PerformLayout();
            this.grpEncryptions.ResumeLayout(false);
            this.grpEncryptions.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.grpMain.ResumeLayout(false);
            this.grpMain.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFile;
        private GroupBox grpMain;
        private GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIcon;
        private GroupBox grpEncryptions;
        private System.Windows.Forms.RadioButton rdbTripleDES;
        private System.Windows.Forms.RadioButton rdbDES;
        private System.Windows.Forms.RadioButton rdbXOR;
        private System.Windows.Forms.RadioButton rdbSymentric;
        private System.Windows.Forms.RadioButton rdbRijndael;
        private System.Windows.Forms.RadioButton rdbRC4;
        private System.Windows.Forms.RadioButton rdbRC2;
        private System.Windows.Forms.RadioButton rdbDefaultBrowser;
        private System.Windows.Forms.RadioButton rdbInjectInto;
        private System.Windows.Forms.TextBox txtInjectInto;
        private GroupBox grpRunPEs;
        private System.Windows.Forms.RadioButton rdbRunPE3;
        private System.Windows.Forms.RadioButton rdbRunPE2;
        private System.Windows.Forms.RadioButton rdbRunPE1;
        private System.Windows.Forms.RadioButton rdbRunPE0;
        private System.Windows.Forms.RadioButton rdbRunPE9;
        private System.Windows.Forms.RadioButton rdbRunPE8;
        private System.Windows.Forms.RadioButton rdbRunPE7;
        private System.Windows.Forms.RadioButton rdbRunPE6;
        private System.Windows.Forms.RadioButton rdbRunPE5;
        private System.Windows.Forms.RadioButton rdbRunPE4;
        private System.Windows.Forms.RadioButton rdbRunPE11;
        private System.Windows.Forms.RadioButton rdbRunPE10;
        private System.Windows.Forms.RadioButton rdbCloud;
        private System.Windows.Forms.RadioButton rdbStairs;
        private System.Windows.Forms.RadioButton rdbAES;
        private System.Windows.Forms.RadioButton rdbPolyBaby;
        private System.Windows.Forms.RadioButton rdbDex;
        private System.Windows.Forms.RadioButton rdbPolyStairs;
        private System.Windows.Forms.RadioButton rdbPolyRev;
        private System.Windows.Forms.RadioButton rdbPolyCloud;
        private System.Windows.Forms.RadioButton rdbVBC;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBindFile;
        private GroupBox grpJunk;
        private System.Windows.Forms.CheckBox chkPreserveEoF;
        private System.Windows.Forms.RadioButton rdbCSC;
        private GroupBox grpOptions;
        private System.Windows.Forms.TextBox txtKeynameStartup;
        private System.Windows.Forms.CheckBox chkStartup;
        private GroupBox grpAssemblyChanger;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox chkEnableAssemblyChanger;
        private System.Windows.Forms.TextBox txtASMCopyright;
        private System.Windows.Forms.TextBox txtASMDescription;
        private System.Windows.Forms.TextBox txtASMTitle;
        private System.Windows.Forms.NumericUpDown numASM4;
        private System.Windows.Forms.NumericUpDown numASM3;
        private System.Windows.Forms.NumericUpDown numASM2;
        private System.Windows.Forms.NumericUpDown numASM1;
        private GroupBox groupBox4;
        private System.Windows.Forms.CheckBox chkFakeAPIs;
        private GroupBox groupBox3;
        private System.Windows.Forms.CheckBox chkJunkCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkUseArrays;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.NumericUpDown numHowManyJunk;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numHowManyAPIs;
        private System.Windows.Forms.NumericUpDown numAPILength;
        private System.Windows.Forms.Label label13;
        private GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdbInstallAppData;
        private System.Windows.Forms.RadioButton rdbInstallNone;
        private System.Windows.Forms.RadioButton rdbInstallTemp;
        private FutureButton futureButton1;
        private FutureButton futureButton3;
        private FutureButton futureButton4;
        private FutureButton futureButton5;
        private FutureButton btnMain;
        private FutureButton futureButton6;
        private FutureButton futureButton7;
        private FutureButton futureButton8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBindFile2;
        private FutureButton btnSelectBindFile2;
        private FutureButton futureButton10;
        private FutureButton futureButton9;
        private FutureButton futureButton2;
        private FutureButton futureButton12;
        private System.Windows.Forms.CheckBox chkCompressGZip;
        private System.Windows.Forms.RadioButton rdbPoly3DES;
        private System.Windows.Forms.RadioButton rdbPolyDES;
        private System.Windows.Forms.RadioButton rdbPolyAES;
        private System.Windows.Forms.RadioButton rdbPolyDEX;
        private System.Windows.Forms.RadioButton rdbPolyRC2;
        private System.Windows.Forms.RadioButton rdbPolySymentric;
        private System.Windows.Forms.NumericUpDown numASMF4;
        private System.Windows.Forms.NumericUpDown numASMF3;
        private System.Windows.Forms.TextBox txtASMProduct;
        private System.Windows.Forms.TextBox txtASMCompany;
        private System.Windows.Forms.NumericUpDown numASMF2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown numASMF1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox chkUseArraysAPI;
        private System.Windows.Forms.CheckBox chkVagueVarsAPI;
        private System.Windows.Forms.CheckBox chkVagueVarsJunk;
        private System.Windows.Forms.NumericUpDown numJunkLength;
        private System.Windows.Forms.Label label17;
        private GroupBox groupBox1;
    }
}

