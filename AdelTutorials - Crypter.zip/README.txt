Crypter
=====
1)Change line 58 encrypted payload file drop location
2)Recompile
3)Chose EXE File(First field), Generate and copy Encryption Key to clipboard, press ">>>"

Server1
=====
1)Paste Encryption key to line 8
2)open encrypted payload file with notepad++, select all and CTRL+C (copy)
3)Go to RESOURCES in VB Solution Explorer, open TXT file. Select all, delete, CTRL+V (paste)
4)Run(yes it will run the server file on you) and get encrypted file from "Debug" Folder

Use "Tools.zip" to change RunPE and HEX2BYTE code for Server1

