﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CopyAllToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown4 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown7 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown6 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown5 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown10 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown9 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown8 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown13 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown12 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown11 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown15 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown14 = New System.Windows.Forms.NumericUpDown()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.NumericUpDown16 = New System.Windows.Forms.NumericUpDown()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.ContextMenuStrip1.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.Red
        Me.Button1.Location = New System.Drawing.Point(2, 272)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(102, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Gerar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Black
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.ForeColor = System.Drawing.Color.Red
        Me.TextBox2.Location = New System.Drawing.Point(2, 296)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(573, 64)
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = "STRINGS AQUI!"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Black
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.ContextMenuStrip = Me.ContextMenuStrip1
        Me.TextBox3.ForeColor = System.Drawing.Color.Red
        Me.TextBox3.Location = New System.Drawing.Point(2, 4)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(573, 266)
        Me.TextBox3.TabIndex = 2
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.BackColor = System.Drawing.Color.White
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyAllToolStripMenuItem, Me.ClearToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(141, 48)
        '
        'CopyAllToolStripMenuItem
        '
        Me.CopyAllToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.CopyAllToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.CopyAllToolStripMenuItem.Image = Global.GeradorSooftT.My.Resources.Resources.copy_xxl
        Me.CopyAllToolStripMenuItem.Name = "CopyAllToolStripMenuItem"
        Me.CopyAllToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.CopyAllToolStripMenuItem.Text = "Copiar Tudo"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.BackColor = System.Drawing.Color.Black
        Me.ClearToolStripMenuItem.ForeColor = System.Drawing.Color.Red
        Me.ClearToolStripMenuItem.Image = Global.GeradorSooftT.My.Resources.Resources.cross_512
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.ClearToolStripMenuItem.Text = "Limpar"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown1.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown1.Location = New System.Drawing.Point(498, 273)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {-1981284353, -1966660860, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(77, 20)
        Me.NumericUpDown1.TabIndex = 3
        Me.NumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown1.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.Color.Black
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ComboBox1.ForeColor = System.Drawing.Color.Red
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"CLIENTE RC4", "CLIENTE XOR", "SUB-MAIN", "RC4", "XOR", "RUMPE", "ENTRY POINT", "JUNK CODE 01", "JUNK CODE 02", "JUNK CODE 03"})
        Me.ComboBox1.Location = New System.Drawing.Point(375, 273)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 4
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Black
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.ForeColor = System.Drawing.Color.Red
        Me.TextBox1.Location = New System.Drawing.Point(581, 4)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(377, 20)
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.Text = "说语动谢涯十伏谢词十那说是方感动道不涯天伏英说动十的语个个方说的常想非年要那方要信谢-天伟动是那个感"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.Color.Black
        Me.TextBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox4.ForeColor = System.Drawing.Color.Red
        Me.TextBox4.Location = New System.Drawing.Point(581, 30)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(377, 20)
        Me.TextBox4.TabIndex = 6
        Me.TextBox4.Text = "CIGJZUPQGIURIHSHBDZNSDÇUIWWIEÇTRRAXAWVQPWZWZCKDEXWSTQQITVSTDYQBREEFHAOJWFWJBBNÇCÇ" & _
    "NJMWFRRENCPOPTWCVDZ"
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.Black
        Me.TextBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox5.ForeColor = System.Drawing.Color.Red
        Me.TextBox5.Location = New System.Drawing.Point(581, 56)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(377, 20)
        Me.TextBox5.TabIndex = 7
        Me.TextBox5.Text = "zwixhifyzhjskywyqpbhakaceujudwuhthguuekklwjrfjdjzpiktesifzafzdvqiuxyfxiuylemufyvf" & _
    "qjiwesetgnjptqwtxts"
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.Black
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox6.ForeColor = System.Drawing.Color.Red
        Me.TextBox6.Location = New System.Drawing.Point(581, 82)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(377, 20)
        Me.TextBox6.TabIndex = 8
        Me.TextBox6.Text = "رشقשאكرXرJكقKצپQצQחقنفוTك-TקقهلבKمغוهYرקنپHكپاXשرUملצחدUمKשك"
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.Black
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox7.ForeColor = System.Drawing.Color.Red
        Me.TextBox7.Location = New System.Drawing.Point(581, 108)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(377, 20)
        Me.TextBox7.TabIndex = 9
        Me.TextBox7.Text = "אלתאלאואאשלבהמרתהאאציללאיםלברמלבואוישלאתאםאנםאסילריבימיםמאלת"
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.Color.Black
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox8.ForeColor = System.Drawing.Color.Red
        Me.TextBox8.Location = New System.Drawing.Point(581, 134)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(377, 20)
        Me.TextBox8.TabIndex = 10
        Me.TextBox8.Text = "~,;?__<`.>$;`@;*$,?^_*;;_*.*[*;-_$_?;*_@$=??~$,>*_%_;.(_.^!~?_.;[&*._-!;*^`;_[?@"
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.Black
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox9.ForeColor = System.Drawing.Color.Red
        Me.TextBox9.Location = New System.Drawing.Point(581, 160)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(377, 20)
        Me.TextBox9.TabIndex = 11
        Me.TextBox9.Text = "خدعاى-کحح-زضقذوغحخغمکحفبسخىخوربتحلضابلخهلافاخفففکاتربككذضااپكفكحطبل-کخوسبرصصذرروع" & _
    "انحزککپسخحدنفلملفسظ"
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.Color.Black
        Me.TextBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox10.ForeColor = System.Drawing.Color.Red
        Me.TextBox10.Location = New System.Drawing.Point(581, 186)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(377, 20)
        Me.TextBox10.TabIndex = 12
        Me.TextBox10.Text = "П-ЦФгИгЯлЖФчъДБЮл-ПЯИФБГЦЬйгДчЩбюГЮщЙкЮБЙЙЮЧкчБЮДХЬЧчЖЬЬлЯчдГбЬФлгЮЮнгЧгШбюѣгЦЮФЮ" & _
    "ъЮъФѣПюДЩПиФЦяЙЮьдХ"
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.Black
        Me.TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox11.ForeColor = System.Drawing.Color.Red
        Me.TextBox11.Location = New System.Drawing.Point(581, 212)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(377, 20)
        Me.TextBox11.TabIndex = 13
        Me.TextBox11.Text = "414453445296422660465401194586968942218543914650943184185469864390293809859562268" & _
    "4443459961644195841"
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.Color.Black
        Me.TextBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox12.ForeColor = System.Drawing.Color.Red
        Me.TextBox12.Location = New System.Drawing.Point(581, 238)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(377, 20)
        Me.TextBox12.TabIndex = 14
        Me.TextBox12.Text = "cו-Б食Ь劳йM英ЪPרёרtتיЮ间ונБPйدירPא食间英רנБ英Юz个间Бйמйוدйמ间PיDP英י什英-PЖ间MוQקЛЮйЬPمп间zר英йQi什" & _
    "ёйנMיйDהЪБQБLק什Miבא"
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.Color.Black
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox13.ForeColor = System.Drawing.Color.Red
        Me.TextBox13.Location = New System.Drawing.Point(581, 264)
        Me.TextBox13.MinimumSize = New System.Drawing.Size(377, 20)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(377, 20)
        Me.TextBox13.TabIndex = 15
        Me.TextBox13.Text = "ª└ª♞0┘0¶ò❥┘§♓♓ò╠♞╦¶❥└❥♞❥♞└╦¶┘╠☺♞♞❥§ò☺♞♞☺§╦¶§╦ó❥└♞♓"
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.Black
        Me.TextBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox14.ForeColor = System.Drawing.Color.Red
        Me.TextBox14.Location = New System.Drawing.Point(581, 290)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(377, 20)
        Me.TextBox14.TabIndex = 16
        Me.TextBox14.Text = "♖£♞ã¤ú◙☥♪♪♪ó¤§úª♓☥ú¤ç¾└☥¤☺ú♓╦❥♗«♞úòº╔£¿╦å¿£☺é┘♋ò¤ãç╬≒┐┘ú≒«ãó"
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.Color.Black
        Me.TextBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox15.ForeColor = System.Drawing.Color.Red
        Me.TextBox15.Location = New System.Drawing.Point(581, 316)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(377, 20)
        Me.TextBox15.TabIndex = 17
        Me.TextBox15.Text = "ऑभटऑखचफटतकअभटचटनयइऔदघनएबञऑऔएलइआठछषआदञघडञआफलचगगधऔतयबधअइदनअदअछनलभदवअकबपदनफअआधघगषखऔछ" & _
    "णइबआअफफडनञछडऋछघअएआन"
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.Color.Black
        Me.TextBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox16.ForeColor = System.Drawing.Color.Red
        Me.TextBox16.Location = New System.Drawing.Point(581, 340)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(377, 20)
        Me.TextBox16.TabIndex = 18
        Me.TextBox16.Text = "иояренерснчеоянесрортчечесиетчоряоееноияитяичоеячтееичстеяеснениедечтрерчеедеирчя" & _
    "ииодересетснчяедояр"
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Black
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.Red
        Me.Button2.Location = New System.Drawing.Point(1030, 2)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 19
        Me.Button2.Text = "Gerar"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown2.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown2.Location = New System.Drawing.Point(962, 4)
        Me.NumericUpDown2.Maximum = New Decimal(New Integer() {1569325055, 23283064, 0, 0})
        Me.NumericUpDown2.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown2.TabIndex = 20
        Me.NumericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown2.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown3.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown3.Location = New System.Drawing.Point(962, 30)
        Me.NumericUpDown3.Maximum = New Decimal(New Integer() {1569325055, 23283064, 0, 0})
        Me.NumericUpDown3.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown3.TabIndex = 21
        Me.NumericUpDown3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown3.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown4
        '
        Me.NumericUpDown4.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown4.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown4.Location = New System.Drawing.Point(962, 56)
        Me.NumericUpDown4.Maximum = New Decimal(New Integer() {1661992959, 1808227885, 5, 0})
        Me.NumericUpDown4.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown4.Name = "NumericUpDown4"
        Me.NumericUpDown4.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown4.TabIndex = 22
        Me.NumericUpDown4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown4.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown7
        '
        Me.NumericUpDown7.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown7.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown7.Location = New System.Drawing.Point(962, 82)
        Me.NumericUpDown7.Maximum = New Decimal(New Integer() {-1981284353, -1966660860, 0, 0})
        Me.NumericUpDown7.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown7.Name = "NumericUpDown7"
        Me.NumericUpDown7.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown7.TabIndex = 23
        Me.NumericUpDown7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown7.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown6
        '
        Me.NumericUpDown6.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown6.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown6.Location = New System.Drawing.Point(962, 108)
        Me.NumericUpDown6.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NumericUpDown6.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown6.Name = "NumericUpDown6"
        Me.NumericUpDown6.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown6.TabIndex = 24
        Me.NumericUpDown6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown6.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown5
        '
        Me.NumericUpDown5.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown5.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown5.Location = New System.Drawing.Point(962, 134)
        Me.NumericUpDown5.Maximum = New Decimal(New Integer() {-559939585, 902409669, 54, 0})
        Me.NumericUpDown5.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown5.Name = "NumericUpDown5"
        Me.NumericUpDown5.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown5.TabIndex = 25
        Me.NumericUpDown5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown5.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown10
        '
        Me.NumericUpDown10.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown10.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown10.Location = New System.Drawing.Point(962, 159)
        Me.NumericUpDown10.Maximum = New Decimal(New Integer() {-559939585, 902409669, 54, 0})
        Me.NumericUpDown10.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown10.Name = "NumericUpDown10"
        Me.NumericUpDown10.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown10.TabIndex = 26
        Me.NumericUpDown10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown10.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown9
        '
        Me.NumericUpDown9.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown9.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown9.Location = New System.Drawing.Point(962, 185)
        Me.NumericUpDown9.Maximum = New Decimal(New Integer() {-1304428545, 434162106, 542, 0})
        Me.NumericUpDown9.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown9.Name = "NumericUpDown9"
        Me.NumericUpDown9.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown9.TabIndex = 27
        Me.NumericUpDown9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown9.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown8
        '
        Me.NumericUpDown8.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown8.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown8.Location = New System.Drawing.Point(962, 211)
        Me.NumericUpDown8.Maximum = New Decimal(New Integer() {-1981284353, -1966660860, 0, 0})
        Me.NumericUpDown8.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown8.Name = "NumericUpDown8"
        Me.NumericUpDown8.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown8.TabIndex = 28
        Me.NumericUpDown8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown8.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown13
        '
        Me.NumericUpDown13.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown13.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown13.Location = New System.Drawing.Point(962, 238)
        Me.NumericUpDown13.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NumericUpDown13.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown13.Name = "NumericUpDown13"
        Me.NumericUpDown13.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown13.TabIndex = 29
        Me.NumericUpDown13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown13.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown12
        '
        Me.NumericUpDown12.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown12.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown12.Location = New System.Drawing.Point(962, 264)
        Me.NumericUpDown12.Maximum = New Decimal(New Integer() {1569325055, 23283064, 0, 0})
        Me.NumericUpDown12.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown12.Name = "NumericUpDown12"
        Me.NumericUpDown12.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown12.TabIndex = 30
        Me.NumericUpDown12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown12.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown11
        '
        Me.NumericUpDown11.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown11.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown11.Location = New System.Drawing.Point(962, 290)
        Me.NumericUpDown11.Maximum = New Decimal(New Integer() {-1486618625, 232830643, 0, 0})
        Me.NumericUpDown11.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown11.Name = "NumericUpDown11"
        Me.NumericUpDown11.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown11.TabIndex = 31
        Me.NumericUpDown11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown11.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown15
        '
        Me.NumericUpDown15.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown15.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown15.Location = New System.Drawing.Point(962, 315)
        Me.NumericUpDown15.Maximum = New Decimal(New Integer() {-1981284353, -1966660860, 0, 0})
        Me.NumericUpDown15.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown15.Name = "NumericUpDown15"
        Me.NumericUpDown15.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown15.TabIndex = 32
        Me.NumericUpDown15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown15.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'NumericUpDown14
        '
        Me.NumericUpDown14.BackColor = System.Drawing.Color.Black
        Me.NumericUpDown14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.NumericUpDown14.ForeColor = System.Drawing.Color.Red
        Me.NumericUpDown14.Location = New System.Drawing.Point(962, 340)
        Me.NumericUpDown14.Maximum = New Decimal(New Integer() {-559939585, 902409669, 54, 0})
        Me.NumericUpDown14.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown14.Name = "NumericUpDown14"
        Me.NumericUpDown14.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown14.TabIndex = 33
        Me.NumericUpDown14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown14.Value = New Decimal(New Integer() {30, 0, 0, 0})
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Black
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.Red
        Me.Button3.Location = New System.Drawing.Point(1030, 28)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 34
        Me.Button3.Text = "Gerar"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Black
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.Red
        Me.Button5.Location = New System.Drawing.Point(1030, 54)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 35
        Me.Button5.Text = "Gerar"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Black
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.Color.Red
        Me.Button4.Location = New System.Drawing.Point(1030, 80)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 36
        Me.Button4.Text = "Gerar"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.Black
        Me.Button7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.ForeColor = System.Drawing.Color.Red
        Me.Button7.Location = New System.Drawing.Point(1030, 106)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 37
        Me.Button7.Text = "Gerar"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Black
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.ForeColor = System.Drawing.Color.Red
        Me.Button6.Location = New System.Drawing.Point(1030, 132)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 23)
        Me.Button6.TabIndex = 38
        Me.Button6.Text = "Gerar"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.Black
        Me.Button9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.ForeColor = System.Drawing.Color.Red
        Me.Button9.Location = New System.Drawing.Point(1030, 157)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 23)
        Me.Button9.TabIndex = 39
        Me.Button9.Text = "Gerar"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.Black
        Me.Button8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.ForeColor = System.Drawing.Color.Red
        Me.Button8.Location = New System.Drawing.Point(1030, 183)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 23)
        Me.Button8.TabIndex = 40
        Me.Button8.Text = "Gerar"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.Color.Black
        Me.Button11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.ForeColor = System.Drawing.Color.Red
        Me.Button11.Location = New System.Drawing.Point(1030, 209)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(75, 23)
        Me.Button11.TabIndex = 41
        Me.Button11.Text = "Gerar"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.Black
        Me.Button10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.ForeColor = System.Drawing.Color.Red
        Me.Button10.Location = New System.Drawing.Point(1030, 237)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(75, 23)
        Me.Button10.TabIndex = 42
        Me.Button10.Text = "Gerar"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.Black
        Me.Button13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.ForeColor = System.Drawing.Color.Red
        Me.Button13.Location = New System.Drawing.Point(1030, 262)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(75, 23)
        Me.Button13.TabIndex = 43
        Me.Button13.Text = "Gerar"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.Color.Black
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button12.ForeColor = System.Drawing.Color.Red
        Me.Button12.Location = New System.Drawing.Point(1030, 288)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(75, 23)
        Me.Button12.TabIndex = 44
        Me.Button12.Text = "Gerar"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.Black
        Me.Button15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button15.ForeColor = System.Drawing.Color.Red
        Me.Button15.Location = New System.Drawing.Point(1030, 313)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(75, 23)
        Me.Button15.TabIndex = 45
        Me.Button15.Text = "Gerar"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Black
        Me.Button14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button14.ForeColor = System.Drawing.Color.Red
        Me.Button14.Location = New System.Drawing.Point(1030, 338)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(75, 23)
        Me.Button14.TabIndex = 46
        Me.Button14.Text = "Gerar"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button16.ForeColor = System.Drawing.Color.Red
        Me.Button16.Location = New System.Drawing.Point(271, 272)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(102, 23)
        Me.Button16.TabIndex = 47
        Me.Button16.Text = "M. Strings"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'NumericUpDown16
        '
        Me.NumericUpDown16.Location = New System.Drawing.Point(1228, 272)
        Me.NumericUpDown16.Maximum = New Decimal(New Integer() {1661992959, 1808227885, 5, 0})
        Me.NumericUpDown16.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown16.Name = "NumericUpDown16"
        Me.NumericUpDown16.Size = New System.Drawing.Size(66, 20)
        Me.NumericUpDown16.TabIndex = 50
        Me.NumericUpDown16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.NumericUpDown16.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1
        '
        'Timer2
        '
        Me.Timer2.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Black
        Me.ClientSize = New System.Drawing.Size(578, 362)
        Me.Controls.Add(Me.NumericUpDown16)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.NumericUpDown14)
        Me.Controls.Add(Me.NumericUpDown15)
        Me.Controls.Add(Me.NumericUpDown11)
        Me.Controls.Add(Me.NumericUpDown12)
        Me.Controls.Add(Me.NumericUpDown13)
        Me.Controls.Add(Me.NumericUpDown8)
        Me.Controls.Add(Me.NumericUpDown9)
        Me.Controls.Add(Me.NumericUpDown10)
        Me.Controls.Add(Me.NumericUpDown5)
        Me.Controls.Add(Me.NumericUpDown6)
        Me.Controls.Add(Me.NumericUpDown7)
        Me.Controls.Add(Me.NumericUpDown4)
        Me.Controls.Add(Me.NumericUpDown3)
        Me.Controls.Add(Me.NumericUpDown2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.TextBox16)
        Me.Controls.Add(Me.TextBox15)
        Me.Controls.Add(Me.TextBox14)
        Me.Controls.Add(Me.TextBox13)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.NumericUpDown1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Button1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Criador de Crypter V2.0 VB.NET  "
        Me.ContextMenuStrip1.ResumeLayout(False)
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents NumericUpDown3 As NumericUpDown
    Friend WithEvents NumericUpDown4 As NumericUpDown
    Friend WithEvents NumericUpDown7 As NumericUpDown
    Friend WithEvents NumericUpDown6 As NumericUpDown
    Friend WithEvents NumericUpDown5 As NumericUpDown
    Friend WithEvents NumericUpDown10 As NumericUpDown
    Friend WithEvents NumericUpDown9 As NumericUpDown
    Friend WithEvents NumericUpDown8 As NumericUpDown
    Friend WithEvents NumericUpDown13 As NumericUpDown
    Friend WithEvents NumericUpDown12 As NumericUpDown
    Friend WithEvents NumericUpDown11 As NumericUpDown
    Friend WithEvents NumericUpDown15 As NumericUpDown
    Friend WithEvents NumericUpDown14 As NumericUpDown
    Friend WithEvents Button3 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button15 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button16 As Button
    Friend WithEvents NumericUpDown16 As NumericUpDown
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CopyAllToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
