﻿Public Class Form1
    Dim ChrREP


    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim SAVETHEVBS As New SaveFileDialog
        SAVETHEVBS.Filter = ("VBS FILE |*.vbs")
        Dim saveloction = ""
        If SAVETHEVBS.ShowDialog = Windows.Forms.DialogResult.OK Then
            saveloction = SAVETHEVBS.FileName

        Else
            MsgBox("There was a problem in choosing file location", MsgBoxStyle.Critical, "Error")
            Exit Sub
        End If
        Dim CRYPTEDFILE = CRYPTtext2(IO.File.ReadAllText(TextBox1.Text))
        Dim revesed As String = StrReverse(CRYPTEDFILE)
        ChrREP = RandomString()
        Dim script = My.Resources.String1
        script = script.Replace("Scripting.FileSystemObject", CRYPTtext("Scripting.FileSystemObject"))
        script = script.Replace("%'%", CRYPTtext("'"))
        script = script.Replace("%Chr%", CRYPTtext(ComboBox1.Text))
        script = script.Replace("%(%", CRYPTtext(ComboBox2.Text))
        script = script.Replace("%(%", CRYPTtext(ComboBox2.Text))
        script = script.Replace("%)%", CRYPTtext(ComboBox3.Text))
        script = script.Replace("%cChr%", CRYPTtext("Chr"))
        script = script.Replace("%c(%", CRYPTtext("("))
        script = script.Replace("%c)%", CRYPTtext(")"))
        script = script.Replace("ScriptControl", CRYPTtext("ScriptControl"))
        script = script.Replace("VBScript", CRYPTtext("VBScript"))
        script = script.Replace("%WSCript%", CRYPTtext("WSCript"))
        script = script.Replace("execute(", CRYPTtext("execute("))
        script = script.Replace("WSCRIPT.SHELL", CRYPTtext("WSCRIPT.SHELL"))
        script = script.Replace("WINMGMTS:\\.\ROOT\CIMV2", CRYPTtext("WINMGMTS:\\.\ROOT\CIMV2"))
        script = script.Replace("SELECT * FROM WIN32_COMPUTERSYSTEM", CRYPTtext("SELECT * FROM WIN32_COMPUTERSYSTEM"))
        script = script.Replace("X64-BASED PC", CRYPTtext("X64-BASED PC"))
        script = script.Replace("%SYSWOW64%", CRYPTtext("SYSWOW64"))
        script = script.Replace("%WINDIR%", CRYPTtext("%WINDIR%"))
        script = script.Replace("\SYSWOW64\WSCRIPT.EXE ", CRYPTtext("\SYSWOW64\WSCRIPT.EXE "))
        script = script.Replace("ScriptControl", CRYPTtext("ScriptControl"))

        script = script.Replace("%Cryptedfile%", revesed)

        script = script.Replace("%CHR%", ChrREP)

        Dim i = 1
        Do Until i = 14
            script = script.Replace("%" & i & "%", RandomString)
            i = i + 1
        Loop

        If CheckBox1.Checked = True Then
            If ComboBox4.SelectedIndex = 0 Then
                script = script.Replace("%Sleep%", "WScript.Sleep(" & NumericUpDown1.Value * 1000 & ")")
            Else
                script = script.Replace("%Sleep%", "WScript.Sleep(" & NumericUpDown1.Value * 60000 & ")")
            End If
        Else
            script = script.Replace("%Sleep%", "")
        End If

        IO.File.WriteAllText(saveloction, script)
        MsgBox("Done" & vbNewLine & saveloction & vbNewLine & "Coded By Mr.Abood", MsgBoxStyle.Information, "Mr.Abood")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 1
        ComboBox2.SelectedIndex = 2
        ComboBox3.SelectedIndex = 3
        ComboBox4.SelectedIndex = 0
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim opndialog As New OpenFileDialog
        opndialog.Filter = ("VBS file |*.vbs")
        If opndialog.ShowDialog = Windows.Forms.DialogResult.OK Then
            TextBox1.Text = opndialog.FileName
        Else
            MsgBox("There was error in choosing vbs file")
        End If
    End Sub
    Function CRYPTtext(ByRef text As String)
        Dim ddd
        Dim ssss = ""
        For Each ddd In text
            Dim i As Integer = Asc(ddd)
            If ssss = "" Then
                ssss = (ChrREP & "(" & i & ")")
            Else
                ssss = ssss & (" & " & ChrREP & "(" & i & ")")
            End If
        Next
        Return ssss
    End Function
    Function CRYPTtext2(ByRef text As String)
        Dim ddd
        Dim ssss = ""
        For Each ddd In text
            Dim i As Integer = Asc(ddd)
            If ssss = "" Then
                ssss = (ComboBox1.Text & ComboBox2.Text & i & ComboBox3.Text)
            Else
                ssss = ssss & (" & " & ComboBox1.Text & ComboBox2.Text & i & ComboBox3.Text)
            End If
        Next
        Return ssss
    End Function
    Dim prng As New Random
    Const minCH As Integer = 25
    Const maxCH As Integer = 50
    Const randCH As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    Private Function RandomString() As String
        Dim sb As New System.Text.StringBuilder
        For i As Integer = 1 To prng.Next(minCH, maxCH + 1)
            sb.Append(randCH.Substring(prng.Next(0, randCH.Length), 1))
        Next
        Return sb.ToString()
    End Function
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.TextChanged, ComboBox3.TextChanged, ComboBox2.TextChanged
        If ComboBox1.Text.Length >= 2 Then
            MsgBox("I think one symbol is enough, Don't you?")
            ComboBox1.Text = ComboBox1.Text.Substring(1)
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            GroupBox1.Enabled = True
        Else
            GroupBox1.Enabled = False
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Form2.Show()
        Process.Start("https://www.facebook.com/abood.AZZ")
    End Sub
    Dim nn = 1
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        '============================================================================
        If nn = 3 Then
            MsgBox("لا اله الا الله - La Allah Ala Allah")
            nn = 1
            Exit Sub
        End If
        '============================================================================
        If nn = 2 Then
            MsgBox("الله أكبر - Allah Akbar")
            nn = 3
        End If
        '============================================================================
        If nn = 1 Then
            MsgBox("سبحان الله - Subhan Allah")
            nn = 2
        End If
        '============================================================================
    End Sub
End Class
