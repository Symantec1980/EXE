/*
UPolyX 
written by Delikon/www.delikon.de
All rights reserved*/

#include "head.h"
#include "poly.h"





void gen(UCHAR * & code,Data* d,int &size){

	int reg[5]={0,2,3,6,7};
	int temp;
	int pos;
	int arrayPos1,arrayPos2;
	size=0;
	


	srand(GetTickCount()+d->start*132452);
	
	for(int i=0;i<5;i++){
		pos =rand()%5;
		temp = reg[i];
		reg[i]=reg[pos];
		reg[pos]=temp;
	}	
	
	do{
	arrayPos1=rand()%5;
	arrayPos2=rand()%5;
	}while(arrayPos1-arrayPos2==0);
	
	

	int reg1=reg[arrayPos1];
	int reg2=reg[arrayPos2];
	srand(GetTickCount()+d->start*132452+reg1+reg2);

	int whichXor=rand()%3;
	
	
	//print information
	printf("[+] using the xor/xor decryptor type %i\n",whichXor);
	printREG(reg1,reg2);
	printf("[+] using offset %i\n",1);	
	printf("[+] use 0x%x as manipulationByte\n",d->ManipulateByte);
	printf("[+] encrypt %i bytes from address 0x%x till address 0x%x \n",d->distance,d->start,d->start+d->distance);


	
	if(whichXor==0){
		/*
0046BFDA   > \BF 10BD4600   MOV EDI,putty.0046BD10
0046BFDF   .  8BD7          MOV EDX,EDI
0046BFE1   .  B9 68000000   MOV ECX,68
0046BFE6   >  8037 0D       XOR BYTE PTR DS:[EDI],0D
0046BFE9   .  83C7 01       ADD EDI,1
0046BFEC   .^ E2 F8         LOOPD SHORT putty.0046BFE6
0046BFEE   .  FFE2          JMP EDX		
		*/
		StackFrame(code,size);
		MoveAddrToReg(code,reg1,d->start,size);
		MoveRegToReg(code,reg2,reg1,size);
		MoveAddrToReg(code,RegEcx,d->distance,size);
		int label=SetLabel(size);
		XorRegOneByte(code,reg1,d->ManipulateByte,size);
		AddToReg(code,reg1,2,size);
		SubFromReg(code,reg1,1,size);
		LoopToLabel(code,label,size);
		JumpToReg(code,reg2,size);
	}
	if(whichXor==1){
		/*
		0046BFD7    BF 10BD4600     MOV EDI,putty.0046BD10
		0046BFDC    57              PUSH EDI
		0046BFDD    58              POP EAX
		0046BFDE    B9 B4000000     MOV ECX,0B4
		0046BFE3    8037 3A         XOR BYTE PTR DS:[EDI],3A
		0046BFE6    83C7 02         ADD EDI,2
		0046BFE9    83EF 01         SUB EDI,1
		0046BFEC  ^ E2 F5           LOOPD SHORT putty.0046BFE3
		0046BFEE    FFE0            JMP EAX
		*/
		MoveAddrToReg(code,reg1,d->start,size);
		PushReg(code,reg1,size);
		PopReg(code,reg2,size);
		MoveAddrToReg(code,RegEcx,d->distance,size);
		int label=SetLabel(size);
		XorRegOneByte(code,reg1,d->ManipulateByte,size);
		AddToReg(code,reg1,2,size);
		SubFromReg(code,reg1,1,size);
		LoopToLabel(code,label,size);
		JumpToReg(code,reg2,size);	
	}
	if(whichXor==2){
		/*
0046BFD6   /EB 01           JMP SHORT putty.0046BFD9
0046BFD8   |C3              RETN
0046BFD9   \B8 10BD4600     MOV EAX,putty.0046BD10
0046BFDE    50              PUSH EAX
0046BFDF    B9 87000000     MOV ECX,87
0046BFE4    8030 24         XOR BYTE PTR DS:[EAX],24
0046BFE7    83C0 02         ADD EAX,2
0046BFEA    83E8 01         SUB EAX,1
0046BFED  ^ E2 F5           LOOPD SHORT putty.0046BFE4
0046BFEF  ^ EB E7           JMP SHORT putty.0046BFD8		
		*/

		JumpForward(code,1,size);
		int label2=SetLabel(size);
		Ret(code,size);
		MoveAddrToReg(code,reg1,d->start,size);
		PushReg(code,reg1,size);
		
		MoveAddrToReg(code,RegEcx,d->distance,size);
		int label=SetLabel(size);
		XorRegOneByte(code,reg1,d->ManipulateByte,size);
		AddToReg(code,reg1,2,size);
		SubFromReg(code,reg1,1,size);
		LoopToLabel(code,label,size);
		JumpBackward(code,label2,size);
		
	}

	

}

