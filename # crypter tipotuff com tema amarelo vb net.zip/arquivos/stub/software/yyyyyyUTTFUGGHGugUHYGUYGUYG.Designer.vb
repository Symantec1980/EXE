﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class yyyyyyUTTFUGGHGugUHYGUYGUYG
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(yyyyyyUTTFUGGHGugUHYGUYGUYG))
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.ERTRETRETER = New System.Windows.Forms.CheckBox()
        Me.ERTRETRRYTTRYTRYRTYTR = New System.Windows.Forms.CheckBox()
        Me.GGFGHDRTERTRETFGFGJHGJUIUUY = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'CheckBox1
        '
        resources.ApplyResources(Me.CheckBox1, "CheckBox1")
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'ERTRETRETER
        '
        resources.ApplyResources(Me.ERTRETRETER, "ERTRETRETER")
        Me.ERTRETRETER.Name = "ERTRETRETER"
        Me.ERTRETRETER.Tag = "RRTRETCBHTRYERWREWFSDFSD"
        Me.ERTRETRETER.UseVisualStyleBackColor = True
        '
        'ERTRETRRYTTRYTRYRTYTR
        '
        resources.ApplyResources(Me.ERTRETRRYTTRYTRYRTYTR, "ERTRETRRYTTRYTRYRTYTR")
        Me.ERTRETRRYTTRYTRYRTYTR.Name = "ERTRETRRYTTRYTRYRTYTR"
        Me.ERTRETRRYTTRYTRYRTYTR.Tag = "EWREWRWREWRWETETRET"
        Me.ERTRETRRYTTRYTRYRTYTR.UseVisualStyleBackColor = True
        '
        'GGFGHDRTERTRETFGFGJHGJUIUUY
        '
        resources.ApplyResources(Me.GGFGHDRTERTRETFGFGJHGJUIUUY, "GGFGHDRTERTRETFGFGJHGJUIUUY")
        Me.GGFGHDRTERTRETFGFGJHGJUIUUY.Name = "GGFGHDRTERTRETFGFGJHGJUIUUY"
        Me.GGFGHDRTERTRETFGFGJHGJUIUUY.Tag = "RRTGNBNBNVNVBGGGGFGHFH"
        Me.GGFGHDRTERTRETFGFGJHGJUIUUY.UseVisualStyleBackColor = True
        '
        'yyyyyyUTTFUGGHGugUHYGUYGUYG
        '
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.GGFGHDRTERTRETFGFGJHGJUIUUY)
        Me.Controls.Add(Me.ERTRETRRYTTRYTRYRTYTR)
        Me.Controls.Add(Me.ERTRETRETER)
        Me.Controls.Add(Me.CheckBox1)
        Me.HelpButton = True
        Me.IsMdiContainer = True
        Me.KeyPreview = True
        Me.Name = "yyyyyyUTTFUGGHGugUHYGUYGUYG"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents ERTRETRETER As System.Windows.Forms.CheckBox
    Friend WithEvents ERTRETRRYTTRYTRYRTYTR As System.Windows.Forms.CheckBox
    Friend WithEvents GGFGHDRTERTRETFGFGJHGJUIUUY As System.Windows.Forms.Button
End Class
