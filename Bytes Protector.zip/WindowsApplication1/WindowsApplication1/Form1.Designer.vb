﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.GhostTheme1 = New WindowsApplication1.GhostTheme()
        Me.GhostProgressbar2 = New WindowsApplication1.GhostProgressbar()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.GhostButton5 = New WindowsApplication1.GhostButton()
        Me.GhostTabControl1 = New WindowsApplication1.GhostTabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GhostTextbox22 = New WindowsApplication1.GhostTextbox()
        Me.GhostTextbox19 = New WindowsApplication1.GhostTextbox()
        Me.GhostTextbox15 = New WindowsApplication1.GhostTextbox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GhostTextbox13 = New WindowsApplication1.GhostTextbox()
        Me.GhostTextbox12 = New WindowsApplication1.GhostTextbox()
        Me.GhostProgressbar1 = New WindowsApplication1.GhostProgressbar()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GhostGroupBox2 = New WindowsApplication1.GhostGroupBox()
        Me.GhostTextbox3 = New WindowsApplication1.GhostTextbox()
        Me.GhostButton3 = New WindowsApplication1.GhostButton()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GhostTextbox4 = New WindowsApplication1.GhostTextbox()
        Me.GhostButton4 = New WindowsApplication1.GhostButton()
        Me.GhostGroupBox1 = New WindowsApplication1.GhostGroupBox()
        Me.GhostTextbox1 = New WindowsApplication1.GhostTextbox()
        Me.GhostButton1 = New WindowsApplication1.GhostButton()
        Me.GhostTextbox2 = New WindowsApplication1.GhostTextbox()
        Me.GhostButton2 = New WindowsApplication1.GhostButton()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.GhostGroupBox9 = New WindowsApplication1.GhostGroupBox()
        Me.GhostCheckbox16 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox15 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox14 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox13 = New WindowsApplication1.GhostCheckbox()
        Me.GhostGroupBox4 = New WindowsApplication1.GhostGroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GhostTextbox6 = New WindowsApplication1.GhostTextbox()
        Me.GhostComboBox2 = New WindowsApplication1.GhostComboBox()
        Me.GhostCheckbox3 = New WindowsApplication1.GhostCheckbox()
        Me.GhostGroupBox3 = New WindowsApplication1.GhostGroupBox()
        Me.GhostCheckbox12 = New WindowsApplication1.GhostCheckbox()
        Me.GhostTextbox11 = New WindowsApplication1.GhostTextbox()
        Me.GhostComboBox1 = New WindowsApplication1.GhostComboBox()
        Me.GhostCheckbox2 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox1 = New WindowsApplication1.GhostCheckbox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GhostGroupBox7 = New WindowsApplication1.GhostGroupBox()
        Me.GhostCheckbox9 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox8 = New WindowsApplication1.GhostCheckbox()
        Me.GhostGroupBox6 = New WindowsApplication1.GhostGroupBox()
        Me.GhostButton7 = New WindowsApplication1.GhostButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GhostTextbox10 = New WindowsApplication1.GhostTextbox()
        Me.GhostTextbox9 = New WindowsApplication1.GhostTextbox()
        Me.GhostTextbox8 = New WindowsApplication1.GhostTextbox()
        Me.GhostTextbox7 = New WindowsApplication1.GhostTextbox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GhostGroupBox8 = New WindowsApplication1.GhostGroupBox()
        Me.GhostRadiobutton5 = New WindowsApplication1.GhostRadiobutton()
        Me.GhostRadiobutton6 = New WindowsApplication1.GhostRadiobutton()
        Me.GhostRadiobutton4 = New WindowsApplication1.GhostRadiobutton()
        Me.GhostRadiobutton3 = New WindowsApplication1.GhostRadiobutton()
        Me.GhostRadiobutton2 = New WindowsApplication1.GhostRadiobutton()
        Me.GhostRadiobutton1 = New WindowsApplication1.GhostRadiobutton()
        Me.GhostButton6 = New WindowsApplication1.GhostButton()
        Me.GhostGroupBox5 = New WindowsApplication1.GhostGroupBox()
        Me.GhostCheckbox10 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox11 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox7 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox6 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox5 = New WindowsApplication1.GhostCheckbox()
        Me.GhostCheckbox4 = New WindowsApplication1.GhostCheckbox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.GhostTextbox5 = New WindowsApplication1.GhostTextbox()
        Me.RandomPool1 = New WindowsApplication1.RandomPool()
        Me.GhostTheme1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GhostTabControl1.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GhostGroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GhostGroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GhostGroupBox9.SuspendLayout()
        Me.GhostGroupBox4.SuspendLayout()
        Me.GhostGroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.GhostGroupBox7.SuspendLayout()
        Me.GhostGroupBox6.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.GhostGroupBox8.SuspendLayout()
        Me.GhostGroupBox5.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'Timer2
        '
        '
        'GhostTheme1
        '
        Me.GhostTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.GhostTheme1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostTheme1.Controls.Add(Me.GhostProgressbar2)
        Me.GhostTheme1.Controls.Add(Me.PictureBox2)
        Me.GhostTheme1.Controls.Add(Me.GhostButton5)
        Me.GhostTheme1.Controls.Add(Me.GhostTabControl1)
        Me.GhostTheme1.Customization = ""
        Me.GhostTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GhostTheme1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostTheme1.Image = Nothing
        Me.GhostTheme1.Location = New System.Drawing.Point(0, 0)
        Me.GhostTheme1.Movable = True
        Me.GhostTheme1.Name = "GhostTheme1"
        Me.GhostTheme1.NoRounding = False
        Me.GhostTheme1.Sizable = True
        Me.GhostTheme1.Size = New System.Drawing.Size(551, 538)
        Me.GhostTheme1.SmartBounds = True
        Me.GhostTheme1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.GhostTheme1.TabIndex = 0
        Me.GhostTheme1.Text = "Private Crypter "
        Me.GhostTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GhostTheme1.Transparent = False
        '
        'GhostProgressbar2
        '
        Me.GhostProgressbar2.Animated = True
        Me.GhostProgressbar2.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostProgressbar2.Customization = ""
        Me.GhostProgressbar2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostProgressbar2.Image = Nothing
        Me.GhostProgressbar2.Location = New System.Drawing.Point(325, 511)
        Me.GhostProgressbar2.Maximum = 100
        Me.GhostProgressbar2.Name = "GhostProgressbar2"
        Me.GhostProgressbar2.NoRounding = False
        Me.GhostProgressbar2.Size = New System.Drawing.Size(197, 13)
        Me.GhostProgressbar2.TabIndex = 3
        Me.GhostProgressbar2.Text = "GhostProgressbar2"
        Me.GhostProgressbar2.Transparent = False
        Me.GhostProgressbar2.Value = 0
        Me.GhostProgressbar2.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(47, 37)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(452, 170)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'GhostButton5
        '
        Me.GhostButton5.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton5.Customization = ""
        Me.GhostButton5.EnableGlass = True
        Me.GhostButton5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton5.Image = Nothing
        Me.GhostButton5.Location = New System.Drawing.Point(519, 0)
        Me.GhostButton5.Name = "GhostButton5"
        Me.GhostButton5.NoRounding = False
        Me.GhostButton5.Size = New System.Drawing.Size(20, 20)
        Me.GhostButton5.TabIndex = 1
        Me.GhostButton5.Text = "X"
        Me.GhostButton5.Transparent = False
        '
        'GhostTabControl1
        '
        Me.GhostTabControl1.Controls.Add(Me.TabPage6)
        Me.GhostTabControl1.Controls.Add(Me.TabPage1)
        Me.GhostTabControl1.Controls.Add(Me.TabPage2)
        Me.GhostTabControl1.Controls.Add(Me.TabPage3)
        Me.GhostTabControl1.Controls.Add(Me.TabPage4)
        Me.GhostTabControl1.Controls.Add(Me.TabPage5)
        Me.GhostTabControl1.Location = New System.Drawing.Point(25, 222)
        Me.GhostTabControl1.Name = "GhostTabControl1"
        Me.GhostTabControl1.SelectedIndex = 0
        Me.GhostTabControl1.Size = New System.Drawing.Size(498, 287)
        Me.GhostTabControl1.TabIndex = 0
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.Black
        Me.TabPage6.Controls.Add(Me.Label16)
        Me.TabPage6.Controls.Add(Me.Label15)
        Me.TabPage6.Controls.Add(Me.Label14)
        Me.TabPage6.Controls.Add(Me.Label13)
        Me.TabPage6.Controls.Add(Me.Label12)
        Me.TabPage6.Controls.Add(Me.Label11)
        Me.TabPage6.Controls.Add(Me.Label10)
        Me.TabPage6.Controls.Add(Me.Label7)
        Me.TabPage6.Controls.Add(Me.GhostTextbox22)
        Me.TabPage6.Controls.Add(Me.GhostTextbox19)
        Me.TabPage6.Controls.Add(Me.GhostTextbox15)
        Me.TabPage6.Controls.Add(Me.Label9)
        Me.TabPage6.Controls.Add(Me.Label8)
        Me.TabPage6.Controls.Add(Me.Label6)
        Me.TabPage6.Controls.Add(Me.GhostTextbox13)
        Me.TabPage6.Controls.Add(Me.GhostTextbox12)
        Me.TabPage6.Controls.Add(Me.GhostProgressbar1)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(490, 258)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Info"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(107, 122)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(51, 13)
        Me.Label16.TabIndex = 26
        Me.Label16.Text = "Label16"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(127, 190)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(19, 13)
        Me.Label15.TabIndex = 25
        Me.Label15.Text = "..."
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(86, 164)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(119, 13)
        Me.Label14.TabIndex = 24
        Me.Label14.Text = "FUD - 10 June 2012"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(86, 177)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(111, 13)
        Me.Label13.TabIndex = 23
        Me.Label13.Text = "Integrate Scanner"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(51, 143)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(195, 13)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Incoming Updates And Messages"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(25, 82)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(73, 13)
        Me.Label11.TabIndex = 20
        Me.Label11.Text = "User Online"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(25, 52)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(61, 13)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "Lifetime :"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(25, 27)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Username :"
        '
        'GhostTextbox22
        '
        Me.GhostTextbox22.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox22.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox22.Location = New System.Drawing.Point(305, 174)
        Me.GhostTextbox22.Multiline = True
        Me.GhostTextbox22.Name = "GhostTextbox22"
        Me.GhostTextbox22.ReadOnly = True
        Me.GhostTextbox22.Size = New System.Drawing.Size(180, 58)
        Me.GhostTextbox22.TabIndex = 17
        Me.GhostTextbox22.Text = "As coder, I'm not responsible in any way on how you use this."
        Me.GhostTextbox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GhostTextbox19
        '
        Me.GhostTextbox19.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox19.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox19.Location = New System.Drawing.Point(305, 119)
        Me.GhostTextbox19.Multiline = True
        Me.GhostTextbox19.Name = "GhostTextbox19"
        Me.GhostTextbox19.ReadOnly = True
        Me.GhostTextbox19.Size = New System.Drawing.Size(180, 58)
        Me.GhostTextbox19.TabIndex = 16
        Me.GhostTextbox19.Text = "All sale are final. If you get caught breaking any rules , I can terminate your a" & _
            "ccount."
        Me.GhostTextbox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GhostTextbox15
        '
        Me.GhostTextbox15.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox15.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox15.Location = New System.Drawing.Point(305, 63)
        Me.GhostTextbox15.Multiline = True
        Me.GhostTextbox15.Name = "GhostTextbox15"
        Me.GhostTextbox15.ReadOnly = True
        Me.GhostTextbox15.Size = New System.Drawing.Size(180, 63)
        Me.GhostTextbox15.TabIndex = 15
        Me.GhostTextbox15.Text = "Only Scan at My-avscan or Novirusthanks with ''Don't distribute Sample'' Checked " & _
            "Box"
        Me.GhostTextbox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(171, 82)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(44, 13)
        Me.Label9.TabIndex = 6
        Me.Label9.Text = "Label9"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(171, 52)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(44, 13)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "Label8"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(171, 27)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(91, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "seal.username"
        '
        'GhostTextbox13
        '
        Me.GhostTextbox13.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox13.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox13.Location = New System.Drawing.Point(305, 31)
        Me.GhostTextbox13.Multiline = True
        Me.GhostTextbox13.Name = "GhostTextbox13"
        Me.GhostTextbox13.ReadOnly = True
        Me.GhostTextbox13.Size = New System.Drawing.Size(180, 34)
        Me.GhostTextbox13.TabIndex = 2
        Me.GhostTextbox13.Text = "Crypting Service isn't allowed.[Free Or Paid]"
        Me.GhostTextbox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GhostTextbox12
        '
        Me.GhostTextbox12.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox12.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox12.Location = New System.Drawing.Point(305, 6)
        Me.GhostTextbox12.Name = "GhostTextbox12"
        Me.GhostTextbox12.ReadOnly = True
        Me.GhostTextbox12.Size = New System.Drawing.Size(180, 20)
        Me.GhostTextbox12.TabIndex = 1
        Me.GhostTextbox12.Text = "Term of Service"
        Me.GhostTextbox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GhostProgressbar1
        '
        Me.GhostProgressbar1.Animated = True
        Me.GhostProgressbar1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostProgressbar1.Customization = ""
        Me.GhostProgressbar1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostProgressbar1.Image = Nothing
        Me.GhostProgressbar1.Location = New System.Drawing.Point(297, -7)
        Me.GhostProgressbar1.Maximum = 100
        Me.GhostProgressbar1.Name = "GhostProgressbar1"
        Me.GhostProgressbar1.NoRounding = False
        Me.GhostProgressbar1.Size = New System.Drawing.Size(8, 269)
        Me.GhostProgressbar1.TabIndex = 0
        Me.GhostProgressbar1.Text = "GhostProgressbar1"
        Me.GhostProgressbar1.Transparent = False
        Me.GhostProgressbar1.Value = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Black
        Me.TabPage1.Controls.Add(Me.GhostGroupBox2)
        Me.TabPage1.Controls.Add(Me.GhostGroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(490, 258)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Main"
        '
        'GhostGroupBox2
        '
        Me.GhostGroupBox2.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox2.Controls.Add(Me.GhostTextbox3)
        Me.GhostGroupBox2.Controls.Add(Me.GhostButton3)
        Me.GhostGroupBox2.Controls.Add(Me.PictureBox1)
        Me.GhostGroupBox2.Controls.Add(Me.GhostTextbox4)
        Me.GhostGroupBox2.Controls.Add(Me.GhostButton4)
        Me.GhostGroupBox2.Customization = ""
        Me.GhostGroupBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox2.Image = Nothing
        Me.GhostGroupBox2.Location = New System.Drawing.Point(94, 130)
        Me.GhostGroupBox2.Name = "GhostGroupBox2"
        Me.GhostGroupBox2.NoRounding = False
        Me.GhostGroupBox2.Size = New System.Drawing.Size(288, 105)
        Me.GhostGroupBox2.TabIndex = 10
        Me.GhostGroupBox2.Text = "Binder/Icon"
        Me.GhostGroupBox2.Transparent = False
        '
        'GhostTextbox3
        '
        Me.GhostTextbox3.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox3.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox3.Location = New System.Drawing.Point(10, 33)
        Me.GhostTextbox3.Name = "GhostTextbox3"
        Me.GhostTextbox3.Size = New System.Drawing.Size(218, 20)
        Me.GhostTextbox3.TabIndex = 4
        Me.GhostTextbox3.Text = "Browse File To Bind"
        '
        'GhostButton3
        '
        Me.GhostButton3.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton3.Customization = ""
        Me.GhostButton3.EnableGlass = True
        Me.GhostButton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton3.Image = Nothing
        Me.GhostButton3.Location = New System.Drawing.Point(236, 30)
        Me.GhostButton3.Name = "GhostButton3"
        Me.GhostButton3.NoRounding = False
        Me.GhostButton3.Size = New System.Drawing.Size(44, 23)
        Me.GhostButton3.TabIndex = 5
        Me.GhostButton3.Text = "----"
        Me.GhostButton3.Transparent = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Location = New System.Drawing.Point(8, 66)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(39, 32)
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'GhostTextbox4
        '
        Me.GhostTextbox4.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox4.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox4.Location = New System.Drawing.Point(57, 73)
        Me.GhostTextbox4.Name = "GhostTextbox4"
        Me.GhostTextbox4.Size = New System.Drawing.Size(153, 20)
        Me.GhostTextbox4.TabIndex = 6
        Me.GhostTextbox4.Text = "Browse Icon To Use"
        '
        'GhostButton4
        '
        Me.GhostButton4.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton4.Customization = ""
        Me.GhostButton4.EnableGlass = True
        Me.GhostButton4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton4.Image = Nothing
        Me.GhostButton4.Location = New System.Drawing.Point(222, 71)
        Me.GhostButton4.Name = "GhostButton4"
        Me.GhostButton4.NoRounding = False
        Me.GhostButton4.Size = New System.Drawing.Size(44, 23)
        Me.GhostButton4.TabIndex = 7
        Me.GhostButton4.Text = "----"
        Me.GhostButton4.Transparent = False
        '
        'GhostGroupBox1
        '
        Me.GhostGroupBox1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox1.Controls.Add(Me.GhostTextbox1)
        Me.GhostGroupBox1.Controls.Add(Me.GhostButton1)
        Me.GhostGroupBox1.Controls.Add(Me.GhostTextbox2)
        Me.GhostGroupBox1.Controls.Add(Me.GhostButton2)
        Me.GhostGroupBox1.Customization = ""
        Me.GhostGroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox1.Image = Nothing
        Me.GhostGroupBox1.Location = New System.Drawing.Point(94, 6)
        Me.GhostGroupBox1.Name = "GhostGroupBox1"
        Me.GhostGroupBox1.NoRounding = False
        Me.GhostGroupBox1.Size = New System.Drawing.Size(288, 107)
        Me.GhostGroupBox1.TabIndex = 9
        Me.GhostGroupBox1.Text = "Browse Your Executable"
        Me.GhostGroupBox1.Transparent = False
        '
        'GhostTextbox1
        '
        Me.GhostTextbox1.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox1.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox1.Location = New System.Drawing.Point(10, 36)
        Me.GhostTextbox1.Name = "GhostTextbox1"
        Me.GhostTextbox1.Size = New System.Drawing.Size(218, 20)
        Me.GhostTextbox1.TabIndex = 0
        Me.GhostTextbox1.Text = "Browse File To Crypt"
        '
        'GhostButton1
        '
        Me.GhostButton1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton1.Customization = ""
        Me.GhostButton1.EnableGlass = True
        Me.GhostButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton1.Image = Nothing
        Me.GhostButton1.Location = New System.Drawing.Point(236, 34)
        Me.GhostButton1.Name = "GhostButton1"
        Me.GhostButton1.NoRounding = False
        Me.GhostButton1.Size = New System.Drawing.Size(44, 23)
        Me.GhostButton1.TabIndex = 1
        Me.GhostButton1.Text = "----"
        Me.GhostButton1.Transparent = False
        '
        'GhostTextbox2
        '
        Me.GhostTextbox2.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox2.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox2.Location = New System.Drawing.Point(56, 73)
        Me.GhostTextbox2.Name = "GhostTextbox2"
        Me.GhostTextbox2.Size = New System.Drawing.Size(153, 20)
        Me.GhostTextbox2.TabIndex = 2
        Me.GhostTextbox2.Text = "Genrate Encryption Pass"
        '
        'GhostButton2
        '
        Me.GhostButton2.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton2.Customization = ""
        Me.GhostButton2.EnableGlass = True
        Me.GhostButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton2.Image = Nothing
        Me.GhostButton2.Location = New System.Drawing.Point(221, 71)
        Me.GhostButton2.Name = "GhostButton2"
        Me.GhostButton2.NoRounding = False
        Me.GhostButton2.Size = New System.Drawing.Size(44, 23)
        Me.GhostButton2.TabIndex = 3
        Me.GhostButton2.Text = "----"
        Me.GhostButton2.Transparent = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.TabPage2.Controls.Add(Me.GhostGroupBox9)
        Me.TabPage2.Controls.Add(Me.GhostGroupBox4)
        Me.TabPage2.Controls.Add(Me.GhostGroupBox3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(490, 258)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Extras"
        '
        'GhostGroupBox9
        '
        Me.GhostGroupBox9.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox9.Controls.Add(Me.GhostCheckbox16)
        Me.GhostGroupBox9.Controls.Add(Me.GhostCheckbox15)
        Me.GhostGroupBox9.Controls.Add(Me.GhostCheckbox14)
        Me.GhostGroupBox9.Controls.Add(Me.GhostCheckbox13)
        Me.GhostGroupBox9.Customization = ""
        Me.GhostGroupBox9.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox9.Image = Nothing
        Me.GhostGroupBox9.Location = New System.Drawing.Point(340, 15)
        Me.GhostGroupBox9.Name = "GhostGroupBox9"
        Me.GhostGroupBox9.NoRounding = False
        Me.GhostGroupBox9.Size = New System.Drawing.Size(130, 154)
        Me.GhostGroupBox9.TabIndex = 2
        Me.GhostGroupBox9.Text = "Disablers"
        Me.GhostGroupBox9.Transparent = False
        '
        'GhostCheckbox16
        '
        Me.GhostCheckbox16.Checked = False
        Me.GhostCheckbox16.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox16.Customization = ""
        Me.GhostCheckbox16.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox16.Image = Nothing
        Me.GhostCheckbox16.Location = New System.Drawing.Point(11, 124)
        Me.GhostCheckbox16.Name = "GhostCheckbox16"
        Me.GhostCheckbox16.NoRounding = False
        Me.GhostCheckbox16.Size = New System.Drawing.Size(94, 16)
        Me.GhostCheckbox16.TabIndex = 9
        Me.GhostCheckbox16.Text = " System Reg"
        Me.GhostCheckbox16.Transparent = False
        '
        'GhostCheckbox15
        '
        Me.GhostCheckbox15.Checked = False
        Me.GhostCheckbox15.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox15.Customization = ""
        Me.GhostCheckbox15.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox15.Image = Nothing
        Me.GhostCheckbox15.Location = New System.Drawing.Point(11, 96)
        Me.GhostCheckbox15.Name = "GhostCheckbox15"
        Me.GhostCheckbox15.NoRounding = False
        Me.GhostCheckbox15.Size = New System.Drawing.Size(115, 16)
        Me.GhostCheckbox15.TabIndex = 8
        Me.GhostCheckbox15.Text = " System Restore"
        Me.GhostCheckbox15.Transparent = False
        '
        'GhostCheckbox14
        '
        Me.GhostCheckbox14.Checked = False
        Me.GhostCheckbox14.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox14.Customization = ""
        Me.GhostCheckbox14.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox14.Image = Nothing
        Me.GhostCheckbox14.Location = New System.Drawing.Point(11, 67)
        Me.GhostCheckbox14.Name = "GhostCheckbox14"
        Me.GhostCheckbox14.NoRounding = False
        Me.GhostCheckbox14.Size = New System.Drawing.Size(49, 16)
        Me.GhostCheckbox14.TabIndex = 7
        Me.GhostCheckbox14.Text = "CMD"
        Me.GhostCheckbox14.Transparent = False
        '
        'GhostCheckbox13
        '
        Me.GhostCheckbox13.Checked = False
        Me.GhostCheckbox13.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox13.Customization = ""
        Me.GhostCheckbox13.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox13.Image = Nothing
        Me.GhostCheckbox13.Location = New System.Drawing.Point(11, 37)
        Me.GhostCheckbox13.Name = "GhostCheckbox13"
        Me.GhostCheckbox13.NoRounding = False
        Me.GhostCheckbox13.Size = New System.Drawing.Size(102, 16)
        Me.GhostCheckbox13.TabIndex = 6
        Me.GhostCheckbox13.Text = "Task-Manager"
        Me.GhostCheckbox13.Transparent = False
        '
        'GhostGroupBox4
        '
        Me.GhostGroupBox4.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox4.Controls.Add(Me.Label1)
        Me.GhostGroupBox4.Controls.Add(Me.GhostTextbox6)
        Me.GhostGroupBox4.Controls.Add(Me.GhostComboBox2)
        Me.GhostGroupBox4.Controls.Add(Me.GhostCheckbox3)
        Me.GhostGroupBox4.Customization = ""
        Me.GhostGroupBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox4.Image = Nothing
        Me.GhostGroupBox4.Location = New System.Drawing.Point(24, 15)
        Me.GhostGroupBox4.Name = "GhostGroupBox4"
        Me.GhostGroupBox4.NoRounding = False
        Me.GhostGroupBox4.Size = New System.Drawing.Size(309, 103)
        Me.GhostGroupBox4.TabIndex = 1
        Me.GhostGroupBox4.Text = "Injection/Process"
        Me.GhostGroupBox4.Transparent = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(17, 73)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(141, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Custom Process Name:"
        '
        'GhostTextbox6
        '
        Me.GhostTextbox6.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox6.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox6.Location = New System.Drawing.Point(168, 70)
        Me.GhostTextbox6.Name = "GhostTextbox6"
        Me.GhostTextbox6.Size = New System.Drawing.Size(100, 20)
        Me.GhostTextbox6.TabIndex = 2
        Me.GhostTextbox6.Text = "Service"
        '
        'GhostComboBox2
        '
        Me.GhostComboBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.GhostComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.GhostComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.GhostComboBox2.FormattingEnabled = True
        Me.GhostComboBox2.ItemHeight = 16
        Me.GhostComboBox2.Items.AddRange(New Object() {"vbc.exe", "svchost.exe", "Winlogon.exe"})
        Me.GhostComboBox2.Location = New System.Drawing.Point(164, 36)
        Me.GhostComboBox2.Name = "GhostComboBox2"
        Me.GhostComboBox2.Size = New System.Drawing.Size(121, 22)
        Me.GhostComboBox2.TabIndex = 1
        '
        'GhostCheckbox3
        '
        Me.GhostCheckbox3.Checked = False
        Me.GhostCheckbox3.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox3.Customization = ""
        Me.GhostCheckbox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox3.Image = Nothing
        Me.GhostCheckbox3.Location = New System.Drawing.Point(21, 36)
        Me.GhostCheckbox3.Name = "GhostCheckbox3"
        Me.GhostCheckbox3.NoRounding = False
        Me.GhostCheckbox3.Size = New System.Drawing.Size(118, 17)
        Me.GhostCheckbox3.TabIndex = 0
        Me.GhostCheckbox3.Text = "Custom Injection"
        Me.GhostCheckbox3.Transparent = False
        '
        'GhostGroupBox3
        '
        Me.GhostGroupBox3.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox3.Controls.Add(Me.GhostCheckbox12)
        Me.GhostGroupBox3.Controls.Add(Me.GhostTextbox11)
        Me.GhostGroupBox3.Controls.Add(Me.GhostComboBox1)
        Me.GhostGroupBox3.Controls.Add(Me.GhostCheckbox2)
        Me.GhostGroupBox3.Controls.Add(Me.GhostCheckbox1)
        Me.GhostGroupBox3.Customization = ""
        Me.GhostGroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox3.Image = Nothing
        Me.GhostGroupBox3.Location = New System.Drawing.Point(24, 133)
        Me.GhostGroupBox3.Name = "GhostGroupBox3"
        Me.GhostGroupBox3.NoRounding = False
        Me.GhostGroupBox3.Size = New System.Drawing.Size(309, 109)
        Me.GhostGroupBox3.TabIndex = 0
        Me.GhostGroupBox3.Text = "StartUp/Install"
        Me.GhostGroupBox3.Transparent = False
        '
        'GhostCheckbox12
        '
        Me.GhostCheckbox12.Checked = False
        Me.GhostCheckbox12.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox12.Customization = ""
        Me.GhostCheckbox12.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox12.Image = Nothing
        Me.GhostCheckbox12.Location = New System.Drawing.Point(164, 74)
        Me.GhostCheckbox12.Name = "GhostCheckbox12"
        Me.GhostCheckbox12.NoRounding = False
        Me.GhostCheckbox12.Size = New System.Drawing.Size(101, 16)
        Me.GhostCheckbox12.TabIndex = 5
        Me.GhostCheckbox12.Text = "Reg Persience"
        Me.GhostCheckbox12.Transparent = False
        '
        'GhostTextbox11
        '
        Me.GhostTextbox11.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox11.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox11.Location = New System.Drawing.Point(86, 38)
        Me.GhostTextbox11.Name = "GhostTextbox11"
        Me.GhostTextbox11.Size = New System.Drawing.Size(100, 20)
        Me.GhostTextbox11.TabIndex = 4
        Me.GhostTextbox11.Text = "Winni"
        '
        'GhostComboBox1
        '
        Me.GhostComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.GhostComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.GhostComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.GhostComboBox1.FormattingEnabled = True
        Me.GhostComboBox1.ItemHeight = 16
        Me.GhostComboBox1.Items.AddRange(New Object() {"Temp", "AppData", "My Documents"})
        Me.GhostComboBox1.Location = New System.Drawing.Point(204, 37)
        Me.GhostComboBox1.Name = "GhostComboBox1"
        Me.GhostComboBox1.Size = New System.Drawing.Size(86, 22)
        Me.GhostComboBox1.TabIndex = 3
        '
        'GhostCheckbox2
        '
        Me.GhostCheckbox2.Checked = False
        Me.GhostCheckbox2.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox2.Customization = ""
        Me.GhostCheckbox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox2.Image = Nothing
        Me.GhostCheckbox2.Location = New System.Drawing.Point(21, 74)
        Me.GhostCheckbox2.Name = "GhostCheckbox2"
        Me.GhostCheckbox2.NoRounding = False
        Me.GhostCheckbox2.Size = New System.Drawing.Size(55, 16)
        Me.GhostCheckbox2.TabIndex = 1
        Me.GhostCheckbox2.Text = "HKLM"
        Me.GhostCheckbox2.Transparent = False
        '
        'GhostCheckbox1
        '
        Me.GhostCheckbox1.Checked = False
        Me.GhostCheckbox1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox1.Customization = ""
        Me.GhostCheckbox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox1.Image = Nothing
        Me.GhostCheckbox1.Location = New System.Drawing.Point(21, 40)
        Me.GhostCheckbox1.Name = "GhostCheckbox1"
        Me.GhostCheckbox1.NoRounding = False
        Me.GhostCheckbox1.Size = New System.Drawing.Size(55, 16)
        Me.GhostCheckbox1.TabIndex = 0
        Me.GhostCheckbox1.Text = "HKCU "
        Me.GhostCheckbox1.Transparent = False
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.Black
        Me.TabPage3.Controls.Add(Me.GhostGroupBox7)
        Me.TabPage3.Controls.Add(Me.GhostGroupBox6)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(490, 258)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Assembly Changer"
        '
        'GhostGroupBox7
        '
        Me.GhostGroupBox7.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox7.Controls.Add(Me.GhostCheckbox9)
        Me.GhostGroupBox7.Controls.Add(Me.GhostCheckbox8)
        Me.GhostGroupBox7.Customization = ""
        Me.GhostGroupBox7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox7.Image = Nothing
        Me.GhostGroupBox7.Location = New System.Drawing.Point(81, 183)
        Me.GhostGroupBox7.Name = "GhostGroupBox7"
        Me.GhostGroupBox7.NoRounding = False
        Me.GhostGroupBox7.Size = New System.Drawing.Size(306, 69)
        Me.GhostGroupBox7.TabIndex = 1
        Me.GhostGroupBox7.Text = "Extras"
        Me.GhostGroupBox7.Transparent = False
        '
        'GhostCheckbox9
        '
        Me.GhostCheckbox9.Checked = False
        Me.GhostCheckbox9.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox9.Customization = ""
        Me.GhostCheckbox9.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox9.Image = Nothing
        Me.GhostCheckbox9.Location = New System.Drawing.Point(137, 38)
        Me.GhostCheckbox9.Name = "GhostCheckbox9"
        Me.GhostCheckbox9.NoRounding = False
        Me.GhostCheckbox9.Size = New System.Drawing.Size(124, 16)
        Me.GhostCheckbox9.TabIndex = 1
        Me.GhostCheckbox9.Text = "Double encryption"
        Me.GhostCheckbox9.Transparent = False
        '
        'GhostCheckbox8
        '
        Me.GhostCheckbox8.Checked = False
        Me.GhostCheckbox8.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox8.Customization = ""
        Me.GhostCheckbox8.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox8.Image = Nothing
        Me.GhostCheckbox8.Location = New System.Drawing.Point(27, 38)
        Me.GhostCheckbox8.Name = "GhostCheckbox8"
        Me.GhostCheckbox8.NoRounding = False
        Me.GhostCheckbox8.Size = New System.Drawing.Size(82, 16)
        Me.GhostCheckbox8.TabIndex = 0
        Me.GhostCheckbox8.Text = "NT Header"
        Me.GhostCheckbox8.Transparent = False
        '
        'GhostGroupBox6
        '
        Me.GhostGroupBox6.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox6.Controls.Add(Me.GhostButton7)
        Me.GhostGroupBox6.Controls.Add(Me.Label5)
        Me.GhostGroupBox6.Controls.Add(Me.Label4)
        Me.GhostGroupBox6.Controls.Add(Me.Label3)
        Me.GhostGroupBox6.Controls.Add(Me.Label2)
        Me.GhostGroupBox6.Controls.Add(Me.GhostTextbox10)
        Me.GhostGroupBox6.Controls.Add(Me.GhostTextbox9)
        Me.GhostGroupBox6.Controls.Add(Me.GhostTextbox8)
        Me.GhostGroupBox6.Controls.Add(Me.GhostTextbox7)
        Me.GhostGroupBox6.Customization = ""
        Me.GhostGroupBox6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox6.Image = Nothing
        Me.GhostGroupBox6.Location = New System.Drawing.Point(81, 6)
        Me.GhostGroupBox6.Name = "GhostGroupBox6"
        Me.GhostGroupBox6.NoRounding = False
        Me.GhostGroupBox6.Size = New System.Drawing.Size(306, 171)
        Me.GhostGroupBox6.TabIndex = 0
        Me.GhostGroupBox6.Text = "Assembly Changer"
        Me.GhostGroupBox6.Transparent = False
        '
        'GhostButton7
        '
        Me.GhostButton7.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton7.Customization = ""
        Me.GhostButton7.EnableGlass = True
        Me.GhostButton7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton7.Image = Nothing
        Me.GhostButton7.Location = New System.Drawing.Point(174, 141)
        Me.GhostButton7.Name = "GhostButton7"
        Me.GhostButton7.NoRounding = False
        Me.GhostButton7.Size = New System.Drawing.Size(94, 23)
        Me.GhostButton7.TabIndex = 8
        Me.GhostButton7.Text = "Randomise"
        Me.GhostButton7.Transparent = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Verdana", 8.75!)
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(27, 113)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(73, 14)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Copyright:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Verdana", 8.75!)
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(27, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 14)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Product:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Verdana", 8.75!)
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(27, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 14)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Company:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Verdana", 8.75!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(27, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 14)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Title:"
        '
        'GhostTextbox10
        '
        Me.GhostTextbox10.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox10.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox10.Location = New System.Drawing.Point(113, 110)
        Me.GhostTextbox10.Name = "GhostTextbox10"
        Me.GhostTextbox10.Size = New System.Drawing.Size(169, 20)
        Me.GhostTextbox10.TabIndex = 3
        '
        'GhostTextbox9
        '
        Me.GhostTextbox9.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox9.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox9.Location = New System.Drawing.Point(113, 84)
        Me.GhostTextbox9.Name = "GhostTextbox9"
        Me.GhostTextbox9.Size = New System.Drawing.Size(169, 20)
        Me.GhostTextbox9.TabIndex = 2
        '
        'GhostTextbox8
        '
        Me.GhostTextbox8.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox8.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox8.Location = New System.Drawing.Point(113, 58)
        Me.GhostTextbox8.Name = "GhostTextbox8"
        Me.GhostTextbox8.Size = New System.Drawing.Size(169, 20)
        Me.GhostTextbox8.TabIndex = 1
        '
        'GhostTextbox7
        '
        Me.GhostTextbox7.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox7.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox7.Location = New System.Drawing.Point(113, 32)
        Me.GhostTextbox7.Name = "GhostTextbox7"
        Me.GhostTextbox7.Size = New System.Drawing.Size(169, 20)
        Me.GhostTextbox7.TabIndex = 0
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.Black
        Me.TabPage4.Controls.Add(Me.GhostGroupBox8)
        Me.TabPage4.Controls.Add(Me.GhostButton6)
        Me.TabPage4.Controls.Add(Me.GhostGroupBox5)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(490, 258)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Protect File"
        '
        'GhostGroupBox8
        '
        Me.GhostGroupBox8.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox8.Controls.Add(Me.GhostRadiobutton5)
        Me.GhostGroupBox8.Controls.Add(Me.GhostRadiobutton6)
        Me.GhostGroupBox8.Controls.Add(Me.GhostRadiobutton4)
        Me.GhostGroupBox8.Controls.Add(Me.GhostRadiobutton3)
        Me.GhostGroupBox8.Controls.Add(Me.GhostRadiobutton2)
        Me.GhostGroupBox8.Controls.Add(Me.GhostRadiobutton1)
        Me.GhostGroupBox8.Customization = ""
        Me.GhostGroupBox8.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox8.Image = Nothing
        Me.GhostGroupBox8.Location = New System.Drawing.Point(29, 123)
        Me.GhostGroupBox8.Name = "GhostGroupBox8"
        Me.GhostGroupBox8.NoRounding = False
        Me.GhostGroupBox8.Size = New System.Drawing.Size(426, 88)
        Me.GhostGroupBox8.TabIndex = 2
        Me.GhostGroupBox8.Text = "Encryptions"
        Me.GhostGroupBox8.Transparent = False
        '
        'GhostRadiobutton5
        '
        Me.GhostRadiobutton5.Checked = False
        Me.GhostRadiobutton5.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostRadiobutton5.Customization = ""
        Me.GhostRadiobutton5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostRadiobutton5.Image = Nothing
        Me.GhostRadiobutton5.Location = New System.Drawing.Point(283, 65)
        Me.GhostRadiobutton5.Name = "GhostRadiobutton5"
        Me.GhostRadiobutton5.NoRounding = False
        Me.GhostRadiobutton5.Size = New System.Drawing.Size(69, 14)
        Me.GhostRadiobutton5.TabIndex = 5
        Me.GhostRadiobutton5.Text = "Poly Xor"
        Me.GhostRadiobutton5.Transparent = False
        '
        'GhostRadiobutton6
        '
        Me.GhostRadiobutton6.Checked = False
        Me.GhostRadiobutton6.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostRadiobutton6.Customization = ""
        Me.GhostRadiobutton6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostRadiobutton6.Image = Nothing
        Me.GhostRadiobutton6.Location = New System.Drawing.Point(283, 34)
        Me.GhostRadiobutton6.Name = "GhostRadiobutton6"
        Me.GhostRadiobutton6.NoRounding = False
        Me.GhostRadiobutton6.Size = New System.Drawing.Size(71, 14)
        Me.GhostRadiobutton6.TabIndex = 4
        Me.GhostRadiobutton6.Text = "Poly Rc4"
        Me.GhostRadiobutton6.Transparent = False
        '
        'GhostRadiobutton4
        '
        Me.GhostRadiobutton4.Checked = False
        Me.GhostRadiobutton4.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostRadiobutton4.Customization = ""
        Me.GhostRadiobutton4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostRadiobutton4.Image = Nothing
        Me.GhostRadiobutton4.Location = New System.Drawing.Point(155, 65)
        Me.GhostRadiobutton4.Name = "GhostRadiobutton4"
        Me.GhostRadiobutton4.NoRounding = False
        Me.GhostRadiobutton4.Size = New System.Drawing.Size(46, 14)
        Me.GhostRadiobutton4.TabIndex = 3
        Me.GhostRadiobutton4.Text = "DES"
        Me.GhostRadiobutton4.Transparent = False
        '
        'GhostRadiobutton3
        '
        Me.GhostRadiobutton3.Checked = False
        Me.GhostRadiobutton3.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostRadiobutton3.Customization = ""
        Me.GhostRadiobutton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostRadiobutton3.Image = Nothing
        Me.GhostRadiobutton3.Location = New System.Drawing.Point(155, 34)
        Me.GhostRadiobutton3.Name = "GhostRadiobutton3"
        Me.GhostRadiobutton3.NoRounding = False
        Me.GhostRadiobutton3.Size = New System.Drawing.Size(76, 14)
        Me.GhostRadiobutton3.TabIndex = 2
        Me.GhostRadiobutton3.Text = "Poly Stair"
        Me.GhostRadiobutton3.Transparent = False
        '
        'GhostRadiobutton2
        '
        Me.GhostRadiobutton2.Checked = False
        Me.GhostRadiobutton2.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostRadiobutton2.Customization = ""
        Me.GhostRadiobutton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostRadiobutton2.Image = Nothing
        Me.GhostRadiobutton2.Location = New System.Drawing.Point(24, 65)
        Me.GhostRadiobutton2.Name = "GhostRadiobutton2"
        Me.GhostRadiobutton2.NoRounding = False
        Me.GhostRadiobutton2.Size = New System.Drawing.Size(46, 14)
        Me.GhostRadiobutton2.TabIndex = 1
        Me.GhostRadiobutton2.Text = "AES"
        Me.GhostRadiobutton2.Transparent = False
        '
        'GhostRadiobutton1
        '
        Me.GhostRadiobutton1.Checked = False
        Me.GhostRadiobutton1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostRadiobutton1.Customization = ""
        Me.GhostRadiobutton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostRadiobutton1.Image = Nothing
        Me.GhostRadiobutton1.Location = New System.Drawing.Point(24, 34)
        Me.GhostRadiobutton1.Name = "GhostRadiobutton1"
        Me.GhostRadiobutton1.NoRounding = False
        Me.GhostRadiobutton1.Size = New System.Drawing.Size(46, 14)
        Me.GhostRadiobutton1.TabIndex = 0
        Me.GhostRadiobutton1.Text = "RC4"
        Me.GhostRadiobutton1.Transparent = False
        '
        'GhostButton6
        '
        Me.GhostButton6.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostButton6.Customization = ""
        Me.GhostButton6.EnableGlass = True
        Me.GhostButton6.Font = New System.Drawing.Font("Verdana", 10.0!)
        Me.GhostButton6.Image = Nothing
        Me.GhostButton6.Location = New System.Drawing.Point(265, 226)
        Me.GhostButton6.Name = "GhostButton6"
        Me.GhostButton6.NoRounding = False
        Me.GhostButton6.Size = New System.Drawing.Size(102, 29)
        Me.GhostButton6.TabIndex = 1
        Me.GhostButton6.Text = "Protect File"
        Me.GhostButton6.Transparent = False
        '
        'GhostGroupBox5
        '
        Me.GhostGroupBox5.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostGroupBox5.Controls.Add(Me.GhostCheckbox10)
        Me.GhostGroupBox5.Controls.Add(Me.GhostCheckbox11)
        Me.GhostGroupBox5.Controls.Add(Me.GhostCheckbox7)
        Me.GhostGroupBox5.Controls.Add(Me.GhostCheckbox6)
        Me.GhostGroupBox5.Controls.Add(Me.GhostCheckbox5)
        Me.GhostGroupBox5.Controls.Add(Me.GhostCheckbox4)
        Me.GhostGroupBox5.Customization = ""
        Me.GhostGroupBox5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostGroupBox5.Image = Nothing
        Me.GhostGroupBox5.Location = New System.Drawing.Point(29, 21)
        Me.GhostGroupBox5.Name = "GhostGroupBox5"
        Me.GhostGroupBox5.NoRounding = False
        Me.GhostGroupBox5.Size = New System.Drawing.Size(426, 96)
        Me.GhostGroupBox5.TabIndex = 0
        Me.GhostGroupBox5.Text = "Extra Options"
        Me.GhostGroupBox5.Transparent = False
        '
        'GhostCheckbox10
        '
        Me.GhostCheckbox10.Checked = False
        Me.GhostCheckbox10.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox10.Customization = ""
        Me.GhostCheckbox10.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox10.Image = Nothing
        Me.GhostCheckbox10.Location = New System.Drawing.Point(283, 64)
        Me.GhostCheckbox10.Name = "GhostCheckbox10"
        Me.GhostCheckbox10.NoRounding = False
        Me.GhostCheckbox10.Size = New System.Drawing.Size(90, 18)
        Me.GhostCheckbox10.TabIndex = 5
        Me.GhostCheckbox10.Text = " Lan Spread"
        Me.GhostCheckbox10.Transparent = False
        '
        'GhostCheckbox11
        '
        Me.GhostCheckbox11.Checked = False
        Me.GhostCheckbox11.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox11.Customization = ""
        Me.GhostCheckbox11.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox11.Image = Nothing
        Me.GhostCheckbox11.Location = New System.Drawing.Point(283, 34)
        Me.GhostCheckbox11.Name = "GhostCheckbox11"
        Me.GhostCheckbox11.NoRounding = False
        Me.GhostCheckbox11.Size = New System.Drawing.Size(112, 18)
        Me.GhostCheckbox11.TabIndex = 4
        Me.GhostCheckbox11.Text = " Zip/Rar Spread"
        Me.GhostCheckbox11.Transparent = False
        '
        'GhostCheckbox7
        '
        Me.GhostCheckbox7.Checked = False
        Me.GhostCheckbox7.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox7.Customization = ""
        Me.GhostCheckbox7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox7.Image = Nothing
        Me.GhostCheckbox7.Location = New System.Drawing.Point(22, 64)
        Me.GhostCheckbox7.Name = "GhostCheckbox7"
        Me.GhostCheckbox7.NoRounding = False
        Me.GhostCheckbox7.Size = New System.Drawing.Size(71, 18)
        Me.GhostCheckbox7.TabIndex = 3
        Me.GhostCheckbox7.Text = " Melt file"
        Me.GhostCheckbox7.Transparent = False
        '
        'GhostCheckbox6
        '
        Me.GhostCheckbox6.Checked = False
        Me.GhostCheckbox6.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox6.Customization = ""
        Me.GhostCheckbox6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox6.Image = Nothing
        Me.GhostCheckbox6.Location = New System.Drawing.Point(153, 64)
        Me.GhostCheckbox6.Name = "GhostCheckbox6"
        Me.GhostCheckbox6.NoRounding = False
        Me.GhostCheckbox6.Size = New System.Drawing.Size(93, 18)
        Me.GhostCheckbox6.TabIndex = 2
        Me.GhostCheckbox6.Text = " USB Spread"
        Me.GhostCheckbox6.Transparent = False
        '
        'GhostCheckbox5
        '
        Me.GhostCheckbox5.Checked = False
        Me.GhostCheckbox5.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox5.Customization = ""
        Me.GhostCheckbox5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox5.Image = Nothing
        Me.GhostCheckbox5.Location = New System.Drawing.Point(153, 34)
        Me.GhostCheckbox5.Name = "GhostCheckbox5"
        Me.GhostCheckbox5.NoRounding = False
        Me.GhostCheckbox5.Size = New System.Drawing.Size(96, 18)
        Me.GhostCheckbox5.TabIndex = 1
        Me.GhostCheckbox5.Text = " Enable Antis"
        Me.GhostCheckbox5.Transparent = False
        '
        'GhostCheckbox4
        '
        Me.GhostCheckbox4.Checked = False
        Me.GhostCheckbox4.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.GhostCheckbox4.Customization = ""
        Me.GhostCheckbox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostCheckbox4.Image = Nothing
        Me.GhostCheckbox4.Location = New System.Drawing.Point(22, 34)
        Me.GhostCheckbox4.Name = "GhostCheckbox4"
        Me.GhostCheckbox4.NoRounding = False
        Me.GhostCheckbox4.Size = New System.Drawing.Size(72, 18)
        Me.GhostCheckbox4.TabIndex = 0
        Me.GhostCheckbox4.Text = " Hide file"
        Me.GhostCheckbox4.Transparent = False
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.Black
        Me.TabPage5.Controls.Add(Me.GhostTextbox5)
        Me.TabPage5.Controls.Add(Me.RandomPool1)
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.MinimumSize = New System.Drawing.Size(120, 80)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(490, 258)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Encryption Pool"
        '
        'GhostTextbox5
        '
        Me.GhostTextbox5.BackColor = System.Drawing.Color.Black
        Me.GhostTextbox5.ForeColor = System.Drawing.Color.White
        Me.GhostTextbox5.Location = New System.Drawing.Point(99, 36)
        Me.GhostTextbox5.Multiline = True
        Me.GhostTextbox5.Name = "GhostTextbox5"
        Me.GhostTextbox5.Size = New System.Drawing.Size(274, 63)
        Me.GhostTextbox5.TabIndex = 1
        '
        'RandomPool1
        '
        Me.RandomPool1.BackColor = System.Drawing.Color.Black
        Me.RandomPool1.ForeColor = System.Drawing.Color.Red
        Me.RandomPool1.Image = Nothing
        Me.RandomPool1.Location = New System.Drawing.Point(92, 115)
        Me.RandomPool1.Name = "RandomPool1"
        Me.RandomPool1.NoRounding = False
        Me.RandomPool1.Range = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        Me.RandomPool1.RangePadding = 2
        Me.RandomPool1.Size = New System.Drawing.Size(286, 137)
        Me.RandomPool1.TabIndex = 0
        Me.RandomPool1.Text = "RandomPool1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(551, 538)
        Me.Controls.Add(Me.GhostTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GhostTheme1.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GhostTabControl1.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.GhostGroupBox2.ResumeLayout(False)
        Me.GhostGroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GhostGroupBox1.ResumeLayout(False)
        Me.GhostGroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.GhostGroupBox9.ResumeLayout(False)
        Me.GhostGroupBox4.ResumeLayout(False)
        Me.GhostGroupBox4.PerformLayout()
        Me.GhostGroupBox3.ResumeLayout(False)
        Me.GhostGroupBox3.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.GhostGroupBox7.ResumeLayout(False)
        Me.GhostGroupBox6.ResumeLayout(False)
        Me.GhostGroupBox6.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.GhostGroupBox8.ResumeLayout(False)
        Me.GhostGroupBox5.ResumeLayout(False)
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GhostTheme1 As WindowsApplication1.GhostTheme
    Friend WithEvents GhostTabControl1 As WindowsApplication1.GhostTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents GhostGroupBox2 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostTextbox3 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostButton3 As WindowsApplication1.GhostButton
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GhostTextbox4 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostButton4 As WindowsApplication1.GhostButton
    Friend WithEvents GhostGroupBox1 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostTextbox1 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostButton1 As WindowsApplication1.GhostButton
    Friend WithEvents GhostTextbox2 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostButton2 As WindowsApplication1.GhostButton
    Friend WithEvents GhostGroupBox3 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostComboBox1 As WindowsApplication1.GhostComboBox
    Friend WithEvents GhostCheckbox2 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox1 As WindowsApplication1.GhostCheckbox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GhostButton5 As WindowsApplication1.GhostButton
    Friend WithEvents GhostGroupBox4 As WindowsApplication1.GhostGroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GhostTextbox6 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostComboBox2 As WindowsApplication1.GhostComboBox
    Friend WithEvents GhostCheckbox3 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostButton6 As WindowsApplication1.GhostButton
    Friend WithEvents GhostGroupBox5 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostCheckbox7 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox6 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox5 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox4 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostGroupBox7 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostCheckbox9 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox8 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostGroupBox6 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostButton7 As WindowsApplication1.GhostButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents GhostTextbox10 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostTextbox9 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostTextbox8 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostTextbox7 As WindowsApplication1.GhostTextbox
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents GhostGroupBox8 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostRadiobutton4 As WindowsApplication1.GhostRadiobutton
    Friend WithEvents GhostRadiobutton3 As WindowsApplication1.GhostRadiobutton
    Friend WithEvents GhostRadiobutton2 As WindowsApplication1.GhostRadiobutton
    Friend WithEvents GhostRadiobutton1 As WindowsApplication1.GhostRadiobutton
    Friend WithEvents GhostTextbox11 As WindowsApplication1.GhostTextbox
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents GhostTextbox5 As WindowsApplication1.GhostTextbox
    Friend WithEvents RandomPool1 As WindowsApplication1.RandomPool
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents GhostProgressbar1 As WindowsApplication1.GhostProgressbar
    Friend WithEvents GhostTextbox13 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostTextbox12 As WindowsApplication1.GhostTextbox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents GhostTextbox22 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostTextbox19 As WindowsApplication1.GhostTextbox
    Friend WithEvents GhostTextbox15 As WindowsApplication1.GhostTextbox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents GhostProgressbar2 As WindowsApplication1.GhostProgressbar
    Friend WithEvents GhostRadiobutton5 As WindowsApplication1.GhostRadiobutton
    Friend WithEvents GhostRadiobutton6 As WindowsApplication1.GhostRadiobutton
    Friend WithEvents GhostGroupBox9 As WindowsApplication1.GhostGroupBox
    Friend WithEvents GhostCheckbox16 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox15 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox14 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox13 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox12 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox10 As WindowsApplication1.GhostCheckbox
    Friend WithEvents GhostCheckbox11 As WindowsApplication1.GhostCheckbox

End Class
