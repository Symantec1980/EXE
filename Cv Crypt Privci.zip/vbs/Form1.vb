﻿Public Class Form1
    Private Sub SkyDarkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkyDarkButton1.Click
        Dim x As New OpenFileDialog
        With x
            .Filter = "|*.exe"
            .ShowDialog()
        End With
        t1.Text = x.FileName
    End Sub
    Private Sub SkyDarkButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkyDarkButton2.Click
        If COM1.Text = "RC4" Then
            Try
                Dim x() As Byte = IO.File.ReadAllBytes(t1.Text)
                Dim x0() As Byte = rc4.RC4Encrypt(x, key.Text)
                Dim x1 As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\RC4.exe"
                System.IO.File.WriteAllBytes(x1, x0)
                l2.Text = "Done"
            Catch ex As Exception
                MsgBox("erorr !")
            End Try
        End If

        If COM1.Text = "ROX" Then
            Try
                Dim x() As Byte = IO.File.ReadAllBytes(t1.Text)
                Dim x0() As Byte = rxooo.XOREncrypt(x, key.Text)
                Dim x1 As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\XOR.exe"
                System.IO.File.WriteAllBytes(x1, x0)
                l2.Text = "Done"
            Catch ex As Exception
                MsgBox("erorr !")
            End Try
        End If

        If COM1.Text = "MD5" Then
            Try
                Dim x() As Byte = IO.File.ReadAllBytes(t1.Text)
                Dim x0() As Byte = MD5.Md5Encrypt(x, key.Text)
                Dim x1 As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\MD5.exe"
                System.IO.File.WriteAllBytes(x1, x0)
                l2.Text = "Done"
            Catch ex As Exception
                MsgBox("erorr !")
            End Try
        End If
    End Sub
    Private Sub SkyDarkForm1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkyDarkForm1.Click

    End Sub
    Private Sub SkyDarkButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkyDarkButton3.Click
        Dim x As String = My.Resources.ENRTRY
        en1.Text = x
        en1.SelectAll()
        en1.Copy()
        l2.Text = "Copy Entrypoint "

    End Sub

    Private Sub com2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles com2.SelectedIndexChanged
        If com2.Text = "RC4" Then
            System.Threading.Thread.Sleep(300)
            Dim x As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\Rc4.txt"
            Dim xx As String = My.Resources.RC4
            System.IO.File.WriteAllText(x, xx)
            MsgBox("RC4 DECRYPT IN DESKTOP DONE")
        End If

        If com2.Text = "ROX" Then
            Dim x As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\ROX.txt"
            Dim xx As String = My.Resources.XORr
            System.IO.File.WriteAllText(x, xx)
            MsgBox("ROX DECRYPT IN DESKTOP DONE")
        End If

        If com2.Text = "MD5" Then
            Dim x As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\MD5.txt"
            Dim xx As String = My.Resources.Md5
            System.IO.File.WriteAllText(x, xx)
            MsgBox("MD5 DECRYPT IN DESKTOP DONE")
        End If
    End Sub

    Private Sub SkyDarkButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkyDarkButton4.Click
        Dim x As New OpenFileDialog
        With x
            .Filter = "|*.vbs"
            .ShowDialog()
        End With
        tv1.Text = x.FileName
    End Sub

 
    Private Sub SkyDarkButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SkyDarkButton5.Click

        If com3.Text = "ASC1" Then
            Try
                Dim x As String = IO.File.ReadAllText(tv1.Text)
                Dim x1 As String = vbs(x, kk.Text)
                Dim x2 As String = My.Resources.vbsappend
                Dim gen As String = x2.Replace("%sam1%", rand(4)).Replace("%sam2%", x1).Replace("%sam3%", rand(8)) _
                    .Replace("%sam4%", rand(12)).Replace("%sam1%", rand(4)).Replace("%sp%", com4.Text) _
                    .Replace("%kk%", kk.Text).Replace("%lop%", rand(20))


                Dim x3 As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\Crypt.vbs"

                Dim y As New System.IO.StreamWriter(x3)
                y.Write(gen)
                y.Dispose()
            Catch ex As Exception
                MsgBox("Erorr key")
            End Try
        End If
        '2
        If com3.Text = "ASC&CHR" Then
            Try
                Dim x As String = IO.File.ReadAllText(tv1.Text)
                Dim x1 As String = vbsc(x, kk.Text)
                Dim x2 As String = My.Resources.chrww
                Dim gen As String = x2.Replace("%sam1%", rand(4)).Replace("%sam2%", x1).Replace("%sam3%", rand(8)) _
                                    .Replace("%kk%", kk.Text).Replace("%lol1%", rand(10)).Replace("%lol2%", rand(14)) _
                                    .Replace("%lol3%", rand(16)).Replace("%lol4%", rand(18)).Replace("%lop%", rand(21))



                Dim x3 As String = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) & "\Crypt.vbs"
                Dim y As New System.IO.StreamWriter(x3)
                y.Write(gen)
                y.Dispose()



            Catch ex As Exception
                MsgBox("Eror key")
            End Try
        End If
    End Sub
    Function vbs(ByVal str As String, ByVal key As String) 'vbs asci num crypt
        Dim but As New System.Text.StringBuilder
        For i = 1 To Len(str)
            but.Append(Asc(Mid(str, i)) + key)
            but.Append(com4.Text)
        Next
        Return but.ToString.Remove(but.Length - 1)
    End Function
    Function vbsc(ByVal str As String, ByVal key As String) 'vbs asci & chrw
        Dim y As Integer
        For i = 1 To Len(str)
            y = AscW(Mid(str, i)) + key Mod 10
            vbsc = vbsc & ChrW(y)
        Next
    End Function



    Public Shared Function rand(ByVal intStrLength As Integer) As String

        Dim chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

        Dim intLength As Integer = intStrLength - 1

        Dim stringChars = New Char(intLength) {}

        Dim random = New Random()

        For i As Integer = 0 To stringChars.Length - 1
            stringChars(i) = chars(random.[Next](chars.Length))
        Next

        Dim finalString = New [String](stringChars)
        Return finalString
    End Function
End Class