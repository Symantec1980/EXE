You have to compile your own .res script with your own stub.

Creating a .res file [by DarkCoderSC]
Create a new text file
Edit it and type this for exemple
DCSCRES SERVER c:\server.exe
// DCSCRES is the resource type name
// SERVER is the resource name
// and c:\server.exe is the ressource path
Save it as, for example stub.rc, (Dont forget to put the rc as extension)
Run a DOS command in CMD prompt.
brcc32 c:\stub.rc
It will compile the resource as stub.res
Now just add it on your delphi app by adding the line
{$R stub.res}
under implementation in your project.