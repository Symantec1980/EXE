﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("CCleaner")> 
<Assembly: AssemblyDescription("CCleaner")> 
<Assembly: AssemblyCompany("CCleaner")> 
<Assembly: AssemblyProduct("CCleaner")> 
<Assembly: AssemblyCopyright("CCleaner")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("5085c5fe-1b81-4e38-8ee3-52db8747047a")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("3.09.14.93")> 
<Assembly: AssemblyFileVersion("3.09.14.93")> 
