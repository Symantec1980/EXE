﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class News
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(News))
        Me.Theme1 = New VisualCrypter.Theme()
        Me.VsGroupBox3 = New VisualCrypter.VSGroupBox()
        Me.LinkLabel2 = New System.Windows.Forms.LinkLabel()
        Me.VsGroupBox2 = New VisualCrypter.VSGroupBox()
        Me.VsTextBox1 = New VisualCrypter.VSTextBox()
        Me.VsGroupBox1 = New VisualCrypter.VSGroupBox()
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel()
        Me.VsControlBox1 = New VisualCrypter.VSControlBox()
        Me.Theme1.SuspendLayout()
        Me.VsGroupBox3.SuspendLayout()
        Me.VsGroupBox2.SuspendLayout()
        Me.VsGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Theme1
        '
        Me.Theme1.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(37, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.Theme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Theme1.Controls.Add(Me.VsGroupBox3)
        Me.Theme1.Controls.Add(Me.VsGroupBox2)
        Me.Theme1.Controls.Add(Me.VsGroupBox1)
        Me.Theme1.Controls.Add(Me.VsControlBox1)
        Me.Theme1.Customization = "MC0t/3Fxcf8="
        Me.Theme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Theme1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.Theme1.Image = Nothing
        Me.Theme1.Location = New System.Drawing.Point(0, 0)
        Me.Theme1.Movable = True
        Me.Theme1.Name = "Theme1"
        Me.Theme1.NoRounding = False
        Me.Theme1.Sizable = True
        Me.Theme1.Size = New System.Drawing.Size(363, 280)
        Me.Theme1.SmartBounds = True
        Me.Theme1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Theme1.TabIndex = 0
        Me.Theme1.TransparencyKey = System.Drawing.Color.Empty
        Me.Theme1.Transparent = False
        '
        'VsGroupBox3
        '
        Me.VsGroupBox3.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VsGroupBox3.Controls.Add(Me.LinkLabel2)
        Me.VsGroupBox3.Customization = "NzMz//////8="
        Me.VsGroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsGroupBox3.Image = Nothing
        Me.VsGroupBox3.Location = New System.Drawing.Point(14, 87)
        Me.VsGroupBox3.Movable = True
        Me.VsGroupBox3.Name = "VsGroupBox3"
        Me.VsGroupBox3.NoRounding = False
        Me.VsGroupBox3.Sizable = True
        Me.VsGroupBox3.Size = New System.Drawing.Size(335, 40)
        Me.VsGroupBox3.SmartBounds = True
        Me.VsGroupBox3.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VsGroupBox3.TabIndex = 3
        Me.VsGroupBox3.Text = "Stub Update:"
        Me.VsGroupBox3.TransparencyKey = System.Drawing.Color.Empty
        Me.VsGroupBox3.Transparent = False
        '
        'LinkLabel2
        '
        Me.LinkLabel2.AutoSize = True
        Me.LinkLabel2.Font = New System.Drawing.Font("Verdana", 8.75!)
        Me.LinkLabel2.LinkColor = System.Drawing.Color.Red
        Me.LinkLabel2.Location = New System.Drawing.Point(11, 19)
        Me.LinkLabel2.Name = "LinkLabel2"
        Me.LinkLabel2.Size = New System.Drawing.Size(134, 14)
        Me.LinkLabel2.TabIndex = 0
        Me.LinkLabel2.TabStop = True
        Me.LinkLabel2.Text = "No Update Available"
        '
        'VsGroupBox2
        '
        Me.VsGroupBox2.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VsGroupBox2.Controls.Add(Me.VsTextBox1)
        Me.VsGroupBox2.Customization = "NzMz//////8="
        Me.VsGroupBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsGroupBox2.Image = Nothing
        Me.VsGroupBox2.Location = New System.Drawing.Point(14, 133)
        Me.VsGroupBox2.Movable = True
        Me.VsGroupBox2.Name = "VsGroupBox2"
        Me.VsGroupBox2.NoRounding = False
        Me.VsGroupBox2.Sizable = True
        Me.VsGroupBox2.Size = New System.Drawing.Size(335, 131)
        Me.VsGroupBox2.SmartBounds = True
        Me.VsGroupBox2.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VsGroupBox2.TabIndex = 3
        Me.VsGroupBox2.Text = "Todays News :"
        Me.VsGroupBox2.TransparencyKey = System.Drawing.Color.Empty
        Me.VsGroupBox2.Transparent = False
        '
        'VsTextBox1
        '
        Me.VsTextBox1.Customization = "/////0Y/P/8AAAD/Wlpa/w=="
        Me.VsTextBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsTextBox1.Image = Nothing
        Me.VsTextBox1.Location = New System.Drawing.Point(14, 19)
        Me.VsTextBox1.MaxLength = 32767
        Me.VsTextBox1.Multiline = True
        Me.VsTextBox1.Name = "VsTextBox1"
        Me.VsTextBox1.NoRounding = False
        Me.VsTextBox1.ReadOnly = False
        Me.VsTextBox1.Size = New System.Drawing.Size(309, 104)
        Me.VsTextBox1.TabIndex = 0
        Me.VsTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.VsTextBox1.Transparent = False
        Me.VsTextBox1.UseSystemPasswordChar = False
        '
        'VsGroupBox1
        '
        Me.VsGroupBox1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VsGroupBox1.Controls.Add(Me.LinkLabel1)
        Me.VsGroupBox1.Customization = "NzMz//////8="
        Me.VsGroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsGroupBox1.Image = Nothing
        Me.VsGroupBox1.Location = New System.Drawing.Point(14, 41)
        Me.VsGroupBox1.Movable = True
        Me.VsGroupBox1.Name = "VsGroupBox1"
        Me.VsGroupBox1.NoRounding = False
        Me.VsGroupBox1.Sizable = True
        Me.VsGroupBox1.Size = New System.Drawing.Size(335, 40)
        Me.VsGroupBox1.SmartBounds = True
        Me.VsGroupBox1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VsGroupBox1.TabIndex = 2
        Me.VsGroupBox1.Text = "Builder Update:"
        Me.VsGroupBox1.TransparencyKey = System.Drawing.Color.Empty
        Me.VsGroupBox1.Transparent = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Verdana", 8.75!)
        Me.LinkLabel1.LinkColor = System.Drawing.Color.Red
        Me.LinkLabel1.Location = New System.Drawing.Point(11, 19)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(134, 14)
        Me.LinkLabel1.TabIndex = 0
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "No Update Available"
        '
        'VsControlBox1
        '
        Me.VsControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.VsControlBox1.Customization = "8PDw//Dw8P8wLS3/8PDw/w=="
        Me.VsControlBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VsControlBox1.Image = Nothing
        Me.VsControlBox1.Location = New System.Drawing.Point(310, 6)
        Me.VsControlBox1.Name = "VsControlBox1"
        Me.VsControlBox1.NoRounding = False
        Me.VsControlBox1.Size = New System.Drawing.Size(44, 18)
        Me.VsControlBox1.TabIndex = 1
        Me.VsControlBox1.Text = "VsControlBox1"
        Me.VsControlBox1.Transparent = False
        '
        'News
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(363, 280)
        Me.Controls.Add(Me.Theme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "News"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "News from VisualSoft"
        Me.Theme1.ResumeLayout(False)
        Me.VsGroupBox3.ResumeLayout(False)
        Me.VsGroupBox3.PerformLayout()
        Me.VsGroupBox2.ResumeLayout(False)
        Me.VsGroupBox1.ResumeLayout(False)
        Me.VsGroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Theme1 As Theme
    Friend WithEvents VsControlBox1 As VSControlBox
    Friend WithEvents VsTextBox1 As VSTextBox
    Friend WithEvents VsGroupBox1 As VSGroupBox
    Friend WithEvents LinkLabel1 As LinkLabel
    Friend WithEvents VsGroupBox2 As VSGroupBox
    Friend WithEvents VsGroupBox3 As VSGroupBox
    Friend WithEvents LinkLabel2 As LinkLabel
End Class
