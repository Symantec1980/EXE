﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace Basic_File_Encryption
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private void EncryptData(String inName, String outName, byte[] desKey, byte[] desIV)
        {
            try
            {
                //Create the file streams to handle the input and output files.
                FileStream fin = new FileStream(inName, FileMode.Open, FileAccess.Read);
                FileStream fout = new FileStream(outName, FileMode.OpenOrCreate, FileAccess.Write);
                fout.SetLength(0);

                //Create variables to help with read and write.
                byte[] bin = new byte[100]; //This is intermediate storage for the encryption.
                long rdlen = 0;              //This is the total number of bytes written.
                long totlen = fin.Length;    //This is the total length of the input file.
                int len;                     //This is the number of bytes to be written at a time.
                
                DES des = new DESCryptoServiceProvider();
                CryptoStream encStream = new CryptoStream(fout, des.CreateEncryptor(desKey, desIV), CryptoStreamMode.Write);
                //Read from the input file, then encrypt and write to the output file.
                while (rdlen < totlen)
                {
                    len = fin.Read(bin, 0, 100);
                    encStream.Write(bin, 0, len);
                    rdlen = rdlen + len;
                }
                encStream.Close();
                fout.Close();
                fin.Close();
                MessageBox.Show("The selected file has been encrypted !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("An error has occured !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void btnSelectEncryptionFile_Click(object sender, EventArgs e)
        {
            ofdEncryptionFile.ShowDialog();
        }

        private void ofdEncryptionFile_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                txtEncryptFile.Text = ofdEncryptionFile.FileName;
            }
            catch
            {
                
            }
        }

        private void btnSaveEncryptionFile_Click(object sender, EventArgs e)
        {
            sfdEncryptionFile.ShowDialog();
        }

        private void sfdEncryptionFile_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                txtSaveEncryptionFile.Text = sfdEncryptionFile.FileName;
            }
            catch
            {
            }
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtEncryptFile.Text == "")
                {
                    MessageBox.Show("Please select a file to encrypt !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (txtSaveEncryptionFile.Text == "")
                {
                    MessageBox.Show("Please select where Basic File Encryption needs to save the encrypted file !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    byte[] deskey2;
                    byte[] deskeyIV;

                    deskey2 = ASCIIEncoding.ASCII.GetBytes("ABCDEFGH");
                    deskeyIV = ASCIIEncoding.ASCII.GetBytes("ABCDEFGH");

                    EncryptData(txtEncryptFile.Text, txtSaveEncryptionFile.Text, deskey2, deskeyIV);
                }
            }
            catch
            {
            }
        }
        private void DecryptData(String inName, String outName, byte[] desKey, byte[] desIV)
        {
            try
            {
                //Create the file streams to handle the input and output files.
                FileStream fin = new FileStream(inName, FileMode.Open, FileAccess.Read);
                FileStream fout = new FileStream(outName, FileMode.OpenOrCreate, FileAccess.Write);
                fout.SetLength(0);

                //Create variables to help with read and write.
                byte[] bin = new byte[100]; //This is intermediate storage for the encryption.
                long rdlen = 0;              //This is the total number of bytes written.
                long totlen = fin.Length;    //This is the total length of the input file.
                int len;                     //This is the number of bytes to be written at a time.

                DES des = new DESCryptoServiceProvider();
                CryptoStream encStream = new CryptoStream(fout, des.CreateDecryptor(desKey, desIV), CryptoStreamMode.Write);
                //Read from the input file, then encrypt and write to the output file.
                while (rdlen < totlen)
                {
                    len = fin.Read(bin, 0, 100);
                    encStream.Write(bin, 0, len);
                    rdlen = rdlen + len;
                }
                encStream.Close();
                fout.Close();
                fin.Close();
                MessageBox.Show("The selected file has been decrypted !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch
            {
                MessageBox.Show("An error has occured !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSelectDecryptionFile_Click(object sender, EventArgs e)
        {
            ofdDecryptionFile.ShowDialog();
        }

        private void ofdDecryptionFile_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                txtDecryptionFile.Text = ofdDecryptionFile.FileName;
            }
            catch
            {
            }
        }

        private void btnSaveDecryptionFile_Click(object sender, EventArgs e)
        {
            sfdDecryptionFile.ShowDialog();
        }

        private void sfdDecryptionFile_FileOk(object sender, CancelEventArgs e)
        {
            try
            {
                txtSaveDecryptionFile.Text = sfdDecryptionFile.FileName;
            }
            catch
            {
            }
        }

        private void btnDecrypt_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtDecryptionFile.Text == "")
                {
                    MessageBox.Show("Please select a file to decrypt !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (txtSaveDecryptionFile.Text == "")
                {
                    MessageBox.Show("Please select where Basic File Encryption needs to save the decrypted file !", "Basic File Encryption", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    byte[] deskey2;
                    byte[] deskeyIV;
                    deskey2 = ASCIIEncoding.ASCII.GetBytes("ABCDEFGH");
                    deskeyIV = ASCIIEncoding.ASCII.GetBytes("ABCDEFGH");

                    DecryptData(txtDecryptionFile.Text, txtSaveDecryptionFile.Text, deskey2, deskeyIV);
                }
            }
            catch
            {
            }
        }

        private void lblInfo_Click(object sender, EventArgs e)
        {

        }
    }
}
