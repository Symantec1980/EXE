﻿Imports System.CodeDom.Compiler
Public Class iCompiler
    Public Shared Sub GenerateExecutable(ByVal Output As String, ByVal Source As String, ByVal Icon As String)
        On Error Resume Next

        Dim uyghfy7tegyuhf7egyufh7y4uy7tg64yhf764y As ICodeCompiler = (New VBCodeProvider).CreateCompiler()
        Dim jhgbnuyehufhgy3ebnfuyb3tghbjnwuye As New CompilerParameters()
        Dim fhbenmigf7y4unmig76yt4hugjhybhn As CompilerResults

        jhgbnuyehufhgy3ebnfuyb3tghbjnwuye.GenerateExecutable = True
        jhgbnuyehufhgy3ebnfuyb3tghbjnwuye.OutputAssembly = Output
        jhgbnuyehufhgy3ebnfuyb3tghbjnwuye.CompilerOptions = "/target:winexe"
        jhgbnuyehufhgy3ebnfuyb3tghbjnwuye.ReferencedAssemblies.Add("System.dll")
        jhgbnuyehufhgy3ebnfuyb3tghbjnwuye.ReferencedAssemblies.Add("System.Data.dll")

        Dim Version = New Dictionary(Of String, String)
        Version.Add("CompilerVersion", "v2.0")

        jhgbnuyehufhgy3ebnfuyb3tghbjnwuye.CompilerOptions = "/filealign:0x00200 /optimize+ /platform:X86 /debug- /target:winexe"

        Dim ICO As String = IO.Path.GetTempPath & "\iCompiler.ico"

        If Icon <> "" Then
            IO.File.Copy(Icon, ICO)
            jhgbnuyehufhgy3ebnfuyb3tghbjnwuye.CompilerOptions &= " /win32icon:" & ICO
        End If

        fhbenmigf7y4unmig76yt4hugjhybhn = uyghfy7tegyuhf7egyufh7y4uy7tg64yhf764y.CompileAssemblyFromSource(jhgbnuyehufhgy3ebnfuyb3tghbjnwuye, Source)

        If fhbenmigf7y4unmig76yt4hugjhybhn.Errors.Count > 0 Then
            For Each CompilerError In fhbenmigf7y4unmig76yt4hugjhybhn.Errors
                MessageBox.Show("Error: " & CompilerError.ErrorText, "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Next
        ElseIf fhbenmigf7y4unmig76yt4hugjhybhn.Errors.Count = 0 Then

        End If
        If Icon <> "" Then : IO.File.Delete(ICO) : End If
    End Sub
End Class
