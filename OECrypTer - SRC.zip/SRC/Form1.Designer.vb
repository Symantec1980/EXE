﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ReconButton1 = New Client.ReconButton()
        Me.ReconButton2 = New Client.ReconButton()
        Me.ReconButton4 = New Client.ReconButton()
        Me.TxtBox1 = New Client.TxtBox()
        Me.ReconButton5 = New Client.ReconButton()
        Me.TxtBox3 = New Client.TxtBox()
        Me.ReconForm1 = New Client.ReconForm()
        Me.ReconBar1 = New Client.ReconBar()
        Me.ReconCheckBox1 = New Client.ReconCheckBox()
        Me.ReconSeperator2 = New Client.ReconSeperator()
        Me.ReconCheck1 = New Client.ReconCheck()
        Me.ReconSeperator1 = New Client.ReconSeperator()
        Me.ReconForm1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ReconButton1
        '
        Me.ReconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton1.ForeColor = System.Drawing.Color.LightYellow
        Me.ReconButton1.Image = Nothing
        Me.ReconButton1.Location = New System.Drawing.Point(369, 6)
        Me.ReconButton1.Name = "ReconButton1"
        Me.ReconButton1.NoRounding = False
        Me.ReconButton1.Size = New System.Drawing.Size(28, 19)
        Me.ReconButton1.TabIndex = 0
        Me.ReconButton1.Text = "X"
        '
        'ReconButton2
        '
        Me.ReconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton2.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconButton2.ForeColor = System.Drawing.Color.Blue
        Me.ReconButton2.Image = Nothing
        Me.ReconButton2.Location = New System.Drawing.Point(33, 48)
        Me.ReconButton2.Name = "ReconButton2"
        Me.ReconButton2.NoRounding = False
        Me.ReconButton2.Size = New System.Drawing.Size(323, 26)
        Me.ReconButton2.TabIndex = 2
        Me.ReconButton2.Text = "Browse File"
        '
        'ReconButton4
        '
        Me.ReconButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton4.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconButton4.ForeColor = System.Drawing.Color.YellowGreen
        Me.ReconButton4.Image = Nothing
        Me.ReconButton4.Location = New System.Drawing.Point(33, 253)
        Me.ReconButton4.Name = "ReconButton4"
        Me.ReconButton4.NoRounding = False
        Me.ReconButton4.Size = New System.Drawing.Size(323, 25)
        Me.ReconButton4.TabIndex = 4
        Me.ReconButton4.Text = "Crypte"
        '
        'TxtBox1
        '
        Me.TxtBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.TxtBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.TxtBox1.ForeColor = System.Drawing.Color.LightGray
        Me.TxtBox1.Location = New System.Drawing.Point(33, 80)
        Me.TxtBox1.Name = "TxtBox1"
        Me.TxtBox1.Size = New System.Drawing.Size(323, 20)
        Me.TxtBox1.TabIndex = 5
        '
        'ReconButton5
        '
        Me.ReconButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton5.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconButton5.ForeColor = System.Drawing.Color.LightGreen
        Me.ReconButton5.Image = Nothing
        Me.ReconButton5.Location = New System.Drawing.Point(33, 107)
        Me.ReconButton5.Name = "ReconButton5"
        Me.ReconButton5.NoRounding = False
        Me.ReconButton5.Size = New System.Drawing.Size(323, 24)
        Me.ReconButton5.TabIndex = 9
        Me.ReconButton5.Text = "Browse Stub"
        '
        'TxtBox3
        '
        Me.TxtBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.TxtBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.TxtBox3.ForeColor = System.Drawing.Color.LightGray
        Me.TxtBox3.Location = New System.Drawing.Point(33, 137)
        Me.TxtBox3.Name = "TxtBox3"
        Me.TxtBox3.Size = New System.Drawing.Size(323, 20)
        Me.TxtBox3.TabIndex = 10
        '
        'ReconForm1
        '
        Me.ReconForm1.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.ReconForm1.Controls.Add(Me.ReconBar1)
        Me.ReconForm1.Controls.Add(Me.ReconCheckBox1)
        Me.ReconForm1.Controls.Add(Me.ReconSeperator2)
        Me.ReconForm1.Controls.Add(Me.ReconCheck1)
        Me.ReconForm1.Controls.Add(Me.ReconSeperator1)
        Me.ReconForm1.Controls.Add(Me.TxtBox3)
        Me.ReconForm1.Controls.Add(Me.ReconButton5)
        Me.ReconForm1.Controls.Add(Me.TxtBox1)
        Me.ReconForm1.Controls.Add(Me.ReconButton4)
        Me.ReconForm1.Controls.Add(Me.ReconButton2)
        Me.ReconForm1.Controls.Add(Me.ReconButton1)
        Me.ReconForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReconForm1.Font = New System.Drawing.Font("Segoe UI Semibold", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconForm1.ForeColor = System.Drawing.Color.CornflowerBlue
        Me.ReconForm1.Image = Nothing
        Me.ReconForm1.Location = New System.Drawing.Point(0, 0)
        Me.ReconForm1.MoveHeight = 30
        Me.ReconForm1.Name = "ReconForm1"
        Me.ReconForm1.Resizable = True
        Me.ReconForm1.ShowIcon = False
        Me.ReconForm1.Size = New System.Drawing.Size(406, 338)
        Me.ReconForm1.TabIndex = 0
        Me.ReconForm1.Text = "OECrypTer - V0.4"
        Me.ReconForm1.TextAlignment = Client.ReconForm.TextAlign.Left
        Me.ReconForm1.TransparencyKey = System.Drawing.Color.Fuchsia
        '
        'ReconBar1
        '
        Me.ReconBar1.Image = Nothing
        Me.ReconBar1.Location = New System.Drawing.Point(33, 303)
        Me.ReconBar1.Maximum = 0
        Me.ReconBar1.Name = "ReconBar1"
        Me.ReconBar1.NoRounding = False
        Me.ReconBar1.Size = New System.Drawing.Size(323, 23)
        Me.ReconBar1.TabIndex = 17
        Me.ReconBar1.Text = "ReconBar1"
        Me.ReconBar1.Value = 0
        '
        'ReconCheckBox1
        '
        Me.ReconCheckBox1.CheckedState = False
        Me.ReconCheckBox1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconCheckBox1.Image = Nothing
        Me.ReconCheckBox1.Location = New System.Drawing.Point(12, 202)
        Me.ReconCheckBox1.MaximumSize = New System.Drawing.Size(600, 16)
        Me.ReconCheckBox1.MinimumSize = New System.Drawing.Size(16, 16)
        Me.ReconCheckBox1.Name = "ReconCheckBox1"
        Me.ReconCheckBox1.NoRounding = False
        Me.ReconCheckBox1.Size = New System.Drawing.Size(98, 16)
        Me.ReconCheckBox1.TabIndex = 16
        Me.ReconCheckBox1.Text = "Obuscator"
        '
        'ReconSeperator2
        '
        Me.ReconSeperator2.Location = New System.Drawing.Point(0, 245)
        Me.ReconSeperator2.MaximumSize = New System.Drawing.Size(10000, 2)
        Me.ReconSeperator2.MinimumSize = New System.Drawing.Size(5, 2)
        Me.ReconSeperator2.Name = "ReconSeperator2"
        Me.ReconSeperator2.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.ReconSeperator2.Size = New System.Drawing.Size(444, 2)
        Me.ReconSeperator2.TabIndex = 15
        Me.ReconSeperator2.Text = "ReconSeperator2"
        '
        'ReconCheck1
        '
        Me.ReconCheck1.CheckedState = False
        Me.ReconCheck1.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconCheck1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ReconCheck1.Image = Nothing
        Me.ReconCheck1.Location = New System.Drawing.Point(12, 179)
        Me.ReconCheck1.MaximumSize = New System.Drawing.Size(600, 16)
        Me.ReconCheck1.MinimumSize = New System.Drawing.Size(16, 16)
        Me.ReconCheck1.Name = "ReconCheck1"
        Me.ReconCheck1.NoRounding = False
        Me.ReconCheck1.Size = New System.Drawing.Size(100, 16)
        Me.ReconCheck1.TabIndex = 12
        Me.ReconCheck1.Text = "USB Spread"
        '
        'ReconSeperator1
        '
        Me.ReconSeperator1.Location = New System.Drawing.Point(3, 171)
        Me.ReconSeperator1.MaximumSize = New System.Drawing.Size(10000, 2)
        Me.ReconSeperator1.MinimumSize = New System.Drawing.Size(5, 2)
        Me.ReconSeperator1.Name = "ReconSeperator1"
        Me.ReconSeperator1.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.ReconSeperator1.Size = New System.Drawing.Size(400, 2)
        Me.ReconSeperator1.TabIndex = 11
        Me.ReconSeperator1.Text = "ReconSeperator1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(406, 338)
        Me.Controls.Add(Me.ReconForm1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ReconForm1.ResumeLayout(False)
        Me.ReconForm1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReconButton1 As Client.ReconButton
    Friend WithEvents ReconButton2 As Client.ReconButton
    Friend WithEvents ReconButton4 As Client.ReconButton
    Friend WithEvents TxtBox1 As Client.TxtBox
    Friend WithEvents ReconButton5 As Client.ReconButton
    Friend WithEvents TxtBox3 As Client.TxtBox
    Friend WithEvents ReconForm1 As Client.ReconForm
    Friend WithEvents ReconSeperator2 As Client.ReconSeperator
    Friend WithEvents ReconCheck1 As Client.ReconCheck
    Friend WithEvents ReconSeperator1 As Client.ReconSeperator
    Friend WithEvents ReconCheckBox1 As Client.ReconCheckBox
    Friend WithEvents ReconBar1 As Client.ReconBar

End Class
