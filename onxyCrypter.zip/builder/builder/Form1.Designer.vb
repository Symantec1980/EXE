﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.VTheme1 = New Onyx.VTheme()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.VTabControl1 = New Onyx.VTabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.VGroupBox4 = New Onyx.VGroupBox()
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.VSeperator1 = New Onyx.VSeperator()
        Me.VGroupBox2 = New Onyx.VGroupBox()
        Me.VGroupBox3 = New Onyx.VGroupBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.VButton3 = New Onyx.VButton()
        Me.VTextBox2 = New Onyx.VTextBox()
        Me.VGroupBox1 = New Onyx.VGroupBox()
        Me.VRadiobutton2 = New Onyx.VRadiobutton()
        Me.VRadiobutton1 = New Onyx.VRadiobutton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.VButton2 = New Onyx.VButton()
        Me.VTextBox1 = New Onyx.VTextBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.VGroupBox6 = New Onyx.VGroupBox()
        Me.VGroupBox7 = New Onyx.VGroupBox()
        Me.VRadiobutton4 = New Onyx.VRadiobutton()
        Me.VRadiobutton3 = New Onyx.VRadiobutton()
        Me.VCheckBox1 = New Onyx.VCheckBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.VTextBox10 = New Onyx.VTextBox()
        Me.VTextBox12 = New Onyx.VTextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.VTextBox11 = New Onyx.VTextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.GhostComboBox1 = New Onyx.GhostComboBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.VSeperator2 = New Onyx.VSeperator()
        Me.VGroupBox5 = New Onyx.VGroupBox()
        Me.VButton6 = New Onyx.VButton()
        Me.VButton4 = New Onyx.VButton()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.VTextBox9 = New Onyx.VTextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.VTextBox8 = New Onyx.VTextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.VTextBox7 = New Onyx.VTextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.VTextBox6 = New Onyx.VTextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.VTextBox5 = New Onyx.VTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.VTextBox4 = New Onyx.VTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.VTextBox3 = New Onyx.VTextBox()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.VGroupBox12 = New Onyx.VGroupBox()
        Me.VTextBox19 = New Onyx.VTextBox()
        Me.VTextBox18 = New Onyx.VTextBox()
        Me.VCheckBox7 = New Onyx.VCheckBox()
        Me.VGroupBox11 = New Onyx.VGroupBox()
        Me.VButton5 = New Onyx.VButton()
        Me.VTextBox17 = New Onyx.VTextBox()
        Me.VCheckBox6 = New Onyx.VCheckBox()
        Me.VGroupBox10 = New Onyx.VGroupBox()
        Me.VTextBox16 = New Onyx.VTextBox()
        Me.VCheckBox5 = New Onyx.VCheckBox()
        Me.VSeperator3 = New Onyx.VSeperator()
        Me.VGroupBox9 = New Onyx.VGroupBox()
        Me.VTextBox15 = New Onyx.VTextBox()
        Me.VCheckBox4 = New Onyx.VCheckBox()
        Me.VTextBox14 = New Onyx.VTextBox()
        Me.VCheckBox3 = New Onyx.VCheckBox()
        Me.VCheckBox2 = New Onyx.VCheckBox()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.VGroupBox13 = New Onyx.VGroupBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.VButton1 = New Onyx.VButton()
        Me.VTextBox13 = New Onyx.VTextBox()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.VTheme1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VTabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.VGroupBox4.SuspendLayout()
        Me.VGroupBox2.SuspendLayout()
        Me.VGroupBox3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.VGroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.VGroupBox6.SuspendLayout()
        Me.VGroupBox7.SuspendLayout()
        Me.VGroupBox5.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.VGroupBox12.SuspendLayout()
        Me.VGroupBox11.SuspendLayout()
        Me.VGroupBox10.SuspendLayout()
        Me.VGroupBox9.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.VGroupBox13.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VTheme1
        '
        Me.VTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VTheme1.Colors = New Onyx.Bloom(-1) {}
        Me.VTheme1.Controls.Add(Me.PictureBox1)
        Me.VTheme1.Controls.Add(Me.VTabControl1)
        Me.VTheme1.Customization = ""
        Me.VTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.VTheme1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTheme1.Image = Nothing
        Me.VTheme1.Location = New System.Drawing.Point(0, 0)
        Me.VTheme1.Movable = True
        Me.VTheme1.Name = "VTheme1"
        Me.VTheme1.NoRounding = False
        Me.VTheme1.Sizable = True
        Me.VTheme1.Size = New System.Drawing.Size(817, 318)
        Me.VTheme1.SmartBounds = True
        Me.VTheme1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.VTheme1.TabIndex = 0
        Me.VTheme1.Text = "  nyx Crypter"
        Me.VTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.VTheme1.Transparent = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Location = New System.Drawing.Point(3, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(35, 35)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'VTabControl1
        '
        Me.VTabControl1.Controls.Add(Me.TabPage1)
        Me.VTabControl1.Controls.Add(Me.TabPage2)
        Me.VTabControl1.Controls.Add(Me.TabPage3)
        Me.VTabControl1.Controls.Add(Me.TabPage4)
        Me.VTabControl1.Controls.Add(Me.TabPage5)
        Me.VTabControl1.Controls.Add(Me.TabPage6)
        Me.VTabControl1.Location = New System.Drawing.Point(12, 38)
        Me.VTabControl1.Name = "VTabControl1"
        Me.VTabControl1.SelectedIndex = 0
        Me.VTabControl1.Size = New System.Drawing.Size(793, 268)
        Me.VTabControl1.Speed = -20
        Me.VTabControl1.TabIndex = 2
        Me.VTabControl1.TabTextColor = System.Drawing.Color.DarkMagenta
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.VGroupBox4)
        Me.TabPage1.Controls.Add(Me.VSeperator1)
        Me.TabPage1.Controls.Add(Me.VGroupBox2)
        Me.TabPage1.Controls.Add(Me.VGroupBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(785, 239)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Main"
        '
        'VGroupBox4
        '
        Me.VGroupBox4.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox4.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox4.Controls.Add(Me.ListView1)
        Me.VGroupBox4.Controls.Add(Me.Label8)
        Me.VGroupBox4.Controls.Add(Me.Label7)
        Me.VGroupBox4.Controls.Add(Me.Label6)
        Me.VGroupBox4.Controls.Add(Me.Label5)
        Me.VGroupBox4.Controls.Add(Me.Label4)
        Me.VGroupBox4.Controls.Add(Me.Label3)
        Me.VGroupBox4.Customization = ""
        Me.VGroupBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox4.Image = Nothing
        Me.VGroupBox4.Location = New System.Drawing.Point(6, 6)
        Me.VGroupBox4.Movable = True
        Me.VGroupBox4.Name = "VGroupBox4"
        Me.VGroupBox4.NoRounding = False
        Me.VGroupBox4.Sizable = True
        Me.VGroupBox4.Size = New System.Drawing.Size(379, 228)
        Me.VGroupBox4.SmartBounds = True
        Me.VGroupBox4.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox4.TabIndex = 5
        Me.VGroupBox4.Text = "VGroupBox4"
        Me.VGroupBox4.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox4.Transparent = False
        '
        'ListView1
        '
        Me.ListView1.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListView1.Location = New System.Drawing.Point(262, 118)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(53, 57)
        Me.ListView1.TabIndex = 9
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label8.Location = New System.Drawing.Point(22, 86)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(33, 13)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Stub"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label7.Location = New System.Drawing.Point(22, 73)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(43, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Online"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label6.Location = New System.Drawing.Point(22, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 13)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "LICType"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label5.Location = New System.Drawing.Point(22, 45)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Time"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label4.Location = New System.Drawing.Point(22, 30)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(91, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "ExpirationDate"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label3.Location = New System.Drawing.Point(22, 17)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Username"
        '
        'VSeperator1
        '
        Me.VSeperator1.BackColor = System.Drawing.Color.Transparent
        Me.VSeperator1.Colors = New Onyx.Bloom(-1) {}
        Me.VSeperator1.Customization = ""
        Me.VSeperator1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VSeperator1.Image = Nothing
        Me.VSeperator1.Location = New System.Drawing.Point(391, 6)
        Me.VSeperator1.Name = "VSeperator1"
        Me.VSeperator1.NoRounding = False
        Me.VSeperator1.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.VSeperator1.Size = New System.Drawing.Size(14, 228)
        Me.VSeperator1.TabIndex = 4
        Me.VSeperator1.Text = "VSeperator1"
        Me.VSeperator1.Transparent = True
        '
        'VGroupBox2
        '
        Me.VGroupBox2.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox2.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox2.Controls.Add(Me.VGroupBox3)
        Me.VGroupBox2.Controls.Add(Me.Label2)
        Me.VGroupBox2.Controls.Add(Me.VButton3)
        Me.VGroupBox2.Controls.Add(Me.VTextBox2)
        Me.VGroupBox2.Customization = ""
        Me.VGroupBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox2.Image = Nothing
        Me.VGroupBox2.Location = New System.Drawing.Point(411, 123)
        Me.VGroupBox2.Movable = True
        Me.VGroupBox2.Name = "VGroupBox2"
        Me.VGroupBox2.NoRounding = False
        Me.VGroupBox2.Sizable = True
        Me.VGroupBox2.Size = New System.Drawing.Size(349, 111)
        Me.VGroupBox2.SmartBounds = True
        Me.VGroupBox2.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox2.TabIndex = 3
        Me.VGroupBox2.Text = "VGroupBox2"
        Me.VGroupBox2.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox2.Transparent = False
        '
        'VGroupBox3
        '
        Me.VGroupBox3.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox3.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox3.Controls.Add(Me.PictureBox3)
        Me.VGroupBox3.Customization = ""
        Me.VGroupBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox3.Image = Nothing
        Me.VGroupBox3.Location = New System.Drawing.Point(243, 17)
        Me.VGroupBox3.Movable = True
        Me.VGroupBox3.Name = "VGroupBox3"
        Me.VGroupBox3.NoRounding = False
        Me.VGroupBox3.Sizable = True
        Me.VGroupBox3.Size = New System.Drawing.Size(89, 75)
        Me.VGroupBox3.SmartBounds = True
        Me.VGroupBox3.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox3.TabIndex = 4
        Me.VGroupBox3.Text = "VGroupBox3"
        Me.VGroupBox3.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox3.Transparent = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), System.Drawing.Image)
        Me.PictureBox3.Location = New System.Drawing.Point(8, 9)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(72, 55)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 0
        Me.PictureBox3.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label2.Location = New System.Drawing.Point(14, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Icon"
        '
        'VButton3
        '
        Me.VButton3.Colors = New Onyx.Bloom(-1) {}
        Me.VButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.VButton3.Customization = ""
        Me.VButton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VButton3.Image = Nothing
        Me.VButton3.Location = New System.Drawing.Point(17, 64)
        Me.VButton3.Name = "VButton3"
        Me.VButton3.NoRounding = False
        Me.VButton3.Size = New System.Drawing.Size(210, 28)
        Me.VButton3.TabIndex = 2
        Me.VButton3.Text = "Browse"
        Me.VButton3.Transparent = False
        '
        'VTextBox2
        '
        Me.VTextBox2.AllowDrop = True
        Me.VTextBox2.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox2.Customization = ""
        Me.VTextBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox2.Image = Nothing
        Me.VTextBox2.Location = New System.Drawing.Point(17, 33)
        Me.VTextBox2.MaxCharacters = 0
        Me.VTextBox2.Multiline = False
        Me.VTextBox2.Name = "VTextBox2"
        Me.VTextBox2.NoRounding = False
        Me.VTextBox2.Size = New System.Drawing.Size(210, 25)
        Me.VTextBox2.TabIndex = 0
        Me.VTextBox2.Text = "              Drag 'n Drop"
        Me.VTextBox2.Transparent = False
        Me.VTextBox2.UsePasswordMask = False
        '
        'VGroupBox1
        '
        Me.VGroupBox1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox1.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox1.Controls.Add(Me.VRadiobutton2)
        Me.VGroupBox1.Controls.Add(Me.VRadiobutton1)
        Me.VGroupBox1.Controls.Add(Me.Label1)
        Me.VGroupBox1.Controls.Add(Me.VButton2)
        Me.VGroupBox1.Controls.Add(Me.VTextBox1)
        Me.VGroupBox1.Customization = ""
        Me.VGroupBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox1.Image = Nothing
        Me.VGroupBox1.Location = New System.Drawing.Point(411, 6)
        Me.VGroupBox1.Movable = True
        Me.VGroupBox1.Name = "VGroupBox1"
        Me.VGroupBox1.NoRounding = False
        Me.VGroupBox1.Sizable = True
        Me.VGroupBox1.Size = New System.Drawing.Size(349, 111)
        Me.VGroupBox1.SmartBounds = True
        Me.VGroupBox1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox1.TabIndex = 1
        Me.VGroupBox1.Text = "VGroupBox1"
        Me.VGroupBox1.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox1.Transparent = False
        '
        'VRadiobutton2
        '
        Me.VRadiobutton2.BackColor = System.Drawing.Color.Transparent
        Me.VRadiobutton2.Checked = False
        Me.VRadiobutton2.Colors = New Onyx.Bloom(-1) {}
        Me.VRadiobutton2.Customization = ""
        Me.VRadiobutton2.Enabled = False
        Me.VRadiobutton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VRadiobutton2.Image = Nothing
        Me.VRadiobutton2.Location = New System.Drawing.Point(233, 56)
        Me.VRadiobutton2.Name = "VRadiobutton2"
        Me.VRadiobutton2.NoRounding = False
        Me.VRadiobutton2.Size = New System.Drawing.Size(78, 17)
        Me.VRadiobutton2.TabIndex = 4
        Me.VRadiobutton2.Text = "Managed"
        Me.VRadiobutton2.Transparent = True
        '
        'VRadiobutton1
        '
        Me.VRadiobutton1.BackColor = System.Drawing.Color.Transparent
        Me.VRadiobutton1.Checked = False
        Me.VRadiobutton1.Colors = New Onyx.Bloom(-1) {}
        Me.VRadiobutton1.Customization = ""
        Me.VRadiobutton1.Enabled = False
        Me.VRadiobutton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VRadiobutton1.Image = Nothing
        Me.VRadiobutton1.Location = New System.Drawing.Point(233, 33)
        Me.VRadiobutton1.Name = "VRadiobutton1"
        Me.VRadiobutton1.NoRounding = False
        Me.VRadiobutton1.Size = New System.Drawing.Size(64, 17)
        Me.VRadiobutton1.TabIndex = 3
        Me.VRadiobutton1.Text = "Native"
        Me.VRadiobutton1.Transparent = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label1.Location = New System.Drawing.Point(14, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Executable"
        '
        'VButton2
        '
        Me.VButton2.Colors = New Onyx.Bloom(-1) {}
        Me.VButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.VButton2.Customization = ""
        Me.VButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VButton2.Image = Nothing
        Me.VButton2.Location = New System.Drawing.Point(17, 64)
        Me.VButton2.Name = "VButton2"
        Me.VButton2.NoRounding = False
        Me.VButton2.Size = New System.Drawing.Size(210, 28)
        Me.VButton2.TabIndex = 2
        Me.VButton2.Text = "Browse"
        Me.VButton2.Transparent = False
        '
        'VTextBox1
        '
        Me.VTextBox1.AllowDrop = True
        Me.VTextBox1.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox1.Customization = ""
        Me.VTextBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox1.Image = Nothing
        Me.VTextBox1.Location = New System.Drawing.Point(17, 33)
        Me.VTextBox1.MaxCharacters = 0
        Me.VTextBox1.Multiline = False
        Me.VTextBox1.Name = "VTextBox1"
        Me.VTextBox1.NoRounding = False
        Me.VTextBox1.Size = New System.Drawing.Size(210, 25)
        Me.VTextBox1.TabIndex = 0
        Me.VTextBox1.Text = "              Drag 'n Drop"
        Me.VTextBox1.Transparent = False
        Me.VTextBox1.UsePasswordMask = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.VGroupBox6)
        Me.TabPage2.Controls.Add(Me.VSeperator2)
        Me.TabPage2.Controls.Add(Me.VGroupBox5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(785, 239)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Settings"
        '
        'VGroupBox6
        '
        Me.VGroupBox6.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox6.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox6.Controls.Add(Me.VGroupBox7)
        Me.VGroupBox6.Controls.Add(Me.GhostComboBox1)
        Me.VGroupBox6.Controls.Add(Me.Label16)
        Me.VGroupBox6.Customization = ""
        Me.VGroupBox6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox6.Image = Nothing
        Me.VGroupBox6.Location = New System.Drawing.Point(347, 7)
        Me.VGroupBox6.Movable = True
        Me.VGroupBox6.Name = "VGroupBox6"
        Me.VGroupBox6.NoRounding = False
        Me.VGroupBox6.Sizable = True
        Me.VGroupBox6.Size = New System.Drawing.Size(419, 212)
        Me.VGroupBox6.SmartBounds = True
        Me.VGroupBox6.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox6.TabIndex = 2
        Me.VGroupBox6.Text = "VGroupBox6"
        Me.VGroupBox6.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox6.Transparent = False
        '
        'VGroupBox7
        '
        Me.VGroupBox7.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox7.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox7.Controls.Add(Me.VRadiobutton4)
        Me.VGroupBox7.Controls.Add(Me.VRadiobutton3)
        Me.VGroupBox7.Controls.Add(Me.VCheckBox1)
        Me.VGroupBox7.Controls.Add(Me.Label20)
        Me.VGroupBox7.Controls.Add(Me.VTextBox10)
        Me.VGroupBox7.Controls.Add(Me.VTextBox12)
        Me.VGroupBox7.Controls.Add(Me.Label17)
        Me.VGroupBox7.Controls.Add(Me.VTextBox11)
        Me.VGroupBox7.Controls.Add(Me.Label18)
        Me.VGroupBox7.Customization = ""
        Me.VGroupBox7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox7.Image = Nothing
        Me.VGroupBox7.Location = New System.Drawing.Point(16, 58)
        Me.VGroupBox7.Movable = True
        Me.VGroupBox7.Name = "VGroupBox7"
        Me.VGroupBox7.NoRounding = False
        Me.VGroupBox7.Sizable = True
        Me.VGroupBox7.Size = New System.Drawing.Size(311, 133)
        Me.VGroupBox7.SmartBounds = True
        Me.VGroupBox7.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox7.TabIndex = 28
        Me.VGroupBox7.Text = "VGroupBox7"
        Me.VGroupBox7.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox7.Transparent = False
        '
        'VRadiobutton4
        '
        Me.VRadiobutton4.BackColor = System.Drawing.Color.Transparent
        Me.VRadiobutton4.Checked = False
        Me.VRadiobutton4.Colors = New Onyx.Bloom(-1) {}
        Me.VRadiobutton4.Customization = ""
        Me.VRadiobutton4.Enabled = False
        Me.VRadiobutton4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VRadiobutton4.Image = Nothing
        Me.VRadiobutton4.Location = New System.Drawing.Point(241, 91)
        Me.VRadiobutton4.Name = "VRadiobutton4"
        Me.VRadiobutton4.NoRounding = False
        Me.VRadiobutton4.Size = New System.Drawing.Size(59, 17)
        Me.VRadiobutton4.TabIndex = 29
        Me.VRadiobutton4.Text = "Temp"
        Me.VRadiobutton4.Transparent = True
        '
        'VRadiobutton3
        '
        Me.VRadiobutton3.BackColor = System.Drawing.Color.Transparent
        Me.VRadiobutton3.Checked = True
        Me.VRadiobutton3.Colors = New Onyx.Bloom(-1) {}
        Me.VRadiobutton3.Customization = ""
        Me.VRadiobutton3.Enabled = False
        Me.VRadiobutton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VRadiobutton3.Image = Nothing
        Me.VRadiobutton3.Location = New System.Drawing.Point(159, 91)
        Me.VRadiobutton3.Name = "VRadiobutton3"
        Me.VRadiobutton3.NoRounding = False
        Me.VRadiobutton3.Size = New System.Drawing.Size(76, 17)
        Me.VRadiobutton3.TabIndex = 28
        Me.VRadiobutton3.Text = "AppData"
        Me.VRadiobutton3.Transparent = True
        '
        'VCheckBox1
        '
        Me.VCheckBox1.BackColor = System.Drawing.Color.Transparent
        Me.VCheckBox1.Checked = False
        Me.VCheckBox1.Colors = New Onyx.Bloom(-1) {}
        Me.VCheckBox1.Customization = ""
        Me.VCheckBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VCheckBox1.Image = Nothing
        Me.VCheckBox1.Location = New System.Drawing.Point(3, 3)
        Me.VCheckBox1.Name = "VCheckBox1"
        Me.VCheckBox1.NoRounding = False
        Me.VCheckBox1.Size = New System.Drawing.Size(138, 20)
        Me.VCheckBox1.TabIndex = 19
        Me.VCheckBox1.Text = "Add to Startup"
        Me.VCheckBox1.Transparent = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Enabled = False
        Me.Label20.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label20.Location = New System.Drawing.Point(156, 27)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(68, 13)
        Me.Label20.TabIndex = 27
        Me.Label20.Text = "Sub Folder"
        '
        'VTextBox10
        '
        Me.VTextBox10.AllowDrop = True
        Me.VTextBox10.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox10.Customization = ""
        Me.VTextBox10.Enabled = False
        Me.VTextBox10.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox10.Image = Nothing
        Me.VTextBox10.Location = New System.Drawing.Point(12, 43)
        Me.VTextBox10.MaxCharacters = 0
        Me.VTextBox10.Multiline = False
        Me.VTextBox10.Name = "VTextBox10"
        Me.VTextBox10.NoRounding = False
        Me.VTextBox10.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox10.TabIndex = 20
        Me.VTextBox10.Text = "Java(TM) Platform SE Auto Updater 2 1"
        Me.VTextBox10.Transparent = False
        Me.VTextBox10.UsePasswordMask = False
        '
        'VTextBox12
        '
        Me.VTextBox12.AllowDrop = True
        Me.VTextBox12.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox12.Customization = ""
        Me.VTextBox12.Enabled = False
        Me.VTextBox12.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox12.Image = Nothing
        Me.VTextBox12.Location = New System.Drawing.Point(159, 43)
        Me.VTextBox12.MaxCharacters = 0
        Me.VTextBox12.Multiline = False
        Me.VTextBox12.Name = "VTextBox12"
        Me.VTextBox12.NoRounding = False
        Me.VTextBox12.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox12.TabIndex = 26
        Me.VTextBox12.Text = "Java Update"
        Me.VTextBox12.Transparent = False
        Me.VTextBox12.UsePasswordMask = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Enabled = False
        Me.Label17.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label17.Location = New System.Drawing.Point(9, 27)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(66, 13)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "Key Name"
        '
        'VTextBox11
        '
        Me.VTextBox11.AllowDrop = True
        Me.VTextBox11.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox11.Customization = ""
        Me.VTextBox11.Enabled = False
        Me.VTextBox11.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox11.Image = Nothing
        Me.VTextBox11.Location = New System.Drawing.Point(12, 87)
        Me.VTextBox11.MaxCharacters = 0
        Me.VTextBox11.Multiline = False
        Me.VTextBox11.Name = "VTextBox11"
        Me.VTextBox11.NoRounding = False
        Me.VTextBox11.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox11.TabIndex = 22
        Me.VTextBox11.Text = "JavaSE.exe"
        Me.VTextBox11.Transparent = False
        Me.VTextBox11.UsePasswordMask = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Enabled = False
        Me.Label18.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label18.Location = New System.Drawing.Point(9, 71)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(63, 13)
        Me.Label18.TabIndex = 23
        Me.Label18.Text = "File Name"
        '
        'GhostComboBox1
        '
        Me.GhostComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(90, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.GhostComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.GhostComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.GhostComboBox1.ForeColor = System.Drawing.Color.DarkMagenta
        Me.GhostComboBox1.FormattingEnabled = True
        Me.GhostComboBox1.ItemHeight = 20
        Me.GhostComboBox1.Location = New System.Drawing.Point(16, 26)
        Me.GhostComboBox1.Name = "GhostComboBox1"
        Me.GhostComboBox1.Size = New System.Drawing.Size(150, 26)
        Me.GhostComboBox1.TabIndex = 18
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label16.Location = New System.Drawing.Point(13, 10)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(57, 13)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Injection"
        '
        'VSeperator2
        '
        Me.VSeperator2.BackColor = System.Drawing.Color.Transparent
        Me.VSeperator2.Colors = New Onyx.Bloom(-1) {}
        Me.VSeperator2.Customization = ""
        Me.VSeperator2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VSeperator2.Image = Nothing
        Me.VSeperator2.Location = New System.Drawing.Point(327, 6)
        Me.VSeperator2.Name = "VSeperator2"
        Me.VSeperator2.NoRounding = False
        Me.VSeperator2.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.VSeperator2.Size = New System.Drawing.Size(14, 227)
        Me.VSeperator2.TabIndex = 1
        Me.VSeperator2.Text = "VSeperator2"
        Me.VSeperator2.Transparent = True
        '
        'VGroupBox5
        '
        Me.VGroupBox5.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox5.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox5.Controls.Add(Me.VButton6)
        Me.VGroupBox5.Controls.Add(Me.VButton4)
        Me.VGroupBox5.Controls.Add(Me.Label15)
        Me.VGroupBox5.Controls.Add(Me.VTextBox9)
        Me.VGroupBox5.Controls.Add(Me.Label14)
        Me.VGroupBox5.Controls.Add(Me.VTextBox8)
        Me.VGroupBox5.Controls.Add(Me.Label13)
        Me.VGroupBox5.Controls.Add(Me.VTextBox7)
        Me.VGroupBox5.Controls.Add(Me.Label12)
        Me.VGroupBox5.Controls.Add(Me.VTextBox6)
        Me.VGroupBox5.Controls.Add(Me.Label11)
        Me.VGroupBox5.Controls.Add(Me.VTextBox5)
        Me.VGroupBox5.Controls.Add(Me.Label10)
        Me.VGroupBox5.Controls.Add(Me.VTextBox4)
        Me.VGroupBox5.Controls.Add(Me.Label9)
        Me.VGroupBox5.Controls.Add(Me.VTextBox3)
        Me.VGroupBox5.Customization = ""
        Me.VGroupBox5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox5.Image = Nothing
        Me.VGroupBox5.Location = New System.Drawing.Point(6, 6)
        Me.VGroupBox5.Movable = True
        Me.VGroupBox5.Name = "VGroupBox5"
        Me.VGroupBox5.NoRounding = False
        Me.VGroupBox5.Sizable = True
        Me.VGroupBox5.Size = New System.Drawing.Size(315, 213)
        Me.VGroupBox5.SmartBounds = True
        Me.VGroupBox5.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox5.TabIndex = 0
        Me.VGroupBox5.Text = "VGroupBox5"
        Me.VGroupBox5.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox5.Transparent = False
        '
        'VButton6
        '
        Me.VButton6.Colors = New Onyx.Bloom(-1) {}
        Me.VButton6.Customization = ""
        Me.VButton6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VButton6.Image = Nothing
        Me.VButton6.Location = New System.Drawing.Point(162, 146)
        Me.VButton6.Name = "VButton6"
        Me.VButton6.NoRounding = False
        Me.VButton6.Size = New System.Drawing.Size(138, 25)
        Me.VButton6.TabIndex = 17
        Me.VButton6.Text = "Clone"
        Me.VButton6.Transparent = False
        '
        'VButton4
        '
        Me.VButton4.Colors = New Onyx.Bloom(-1) {}
        Me.VButton4.Customization = ""
        Me.VButton4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VButton4.Image = Nothing
        Me.VButton4.Location = New System.Drawing.Point(162, 177)
        Me.VButton4.Name = "VButton4"
        Me.VButton4.NoRounding = False
        Me.VButton4.Size = New System.Drawing.Size(138, 25)
        Me.VButton4.TabIndex = 1
        Me.VButton4.Text = "Generate"
        Me.VButton4.Transparent = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label15.Location = New System.Drawing.Point(159, 99)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(97, 13)
        Me.Label15.TabIndex = 16
        Me.Label15.Text = "Product Version"
        '
        'VTextBox9
        '
        Me.VTextBox9.AllowDrop = True
        Me.VTextBox9.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox9.Customization = ""
        Me.VTextBox9.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox9.Image = Nothing
        Me.VTextBox9.Location = New System.Drawing.Point(162, 115)
        Me.VTextBox9.MaxCharacters = 0
        Me.VTextBox9.Multiline = False
        Me.VTextBox9.Name = "VTextBox9"
        Me.VTextBox9.NoRounding = False
        Me.VTextBox9.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox9.TabIndex = 15
        Me.VTextBox9.Text = "7.0.70.11"
        Me.VTextBox9.Transparent = False
        Me.VTextBox9.UsePasswordMask = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label14.Location = New System.Drawing.Point(159, 55)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(109, 13)
        Me.Label14.TabIndex = 14
        Me.Label14.Text = "Assembly Version"
        '
        'VTextBox8
        '
        Me.VTextBox8.AllowDrop = True
        Me.VTextBox8.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox8.Customization = ""
        Me.VTextBox8.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox8.Image = Nothing
        Me.VTextBox8.Location = New System.Drawing.Point(162, 71)
        Me.VTextBox8.MaxCharacters = 0
        Me.VTextBox8.Multiline = False
        Me.VTextBox8.Name = "VTextBox8"
        Me.VTextBox8.NoRounding = False
        Me.VTextBox8.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox8.TabIndex = 13
        Me.VTextBox8.Text = "1.7.0.7"
        Me.VTextBox8.Transparent = False
        Me.VTextBox8.UsePasswordMask = False
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label13.Location = New System.Drawing.Point(159, 11)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(70, 13)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Trademark"
        '
        'VTextBox7
        '
        Me.VTextBox7.AllowDrop = True
        Me.VTextBox7.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox7.Customization = ""
        Me.VTextBox7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox7.Image = Nothing
        Me.VTextBox7.Location = New System.Drawing.Point(162, 27)
        Me.VTextBox7.MaxCharacters = 0
        Me.VTextBox7.Multiline = False
        Me.VTextBox7.Name = "VTextBox7"
        Me.VTextBox7.NoRounding = False
        Me.VTextBox7.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox7.TabIndex = 11
        Me.VTextBox7.Text = "Java(TM)"
        Me.VTextBox7.Transparent = False
        Me.VTextBox7.UsePasswordMask = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label12.Location = New System.Drawing.Point(12, 143)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(63, 13)
        Me.Label12.TabIndex = 10
        Me.Label12.Text = "Copyright"
        '
        'VTextBox6
        '
        Me.VTextBox6.AllowDrop = True
        Me.VTextBox6.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox6.Customization = ""
        Me.VTextBox6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox6.Image = Nothing
        Me.VTextBox6.Location = New System.Drawing.Point(15, 159)
        Me.VTextBox6.MaxCharacters = 0
        Me.VTextBox6.Multiline = False
        Me.VTextBox6.Name = "VTextBox6"
        Me.VTextBox6.NoRounding = False
        Me.VTextBox6.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox6.TabIndex = 9
        Me.VTextBox6.Text = "Copyright © 2012"
        Me.VTextBox6.Transparent = False
        Me.VTextBox6.UsePasswordMask = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label11.Location = New System.Drawing.Point(12, 99)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(87, 13)
        Me.Label11.TabIndex = 8
        Me.Label11.Text = "Product Name"
        '
        'VTextBox5
        '
        Me.VTextBox5.AllowDrop = True
        Me.VTextBox5.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox5.Customization = ""
        Me.VTextBox5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox5.Image = Nothing
        Me.VTextBox5.Location = New System.Drawing.Point(15, 115)
        Me.VTextBox5.MaxCharacters = 0
        Me.VTextBox5.Multiline = False
        Me.VTextBox5.Name = "VTextBox5"
        Me.VTextBox5.NoRounding = False
        Me.VTextBox5.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox5.TabIndex = 7
        Me.VTextBox5.Text = "Java(TM) Platform SE binary"
        Me.VTextBox5.Transparent = False
        Me.VTextBox5.UsePasswordMask = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label10.Location = New System.Drawing.Point(12, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(99, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Company Name"
        '
        'VTextBox4
        '
        Me.VTextBox4.AllowDrop = True
        Me.VTextBox4.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox4.Customization = ""
        Me.VTextBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox4.Image = Nothing
        Me.VTextBox4.Location = New System.Drawing.Point(15, 71)
        Me.VTextBox4.MaxCharacters = 0
        Me.VTextBox4.Multiline = False
        Me.VTextBox4.Name = "VTextBox4"
        Me.VTextBox4.NoRounding = False
        Me.VTextBox4.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox4.TabIndex = 5
        Me.VTextBox4.Text = "Oracle Corporation"
        Me.VTextBox4.Transparent = False
        Me.VTextBox4.UsePasswordMask = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.DarkMagenta
        Me.Label9.Location = New System.Drawing.Point(12, 11)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(99, 13)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Assembly Name"
        '
        'VTextBox3
        '
        Me.VTextBox3.AllowDrop = True
        Me.VTextBox3.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox3.Customization = ""
        Me.VTextBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox3.Image = Nothing
        Me.VTextBox3.Location = New System.Drawing.Point(15, 27)
        Me.VTextBox3.MaxCharacters = 0
        Me.VTextBox3.Multiline = False
        Me.VTextBox3.Name = "VTextBox3"
        Me.VTextBox3.NoRounding = False
        Me.VTextBox3.Size = New System.Drawing.Size(138, 25)
        Me.VTextBox3.TabIndex = 3
        Me.VTextBox3.Text = "Java(TM) Platform SE 7 U7"
        Me.VTextBox3.Transparent = False
        Me.VTextBox3.UsePasswordMask = False
        '
        'TabPage3
        '
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.VGroupBox12)
        Me.TabPage3.Controls.Add(Me.VGroupBox11)
        Me.TabPage3.Controls.Add(Me.VGroupBox10)
        Me.TabPage3.Controls.Add(Me.VSeperator3)
        Me.TabPage3.Controls.Add(Me.VGroupBox9)
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(785, 239)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Extra"
        '
        'VGroupBox12
        '
        Me.VGroupBox12.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox12.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox12.Controls.Add(Me.VTextBox19)
        Me.VGroupBox12.Controls.Add(Me.VTextBox18)
        Me.VGroupBox12.Controls.Add(Me.VCheckBox7)
        Me.VGroupBox12.Customization = ""
        Me.VGroupBox12.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox12.Image = Nothing
        Me.VGroupBox12.Location = New System.Drawing.Point(453, 88)
        Me.VGroupBox12.Movable = True
        Me.VGroupBox12.Name = "VGroupBox12"
        Me.VGroupBox12.NoRounding = False
        Me.VGroupBox12.Sizable = True
        Me.VGroupBox12.Size = New System.Drawing.Size(243, 110)
        Me.VGroupBox12.SmartBounds = True
        Me.VGroupBox12.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox12.TabIndex = 5
        Me.VGroupBox12.Text = "VGroupBox12"
        Me.VGroupBox12.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox12.Transparent = False
        '
        'VTextBox19
        '
        Me.VTextBox19.AllowDrop = True
        Me.VTextBox19.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox19.Customization = ""
        Me.VTextBox19.Enabled = False
        Me.VTextBox19.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox19.Image = Nothing
        Me.VTextBox19.Location = New System.Drawing.Point(16, 63)
        Me.VTextBox19.MaxCharacters = 0
        Me.VTextBox19.Multiline = False
        Me.VTextBox19.Name = "VTextBox19"
        Me.VTextBox19.NoRounding = False
        Me.VTextBox19.Size = New System.Drawing.Size(210, 25)
        Me.VTextBox19.TabIndex = 4
        Me.VTextBox19.Text = "Message"
        Me.VTextBox19.Transparent = False
        Me.VTextBox19.UsePasswordMask = False
        '
        'VTextBox18
        '
        Me.VTextBox18.AllowDrop = True
        Me.VTextBox18.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox18.Customization = ""
        Me.VTextBox18.Enabled = False
        Me.VTextBox18.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox18.Image = Nothing
        Me.VTextBox18.Location = New System.Drawing.Point(16, 29)
        Me.VTextBox18.MaxCharacters = 0
        Me.VTextBox18.Multiline = False
        Me.VTextBox18.Name = "VTextBox18"
        Me.VTextBox18.NoRounding = False
        Me.VTextBox18.Size = New System.Drawing.Size(210, 25)
        Me.VTextBox18.TabIndex = 3
        Me.VTextBox18.Text = "Title"
        Me.VTextBox18.Transparent = False
        Me.VTextBox18.UsePasswordMask = False
        '
        'VCheckBox7
        '
        Me.VCheckBox7.BackColor = System.Drawing.Color.Transparent
        Me.VCheckBox7.Checked = False
        Me.VCheckBox7.Colors = New Onyx.Bloom(-1) {}
        Me.VCheckBox7.Customization = ""
        Me.VCheckBox7.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VCheckBox7.Image = Nothing
        Me.VCheckBox7.Location = New System.Drawing.Point(3, 3)
        Me.VCheckBox7.Name = "VCheckBox7"
        Me.VCheckBox7.NoRounding = False
        Me.VCheckBox7.Size = New System.Drawing.Size(168, 20)
        Me.VCheckBox7.TabIndex = 0
        Me.VCheckBox7.Text = "Fake Error Message"
        Me.VCheckBox7.Transparent = True
        '
        'VGroupBox11
        '
        Me.VGroupBox11.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox11.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox11.Controls.Add(Me.VButton5)
        Me.VGroupBox11.Controls.Add(Me.VTextBox17)
        Me.VGroupBox11.Controls.Add(Me.VCheckBox6)
        Me.VGroupBox11.Customization = ""
        Me.VGroupBox11.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox11.Image = Nothing
        Me.VGroupBox11.Location = New System.Drawing.Point(195, 88)
        Me.VGroupBox11.Movable = True
        Me.VGroupBox11.Name = "VGroupBox11"
        Me.VGroupBox11.NoRounding = False
        Me.VGroupBox11.Sizable = True
        Me.VGroupBox11.Size = New System.Drawing.Size(243, 110)
        Me.VGroupBox11.SmartBounds = True
        Me.VGroupBox11.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox11.TabIndex = 3
        Me.VGroupBox11.Text = "VGroupBox11"
        Me.VGroupBox11.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox11.Transparent = False
        '
        'VButton5
        '
        Me.VButton5.Colors = New Onyx.Bloom(-1) {}
        Me.VButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.VButton5.Customization = ""
        Me.VButton5.Enabled = False
        Me.VButton5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VButton5.Image = Nothing
        Me.VButton5.Location = New System.Drawing.Point(16, 60)
        Me.VButton5.Name = "VButton5"
        Me.VButton5.NoRounding = False
        Me.VButton5.Size = New System.Drawing.Size(210, 28)
        Me.VButton5.TabIndex = 4
        Me.VButton5.Text = "Browse"
        Me.VButton5.Transparent = False
        '
        'VTextBox17
        '
        Me.VTextBox17.AllowDrop = True
        Me.VTextBox17.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox17.Customization = ""
        Me.VTextBox17.Enabled = False
        Me.VTextBox17.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox17.Image = Nothing
        Me.VTextBox17.Location = New System.Drawing.Point(16, 29)
        Me.VTextBox17.MaxCharacters = 0
        Me.VTextBox17.Multiline = False
        Me.VTextBox17.Name = "VTextBox17"
        Me.VTextBox17.NoRounding = False
        Me.VTextBox17.Size = New System.Drawing.Size(210, 25)
        Me.VTextBox17.TabIndex = 3
        Me.VTextBox17.Text = "              Drag 'n Drop"
        Me.VTextBox17.Transparent = False
        Me.VTextBox17.UsePasswordMask = False
        '
        'VCheckBox6
        '
        Me.VCheckBox6.BackColor = System.Drawing.Color.Transparent
        Me.VCheckBox6.Checked = False
        Me.VCheckBox6.Colors = New Onyx.Bloom(-1) {}
        Me.VCheckBox6.Customization = ""
        Me.VCheckBox6.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VCheckBox6.Image = Nothing
        Me.VCheckBox6.Location = New System.Drawing.Point(3, 3)
        Me.VCheckBox6.Name = "VCheckBox6"
        Me.VCheckBox6.NoRounding = False
        Me.VCheckBox6.Size = New System.Drawing.Size(130, 20)
        Me.VCheckBox6.TabIndex = 0
        Me.VCheckBox6.Text = "Binder"
        Me.VCheckBox6.Transparent = True
        '
        'VGroupBox10
        '
        Me.VGroupBox10.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox10.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox10.Controls.Add(Me.VTextBox16)
        Me.VGroupBox10.Controls.Add(Me.VCheckBox5)
        Me.VGroupBox10.Customization = ""
        Me.VGroupBox10.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox10.Image = Nothing
        Me.VGroupBox10.Location = New System.Drawing.Point(195, 11)
        Me.VGroupBox10.Movable = True
        Me.VGroupBox10.Name = "VGroupBox10"
        Me.VGroupBox10.NoRounding = False
        Me.VGroupBox10.Sizable = True
        Me.VGroupBox10.Size = New System.Drawing.Size(501, 71)
        Me.VGroupBox10.SmartBounds = True
        Me.VGroupBox10.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox10.TabIndex = 2
        Me.VGroupBox10.Text = "VGroupBox10"
        Me.VGroupBox10.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox10.Transparent = False
        '
        'VTextBox16
        '
        Me.VTextBox16.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox16.Customization = ""
        Me.VTextBox16.Enabled = False
        Me.VTextBox16.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox16.Image = Nothing
        Me.VTextBox16.Location = New System.Drawing.Point(16, 29)
        Me.VTextBox16.MaxCharacters = 0
        Me.VTextBox16.Multiline = False
        Me.VTextBox16.Name = "VTextBox16"
        Me.VTextBox16.NoRounding = False
        Me.VTextBox16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.VTextBox16.Size = New System.Drawing.Size(317, 25)
        Me.VTextBox16.TabIndex = 1
        Me.VTextBox16.Text = "http://www.website.com/server.exe"
        Me.VTextBox16.Transparent = False
        Me.VTextBox16.UsePasswordMask = False
        '
        'VCheckBox5
        '
        Me.VCheckBox5.BackColor = System.Drawing.Color.Transparent
        Me.VCheckBox5.Checked = False
        Me.VCheckBox5.Colors = New Onyx.Bloom(-1) {}
        Me.VCheckBox5.Customization = ""
        Me.VCheckBox5.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VCheckBox5.Image = Nothing
        Me.VCheckBox5.Location = New System.Drawing.Point(3, 3)
        Me.VCheckBox5.Name = "VCheckBox5"
        Me.VCheckBox5.NoRounding = False
        Me.VCheckBox5.Size = New System.Drawing.Size(130, 20)
        Me.VCheckBox5.TabIndex = 0
        Me.VCheckBox5.Text = "Downloader"
        Me.VCheckBox5.Transparent = True
        '
        'VSeperator3
        '
        Me.VSeperator3.BackColor = System.Drawing.Color.Transparent
        Me.VSeperator3.Colors = New Onyx.Bloom(-1) {}
        Me.VSeperator3.Customization = ""
        Me.VSeperator3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VSeperator3.Image = Nothing
        Me.VSeperator3.Location = New System.Drawing.Point(175, 3)
        Me.VSeperator3.Name = "VSeperator3"
        Me.VSeperator3.NoRounding = False
        Me.VSeperator3.Orientation = System.Windows.Forms.Orientation.Vertical
        Me.VSeperator3.Size = New System.Drawing.Size(14, 230)
        Me.VSeperator3.TabIndex = 1
        Me.VSeperator3.Text = "VSeperator3"
        Me.VSeperator3.Transparent = True
        '
        'VGroupBox9
        '
        Me.VGroupBox9.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox9.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox9.Controls.Add(Me.VTextBox15)
        Me.VGroupBox9.Controls.Add(Me.VCheckBox4)
        Me.VGroupBox9.Controls.Add(Me.VTextBox14)
        Me.VGroupBox9.Controls.Add(Me.VCheckBox3)
        Me.VGroupBox9.Controls.Add(Me.VCheckBox2)
        Me.VGroupBox9.Customization = ""
        Me.VGroupBox9.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox9.Image = Nothing
        Me.VGroupBox9.Location = New System.Drawing.Point(6, 11)
        Me.VGroupBox9.Movable = True
        Me.VGroupBox9.Name = "VGroupBox9"
        Me.VGroupBox9.NoRounding = False
        Me.VGroupBox9.Sizable = True
        Me.VGroupBox9.Size = New System.Drawing.Size(167, 187)
        Me.VGroupBox9.SmartBounds = True
        Me.VGroupBox9.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox9.TabIndex = 0
        Me.VGroupBox9.Text = "VGroupBox9"
        Me.VGroupBox9.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox9.Transparent = False
        '
        'VTextBox15
        '
        Me.VTextBox15.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox15.Customization = ""
        Me.VTextBox15.Enabled = False
        Me.VTextBox15.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox15.Image = Nothing
        Me.VTextBox15.Location = New System.Drawing.Point(13, 129)
        Me.VTextBox15.MaxCharacters = 0
        Me.VTextBox15.Multiline = False
        Me.VTextBox15.Name = "VTextBox15"
        Me.VTextBox15.NoRounding = False
        Me.VTextBox15.Size = New System.Drawing.Size(43, 25)
        Me.VTextBox15.TabIndex = 4
        Me.VTextBox15.Text = "png"
        Me.VTextBox15.Transparent = False
        Me.VTextBox15.UsePasswordMask = False
        '
        'VCheckBox4
        '
        Me.VCheckBox4.BackColor = System.Drawing.Color.Transparent
        Me.VCheckBox4.Checked = False
        Me.VCheckBox4.Colors = New Onyx.Bloom(-1) {}
        Me.VCheckBox4.Customization = ""
        Me.VCheckBox4.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VCheckBox4.Image = Nothing
        Me.VCheckBox4.Location = New System.Drawing.Point(13, 104)
        Me.VCheckBox4.Name = "VCheckBox4"
        Me.VCheckBox4.NoRounding = False
        Me.VCheckBox4.Size = New System.Drawing.Size(151, 19)
        Me.VCheckBox4.TabIndex = 3
        Me.VCheckBox4.Text = "Spoof Extension"
        Me.VCheckBox4.Transparent = True
        '
        'VTextBox14
        '
        Me.VTextBox14.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox14.Customization = ""
        Me.VTextBox14.Enabled = False
        Me.VTextBox14.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox14.Image = Nothing
        Me.VTextBox14.Location = New System.Drawing.Point(13, 73)
        Me.VTextBox14.MaxCharacters = 0
        Me.VTextBox14.Multiline = False
        Me.VTextBox14.Name = "VTextBox14"
        Me.VTextBox14.NoRounding = False
        Me.VTextBox14.Size = New System.Drawing.Size(43, 25)
        Me.VTextBox14.TabIndex = 1
        Me.VTextBox14.Text = "25"
        Me.VTextBox14.Transparent = False
        Me.VTextBox14.UsePasswordMask = False
        '
        'VCheckBox3
        '
        Me.VCheckBox3.BackColor = System.Drawing.Color.Transparent
        Me.VCheckBox3.Checked = False
        Me.VCheckBox3.Colors = New Onyx.Bloom(-1) {}
        Me.VCheckBox3.Customization = ""
        Me.VCheckBox3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VCheckBox3.Image = Nothing
        Me.VCheckBox3.Location = New System.Drawing.Point(13, 48)
        Me.VCheckBox3.Name = "VCheckBox3"
        Me.VCheckBox3.NoRounding = False
        Me.VCheckBox3.Size = New System.Drawing.Size(151, 19)
        Me.VCheckBox3.TabIndex = 2
        Me.VCheckBox3.Text = "Delay Execution"
        Me.VCheckBox3.Transparent = True
        '
        'VCheckBox2
        '
        Me.VCheckBox2.BackColor = System.Drawing.Color.Transparent
        Me.VCheckBox2.Checked = True
        Me.VCheckBox2.Colors = New Onyx.Bloom(-1) {}
        Me.VCheckBox2.Customization = ""
        Me.VCheckBox2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VCheckBox2.Image = Nothing
        Me.VCheckBox2.Location = New System.Drawing.Point(13, 23)
        Me.VCheckBox2.Name = "VCheckBox2"
        Me.VCheckBox2.NoRounding = False
        Me.VCheckBox2.Size = New System.Drawing.Size(128, 19)
        Me.VCheckBox2.TabIndex = 1
        Me.VCheckBox2.Text = "Hide File"
        Me.VCheckBox2.Transparent = True
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.VGroupBox13)
        Me.TabPage4.Controls.Add(Me.VButton1)
        Me.TabPage4.Controls.Add(Me.VTextBox13)
        Me.TabPage4.Location = New System.Drawing.Point(4, 25)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(785, 239)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Build"
        '
        'VGroupBox13
        '
        Me.VGroupBox13.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.VGroupBox13.Colors = New Onyx.Bloom(-1) {}
        Me.VGroupBox13.Controls.Add(Me.RichTextBox1)
        Me.VGroupBox13.Customization = ""
        Me.VGroupBox13.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VGroupBox13.Image = Nothing
        Me.VGroupBox13.Location = New System.Drawing.Point(6, 6)
        Me.VGroupBox13.Movable = True
        Me.VGroupBox13.Name = "VGroupBox13"
        Me.VGroupBox13.NoRounding = False
        Me.VGroupBox13.Sizable = True
        Me.VGroupBox13.Size = New System.Drawing.Size(773, 182)
        Me.VGroupBox13.SmartBounds = True
        Me.VGroupBox13.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.VGroupBox13.TabIndex = 8
        Me.VGroupBox13.Text = "VGroupBox13"
        Me.VGroupBox13.TransparencyKey = System.Drawing.Color.Empty
        Me.VGroupBox13.Transparent = False
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Cursor = System.Windows.Forms.Cursors.NoMoveVert
        Me.RichTextBox1.ForeColor = System.Drawing.Color.DarkMagenta
        Me.RichTextBox1.Location = New System.Drawing.Point(8, 7)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None
        Me.RichTextBox1.Size = New System.Drawing.Size(755, 166)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = resources.GetString("RichTextBox1.Text")
        '
        'VButton1
        '
        Me.VButton1.Colors = New Onyx.Bloom(-1) {}
        Me.VButton1.Customization = ""
        Me.VButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VButton1.Image = Nothing
        Me.VButton1.Location = New System.Drawing.Point(282, 194)
        Me.VButton1.Name = "VButton1"
        Me.VButton1.NoRounding = False
        Me.VButton1.Size = New System.Drawing.Size(250, 25)
        Me.VButton1.TabIndex = 6
        Me.VButton1.Text = "Crypt"
        Me.VButton1.Transparent = False
        '
        'VTextBox13
        '
        Me.VTextBox13.Colors = New Onyx.Bloom(-1) {}
        Me.VTextBox13.Customization = ""
        Me.VTextBox13.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.VTextBox13.Image = Nothing
        Me.VTextBox13.Location = New System.Drawing.Point(6, 194)
        Me.VTextBox13.MaxCharacters = 0
        Me.VTextBox13.Multiline = False
        Me.VTextBox13.Name = "VTextBox13"
        Me.VTextBox13.NoRounding = False
        Me.VTextBox13.Size = New System.Drawing.Size(250, 25)
        Me.VTextBox13.TabIndex = 4
        Me.VTextBox13.Transparent = False
        Me.VTextBox13.UsePasswordMask = False
        Me.VTextBox13.Visible = False
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.TabPage5.Location = New System.Drawing.Point(4, 25)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(785, 239)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Scanner"
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.FromArgb(CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer), CType(CType(15, Byte), Integer))
        Me.TabPage6.Controls.Add(Me.PictureBox2)
        Me.TabPage6.Location = New System.Drawing.Point(4, 25)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(785, 239)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "About"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(18, 16)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(174, 164)
        Me.PictureBox2.TabIndex = 0
        Me.PictureBox2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(817, 318)
        Me.Controls.Add(Me.VTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Onyx Crypter"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.VTheme1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VTabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.VGroupBox4.ResumeLayout(False)
        Me.VGroupBox4.PerformLayout()
        Me.VGroupBox2.ResumeLayout(False)
        Me.VGroupBox2.PerformLayout()
        Me.VGroupBox3.ResumeLayout(False)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.VGroupBox1.ResumeLayout(False)
        Me.VGroupBox1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.VGroupBox6.ResumeLayout(False)
        Me.VGroupBox6.PerformLayout()
        Me.VGroupBox7.ResumeLayout(False)
        Me.VGroupBox7.PerformLayout()
        Me.VGroupBox5.ResumeLayout(False)
        Me.VGroupBox5.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.VGroupBox12.ResumeLayout(False)
        Me.VGroupBox11.ResumeLayout(False)
        Me.VGroupBox10.ResumeLayout(False)
        Me.VGroupBox9.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        Me.VGroupBox13.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents VTheme1 As Onyx.VTheme
    Friend WithEvents VTextBox1 As Onyx.VTextBox
    Friend WithEvents VTabControl1 As Onyx.VTabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents VGroupBox1 As Onyx.VGroupBox
    Friend WithEvents VButton2 As Onyx.VButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents VGroupBox2 As Onyx.VGroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents VButton3 As Onyx.VButton
    Friend WithEvents VTextBox2 As Onyx.VTextBox
    Friend WithEvents VGroupBox3 As Onyx.VGroupBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents VSeperator1 As Onyx.VSeperator
    Friend WithEvents VRadiobutton1 As Onyx.VRadiobutton
    Friend WithEvents VRadiobutton2 As Onyx.VRadiobutton
    Friend WithEvents VGroupBox4 As Onyx.VGroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents VGroupBox6 As Onyx.VGroupBox
    Friend WithEvents VSeperator2 As Onyx.VSeperator
    Friend WithEvents VGroupBox5 As Onyx.VGroupBox
    Friend WithEvents VButton4 As Onyx.VButton
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents VTextBox9 As Onyx.VTextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents VTextBox8 As Onyx.VTextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents VTextBox7 As Onyx.VTextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents VTextBox6 As Onyx.VTextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents VTextBox5 As Onyx.VTextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents VTextBox4 As Onyx.VTextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents VTextBox3 As Onyx.VTextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents GhostComboBox1 As Onyx.GhostComboBox
    Friend WithEvents VCheckBox1 As Onyx.VCheckBox
    Friend WithEvents VGroupBox7 As Onyx.VGroupBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents VTextBox10 As Onyx.VTextBox
    Friend WithEvents VTextBox12 As Onyx.VTextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents VTextBox11 As Onyx.VTextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents VTextBox13 As Onyx.VTextBox
    Friend WithEvents VGroupBox12 As Onyx.VGroupBox
    Friend WithEvents VTextBox18 As Onyx.VTextBox
    Friend WithEvents VCheckBox7 As Onyx.VCheckBox
    Friend WithEvents VGroupBox11 As Onyx.VGroupBox
    Friend WithEvents VButton5 As Onyx.VButton
    Friend WithEvents VTextBox17 As Onyx.VTextBox
    Friend WithEvents VCheckBox6 As Onyx.VCheckBox
    Friend WithEvents VGroupBox10 As Onyx.VGroupBox
    Friend WithEvents VTextBox16 As Onyx.VTextBox
    Friend WithEvents VCheckBox5 As Onyx.VCheckBox
    Friend WithEvents VSeperator3 As Onyx.VSeperator
    Friend WithEvents VGroupBox9 As Onyx.VGroupBox
    Friend WithEvents VTextBox15 As Onyx.VTextBox
    Friend WithEvents VCheckBox4 As Onyx.VCheckBox
    Friend WithEvents VTextBox14 As Onyx.VTextBox
    Friend WithEvents VCheckBox3 As Onyx.VCheckBox
    Friend WithEvents VCheckBox2 As Onyx.VCheckBox
    Friend WithEvents VTextBox19 As Onyx.VTextBox
    Friend WithEvents ListView1 As System.Windows.Forms.ListView
    Friend WithEvents VButton1 As Onyx.VButton
    Friend WithEvents VGroupBox13 As Onyx.VGroupBox
    Friend WithEvents VButton6 As Onyx.VButton
    Friend WithEvents VRadiobutton4 As Onyx.VRadiobutton
    Friend WithEvents VRadiobutton3 As Onyx.VRadiobutton
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox

End Class
