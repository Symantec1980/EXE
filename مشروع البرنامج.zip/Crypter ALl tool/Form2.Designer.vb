﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.FormSkin1 = New Crypter_ALl_tool.FormSkin()
        Me.FlatButton18 = New Crypter_ALl_tool.FlatButton()
        Me.FlatButton2 = New Crypter_ALl_tool.FlatButton()
        Me.FlatButton10 = New Crypter_ALl_tool.FlatButton()
        Me.a1 = New System.Windows.Forms.RichTextBox()
        Me.t4 = New Crypter_ALl_tool.FlatTextBox()
        Me.Button2 = New Crypter_ALl_tool.FlatButton()
        Me.t5 = New Crypter_ALl_tool.FlatTextBox()
        Me.FlatButton4 = New Crypter_ALl_tool.FlatButton()
        Me.FlatButton3 = New Crypter_ALl_tool.FlatButton()
        Me.FlatButton1 = New Crypter_ALl_tool.FlatButton()
        Me.FlatGroupBox1 = New Crypter_ALl_tool.FlatGroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button4 = New Crypter_ALl_tool.FlatButton()
        Me.Button1 = New Crypter_ALl_tool.FlatButton()
        Me.t1 = New Crypter_ALl_tool.FlatTextBox()
        Me.Button5 = New Crypter_ALl_tool.FlatButton()
        Me.t3 = New Crypter_ALl_tool.FlatTextBox()
        Me.Button6 = New Crypter_ALl_tool.FlatButton()
        Me.T16 = New Crypter_ALl_tool.FlatTextBox()
        Me.Button3 = New Crypter_ALl_tool.FlatButton()
        Me.Label2 = New Crypter_ALl_tool.FlatLabel()
        Me.r1 = New System.Windows.Forms.RichTextBox()
        Me.r2 = New System.Windows.Forms.RichTextBox()
        Me.FormSkin1.SuspendLayout()
        Me.FlatGroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'FormSkin1
        '
        Me.FormSkin1.BackColor = System.Drawing.Color.White
        Me.FormSkin1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(70, Byte), Integer), CType(CType(73, Byte), Integer))
        Me.FormSkin1.BorderColor = System.Drawing.Color.FromArgb(CType(CType(53, Byte), Integer), CType(CType(58, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.FormSkin1.Controls.Add(Me.FlatButton18)
        Me.FormSkin1.Controls.Add(Me.FlatButton2)
        Me.FormSkin1.Controls.Add(Me.FlatButton10)
        Me.FormSkin1.Controls.Add(Me.a1)
        Me.FormSkin1.Controls.Add(Me.t4)
        Me.FormSkin1.Controls.Add(Me.Button2)
        Me.FormSkin1.Controls.Add(Me.t5)
        Me.FormSkin1.Controls.Add(Me.FlatButton4)
        Me.FormSkin1.Controls.Add(Me.FlatButton3)
        Me.FormSkin1.Controls.Add(Me.FlatButton1)
        Me.FormSkin1.Controls.Add(Me.FlatGroupBox1)
        Me.FormSkin1.Controls.Add(Me.r1)
        Me.FormSkin1.Controls.Add(Me.r2)
        Me.FormSkin1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FormSkin1.FlatColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(168, Byte), Integer), CType(CType(109, Byte), Integer))
        Me.FormSkin1.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormSkin1.HeaderColor = System.Drawing.Color.FromArgb(CType(CType(45, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.FormSkin1.HeaderMaximize = False
        Me.FormSkin1.Location = New System.Drawing.Point(0, 0)
        Me.FormSkin1.Name = "FormSkin1"
        Me.FormSkin1.Size = New System.Drawing.Size(830, 490)
        Me.FormSkin1.TabIndex = 0
        Me.FormSkin1.Text = "crypter algorithme  & splet Hex  server"
        '
        'FlatButton18
        '
        Me.FlatButton18.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton18.BaseColor = System.Drawing.Color.Red
        Me.FlatButton18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton18.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton18.Location = New System.Drawing.Point(238, 439)
        Me.FlatButton18.Name = "FlatButton18"
        Me.FlatButton18.Rounded = False
        Me.FlatButton18.Size = New System.Drawing.Size(104, 25)
        Me.FlatButton18.TabIndex = 25
        Me.FlatButton18.Text = "Copy Ascii Cod"
        Me.FlatButton18.TextColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        '
        'FlatButton2
        '
        Me.FlatButton2.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton2.BaseColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.FlatButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton2.Location = New System.Drawing.Point(348, 439)
        Me.FlatButton2.Name = "FlatButton2"
        Me.FlatButton2.Rounded = False
        Me.FlatButton2.Size = New System.Drawing.Size(104, 25)
        Me.FlatButton2.TabIndex = 24
        Me.FlatButton2.Text = "Clean All Text"
        Me.FlatButton2.TextColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        '
        'FlatButton10
        '
        Me.FlatButton10.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton10.BaseColor = System.Drawing.Color.Red
        Me.FlatButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton10.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton10.Location = New System.Drawing.Point(123, 439)
        Me.FlatButton10.Name = "FlatButton10"
        Me.FlatButton10.Rounded = False
        Me.FlatButton10.Size = New System.Drawing.Size(109, 25)
        Me.FlatButton10.TabIndex = 23
        Me.FlatButton10.Text = "Copy Hex Gen "
        Me.FlatButton10.TextColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        '
        'a1
        '
        Me.a1.BackColor = System.Drawing.SystemColors.InfoText
        Me.a1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.a1.ForeColor = System.Drawing.Color.Red
        Me.a1.Location = New System.Drawing.Point(21, 61)
        Me.a1.Name = "a1"
        Me.a1.Size = New System.Drawing.Size(211, 145)
        Me.a1.TabIndex = 22
        Me.a1.Text = ""
        '
        't4
        '
        Me.t4.BackColor = System.Drawing.Color.Transparent
        Me.t4.Location = New System.Drawing.Point(271, 121)
        Me.t4.MaxLength = 32767
        Me.t4.Multiline = False
        Me.t4.Name = "t4"
        Me.t4.ReadOnly = False
        Me.t4.Size = New System.Drawing.Size(181, 29)
        Me.t4.TabIndex = 21
        Me.t4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t4.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t4.UseSystemPasswordChar = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Transparent
        Me.Button2.BaseColor = System.Drawing.Color.Red
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(21, 439)
        Me.Button2.Name = "Button2"
        Me.Button2.Rounded = False
        Me.Button2.Size = New System.Drawing.Size(96, 25)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Copy sub "
        Me.Button2.TextColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        '
        't5
        '
        Me.t5.BackColor = System.Drawing.Color.Transparent
        Me.t5.Location = New System.Drawing.Point(271, 156)
        Me.t5.MaxLength = 32767
        Me.t5.Multiline = False
        Me.t5.Name = "t5"
        Me.t5.ReadOnly = False
        Me.t5.Size = New System.Drawing.Size(181, 29)
        Me.t5.TabIndex = 20
        Me.t5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t5.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t5.UseSystemPasswordChar = False
        '
        'FlatButton4
        '
        Me.FlatButton4.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton4.BaseColor = System.Drawing.Color.Black
        Me.FlatButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton4.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton4.Location = New System.Drawing.Point(271, 98)
        Me.FlatButton4.Name = "FlatButton4"
        Me.FlatButton4.Rounded = False
        Me.FlatButton4.Size = New System.Drawing.Size(85, 17)
        Me.FlatButton4.TabIndex = 19
        Me.FlatButton4.Text = "gen"
        Me.FlatButton4.TextColor = System.Drawing.Color.DarkGray
        '
        'FlatButton3
        '
        Me.FlatButton3.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton3.BaseColor = System.Drawing.Color.Black
        Me.FlatButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton3.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton3.Location = New System.Drawing.Point(362, 98)
        Me.FlatButton3.Name = "FlatButton3"
        Me.FlatButton3.Rounded = False
        Me.FlatButton3.Size = New System.Drawing.Size(90, 17)
        Me.FlatButton3.TabIndex = 18
        Me.FlatButton3.Text = "Cler Text"
        Me.FlatButton3.TextColor = System.Drawing.Color.DarkGray
        '
        'FlatButton1
        '
        Me.FlatButton1.BackColor = System.Drawing.Color.Transparent
        Me.FlatButton1.BaseColor = System.Drawing.Color.Black
        Me.FlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlatButton1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatButton1.Location = New System.Drawing.Point(271, 75)
        Me.FlatButton1.Name = "FlatButton1"
        Me.FlatButton1.Rounded = False
        Me.FlatButton1.Size = New System.Drawing.Size(181, 17)
        Me.FlatButton1.TabIndex = 16
        Me.FlatButton1.Text = "Random"
        Me.FlatButton1.TextColor = System.Drawing.Color.DarkGray
        '
        'FlatGroupBox1
        '
        Me.FlatGroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.FlatGroupBox1.BaseColor = System.Drawing.Color.Gray
        Me.FlatGroupBox1.Controls.Add(Me.PictureBox1)
        Me.FlatGroupBox1.Controls.Add(Me.Button4)
        Me.FlatGroupBox1.Controls.Add(Me.Button1)
        Me.FlatGroupBox1.Controls.Add(Me.t1)
        Me.FlatGroupBox1.Controls.Add(Me.Button5)
        Me.FlatGroupBox1.Controls.Add(Me.t3)
        Me.FlatGroupBox1.Controls.Add(Me.Button6)
        Me.FlatGroupBox1.Controls.Add(Me.T16)
        Me.FlatGroupBox1.Controls.Add(Me.Button3)
        Me.FlatGroupBox1.Controls.Add(Me.Label2)
        Me.FlatGroupBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.FlatGroupBox1.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.FlatGroupBox1.Location = New System.Drawing.Point(476, 52)
        Me.FlatGroupBox1.Name = "FlatGroupBox1"
        Me.FlatGroupBox1.ShowText = True
        Me.FlatGroupBox1.Size = New System.Drawing.Size(342, 419)
        Me.FlatGroupBox1.TabIndex = 15
        Me.FlatGroupBox1.Text = "File TO Hex"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Crypter_ALl_tool.My.Resources.Resources.left_round
        Me.PictureBox1.Location = New System.Drawing.Point(230, 325)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(81, 73)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 14
        Me.PictureBox1.TabStop = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Transparent
        Me.Button4.BaseColor = System.Drawing.Color.Silver
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Button4.Location = New System.Drawing.Point(165, 69)
        Me.Button4.Name = "Button4"
        Me.Button4.Rounded = False
        Me.Button4.Size = New System.Drawing.Size(156, 29)
        Me.Button4.TabIndex = 12
        Me.Button4.Text = "Select File "
        Me.Button4.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Transparent
        Me.Button1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Button1.Location = New System.Drawing.Point(165, 276)
        Me.Button1.Name = "Button1"
        Me.Button1.Rounded = False
        Me.Button1.Size = New System.Drawing.Size(156, 32)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Generator Sub"
        Me.Button1.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        't1
        '
        Me.t1.BackColor = System.Drawing.Color.Transparent
        Me.t1.Location = New System.Drawing.Point(15, 69)
        Me.t1.MaxLength = 32767
        Me.t1.Multiline = False
        Me.t1.Name = "t1"
        Me.t1.ReadOnly = False
        Me.t1.Size = New System.Drawing.Size(141, 29)
        Me.t1.TabIndex = 5
        Me.t1.Text = "File path ,,,,,,,,"
        Me.t1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t1.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t1.UseSystemPasswordChar = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.Transparent
        Me.Button5.BaseColor = System.Drawing.Color.Silver
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Button5.Location = New System.Drawing.Point(165, 139)
        Me.Button5.Name = "Button5"
        Me.Button5.Rounded = False
        Me.Button5.Size = New System.Drawing.Size(156, 29)
        Me.Button5.TabIndex = 11
        Me.Button5.Text = "Linage"
        Me.Button5.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        't3
        '
        Me.t3.BackColor = System.Drawing.Color.Transparent
        Me.t3.Location = New System.Drawing.Point(15, 104)
        Me.t3.MaxLength = 32767
        Me.t3.Multiline = False
        Me.t3.Name = "t3"
        Me.t3.ReadOnly = False
        Me.t3.Size = New System.Drawing.Size(141, 29)
        Me.t3.TabIndex = 7
        Me.t3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.t3.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.t3.UseSystemPasswordChar = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.Transparent
        Me.Button6.BaseColor = System.Drawing.Color.Silver
        Me.Button6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button6.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Button6.Location = New System.Drawing.Point(165, 104)
        Me.Button6.Name = "Button6"
        Me.Button6.Rounded = False
        Me.Button6.Size = New System.Drawing.Size(156, 29)
        Me.Button6.TabIndex = 10
        Me.Button6.Text = "String names"
        Me.Button6.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'T16
        '
        Me.T16.BackColor = System.Drawing.Color.Transparent
        Me.T16.Location = New System.Drawing.Point(15, 139)
        Me.T16.MaxLength = 32767
        Me.T16.Multiline = False
        Me.T16.Name = "T16"
        Me.T16.ReadOnly = False
        Me.T16.Size = New System.Drawing.Size(141, 29)
        Me.T16.TabIndex = 8
        Me.T16.Text = "300"
        Me.T16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.T16.TextColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.T16.UseSystemPasswordChar = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Transparent
        Me.Button3.BaseColor = System.Drawing.Color.Tomato
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 12.0!)
        Me.Button3.Location = New System.Drawing.Point(165, 228)
        Me.Button3.Name = "Button3"
        Me.Button3.Rounded = False
        Me.Button3.Size = New System.Drawing.Size(156, 32)
        Me.Button3.TabIndex = 9
        Me.Button3.Text = "Convert file To Hex"
        Me.Button3.TextColor = System.Drawing.Color.FromArgb(CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer), CType(CType(243, Byte), Integer))
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 8.0!)
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(42, 295)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(16, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "..."
        '
        'r1
        '
        Me.r1.BackColor = System.Drawing.SystemColors.InfoText
        Me.r1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.r1.ForeColor = System.Drawing.Color.Red
        Me.r1.Location = New System.Drawing.Point(21, 236)
        Me.r1.Name = "r1"
        Me.r1.Size = New System.Drawing.Size(211, 197)
        Me.r1.TabIndex = 3
        Me.r1.Text = ""
        '
        'r2
        '
        Me.r2.BackColor = System.Drawing.SystemColors.InfoText
        Me.r2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.r2.ForeColor = System.Drawing.Color.Red
        Me.r2.Location = New System.Drawing.Point(252, 236)
        Me.r2.Name = "r2"
        Me.r2.Size = New System.Drawing.Size(214, 197)
        Me.r2.TabIndex = 2
        Me.r2.Text = ""
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(830, 490)
        Me.Controls.Add(Me.FormSkin1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form2"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.FormSkin1.ResumeLayout(False)
        Me.FlatGroupBox1.ResumeLayout(False)
        Me.FlatGroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents FormSkin1 As Crypter_ALl_tool.FormSkin
    Friend WithEvents r1 As System.Windows.Forms.RichTextBox
    Friend WithEvents r2 As System.Windows.Forms.RichTextBox
    Friend WithEvents Button1 As Crypter_ALl_tool.FlatButton
    Friend WithEvents Button2 As Crypter_ALl_tool.FlatButton
    Friend WithEvents Button4 As Crypter_ALl_tool.FlatButton
    Friend WithEvents Button5 As Crypter_ALl_tool.FlatButton
    Friend WithEvents Button6 As Crypter_ALl_tool.FlatButton
    Friend WithEvents Button3 As Crypter_ALl_tool.FlatButton
    Friend WithEvents T16 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t3 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t1 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents Label2 As Crypter_ALl_tool.FlatLabel
    Friend WithEvents FlatGroupBox1 As Crypter_ALl_tool.FlatGroupBox
    Friend WithEvents a1 As System.Windows.Forms.RichTextBox
    Friend WithEvents t4 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents t5 As Crypter_ALl_tool.FlatTextBox
    Friend WithEvents FlatButton4 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatButton3 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatButton1 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatButton2 As Crypter_ALl_tool.FlatButton
    Friend WithEvents FlatButton10 As Crypter_ALl_tool.FlatButton
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents FlatButton18 As Crypter_ALl_tool.FlatButton
End Class
