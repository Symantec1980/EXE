﻿/* 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

 * 
 * CodeDefender 
 * Copyright © 2010 http://codedefender.codeplex.com (oguz@bastemur.com)
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace CodeDefender
{
    internal class Helpers
    {
        public static List<string> ILVersions;

        public static void searchFiles(string sDir)
        {
            try
            {
                foreach (string dir in Directory.GetDirectories(sDir))
                {
                    foreach (string f in Directory.GetFiles(dir, "vcvarsall.bat"))
                    {
                        ILVersions.Add(f.Substring(0, f.Length-13));
                    }
                    searchFiles(dir);
                }
            }
            catch (System.Exception)
            {
            }
        }

        public static void locationOfBinaries()
        {
            short locationCount = 1;
            if (IntPtr.Size == 8 || (!String.IsNullOrEmpty(Environment.GetEnvironmentVariable("PROCESSOR_ARCHITEW6432"))))
            {
                locationCount++;
            }
            string[] locations = new string[locationCount];

            locations[0] = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);

            if (locationCount > 1)
            {
                if (locations[0].EndsWith("(x86)"))
                {
                    locations[1] = locations[0].Substring(0, locations[0].Length - 5).Trim();
                }
                else
                {
                    locations[1] = locations[0] + "(x86)";
                }
            }

            foreach (string location in locations)
            {
                foreach (string directory in Directory.GetDirectories(location, "Microsoft*.*"))
                    searchFiles(directory);
            }
        }

    }
}
