﻿namespace The_RATs_Crew_Crypter
{
    partial class frmTRC_Crypter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            The_RATs_Crew_Crypter.Pigment pigment1 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment2 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment3 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment4 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment5 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment6 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment7 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment8 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment9 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment10 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment11 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment12 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment13 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment14 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment15 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment16 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment17 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment18 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment19 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment20 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment21 = new The_RATs_Crew_Crypter.Pigment();
            this.groupBox3 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbXOR = new System.Windows.Forms.RadioButton();
            this.rdbSymentric = new System.Windows.Forms.RadioButton();
            this.rdbRijndael = new System.Windows.Forms.RadioButton();
            this.rdbRC4 = new System.Windows.Forms.RadioButton();
            this.rdbRC2 = new System.Windows.Forms.RadioButton();
            this.rdbTripleDES = new System.Windows.Forms.RadioButton();
            this.rdbDES = new System.Windows.Forms.RadioButton();
            this.btnEncrypt = new The_RATs_Crew_Crypter.FButton();
            this.groupBox2 = new The_RATs_Crew_Crypter.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new The_RATs_Crew_Crypter.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSelectIcon = new The_RATs_Crew_Crypter.FButton();
            this.txtIcon = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectFile = new The_RATs_Crew_Crypter.FButton();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.groupBox4 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbDefaultBrowser = new System.Windows.Forms.RadioButton();
            this.rdbInjectInto = new System.Windows.Forms.RadioButton();
            this.txtInjectInto = new System.Windows.Forms.TextBox();
            this.groupBox5 = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbRunPE3 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE2 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE1 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE0 = new System.Windows.Forms.RadioButton();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox3
            // 
            this.groupBox3.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox3.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox3.Controls.Add(this.rdbXOR);
            this.groupBox3.Controls.Add(this.rdbSymentric);
            this.groupBox3.Controls.Add(this.rdbRijndael);
            this.groupBox3.Controls.Add(this.rdbRC4);
            this.groupBox3.Controls.Add(this.rdbRC2);
            this.groupBox3.Controls.Add(this.rdbTripleDES);
            this.groupBox3.Controls.Add(this.rdbDES);
            this.groupBox3.FillColor = System.Drawing.Color.Transparent;
            this.groupBox3.Location = new System.Drawing.Point(14, 287);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.NoRounding = false;
            this.groupBox3.Size = new System.Drawing.Size(355, 56);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.Text = "groupBox3";
            // 
            // rdbXOR
            // 
            this.rdbXOR.AutoSize = true;
            this.rdbXOR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbXOR.Location = new System.Drawing.Point(287, 7);
            this.rdbXOR.Name = "rdbXOR";
            this.rdbXOR.Size = new System.Drawing.Size(50, 17);
            this.rdbXOR.TabIndex = 6;
            this.rdbXOR.Text = "XOR";
            this.rdbXOR.UseVisualStyleBackColor = true;
            // 
            // rdbSymentric
            // 
            this.rdbSymentric.AutoSize = true;
            this.rdbSymentric.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbSymentric.Location = new System.Drawing.Point(188, 30);
            this.rdbSymentric.Name = "rdbSymentric";
            this.rdbSymentric.Size = new System.Drawing.Size(83, 17);
            this.rdbSymentric.TabIndex = 5;
            this.rdbSymentric.Text = "Symentric";
            this.rdbSymentric.UseVisualStyleBackColor = true;
            // 
            // rdbRijndael
            // 
            this.rdbRijndael.AutoSize = true;
            this.rdbRijndael.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRijndael.Location = new System.Drawing.Point(188, 7);
            this.rdbRijndael.Name = "rdbRijndael";
            this.rdbRijndael.Size = new System.Drawing.Size(71, 17);
            this.rdbRijndael.TabIndex = 4;
            this.rdbRijndael.Text = "Rijndael";
            this.rdbRijndael.UseVisualStyleBackColor = true;
            // 
            // rdbRC4
            // 
            this.rdbRC4.AutoSize = true;
            this.rdbRC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC4.Location = new System.Drawing.Point(112, 30);
            this.rdbRC4.Name = "rdbRC4";
            this.rdbRC4.Size = new System.Drawing.Size(49, 17);
            this.rdbRC4.TabIndex = 3;
            this.rdbRC4.Text = "RC4";
            this.rdbRC4.UseVisualStyleBackColor = true;
            // 
            // rdbRC2
            // 
            this.rdbRC2.AutoSize = true;
            this.rdbRC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC2.Location = new System.Drawing.Point(112, 7);
            this.rdbRC2.Name = "rdbRC2";
            this.rdbRC2.Size = new System.Drawing.Size(49, 17);
            this.rdbRC2.TabIndex = 2;
            this.rdbRC2.Text = "RC2";
            this.rdbRC2.UseVisualStyleBackColor = true;
            // 
            // rdbTripleDES
            // 
            this.rdbTripleDES.AutoSize = true;
            this.rdbTripleDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbTripleDES.Location = new System.Drawing.Point(18, 30);
            this.rdbTripleDES.Name = "rdbTripleDES";
            this.rdbTripleDES.Size = new System.Drawing.Size(81, 17);
            this.rdbTripleDES.TabIndex = 1;
            this.rdbTripleDES.Text = "TripleDES";
            this.rdbTripleDES.UseVisualStyleBackColor = true;
            // 
            // rdbDES
            // 
            this.rdbDES.AutoSize = true;
            this.rdbDES.Checked = true;
            this.rdbDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDES.Location = new System.Drawing.Point(18, 7);
            this.rdbDES.Name = "rdbDES";
            this.rdbDES.Size = new System.Drawing.Size(49, 17);
            this.rdbDES.TabIndex = 0;
            this.rdbDES.TabStop = true;
            this.rdbDES.Text = "DES";
            this.rdbDES.UseVisualStyleBackColor = true;
            // 
            // btnEncrypt
            // 
            pigment1.Name = "Border";
            pigment1.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment2.Name = "Backcolor";
            pigment2.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment3.Name = "Highlight";
            pigment3.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment4.Name = "Gradient1";
            pigment4.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment5.Name = "Gradient2";
            pigment5.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment6.Name = "Text Color";
            pigment6.Value = System.Drawing.Color.White;
            pigment7.Name = "Text Shadow";
            pigment7.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnEncrypt.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment1,
        pigment2,
        pigment3,
        pigment4,
        pigment5,
        pigment6,
        pigment7};
            this.btnEncrypt.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnEncrypt.Location = new System.Drawing.Point(144, 460);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Shadow = true;
            this.btnEncrypt.Size = new System.Drawing.Size(91, 27);
            this.btnEncrypt.TabIndex = 4;
            this.btnEncrypt.Text = "ENCRYPT";
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.FillColor = System.Drawing.Color.Transparent;
            this.groupBox2.Location = new System.Drawing.Point(14, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.NoRounding = false;
            this.groupBox2.Size = new System.Drawing.Size(355, 153);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.Text = "groupBox2";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::The_RATs_Crew_Crypter.Properties.Resources.ratscrewlogo;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(352, 149);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnSelectIcon);
            this.groupBox1.Controls.Add(this.txtIcon);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSelectFile);
            this.groupBox1.Controls.Add(this.txtFile);
            this.groupBox1.FillColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(14, 171);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.NoRounding = false;
            this.groupBox1.Size = new System.Drawing.Size(355, 110);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.Text = "groupBox1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label2.Location = new System.Drawing.Point(15, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Icon:";
            // 
            // btnSelectIcon
            // 
            pigment8.Name = "Border";
            pigment8.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment9.Name = "Backcolor";
            pigment9.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment10.Name = "Highlight";
            pigment10.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment11.Name = "Gradient1";
            pigment11.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment12.Name = "Gradient2";
            pigment12.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment13.Name = "Text Color";
            pigment13.Value = System.Drawing.Color.White;
            pigment14.Name = "Text Shadow";
            pigment14.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectIcon.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment8,
        pigment9,
        pigment10,
        pigment11,
        pigment12,
        pigment13,
        pigment14};
            this.btnSelectIcon.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectIcon.Location = new System.Drawing.Point(287, 72);
            this.btnSelectIcon.Name = "btnSelectIcon";
            this.btnSelectIcon.Shadow = true;
            this.btnSelectIcon.Size = new System.Drawing.Size(54, 23);
            this.btnSelectIcon.TabIndex = 5;
            this.btnSelectIcon.Text = "...";
            this.btnSelectIcon.Click += new System.EventHandler(this.btnSelectIcon_Click);
            // 
            // txtIcon
            // 
            this.txtIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIcon.ForeColor = System.Drawing.Color.Lime;
            this.txtIcon.Location = new System.Drawing.Point(18, 74);
            this.txtIcon.Name = "txtIcon";
            this.txtIcon.Size = new System.Drawing.Size(254, 21);
            this.txtIcon.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label1.Location = new System.Drawing.Point(15, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "File to be encrypted:";
            // 
            // btnSelectFile
            // 
            pigment15.Name = "Border";
            pigment15.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment16.Name = "Backcolor";
            pigment16.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment17.Name = "Highlight";
            pigment17.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment18.Name = "Gradient1";
            pigment18.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment19.Name = "Gradient2";
            pigment19.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment20.Name = "Text Color";
            pigment20.Value = System.Drawing.Color.White;
            pigment21.Name = "Text Shadow";
            pigment21.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectFile.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment15,
        pigment16,
        pigment17,
        pigment18,
        pigment19,
        pigment20,
        pigment21};
            this.btnSelectFile.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectFile.Location = new System.Drawing.Point(287, 26);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Shadow = true;
            this.btnSelectFile.Size = new System.Drawing.Size(54, 23);
            this.btnSelectFile.TabIndex = 2;
            this.btnSelectFile.Text = "...";
            this.btnSelectFile.Click += new System.EventHandler(this.btnEncryptedFileSearch_Click);
            // 
            // txtFile
            // 
            this.txtFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFile.ForeColor = System.Drawing.Color.Lime;
            this.txtFile.Location = new System.Drawing.Point(18, 28);
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(254, 21);
            this.txtFile.TabIndex = 1;
            // 
            // groupBox4
            // 
            this.groupBox4.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox4.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox4.Controls.Add(this.rdbDefaultBrowser);
            this.groupBox4.Controls.Add(this.rdbInjectInto);
            this.groupBox4.Controls.Add(this.txtInjectInto);
            this.groupBox4.FillColor = System.Drawing.Color.Transparent;
            this.groupBox4.Location = new System.Drawing.Point(14, 349);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.NoRounding = false;
            this.groupBox4.Size = new System.Drawing.Size(355, 40);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.Text = "groupBox4";
            // 
            // rdbDefaultBrowser
            // 
            this.rdbDefaultBrowser.AutoSize = true;
            this.rdbDefaultBrowser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDefaultBrowser.Location = new System.Drawing.Point(227, 11);
            this.rdbDefaultBrowser.Name = "rdbDefaultBrowser";
            this.rdbDefaultBrowser.Size = new System.Drawing.Size(117, 17);
            this.rdbDefaultBrowser.TabIndex = 9;
            this.rdbDefaultBrowser.TabStop = true;
            this.rdbDefaultBrowser.Text = "Default Browser";
            this.rdbDefaultBrowser.UseVisualStyleBackColor = true;
            // 
            // rdbInjectInto
            // 
            this.rdbInjectInto.AutoSize = true;
            this.rdbInjectInto.Checked = true;
            this.rdbInjectInto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInjectInto.Location = new System.Drawing.Point(18, 11);
            this.rdbInjectInto.Name = "rdbInjectInto";
            this.rdbInjectInto.Size = new System.Drawing.Size(88, 17);
            this.rdbInjectInto.TabIndex = 8;
            this.rdbInjectInto.TabStop = true;
            this.rdbInjectInto.Text = "Inject into:";
            this.rdbInjectInto.UseVisualStyleBackColor = true;
            // 
            // txtInjectInto
            // 
            this.txtInjectInto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtInjectInto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInjectInto.ForeColor = System.Drawing.Color.Lime;
            this.txtInjectInto.Location = new System.Drawing.Point(112, 9);
            this.txtInjectInto.Name = "txtInjectInto";
            this.txtInjectInto.Size = new System.Drawing.Size(99, 21);
            this.txtInjectInto.TabIndex = 7;
            this.txtInjectInto.Text = "svchost.exe";
            // 
            // groupBox5
            // 
            this.groupBox5.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox5.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox5.Controls.Add(this.rdbRunPE3);
            this.groupBox5.Controls.Add(this.rdbRunPE2);
            this.groupBox5.Controls.Add(this.rdbRunPE1);
            this.groupBox5.Controls.Add(this.rdbRunPE0);
            this.groupBox5.FillColor = System.Drawing.Color.Transparent;
            this.groupBox5.Location = new System.Drawing.Point(14, 395);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.NoRounding = false;
            this.groupBox5.Size = new System.Drawing.Size(355, 59);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.Text = "groupBox5";
            // 
            // rdbRunPE3
            // 
            this.rdbRunPE3.AutoSize = true;
            this.rdbRunPE3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE3.Location = new System.Drawing.Point(227, 34);
            this.rdbRunPE3.Name = "rdbRunPE3";
            this.rdbRunPE3.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE3.TabIndex = 3;
            this.rdbRunPE3.TabStop = true;
            this.rdbRunPE3.Text = "RunPE 4 (3.5kb)";
            this.rdbRunPE3.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE2
            // 
            this.rdbRunPE2.AutoSize = true;
            this.rdbRunPE2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE2.Location = new System.Drawing.Point(227, 11);
            this.rdbRunPE2.Name = "rdbRunPE2";
            this.rdbRunPE2.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE2.TabIndex = 2;
            this.rdbRunPE2.Text = "RunPE 3 (12.5kb)";
            this.rdbRunPE2.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE1
            // 
            this.rdbRunPE1.AutoSize = true;
            this.rdbRunPE1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE1.Location = new System.Drawing.Point(18, 34);
            this.rdbRunPE1.Name = "rdbRunPE1";
            this.rdbRunPE1.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE1.TabIndex = 1;
            this.rdbRunPE1.Text = "RunPE 2 (3.0kb)";
            this.rdbRunPE1.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE0
            // 
            this.rdbRunPE0.AutoSize = true;
            this.rdbRunPE0.Checked = true;
            this.rdbRunPE0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE0.Location = new System.Drawing.Point(18, 11);
            this.rdbRunPE0.Name = "rdbRunPE0";
            this.rdbRunPE0.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE0.TabIndex = 0;
            this.rdbRunPE0.TabStop = true;
            this.rdbRunPE0.Text = "RunPE 1 (13.5kb)";
            this.rdbRunPE0.UseVisualStyleBackColor = true;
            // 
            // frmTRC_Crypter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ClientSize = new System.Drawing.Size(379, 495);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmTRC_Crypter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TRC Crypter ~ Version 1.3";
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFile;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private FButton btnSelectFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private FButton btnSelectIcon;
        private System.Windows.Forms.TextBox txtIcon;
        private FButton btnEncrypt;
        private GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rdbTripleDES;
        private System.Windows.Forms.RadioButton rdbDES;
        private System.Windows.Forms.RadioButton rdbXOR;
        private System.Windows.Forms.RadioButton rdbSymentric;
        private System.Windows.Forms.RadioButton rdbRijndael;
        private System.Windows.Forms.RadioButton rdbRC4;
        private System.Windows.Forms.RadioButton rdbRC2;
        private GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rdbDefaultBrowser;
        private System.Windows.Forms.RadioButton rdbInjectInto;
        private System.Windows.Forms.TextBox txtInjectInto;
        private GroupBox groupBox5;
        private System.Windows.Forms.RadioButton rdbRunPE3;
        private System.Windows.Forms.RadioButton rdbRunPE2;
        private System.Windows.Forms.RadioButton rdbRunPE1;
        private System.Windows.Forms.RadioButton rdbRunPE0;
    }
}

