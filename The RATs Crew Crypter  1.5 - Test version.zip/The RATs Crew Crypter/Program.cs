﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace The_RATs_Crew_Crypter
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            new System.Threading.Thread(delegate()
            {
                try
                {
                    double version = 1.4;
                    double CurrentVersion = Convert.ToDouble(new System.Net.WebClient().DownloadString(
                        "http://dl.dropbox.com/u/23840983/RATs%20Crew%20Crypter/version.txt"));
                    CurrentVersion /= 10;
                    if (CurrentVersion > version)
                    {
                        DialogResult result = MessageBox.Show("There is an update available (v" + CurrentVersion + "), would you like to download it?",
                            "Update available", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                        if (result == DialogResult.Yes)
                        {
                            SaveFileDialog diag = new SaveFileDialog();
                            diag.Filter = "Executable (*.exe)|*.exe";
                            if (diag.ShowDialog() == DialogResult.OK)
                            {
                                new System.Net.WebClient().DownloadFile(
                                    "http://dl.dropbox.com/u/23840983/RATs%20Crew%20Crypter/The%20RATs%20Crew%20Crypter.exe",
                                    diag.FileName);
                                MessageBox.Show("Successfully downloaded the update!\r\n\r\nTake care,\r\nCaptainBri");
                            }
                        }
                    }
                }
                catch { }
            }).Start();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmTRC_Crypter());
        }
    }
}
