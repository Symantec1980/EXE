﻿Public Class Form1

    Private Sub NsButton1_Click(sender As Object, e As EventArgs) Handles NsButton1.Click
        Dim ofd As New OpenFileDialog With
       {
           .Filter = "ExE Files (*.exe) | *.exe"
           }
        If ofd.ShowDialog() = Windows.Forms.DialogResult.OK Then
            TextBox1.Text = ofd.FileName
        End If
    End Sub

    Private Sub NsButton2_Click(sender As Object, e As EventArgs) Handles NsButton2.Click
        Dim os As String = NumericUpDown1.Value
        If (Not String.IsNullOrEmpty(TextBox1.Text)) Then
            Dim azert As String = Convert.ToBase64String(IO.File.ReadAllBytes(TextBox1.Text))
            Dim rty As String = azert.Length
            Dim osx As String = rty / os
            Dim kerkoz As Integer
            Dim oiuy As String
            Dim fsdfs As String = ""
            Dim dfhdfhdf As String = "ഗദ്യപ്രബന്ധമാണ്ഉപന്യാസം"
            For ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ As Integer = 1 To os
                For lop = 0 To rty - 1 Step +os
                    oiuy += Mid(azert, lop + ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ, 1)
                Next
                Dim ertyuio As String = ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ
                dfhdfhdf = dfhdfhdf + " & Strings.Mid(ണ്ടാവേണ്ടതാണ്വിഷയത്തിന്റെആരംഭത്തെക്കുറിച്ചുംഉപസംഹാരത്തെക്കുറിച്ചുംരചയിതാവ്" + ertyuio + ", ഏകാഗ്രതയോടെസമീപിയ്ക്കുന്നതാണ്ഒന്നാമത്തെഗുണംവിഷയത്തെ, 1)"
                fsdfs = fsdfs + "dim ണ്ടാവേണ്ടതാണ്വിഷയത്തിന്റെആരംഭത്തെക്കുറിച്ചുംഉപസംഹാരത്തെക്കുറിച്ചുംരചയിതാവ്" + ertyuio + " as string= """ + oiuy + """" + ChrW(10)
                oiuy = ""
            Next
            TextBox1.Text = My.Resources.stub.Replace("अपेक्षाइतनास्वतंत्रहैकिउसकीसटीकपरिभाषाकरनाअत्यंकठिनहै", fsdfs).Replace("写作者惯常用各种修辞手法曲折传达自己的见解和情", dfhdfhdf)
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub NsTextBox1_TextChanged(sender As Object, e As EventArgs) Handles NsTextBox1.TextChanged

    End Sub

    Private Sub NsButton3_Click(sender As Object, e As EventArgs) Handles NsButton3.Click
        Clipboard.Clear()
        If NsTextBox1.Text = "" Then
            MsgBox("No Text To Copie", MsgBoxStyle.Critical, "Information")
            Exit Sub
        End If
        Clipboard.SetText(NsTextBox1.Text)
        MsgBox("Copied", MsgBoxStyle.Information, "Information")
    End Sub

    Private Sub NsButton4_Click(sender As Object, e As EventArgs) Handles NsButton4.Click
        MsgBox("♕| K O P R A |♕")

    End Sub

    Private Sub NsButton5_Click(sender As Object, e As EventArgs) Handles NsButton5.Click
        Me.Close()
    End Sub
End Class
