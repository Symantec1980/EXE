﻿namespace The_RATs_Crew_Crypter
{
    partial class frmTRC_Crypter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            The_RATs_Crew_Crypter.Pigment pigment29 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment30 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment31 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment32 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment33 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment34 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment35 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment36 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment37 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment38 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment39 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment40 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment41 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment42 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment43 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment44 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment45 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment46 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment47 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment48 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment49 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment50 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment51 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment52 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment53 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment54 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment55 = new The_RATs_Crew_Crypter.Pigment();
            The_RATs_Crew_Crypter.Pigment pigment56 = new The_RATs_Crew_Crypter.Pigment();
            this.btnRunPEs = new System.Windows.Forms.Button();
            this.btnEncryption = new System.Windows.Forms.Button();
            this.btnInjection = new System.Windows.Forms.Button();
            this.btnJunk = new System.Windows.Forms.Button();
            this.grpRunPEs = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbRunPE11 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE10 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE9 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE8 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE7 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE6 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE5 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE4 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE3 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE2 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE1 = new System.Windows.Forms.RadioButton();
            this.rdbRunPE0 = new System.Windows.Forms.RadioButton();
            this.grpInjectionTo = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbVBC = new System.Windows.Forms.RadioButton();
            this.rdbDefaultBrowser = new System.Windows.Forms.RadioButton();
            this.rdbInjectInto = new System.Windows.Forms.RadioButton();
            this.txtInjectInto = new System.Windows.Forms.TextBox();
            this.grpEncryptions = new The_RATs_Crew_Crypter.GroupBox();
            this.rdbPolyCloud = new System.Windows.Forms.RadioButton();
            this.rdbCloud = new System.Windows.Forms.RadioButton();
            this.rdbStairs = new System.Windows.Forms.RadioButton();
            this.rdbAES = new System.Windows.Forms.RadioButton();
            this.rdbPolyBaby = new System.Windows.Forms.RadioButton();
            this.rdbDex = new System.Windows.Forms.RadioButton();
            this.rdbPolyStairs = new System.Windows.Forms.RadioButton();
            this.rdbXOR = new System.Windows.Forms.RadioButton();
            this.rdbSymentric = new System.Windows.Forms.RadioButton();
            this.rdbPolyRev = new System.Windows.Forms.RadioButton();
            this.rdbRijndael = new System.Windows.Forms.RadioButton();
            this.rdbRC4 = new System.Windows.Forms.RadioButton();
            this.rdbRC2 = new System.Windows.Forms.RadioButton();
            this.rdbTripleDES = new System.Windows.Forms.RadioButton();
            this.rdbDES = new System.Windows.Forms.RadioButton();
            this.btnEncrypt = new The_RATs_Crew_Crypter.FButton();
            this.groupBox2 = new The_RATs_Crew_Crypter.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new The_RATs_Crew_Crypter.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSelectBindFile = new The_RATs_Crew_Crypter.FButton();
            this.txtBindFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSelectIcon = new The_RATs_Crew_Crypter.FButton();
            this.txtIcon = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSelectFile = new The_RATs_Crew_Crypter.FButton();
            this.txtFile = new System.Windows.Forms.TextBox();
            this.grpJunk = new The_RATs_Crew_Crypter.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.grpRunPEs.SuspendLayout();
            this.grpInjectionTo.SuspendLayout();
            this.grpEncryptions.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.grpJunk.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRunPEs
            // 
            this.btnRunPEs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRunPEs.ForeColor = System.Drawing.Color.Red;
            this.btnRunPEs.Location = new System.Drawing.Point(7, 300);
            this.btnRunPEs.Name = "btnRunPEs";
            this.btnRunPEs.Size = new System.Drawing.Size(75, 23);
            this.btnRunPEs.TabIndex = 10;
            this.btnRunPEs.Text = "RunPE\'s";
            this.btnRunPEs.UseVisualStyleBackColor = true;
            this.btnRunPEs.Click += new System.EventHandler(this.btnRunPEs_Click);
            // 
            // btnEncryption
            // 
            this.btnEncryption.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEncryption.ForeColor = System.Drawing.Color.Red;
            this.btnEncryption.Location = new System.Drawing.Point(87, 300);
            this.btnEncryption.Name = "btnEncryption";
            this.btnEncryption.Size = new System.Drawing.Size(77, 23);
            this.btnEncryption.TabIndex = 11;
            this.btnEncryption.Text = "Encryption";
            this.btnEncryption.UseVisualStyleBackColor = true;
            this.btnEncryption.Click += new System.EventHandler(this.btnEncryption_Click);
            // 
            // btnInjection
            // 
            this.btnInjection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInjection.ForeColor = System.Drawing.Color.Red;
            this.btnInjection.Location = new System.Drawing.Point(167, 300);
            this.btnInjection.Name = "btnInjection";
            this.btnInjection.Size = new System.Drawing.Size(75, 23);
            this.btnInjection.TabIndex = 12;
            this.btnInjection.Text = "Injection";
            this.btnInjection.UseVisualStyleBackColor = true;
            this.btnInjection.Click += new System.EventHandler(this.btnInjection_Click);
            // 
            // btnJunk
            // 
            this.btnJunk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnJunk.ForeColor = System.Drawing.Color.Red;
            this.btnJunk.Location = new System.Drawing.Point(248, 300);
            this.btnJunk.Name = "btnJunk";
            this.btnJunk.Size = new System.Drawing.Size(75, 23);
            this.btnJunk.TabIndex = 13;
            this.btnJunk.Text = "Junk";
            this.btnJunk.UseVisualStyleBackColor = true;
            this.btnJunk.Click += new System.EventHandler(this.btnUSG_Click);
            // 
            // grpRunPEs
            // 
            this.grpRunPEs.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpRunPEs.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpRunPEs.Controls.Add(this.rdbRunPE11);
            this.grpRunPEs.Controls.Add(this.rdbRunPE10);
            this.grpRunPEs.Controls.Add(this.rdbRunPE9);
            this.grpRunPEs.Controls.Add(this.rdbRunPE8);
            this.grpRunPEs.Controls.Add(this.rdbRunPE7);
            this.grpRunPEs.Controls.Add(this.rdbRunPE6);
            this.grpRunPEs.Controls.Add(this.rdbRunPE5);
            this.grpRunPEs.Controls.Add(this.rdbRunPE4);
            this.grpRunPEs.Controls.Add(this.rdbRunPE3);
            this.grpRunPEs.Controls.Add(this.rdbRunPE2);
            this.grpRunPEs.Controls.Add(this.rdbRunPE1);
            this.grpRunPEs.Controls.Add(this.rdbRunPE0);
            this.grpRunPEs.FillColor = System.Drawing.Color.Transparent;
            this.grpRunPEs.Location = new System.Drawing.Point(6, 329);
            this.grpRunPEs.Name = "grpRunPEs";
            this.grpRunPEs.NoRounding = false;
            this.grpRunPEs.Size = new System.Drawing.Size(317, 127);
            this.grpRunPEs.TabIndex = 9;
            this.grpRunPEs.Text = "groupBox5";
            // 
            // rdbRunPE11
            // 
            this.rdbRunPE11.AutoSize = true;
            this.rdbRunPE11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE11.Location = new System.Drawing.Point(177, 100);
            this.rdbRunPE11.Name = "rdbRunPE11";
            this.rdbRunPE11.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE11.TabIndex = 13;
            this.rdbRunPE11.TabStop = true;
            this.rdbRunPE11.Text = "RunPE 12 (3.5kb)";
            this.rdbRunPE11.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE10
            // 
            this.rdbRunPE10.AutoSize = true;
            this.rdbRunPE10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE10.Location = new System.Drawing.Point(177, 82);
            this.rdbRunPE10.Name = "rdbRunPE10";
            this.rdbRunPE10.Size = new System.Drawing.Size(121, 17);
            this.rdbRunPE10.TabIndex = 12;
            this.rdbRunPE10.TabStop = true;
            this.rdbRunPE10.Text = "RunPE 11 (13kb)";
            this.rdbRunPE10.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE9
            // 
            this.rdbRunPE9.AutoSize = true;
            this.rdbRunPE9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE9.Location = new System.Drawing.Point(177, 64);
            this.rdbRunPE9.Name = "rdbRunPE9";
            this.rdbRunPE9.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE9.TabIndex = 11;
            this.rdbRunPE9.TabStop = true;
            this.rdbRunPE9.Text = "RunPE 10 (9.5kb)";
            this.rdbRunPE9.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE8
            // 
            this.rdbRunPE8.AutoSize = true;
            this.rdbRunPE8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE8.Location = new System.Drawing.Point(177, 46);
            this.rdbRunPE8.Name = "rdbRunPE8";
            this.rdbRunPE8.Size = new System.Drawing.Size(114, 17);
            this.rdbRunPE8.TabIndex = 10;
            this.rdbRunPE8.TabStop = true;
            this.rdbRunPE8.Text = "RunPE 9 (10kb)";
            this.rdbRunPE8.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE7
            // 
            this.rdbRunPE7.AutoSize = true;
            this.rdbRunPE7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE7.Location = new System.Drawing.Point(177, 28);
            this.rdbRunPE7.Name = "rdbRunPE7";
            this.rdbRunPE7.Size = new System.Drawing.Size(114, 17);
            this.rdbRunPE7.TabIndex = 9;
            this.rdbRunPE7.TabStop = true;
            this.rdbRunPE7.Text = "RunPE 8 (13kb)";
            this.rdbRunPE7.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE6
            // 
            this.rdbRunPE6.AutoSize = true;
            this.rdbRunPE6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE6.Location = new System.Drawing.Point(177, 10);
            this.rdbRunPE6.Name = "rdbRunPE6";
            this.rdbRunPE6.Size = new System.Drawing.Size(107, 17);
            this.rdbRunPE6.TabIndex = 8;
            this.rdbRunPE6.Text = "RunPE 7 (8kb)";
            this.rdbRunPE6.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE5
            // 
            this.rdbRunPE5.AutoSize = true;
            this.rdbRunPE5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE5.Location = new System.Drawing.Point(9, 100);
            this.rdbRunPE5.Name = "rdbRunPE5";
            this.rdbRunPE5.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE5.TabIndex = 7;
            this.rdbRunPE5.TabStop = true;
            this.rdbRunPE5.Text = "RunPE 6 (8.5kb)";
            this.rdbRunPE5.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE4
            // 
            this.rdbRunPE4.AutoSize = true;
            this.rdbRunPE4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE4.Location = new System.Drawing.Point(9, 82);
            this.rdbRunPE4.Name = "rdbRunPE4";
            this.rdbRunPE4.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE4.TabIndex = 6;
            this.rdbRunPE4.Text = "RunPE 5 (3.5kb)";
            this.rdbRunPE4.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE3
            // 
            this.rdbRunPE3.AutoSize = true;
            this.rdbRunPE3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE3.Location = new System.Drawing.Point(9, 64);
            this.rdbRunPE3.Name = "rdbRunPE3";
            this.rdbRunPE3.Size = new System.Drawing.Size(118, 17);
            this.rdbRunPE3.TabIndex = 3;
            this.rdbRunPE3.TabStop = true;
            this.rdbRunPE3.Text = "RunPE 4 (3.5kb)";
            this.rdbRunPE3.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE2
            // 
            this.rdbRunPE2.AutoSize = true;
            this.rdbRunPE2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE2.Location = new System.Drawing.Point(9, 46);
            this.rdbRunPE2.Name = "rdbRunPE2";
            this.rdbRunPE2.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE2.TabIndex = 2;
            this.rdbRunPE2.Text = "RunPE 3 (12.5kb)";
            this.rdbRunPE2.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE1
            // 
            this.rdbRunPE1.AutoSize = true;
            this.rdbRunPE1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE1.Location = new System.Drawing.Point(9, 28);
            this.rdbRunPE1.Name = "rdbRunPE1";
            this.rdbRunPE1.Size = new System.Drawing.Size(107, 17);
            this.rdbRunPE1.TabIndex = 1;
            this.rdbRunPE1.Text = "RunPE 2 (3kb)";
            this.rdbRunPE1.UseVisualStyleBackColor = true;
            // 
            // rdbRunPE0
            // 
            this.rdbRunPE0.AutoSize = true;
            this.rdbRunPE0.Checked = true;
            this.rdbRunPE0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRunPE0.Location = new System.Drawing.Point(9, 10);
            this.rdbRunPE0.Name = "rdbRunPE0";
            this.rdbRunPE0.Size = new System.Drawing.Size(125, 17);
            this.rdbRunPE0.TabIndex = 0;
            this.rdbRunPE0.TabStop = true;
            this.rdbRunPE0.Text = "RunPE 1 (13.5kb)";
            this.rdbRunPE0.UseVisualStyleBackColor = true;
            // 
            // grpInjectionTo
            // 
            this.grpInjectionTo.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpInjectionTo.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpInjectionTo.Controls.Add(this.rdbVBC);
            this.grpInjectionTo.Controls.Add(this.rdbDefaultBrowser);
            this.grpInjectionTo.Controls.Add(this.rdbInjectInto);
            this.grpInjectionTo.Controls.Add(this.txtInjectInto);
            this.grpInjectionTo.FillColor = System.Drawing.Color.Transparent;
            this.grpInjectionTo.Location = new System.Drawing.Point(345, 156);
            this.grpInjectionTo.Name = "grpInjectionTo";
            this.grpInjectionTo.NoRounding = false;
            this.grpInjectionTo.Size = new System.Drawing.Size(317, 127);
            this.grpInjectionTo.TabIndex = 8;
            this.grpInjectionTo.Text = "groupBox4";
            // 
            // rdbVBC
            // 
            this.rdbVBC.AutoSize = true;
            this.rdbVBC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbVBC.Location = new System.Drawing.Point(12, 66);
            this.rdbVBC.Name = "rdbVBC";
            this.rdbVBC.Size = new System.Drawing.Size(46, 17);
            this.rdbVBC.TabIndex = 10;
            this.rdbVBC.TabStop = true;
            this.rdbVBC.Text = "Vbc";
            this.rdbVBC.UseVisualStyleBackColor = true;
            // 
            // rdbDefaultBrowser
            // 
            this.rdbDefaultBrowser.AutoSize = true;
            this.rdbDefaultBrowser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDefaultBrowser.Location = new System.Drawing.Point(12, 42);
            this.rdbDefaultBrowser.Name = "rdbDefaultBrowser";
            this.rdbDefaultBrowser.Size = new System.Drawing.Size(117, 17);
            this.rdbDefaultBrowser.TabIndex = 9;
            this.rdbDefaultBrowser.TabStop = true;
            this.rdbDefaultBrowser.Text = "Default Browser";
            this.rdbDefaultBrowser.UseVisualStyleBackColor = true;
            // 
            // rdbInjectInto
            // 
            this.rdbInjectInto.AutoSize = true;
            this.rdbInjectInto.Checked = true;
            this.rdbInjectInto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbInjectInto.Location = new System.Drawing.Point(12, 16);
            this.rdbInjectInto.Name = "rdbInjectInto";
            this.rdbInjectInto.Size = new System.Drawing.Size(88, 17);
            this.rdbInjectInto.TabIndex = 8;
            this.rdbInjectInto.TabStop = true;
            this.rdbInjectInto.Text = "Inject into:";
            this.rdbInjectInto.UseVisualStyleBackColor = true;
            // 
            // txtInjectInto
            // 
            this.txtInjectInto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtInjectInto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInjectInto.ForeColor = System.Drawing.Color.Lime;
            this.txtInjectInto.Location = new System.Drawing.Point(106, 16);
            this.txtInjectInto.Name = "txtInjectInto";
            this.txtInjectInto.Size = new System.Drawing.Size(195, 21);
            this.txtInjectInto.TabIndex = 7;
            this.txtInjectInto.Text = "svchost.exe";
            // 
            // grpEncryptions
            // 
            this.grpEncryptions.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpEncryptions.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpEncryptions.Controls.Add(this.rdbPolyCloud);
            this.grpEncryptions.Controls.Add(this.rdbCloud);
            this.grpEncryptions.Controls.Add(this.rdbStairs);
            this.grpEncryptions.Controls.Add(this.rdbAES);
            this.grpEncryptions.Controls.Add(this.rdbPolyBaby);
            this.grpEncryptions.Controls.Add(this.rdbDex);
            this.grpEncryptions.Controls.Add(this.rdbPolyStairs);
            this.grpEncryptions.Controls.Add(this.rdbXOR);
            this.grpEncryptions.Controls.Add(this.rdbSymentric);
            this.grpEncryptions.Controls.Add(this.rdbPolyRev);
            this.grpEncryptions.Controls.Add(this.rdbRijndael);
            this.grpEncryptions.Controls.Add(this.rdbRC4);
            this.grpEncryptions.Controls.Add(this.rdbRC2);
            this.grpEncryptions.Controls.Add(this.rdbTripleDES);
            this.grpEncryptions.Controls.Add(this.rdbDES);
            this.grpEncryptions.FillColor = System.Drawing.Color.Transparent;
            this.grpEncryptions.Location = new System.Drawing.Point(329, 5);
            this.grpEncryptions.Name = "grpEncryptions";
            this.grpEncryptions.NoRounding = false;
            this.grpEncryptions.Size = new System.Drawing.Size(317, 127);
            this.grpEncryptions.TabIndex = 5;
            this.grpEncryptions.Text = "groupBox3";
            // 
            // rdbPolyCloud
            // 
            this.rdbPolyCloud.AutoSize = true;
            this.rdbPolyCloud.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyCloud.Location = new System.Drawing.Point(216, 33);
            this.rdbPolyCloud.Name = "rdbPolyCloud";
            this.rdbPolyCloud.Size = new System.Drawing.Size(82, 17);
            this.rdbPolyCloud.TabIndex = 14;
            this.rdbPolyCloud.Text = "PolyCloud";
            this.rdbPolyCloud.UseVisualStyleBackColor = true;
            // 
            // rdbCloud
            // 
            this.rdbCloud.AutoSize = true;
            this.rdbCloud.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbCloud.Location = new System.Drawing.Point(216, 10);
            this.rdbCloud.Name = "rdbCloud";
            this.rdbCloud.Size = new System.Drawing.Size(58, 17);
            this.rdbCloud.TabIndex = 13;
            this.rdbCloud.Text = "Cloud";
            this.rdbCloud.UseVisualStyleBackColor = true;
            // 
            // rdbStairs
            // 
            this.rdbStairs.AutoSize = true;
            this.rdbStairs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbStairs.Location = new System.Drawing.Point(103, 102);
            this.rdbStairs.Name = "rdbStairs";
            this.rdbStairs.Size = new System.Drawing.Size(58, 17);
            this.rdbStairs.TabIndex = 12;
            this.rdbStairs.Text = "Stairs";
            this.rdbStairs.UseVisualStyleBackColor = true;
            // 
            // rdbAES
            // 
            this.rdbAES.AutoSize = true;
            this.rdbAES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbAES.Location = new System.Drawing.Point(103, 79);
            this.rdbAES.Name = "rdbAES";
            this.rdbAES.Size = new System.Drawing.Size(48, 17);
            this.rdbAES.TabIndex = 11;
            this.rdbAES.Text = "AES";
            this.rdbAES.UseVisualStyleBackColor = true;
            // 
            // rdbPolyBaby
            // 
            this.rdbPolyBaby.AutoSize = true;
            this.rdbPolyBaby.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyBaby.Location = new System.Drawing.Point(216, 56);
            this.rdbPolyBaby.Name = "rdbPolyBaby";
            this.rdbPolyBaby.Size = new System.Drawing.Size(78, 17);
            this.rdbPolyBaby.TabIndex = 10;
            this.rdbPolyBaby.Text = "PolyBaby";
            this.rdbPolyBaby.UseVisualStyleBackColor = true;
            // 
            // rdbDex
            // 
            this.rdbDex.AutoSize = true;
            this.rdbDex.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDex.Location = new System.Drawing.Point(103, 56);
            this.rdbDex.Name = "rdbDex";
            this.rdbDex.Size = new System.Drawing.Size(48, 17);
            this.rdbDex.TabIndex = 9;
            this.rdbDex.Text = "Dex";
            this.rdbDex.UseVisualStyleBackColor = true;
            // 
            // rdbPolyStairs
            // 
            this.rdbPolyStairs.AutoSize = true;
            this.rdbPolyStairs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyStairs.Location = new System.Drawing.Point(216, 102);
            this.rdbPolyStairs.Name = "rdbPolyStairs";
            this.rdbPolyStairs.Size = new System.Drawing.Size(82, 17);
            this.rdbPolyStairs.TabIndex = 8;
            this.rdbPolyStairs.Text = "PolyStairs";
            this.rdbPolyStairs.UseVisualStyleBackColor = true;
            // 
            // rdbXOR
            // 
            this.rdbXOR.AutoSize = true;
            this.rdbXOR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbXOR.Location = new System.Drawing.Point(15, 33);
            this.rdbXOR.Name = "rdbXOR";
            this.rdbXOR.Size = new System.Drawing.Size(50, 17);
            this.rdbXOR.TabIndex = 6;
            this.rdbXOR.Text = "XOR";
            this.rdbXOR.UseVisualStyleBackColor = true;
            // 
            // rdbSymentric
            // 
            this.rdbSymentric.AutoSize = true;
            this.rdbSymentric.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbSymentric.Location = new System.Drawing.Point(103, 33);
            this.rdbSymentric.Name = "rdbSymentric";
            this.rdbSymentric.Size = new System.Drawing.Size(83, 17);
            this.rdbSymentric.TabIndex = 5;
            this.rdbSymentric.Text = "Symentric";
            this.rdbSymentric.UseVisualStyleBackColor = true;
            // 
            // rdbPolyRev
            // 
            this.rdbPolyRev.AutoSize = true;
            this.rdbPolyRev.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbPolyRev.Location = new System.Drawing.Point(216, 79);
            this.rdbPolyRev.Name = "rdbPolyRev";
            this.rdbPolyRev.Size = new System.Drawing.Size(71, 17);
            this.rdbPolyRev.TabIndex = 7;
            this.rdbPolyRev.Text = "PolyRev";
            this.rdbPolyRev.UseVisualStyleBackColor = true;
            // 
            // rdbRijndael
            // 
            this.rdbRijndael.AutoSize = true;
            this.rdbRijndael.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRijndael.Location = new System.Drawing.Point(15, 102);
            this.rdbRijndael.Name = "rdbRijndael";
            this.rdbRijndael.Size = new System.Drawing.Size(71, 17);
            this.rdbRijndael.TabIndex = 4;
            this.rdbRijndael.Text = "Rijndael";
            this.rdbRijndael.UseVisualStyleBackColor = true;
            // 
            // rdbRC4
            // 
            this.rdbRC4.AutoSize = true;
            this.rdbRC4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC4.Location = new System.Drawing.Point(15, 79);
            this.rdbRC4.Name = "rdbRC4";
            this.rdbRC4.Size = new System.Drawing.Size(49, 17);
            this.rdbRC4.TabIndex = 3;
            this.rdbRC4.Text = "RC4";
            this.rdbRC4.UseVisualStyleBackColor = true;
            // 
            // rdbRC2
            // 
            this.rdbRC2.AutoSize = true;
            this.rdbRC2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbRC2.Location = new System.Drawing.Point(15, 56);
            this.rdbRC2.Name = "rdbRC2";
            this.rdbRC2.Size = new System.Drawing.Size(49, 17);
            this.rdbRC2.TabIndex = 2;
            this.rdbRC2.Text = "RC2";
            this.rdbRC2.UseVisualStyleBackColor = true;
            // 
            // rdbTripleDES
            // 
            this.rdbTripleDES.AutoSize = true;
            this.rdbTripleDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbTripleDES.Location = new System.Drawing.Point(103, 10);
            this.rdbTripleDES.Name = "rdbTripleDES";
            this.rdbTripleDES.Size = new System.Drawing.Size(81, 17);
            this.rdbTripleDES.TabIndex = 1;
            this.rdbTripleDES.Text = "TripleDES";
            this.rdbTripleDES.UseVisualStyleBackColor = true;
            // 
            // rdbDES
            // 
            this.rdbDES.AutoSize = true;
            this.rdbDES.Checked = true;
            this.rdbDES.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.rdbDES.Location = new System.Drawing.Point(15, 10);
            this.rdbDES.Name = "rdbDES";
            this.rdbDES.Size = new System.Drawing.Size(49, 17);
            this.rdbDES.TabIndex = 0;
            this.rdbDES.TabStop = true;
            this.rdbDES.Text = "DES";
            this.rdbDES.UseVisualStyleBackColor = true;
            // 
            // btnEncrypt
            // 
            pigment29.Name = "Border";
            pigment29.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment30.Name = "Backcolor";
            pigment30.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment31.Name = "Highlight";
            pigment31.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment32.Name = "Gradient1";
            pigment32.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment33.Name = "Gradient2";
            pigment33.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment34.Name = "Text Color";
            pigment34.Value = System.Drawing.Color.White;
            pigment35.Name = "Text Shadow";
            pigment35.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnEncrypt.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment29,
        pigment30,
        pigment31,
        pigment32,
        pigment33,
        pigment34,
        pigment35};
            this.btnEncrypt.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnEncrypt.Location = new System.Drawing.Point(123, 462);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Shadow = true;
            this.btnEncrypt.Size = new System.Drawing.Size(91, 24);
            this.btnEncrypt.TabIndex = 4;
            this.btnEncrypt.Text = "ENCRYPT";
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox2.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.FillColor = System.Drawing.Color.Transparent;
            this.groupBox2.Location = new System.Drawing.Point(6, 5);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.NoRounding = false;
            this.groupBox2.Size = new System.Drawing.Size(317, 138);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.Text = "groupBox2";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::The_RATs_Crew_Crypter.Properties.Resources.ratscrewlogo;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(311, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.groupBox1.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnSelectBindFile);
            this.groupBox1.Controls.Add(this.txtBindFile);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btnSelectIcon);
            this.groupBox1.Controls.Add(this.txtIcon);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnSelectFile);
            this.groupBox1.Controls.Add(this.txtFile);
            this.groupBox1.FillColor = System.Drawing.Color.Transparent;
            this.groupBox1.Location = new System.Drawing.Point(6, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.NoRounding = false;
            this.groupBox1.Size = new System.Drawing.Size(317, 145);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.Text = "groupBox1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label3.Location = new System.Drawing.Point(6, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Binder:";
            // 
            // btnSelectBindFile
            // 
            pigment36.Name = "Border";
            pigment36.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment37.Name = "Backcolor";
            pigment37.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment38.Name = "Highlight";
            pigment38.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment39.Name = "Gradient1";
            pigment39.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment40.Name = "Gradient2";
            pigment40.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment41.Name = "Text Color";
            pigment41.Value = System.Drawing.Color.White;
            pigment42.Name = "Text Shadow";
            pigment42.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectBindFile.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment36,
        pigment37,
        pigment38,
        pigment39,
        pigment40,
        pigment41,
        pigment42};
            this.btnSelectBindFile.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectBindFile.Location = new System.Drawing.Point(254, 111);
            this.btnSelectBindFile.Name = "btnSelectBindFile";
            this.btnSelectBindFile.Shadow = true;
            this.btnSelectBindFile.Size = new System.Drawing.Size(54, 23);
            this.btnSelectBindFile.TabIndex = 8;
            this.btnSelectBindFile.Text = "...";
            this.btnSelectBindFile.Click += new System.EventHandler(this.btnSelectBindFile_Click);
            // 
            // txtBindFile
            // 
            this.txtBindFile.AllowDrop = true;
            this.txtBindFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtBindFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBindFile.ForeColor = System.Drawing.Color.Lime;
            this.txtBindFile.Location = new System.Drawing.Point(9, 113);
            this.txtBindFile.Name = "txtBindFile";
            this.txtBindFile.Size = new System.Drawing.Size(230, 21);
            this.txtBindFile.TabIndex = 7;
            this.txtBindFile.DragDrop += new System.Windows.Forms.DragEventHandler(this.FileBinderDr0p);
            this.txtBindFile.DragEnter += new System.Windows.Forms.DragEventHandler(this.FileBinderEnt3r);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label2.Location = new System.Drawing.Point(6, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Icon:";
            // 
            // btnSelectIcon
            // 
            pigment43.Name = "Border";
            pigment43.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment44.Name = "Backcolor";
            pigment44.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment45.Name = "Highlight";
            pigment45.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment46.Name = "Gradient1";
            pigment46.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment47.Name = "Gradient2";
            pigment47.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment48.Name = "Text Color";
            pigment48.Value = System.Drawing.Color.White;
            pigment49.Name = "Text Shadow";
            pigment49.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectIcon.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment43,
        pigment44,
        pigment45,
        pigment46,
        pigment47,
        pigment48,
        pigment49};
            this.btnSelectIcon.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectIcon.Location = new System.Drawing.Point(254, 67);
            this.btnSelectIcon.Name = "btnSelectIcon";
            this.btnSelectIcon.Shadow = true;
            this.btnSelectIcon.Size = new System.Drawing.Size(54, 23);
            this.btnSelectIcon.TabIndex = 5;
            this.btnSelectIcon.Text = "...";
            this.btnSelectIcon.Click += new System.EventHandler(this.btnSelectIcon_Click);
            // 
            // txtIcon
            // 
            this.txtIcon.AllowDrop = true;
            this.txtIcon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtIcon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtIcon.ForeColor = System.Drawing.Color.Lime;
            this.txtIcon.Location = new System.Drawing.Point(9, 69);
            this.txtIcon.Name = "txtIcon";
            this.txtIcon.Size = new System.Drawing.Size(230, 21);
            this.txtIcon.TabIndex = 4;
            this.txtIcon.DragDrop += new System.Windows.Forms.DragEventHandler(this.txtIcon_DragDrop);
            this.txtIcon.DragEnter += new System.Windows.Forms.DragEventHandler(this.txtIcon_DragEnter);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label1.Location = new System.Drawing.Point(6, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "File to be encrypted:";
            // 
            // btnSelectFile
            // 
            pigment50.Name = "Border";
            pigment50.Value = System.Drawing.Color.FromArgb(((int)(((byte)(254)))), ((int)(((byte)(133)))), ((int)(((byte)(0)))));
            pigment51.Name = "Backcolor";
            pigment51.Value = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            pigment52.Name = "Highlight";
            pigment52.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(197)))), ((int)(((byte)(19)))));
            pigment53.Name = "Gradient1";
            pigment53.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(175)))), ((int)(((byte)(12)))));
            pigment54.Name = "Gradient2";
            pigment54.Value = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(127)))), ((int)(((byte)(1)))));
            pigment55.Name = "Text Color";
            pigment55.Value = System.Drawing.Color.White;
            pigment56.Name = "Text Shadow";
            pigment56.Value = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSelectFile.Colors = new The_RATs_Crew_Crypter.Pigment[] {
        pigment50,
        pigment51,
        pigment52,
        pigment53,
        pigment54,
        pigment55,
        pigment56};
            this.btnSelectFile.Font = new System.Drawing.Font("Verdana", 8F);
            this.btnSelectFile.Location = new System.Drawing.Point(254, 21);
            this.btnSelectFile.Name = "btnSelectFile";
            this.btnSelectFile.Shadow = true;
            this.btnSelectFile.Size = new System.Drawing.Size(54, 23);
            this.btnSelectFile.TabIndex = 2;
            this.btnSelectFile.Text = "...";
            this.btnSelectFile.Click += new System.EventHandler(this.btnEncryptedFileSearch_Click);
            // 
            // txtFile
            // 
            this.txtFile.AllowDrop = true;
            this.txtFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtFile.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtFile.ForeColor = System.Drawing.Color.Lime;
            this.txtFile.Location = new System.Drawing.Point(9, 23);
            this.txtFile.Name = "txtFile";
            this.txtFile.Size = new System.Drawing.Size(230, 21);
            this.txtFile.TabIndex = 1;
            this.txtFile.DragDrop += new System.Windows.Forms.DragEventHandler(this.FileBinderDr0p);
            this.txtFile.DragEnter += new System.Windows.Forms.DragEventHandler(this.FileBinderEnt3r);
            // 
            // grpJunk
            // 
            this.grpJunk.Border1 = System.Drawing.Color.FromArgb(((int)(((byte)(90)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.grpJunk.Border2 = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.grpJunk.Controls.Add(this.label4);
            this.grpJunk.FillColor = System.Drawing.Color.Transparent;
            this.grpJunk.Location = new System.Drawing.Point(344, 300);
            this.grpJunk.Name = "grpJunk";
            this.grpJunk.NoRounding = false;
            this.grpJunk.Size = new System.Drawing.Size(317, 127);
            this.grpJunk.TabIndex = 11;
            this.grpJunk.Text = "groupBox4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(175)))), ((int)(((byte)(244)))));
            this.label4.Location = new System.Drawing.Point(73, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Junk code is coming in v1.7";
            // 
            // frmTRC_Crypter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.ClientSize = new System.Drawing.Size(697, 492);
            this.Controls.Add(this.grpJunk);
            this.Controls.Add(this.btnJunk);
            this.Controls.Add(this.btnInjection);
            this.Controls.Add(this.btnEncryption);
            this.Controls.Add(this.btnRunPEs);
            this.Controls.Add(this.grpRunPEs);
            this.Controls.Add(this.grpInjectionTo);
            this.Controls.Add(this.grpEncryptions);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmTRC_Crypter";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TRC Crypter ~ Version 1.6";
            this.grpRunPEs.ResumeLayout(false);
            this.grpRunPEs.PerformLayout();
            this.grpInjectionTo.ResumeLayout(false);
            this.grpInjectionTo.PerformLayout();
            this.grpEncryptions.ResumeLayout(false);
            this.grpEncryptions.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpJunk.ResumeLayout(false);
            this.grpJunk.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFile;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private FButton btnSelectFile;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private FButton btnSelectIcon;
        private System.Windows.Forms.TextBox txtIcon;
        private FButton btnEncrypt;
        private GroupBox grpEncryptions;
        private System.Windows.Forms.RadioButton rdbTripleDES;
        private System.Windows.Forms.RadioButton rdbDES;
        private System.Windows.Forms.RadioButton rdbXOR;
        private System.Windows.Forms.RadioButton rdbSymentric;
        private System.Windows.Forms.RadioButton rdbRijndael;
        private System.Windows.Forms.RadioButton rdbRC4;
        private System.Windows.Forms.RadioButton rdbRC2;
        private GroupBox grpInjectionTo;
        private System.Windows.Forms.RadioButton rdbDefaultBrowser;
        private System.Windows.Forms.RadioButton rdbInjectInto;
        private System.Windows.Forms.TextBox txtInjectInto;
        private GroupBox grpRunPEs;
        private System.Windows.Forms.RadioButton rdbRunPE3;
        private System.Windows.Forms.RadioButton rdbRunPE2;
        private System.Windows.Forms.RadioButton rdbRunPE1;
        private System.Windows.Forms.RadioButton rdbRunPE0;
        private System.Windows.Forms.RadioButton rdbRunPE9;
        private System.Windows.Forms.RadioButton rdbRunPE8;
        private System.Windows.Forms.RadioButton rdbRunPE7;
        private System.Windows.Forms.RadioButton rdbRunPE6;
        private System.Windows.Forms.RadioButton rdbRunPE5;
        private System.Windows.Forms.RadioButton rdbRunPE4;
        private System.Windows.Forms.RadioButton rdbRunPE11;
        private System.Windows.Forms.RadioButton rdbRunPE10;
        private System.Windows.Forms.RadioButton rdbCloud;
        private System.Windows.Forms.RadioButton rdbStairs;
        private System.Windows.Forms.RadioButton rdbAES;
        private System.Windows.Forms.RadioButton rdbPolyBaby;
        private System.Windows.Forms.RadioButton rdbDex;
        private System.Windows.Forms.RadioButton rdbPolyStairs;
        private System.Windows.Forms.RadioButton rdbPolyRev;
        private System.Windows.Forms.Button btnRunPEs;
        private System.Windows.Forms.Button btnEncryption;
        private System.Windows.Forms.Button btnInjection;
        private System.Windows.Forms.Button btnJunk;
        private System.Windows.Forms.RadioButton rdbPolyCloud;
        private System.Windows.Forms.RadioButton rdbVBC;
        private System.Windows.Forms.Label label3;
        private FButton btnSelectBindFile;
        private System.Windows.Forms.TextBox txtBindFile;
        private GroupBox grpJunk;
        private System.Windows.Forms.Label label4;
    }
}

