﻿Public Class Form2

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Clipboard.Clear()
        Clipboard.SetText(TextBox99.Text)
        MsgBox("Copied", MsgBoxStyle.Information, "Information")
    End Sub
End Class