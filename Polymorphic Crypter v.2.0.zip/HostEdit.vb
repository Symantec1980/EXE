﻿Public Class HostEdit

    Private Sub BullionButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BullionButton1.Click
        Me.Close()
    End Sub
End Class