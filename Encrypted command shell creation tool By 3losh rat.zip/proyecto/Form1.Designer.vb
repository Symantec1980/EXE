﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ReconForm1 = New proyecto.ReconForm()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ReconButton3 = New proyecto.ReconButton()
        Me.texbox2 = New proyecto.TxtBox()
        Me.ReconButton2 = New proyecto.ReconButton()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Longi = New proyecto.TxtBox()
        Me.ReconButton8 = New proyecto.ReconButton()
        Me.ReconButton7 = New proyecto.ReconButton()
        Me.ReconButton6 = New proyecto.ReconButton()
        Me.ReconButton5 = New proyecto.ReconButton()
        Me.texbox2p = New proyecto.TxtBox()
        Me.TxtBox1 = New proyecto.TxtBox()
        Me.ReconButton4 = New proyecto.ReconButton()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.ReconButton10 = New proyecto.ReconButton()
        Me.ReconGroupBox1 = New proyecto.ReconGroupBox()
        Me.ReconCheck1 = New proyecto.ReconCheck()
        Me.ReconCheck2 = New proyecto.ReconCheck()
        Me.ReconButton9 = New proyecto.ReconButton()
        Me.TxtBox2 = New proyecto.TxtBox()
        Me.ReconButton1 = New proyecto.ReconButton()
        Me.ReconForm1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.ReconGroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ReconForm1
        '
        Me.ReconForm1.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(41, Byte), Integer))
        Me.ReconForm1.Controls.Add(Me.TabControl1)
        Me.ReconForm1.Controls.Add(Me.ReconButton1)
        Me.ReconForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ReconForm1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReconForm1.ForeColor = System.Drawing.Color.Olive
        Me.ReconForm1.Image = Nothing
        Me.ReconForm1.Location = New System.Drawing.Point(0, 0)
        Me.ReconForm1.MoveHeight = 30
        Me.ReconForm1.Name = "ReconForm1"
        Me.ReconForm1.Resizable = True
        Me.ReconForm1.ShowIcon = False
        Me.ReconForm1.Size = New System.Drawing.Size(481, 450)
        Me.ReconForm1.TabIndex = 0
        Me.ReconForm1.Text = "B64 3losh"
        Me.ReconForm1.TextAlignment = proyecto.ReconForm.TextAlign.Left
        Me.ReconForm1.TransparencyKey = System.Drawing.Color.Fuchsia
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(0, 32)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(478, 418)
        Me.TabControl1.TabIndex = 6
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Gray
        Me.TabPage1.BackgroundImage = CType(resources.GetObject("TabPage1.BackgroundImage"), System.Drawing.Image)
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Controls.Add(Me.ReconButton3)
        Me.TabPage1.Controls.Add(Me.texbox2)
        Me.TabPage1.Controls.Add(Me.ReconButton2)
        Me.TabPage1.ForeColor = System.Drawing.Color.Lime
        Me.TabPage1.Location = New System.Drawing.Point(4, 25)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(470, 389)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "[ B64 Powershell ]"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.TextBox1.ForeColor = System.Drawing.Color.Lime
        Me.TextBox1.Location = New System.Drawing.Point(9, 132)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(455, 215)
        Me.TextBox1.TabIndex = 6
        '
        'ReconButton3
        '
        Me.ReconButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton3.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton3.Image = Nothing
        Me.ReconButton3.Location = New System.Drawing.Point(352, 353)
        Me.ReconButton3.Name = "ReconButton3"
        Me.ReconButton3.NoRounding = False
        Me.ReconButton3.Size = New System.Drawing.Size(98, 28)
        Me.ReconButton3.TabIndex = 4
        Me.ReconButton3.Text = "Ejecucion "
        '
        'texbox2
        '
        Me.texbox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.texbox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.texbox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.texbox2.ForeColor = System.Drawing.Color.Lime
        Me.texbox2.Location = New System.Drawing.Point(9, 353)
        Me.texbox2.Multiline = True
        Me.texbox2.Name = "texbox2"
        Me.texbox2.Size = New System.Drawing.Size(337, 30)
        Me.texbox2.TabIndex = 3
        '
        'ReconButton2
        '
        Me.ReconButton2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton2.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton2.Image = Nothing
        Me.ReconButton2.Location = New System.Drawing.Point(176, 4)
        Me.ReconButton2.Name = "ReconButton2"
        Me.ReconButton2.NoRounding = False
        Me.ReconButton2.Size = New System.Drawing.Size(103, 23)
        Me.ReconButton2.TabIndex = 1
        Me.ReconButton2.Text = "Obfuscar"
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Gray
        Me.TabPage2.BackgroundImage = CType(resources.GetObject("TabPage2.BackgroundImage"), System.Drawing.Image)
        Me.TabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.Longi)
        Me.TabPage2.Controls.Add(Me.ReconButton8)
        Me.TabPage2.Controls.Add(Me.ReconButton7)
        Me.TabPage2.Controls.Add(Me.ReconButton6)
        Me.TabPage2.Controls.Add(Me.ReconButton5)
        Me.TabPage2.Controls.Add(Me.texbox2p)
        Me.TabPage2.Controls.Add(Me.TxtBox1)
        Me.TabPage2.Controls.Add(Me.ReconButton4)
        Me.TabPage2.ForeColor = System.Drawing.Color.Lime
        Me.TabPage2.Location = New System.Drawing.Point(4, 25)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(470, 389)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "[ B64 File ]"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(385, 365)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 16)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Longitud"
        '
        'Longi
        '
        Me.Longi.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.Longi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Longi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Longi.ForeColor = System.Drawing.Color.Red
        Me.Longi.Location = New System.Drawing.Point(377, 323)
        Me.Longi.Multiline = True
        Me.Longi.Name = "Longi"
        Me.Longi.Size = New System.Drawing.Size(87, 28)
        Me.Longi.TabIndex = 7
        '
        'ReconButton8
        '
        Me.ReconButton8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton8.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton8.Image = Nothing
        Me.ReconButton8.Location = New System.Drawing.Point(377, 269)
        Me.ReconButton8.Name = "ReconButton8"
        Me.ReconButton8.NoRounding = False
        Me.ReconButton8.Size = New System.Drawing.Size(75, 23)
        Me.ReconButton8.TabIndex = 6
        Me.ReconButton8.Text = "B64"
        '
        'ReconButton7
        '
        Me.ReconButton7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton7.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton7.Image = Nothing
        Me.ReconButton7.Location = New System.Drawing.Point(377, 210)
        Me.ReconButton7.Name = "ReconButton7"
        Me.ReconButton7.NoRounding = False
        Me.ReconButton7.Size = New System.Drawing.Size(75, 23)
        Me.ReconButton7.TabIndex = 5
        Me.ReconButton7.Text = "Reverse"
        '
        'ReconButton6
        '
        Me.ReconButton6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton6.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton6.Image = Nothing
        Me.ReconButton6.Location = New System.Drawing.Point(377, 153)
        Me.ReconButton6.Name = "ReconButton6"
        Me.ReconButton6.NoRounding = False
        Me.ReconButton6.Size = New System.Drawing.Size(75, 23)
        Me.ReconButton6.TabIndex = 4
        Me.ReconButton6.Text = "Clear"
        '
        'ReconButton5
        '
        Me.ReconButton5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton5.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton5.Image = Nothing
        Me.ReconButton5.Location = New System.Drawing.Point(377, 85)
        Me.ReconButton5.Name = "ReconButton5"
        Me.ReconButton5.NoRounding = False
        Me.ReconButton5.Size = New System.Drawing.Size(75, 23)
        Me.ReconButton5.TabIndex = 3
        Me.ReconButton5.Text = "Copy"
        '
        'texbox2p
        '
        Me.texbox2p.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.texbox2p.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.texbox2p.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.texbox2p.ForeColor = System.Drawing.Color.Lime
        Me.texbox2p.Location = New System.Drawing.Point(8, 132)
        Me.texbox2p.Multiline = True
        Me.texbox2p.Name = "texbox2p"
        Me.texbox2p.Size = New System.Drawing.Size(363, 249)
        Me.texbox2p.TabIndex = 2
        '
        'TxtBox1
        '
        Me.TxtBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.TxtBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.TxtBox1.ForeColor = System.Drawing.Color.Red
        Me.TxtBox1.Location = New System.Drawing.Point(104, 10)
        Me.TxtBox1.Multiline = True
        Me.TxtBox1.Name = "TxtBox1"
        Me.TxtBox1.Size = New System.Drawing.Size(267, 28)
        Me.TxtBox1.TabIndex = 1
        '
        'ReconButton4
        '
        Me.ReconButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton4.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton4.Image = Nothing
        Me.ReconButton4.Location = New System.Drawing.Point(8, 15)
        Me.ReconButton4.Name = "ReconButton4"
        Me.ReconButton4.NoRounding = False
        Me.ReconButton4.Size = New System.Drawing.Size(75, 23)
        Me.ReconButton4.TabIndex = 0
        Me.ReconButton4.Text = "Server"
        '
        'TabPage3
        '
        Me.TabPage3.BackgroundImage = CType(resources.GetObject("TabPage3.BackgroundImage"), System.Drawing.Image)
        Me.TabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage3.Controls.Add(Me.ReconButton10)
        Me.TabPage3.Controls.Add(Me.ReconGroupBox1)
        Me.TabPage3.Controls.Add(Me.ReconButton9)
        Me.TabPage3.Controls.Add(Me.TxtBox2)
        Me.TabPage3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.TabPage3.Location = New System.Drawing.Point(4, 25)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(470, 389)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Encrypt Strings"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'ReconButton10
        '
        Me.ReconButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton10.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton10.Image = Nothing
        Me.ReconButton10.Location = New System.Drawing.Point(39, 52)
        Me.ReconButton10.Name = "ReconButton10"
        Me.ReconButton10.NoRounding = False
        Me.ReconButton10.Size = New System.Drawing.Size(81, 23)
        Me.ReconButton10.TabIndex = 5
        Me.ReconButton10.Text = "Zara"
        '
        'ReconGroupBox1
        '
        Me.ReconGroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.ReconGroupBox1.Controls.Add(Me.ReconCheck1)
        Me.ReconGroupBox1.Controls.Add(Me.ReconCheck2)
        Me.ReconGroupBox1.Location = New System.Drawing.Point(345, 34)
        Me.ReconGroupBox1.Name = "ReconGroupBox1"
        Me.ReconGroupBox1.NoRounding = False
        Me.ReconGroupBox1.Size = New System.Drawing.Size(119, 76)
        Me.ReconGroupBox1.TabIndex = 4
        Me.ReconGroupBox1.Text = "Funcion"
        '
        'ReconCheck1
        '
        Me.ReconCheck1.CheckedState = False
        Me.ReconCheck1.ForeColor = System.Drawing.Color.Red
        Me.ReconCheck1.Image = Nothing
        Me.ReconCheck1.Location = New System.Drawing.Point(15, 26)
        Me.ReconCheck1.MaximumSize = New System.Drawing.Size(600, 16)
        Me.ReconCheck1.MinimumSize = New System.Drawing.Size(16, 16)
        Me.ReconCheck1.Name = "ReconCheck1"
        Me.ReconCheck1.NoRounding = False
        Me.ReconCheck1.Size = New System.Drawing.Size(90, 16)
        Me.ReconCheck1.TabIndex = 2
        Me.ReconCheck1.Text = "Encrypt"
        '
        'ReconCheck2
        '
        Me.ReconCheck2.CheckedState = False
        Me.ReconCheck2.ForeColor = System.Drawing.Color.Red
        Me.ReconCheck2.Image = Nothing
        Me.ReconCheck2.Location = New System.Drawing.Point(15, 48)
        Me.ReconCheck2.MaximumSize = New System.Drawing.Size(600, 16)
        Me.ReconCheck2.MinimumSize = New System.Drawing.Size(16, 16)
        Me.ReconCheck2.Name = "ReconCheck2"
        Me.ReconCheck2.NoRounding = False
        Me.ReconCheck2.Size = New System.Drawing.Size(90, 16)
        Me.ReconCheck2.TabIndex = 3
        Me.ReconCheck2.Text = "Decrypt"
        '
        'ReconButton9
        '
        Me.ReconButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton9.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton9.Image = Nothing
        Me.ReconButton9.Location = New System.Drawing.Point(39, 23)
        Me.ReconButton9.Name = "ReconButton9"
        Me.ReconButton9.NoRounding = False
        Me.ReconButton9.Size = New System.Drawing.Size(81, 23)
        Me.ReconButton9.TabIndex = 1
        Me.ReconButton9.Text = "Hex"
        '
        'TxtBox2
        '
        Me.TxtBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer), CType(CType(28, Byte), Integer))
        Me.TxtBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TxtBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtBox2.ForeColor = System.Drawing.Color.Lime
        Me.TxtBox2.Location = New System.Drawing.Point(8, 183)
        Me.TxtBox2.Multiline = True
        Me.TxtBox2.Name = "TxtBox2"
        Me.TxtBox2.Size = New System.Drawing.Size(456, 200)
        Me.TxtBox2.TabIndex = 0
        '
        'ReconButton1
        '
        Me.ReconButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ReconButton1.ForeColor = System.Drawing.Color.DarkOliveGreen
        Me.ReconButton1.Image = Nothing
        Me.ReconButton1.Location = New System.Drawing.Point(430, 3)
        Me.ReconButton1.Name = "ReconButton1"
        Me.ReconButton1.NoRounding = False
        Me.ReconButton1.Size = New System.Drawing.Size(48, 23)
        Me.ReconButton1.TabIndex = 0
        Me.ReconButton1.Text = "X"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(481, 450)
        Me.Controls.Add(Me.ReconForm1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.ReconForm1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.ReconGroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ReconForm1 As ReconForm
    Friend WithEvents texbox2 As TxtBox
    Friend WithEvents ReconButton2 As ReconButton
    Friend WithEvents ReconButton1 As ReconButton
    Friend WithEvents ReconButton3 As ReconButton
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ReconButton8 As ReconButton
    Friend WithEvents ReconButton7 As ReconButton
    Friend WithEvents ReconButton6 As ReconButton
    Friend WithEvents ReconButton5 As ReconButton
    Friend WithEvents texbox2p As TxtBox
    Friend WithEvents TxtBox1 As TxtBox
    Friend WithEvents ReconButton4 As ReconButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Longi As TxtBox
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents ReconButton9 As ReconButton
    Friend WithEvents TxtBox2 As TxtBox
    Friend WithEvents ReconGroupBox1 As ReconGroupBox
    Friend WithEvents ReconCheck1 As ReconCheck
    Friend WithEvents ReconCheck2 As ReconCheck
    Friend WithEvents ReconButton10 As ReconButton
End Class
