﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace EasyCrypt.UI.Components
{
    public class FileBrowserDrop : UserControl
    {
        public new string Name { get; set; }
        public string Description { get; set; }

        public string DialogFilter { get; set; }
        public Icon DialogIcon { get; set; }

        public FileInfo SelectedFile { get; set; }

        public FileBrowserDrop()
            : base()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.StandardClick | ControlStyles.OptimizedDoubleBuffer, true);
            Size = new Size(240, 100);
            DialogFilter = "All Files *.*|*.*";
            DoubleBuffered = true;
            AllowDrop = true;
            DragEnter += OnDragEnter;
            DragDrop += OnDragDrop;
        }

        private void OnDragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }

        private void OnDragDrop(object sender, DragEventArgs e)
        {
            string[] droppedFiles = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string fileName in droppedFiles)
            {
                SelectedFile = new FileInfo(fileName);
                break;
            }
            Invalidate();
        }

        protected override void OnClick(EventArgs e)
        {
            MouseEventArgs mouseEvent = (MouseEventArgs)e ?? null;

            if (e != null)
            {
                if (mouseEvent.Button != System.Windows.Forms.MouseButtons.Left ||
                    mouseEvent.Button != System.Windows.Forms.MouseButtons.XButton1)
                {
                    using (OpenFileDialog openFileDialog = new OpenFileDialog())
                    {
                        openFileDialog.Title = Name;
                        openFileDialog.RestoreDirectory = true;
                        openFileDialog.Multiselect = false;
                        openFileDialog.SupportMultiDottedExtensions = true;
                        openFileDialog.FileName = "";

                        if (openFileDialog.ShowDialog() == DialogResult.OK)
                        {
                            SelectedFile = new FileInfo(openFileDialog.FileName);
                            Invalidate();
                        }
                    }
                }
            }

            base.OnClick(e);
        }

        protected override void CreateHandle()
        {
            Form parentForm = ParentForm ?? null;

            if (parentForm != null)
            {
                parentForm.AllowDrop = true;

                if (Name == null)
                {
                    Name = parentForm.Text;
                }

                if (Description == null)
                {
                    Description = "Drag and drop a file, or click to browse";
                }

                if (parentForm.Icon != null)
                {
                    DialogIcon = parentForm.Icon;
                }
            }

            Control parentControl = Parent ?? null;

            if (parentControl != null)
            {
                if (parentControl.GetType() != typeof(Form))
                {
                    parentControl.AllowDrop = true;
                }
            }

            base.CreateHandle();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            string displayText = Description;

            if (SelectedFile != null)
            {
                displayText = SelectedFile.Name;
            }

            e.Graphics.DrawString(displayText, Font, SystemBrushes.ControlText, ClientRectangle, new StringFormat() { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center });

            base.OnPaint(e);
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            base.OnPaintBackground(e);

            Rectangle displayRectangle = DisplayRectangle;
            displayRectangle.Width -= 1;
            displayRectangle.Height -= 1;

            Pen borderPen = new Pen(Color.FromArgb(220, 220, 220), 1);

            e.Graphics.DrawRectangle(borderPen, displayRectangle);
        }
    }
}