/*
UPolyX 
written by Delikon/www.delikon.de
All rights reserved*/

#include "head.h"
#include "poly.h"



void gen2(UCHAR * & code,Data* d,int &size){

	int reg[5]={0,2,3,6,7};
	int temp;
	int pos;
	int arrayPos1,arrayPos2;
	size=0;

	srand(GetTickCount()+d->start);
	
	for(int i=0;i<5;i++){
		pos =rand()%5;
		temp = reg[i];
		reg[i]=reg[pos];
		reg[pos]=temp;
	}	

		do{
	arrayPos1=rand()%5;
	arrayPos2=rand()%5;
	}while(arrayPos1-arrayPos2==0);


	int reg1=reg[arrayPos1];
	int reg2=reg[arrayPos2];

	
	printf("[+] using the sub/add decryptor\n");
	printREG(reg1,reg2);
	printf("[+] using offset %i\n",d->offset);	
	printf("[+] use 0x%x as manipulationByte\n",d->ManipulateByte);
	printf("[+] encrypt %i bytes from address 0x%x till address 0x%x \n",d->distance,d->start,d->start+d->distance);

	//putted some trash between real instructions
	//is this lame ?? yes it is ;) 

	
	PushReg(code,reg[3],size);
	PopReg(code,RegEcx,size);
	MoveAddrToReg(code,reg[3],d->distance,size);
	PushReg(code,reg[3],size);


	//------start trash
	AddToReg(code,reg[1],0x11,size);
	SubFromReg(code,reg[1],0x11,size);
	//----end trash

	PopReg(code,RegEcx,size);
	AddToReg(code,reg[1],0x11,size);
	SubFromReg(code,reg[1],0x11,size);
	
	MoveAddrToReg(code,reg1,d->start,size);
	AddToReg(code,reg[1],0x11,size);
	SubFromReg(code,reg[1],0x11,size);
	PushReg(code,reg1,size);
	AddToReg(code,reg[1],0x11,size);
	SubFromReg(code,reg[1],0x11,size);
	int label=SetLabel(size);
	
		AddToRegOneByte(code,reg1,d->ManipulateByte,size);
		AddToReg(code,reg[1],0x11,size);
		SubFromReg(code,reg[1],0x11,size);
		AddToReg(code,reg1,d->offset,size);
		AddToReg(code,reg[1],0x11,size);
		SubFromReg(code,reg[1],0x11,size);
		SubFromReg(code,RegEcx,d->offset-1,size);

	LoopToLabel(code,label,size);
	PushReg(code,reg[1],size);
	AddToReg(code,reg[1],0x11,size);
	SubFromReg(code,reg[1],0x11,size);
	PopReg(code,RegEcx,size);
	Ret(code,size);


	





	
}

