﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.GhostTheme1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostTheme()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.GhostButton3 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.GhostControlBox1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostControlBox()
        Me.GhostButton2 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.TextBox1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox()
        Me.GhostButton1 = New Encryption_Tools_By_GAITH7H3WOLF.GhostButton()
        Me.GhostTheme1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GhostTheme1
        '
        Me.GhostTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.GhostTheme1.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostTheme1.Controls.Add(Me.TextBox3)
        Me.GhostTheme1.Controls.Add(Me.GhostButton3)
        Me.GhostTheme1.Controls.Add(Me.TextBox2)
        Me.GhostTheme1.Controls.Add(Me.GhostControlBox1)
        Me.GhostTheme1.Controls.Add(Me.GhostButton2)
        Me.GhostTheme1.Controls.Add(Me.TextBox1)
        Me.GhostTheme1.Controls.Add(Me.GhostButton1)
        Me.GhostTheme1.Customization = ""
        Me.GhostTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GhostTheme1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostTheme1.Image = Nothing
        Me.GhostTheme1.Location = New System.Drawing.Point(0, 0)
        Me.GhostTheme1.Movable = True
        Me.GhostTheme1.Name = "GhostTheme1"
        Me.GhostTheme1.NoRounding = False
        Me.GhostTheme1.ShowIcon = True
        Me.GhostTheme1.Sizable = False
        Me.GhostTheme1.Size = New System.Drawing.Size(752, 426)
        Me.GhostTheme1.SmartBounds = True
        Me.GhostTheme1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.GhostTheme1.TabIndex = 0
        Me.GhostTheme1.Text = "VB.NET Compiler  ---->> NOTE : In Case Of Error Please check the library <<----"
        Me.GhostTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GhostTheme1.Transparent = False
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Silver
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Font = New System.Drawing.Font("Segoe UI Semibold", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.ForeColor = System.Drawing.Color.Purple
        Me.TextBox3.Location = New System.Drawing.Point(12, 28)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox3.Size = New System.Drawing.Size(728, 357)
        Me.TextBox3.TabIndex = 8
        Me.TextBox3.Text = "Editor"
        '
        'GhostButton3
        '
        Me.GhostButton3.Color = System.Drawing.Color.Empty
        Me.GhostButton3.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton3.Customization = ""
        Me.GhostButton3.EnableGlass = True
        Me.GhostButton3.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton3.Image = Nothing
        Me.GhostButton3.Location = New System.Drawing.Point(506, 391)
        Me.GhostButton3.Name = "GhostButton3"
        Me.GhostButton3.NoRounding = False
        Me.GhostButton3.Size = New System.Drawing.Size(114, 23)
        Me.GhostButton3.TabIndex = 7
        Me.GhostButton3.Text = "Edit"
        Me.GhostButton3.Transparent = False
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.DimGray
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(12, 27)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.TextBox2.Size = New System.Drawing.Size(728, 357)
        Me.TextBox2.TabIndex = 6
        '
        'GhostControlBox1
        '
        Me.GhostControlBox1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GhostControlBox1.Customization = "QEBA/wAAAP9aWlr/"
        Me.GhostControlBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostControlBox1.Image = Nothing
        Me.GhostControlBox1.Location = New System.Drawing.Point(678, 3)
        Me.GhostControlBox1.Name = "GhostControlBox1"
        Me.GhostControlBox1.NoRounding = False
        Me.GhostControlBox1.Size = New System.Drawing.Size(71, 19)
        Me.GhostControlBox1.TabIndex = 5
        Me.GhostControlBox1.Text = "GhostControlBox1"
        Me.GhostControlBox1.Transparent = False
        '
        'GhostButton2
        '
        Me.GhostButton2.Color = System.Drawing.Color.Empty
        Me.GhostButton2.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton2.Customization = ""
        Me.GhostButton2.EnableGlass = True
        Me.GhostButton2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton2.Image = Nothing
        Me.GhostButton2.Location = New System.Drawing.Point(626, 391)
        Me.GhostButton2.Name = "GhostButton2"
        Me.GhostButton2.NoRounding = False
        Me.GhostButton2.Size = New System.Drawing.Size(114, 23)
        Me.GhostButton2.TabIndex = 4
        Me.GhostButton2.Text = "Compiler"
        Me.GhostButton2.Transparent = False
        '
        'TextBox1
        '
        Me.TextBox1.Customization = "/////wAAAP8AAAD/Wlpa/w=="
        Me.TextBox1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.TextBox1.Image = Nothing
        Me.TextBox1.Location = New System.Drawing.Point(132, 390)
        Me.TextBox1.MaxLength = 32767
        Me.TextBox1.Multiline = False
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.NoRounding = False
        Me.TextBox1.ReadOnly = False
        Me.TextBox1.Size = New System.Drawing.Size(368, 24)
        Me.TextBox1.TabIndex = 2
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox1.Transparent = False
        Me.TextBox1.UseSystemPasswordChar = False
        '
        'GhostButton1
        '
        Me.GhostButton1.Color = System.Drawing.Color.Empty
        Me.GhostButton1.Colors = New Encryption_Tools_By_GAITH7H3WOLF.Bloom(-1) {}
        Me.GhostButton1.Customization = ""
        Me.GhostButton1.EnableGlass = True
        Me.GhostButton1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GhostButton1.Image = Nothing
        Me.GhostButton1.Location = New System.Drawing.Point(12, 391)
        Me.GhostButton1.Name = "GhostButton1"
        Me.GhostButton1.NoRounding = False
        Me.GhostButton1.Size = New System.Drawing.Size(114, 23)
        Me.GhostButton1.TabIndex = 1
        Me.GhostButton1.Text = "Load (.vb) File"
        Me.GhostButton1.Transparent = False
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(752, 426)
        Me.Controls.Add(Me.GhostTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form3"
        Me.Text = "Form3"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GhostTheme1.ResumeLayout(False)
        Me.GhostTheme1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GhostTheme1 As Encryption_Tools_By_GAITH7H3WOLF.GhostTheme
    Friend WithEvents GhostButton2 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents TextBox1 As Encryption_Tools_By_GAITH7H3WOLF.GhostTextBox
    Friend WithEvents GhostButton1 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents GhostControlBox1 As Encryption_Tools_By_GAITH7H3WOLF.GhostControlBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents GhostButton3 As Encryption_Tools_By_GAITH7H3WOLF.GhostButton
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
End Class
