﻿Public Class Form1

    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub

    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        Form45.Show()
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Form87.Show()
    End Sub

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Form3.Show()
    End Sub

    Private Sub FlatButton3_Click(sender As Object, e As EventArgs) Handles FlatButton3.Click
        Dim fewfewfew As String = My.Computer.FileSystem.SpecialDirectories.Temp
        Dim asdwasd As String = fewfewfew + "SmartAssembly.rar"
        IO.File.WriteAllBytes(asdwasd, My.Resources.clen_temp)
        Process.Start(asdwasd)
    End Sub
End Class
