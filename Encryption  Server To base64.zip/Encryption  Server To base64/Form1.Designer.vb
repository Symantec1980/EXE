﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.BlackShadesNetForm1 = New Encryption__Server_To_base64.BlackShadesNetForm()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.BlackShadesNetButton3 = New Encryption__Server_To_base64.BlackShadesNetButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.BlackShadesNetButton4 = New Encryption__Server_To_base64.BlackShadesNetButton()
        Me.BlackShadesNetButton2 = New Encryption__Server_To_base64.BlackShadesNetButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.BlackShadesNetButton1 = New Encryption__Server_To_base64.BlackShadesNetButton()
        Me.BlackShadesNetTextBox1 = New Encryption__Server_To_base64.BlackShadesNetTextBox()
        Me.BlackShadesNetButton5 = New Encryption__Server_To_base64.BlackShadesNetButton()
        Me.BlackShadesNetForm1.SuspendLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BlackShadesNetForm1
        '
        Me.BlackShadesNetForm1.CloseButtonExitsApp = False
        Me.BlackShadesNetForm1.Controls.Add(Me.BlackShadesNetButton5)
        Me.BlackShadesNetForm1.Controls.Add(Me.Label3)
        Me.BlackShadesNetForm1.Controls.Add(Me.BlackShadesNetButton3)
        Me.BlackShadesNetForm1.Controls.Add(Me.Label2)
        Me.BlackShadesNetForm1.Controls.Add(Me.BlackShadesNetButton4)
        Me.BlackShadesNetForm1.Controls.Add(Me.BlackShadesNetButton2)
        Me.BlackShadesNetForm1.Controls.Add(Me.Label1)
        Me.BlackShadesNetForm1.Controls.Add(Me.NumericUpDown1)
        Me.BlackShadesNetForm1.Controls.Add(Me.BlackShadesNetButton1)
        Me.BlackShadesNetForm1.Controls.Add(Me.BlackShadesNetTextBox1)
        Me.BlackShadesNetForm1.Cursor = System.Windows.Forms.Cursors.Cross
        Me.BlackShadesNetForm1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.BlackShadesNetForm1.Font = New System.Drawing.Font("Trebuchet MS", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BlackShadesNetForm1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(142, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(156, Byte), Integer))
        Me.BlackShadesNetForm1.Location = New System.Drawing.Point(0, 0)
        Me.BlackShadesNetForm1.MinimizeButton = True
        Me.BlackShadesNetForm1.Name = "BlackShadesNetForm1"
        Me.BlackShadesNetForm1.Size = New System.Drawing.Size(570, 174)
        Me.BlackShadesNetForm1.TabIndex = 0
        Me.BlackShadesNetForm1.Text = "Encryption  Server To base64 By Professor Nahrawan"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(7, 149)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(560, 16)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ" & _
            "ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ"
        '
        'BlackShadesNetButton3
        '
        Me.BlackShadesNetButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BlackShadesNetButton3.Font = New System.Drawing.Font("Trebuchet MS", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BlackShadesNetButton3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BlackShadesNetButton3.Location = New System.Drawing.Point(10, 128)
        Me.BlackShadesNetButton3.Name = "BlackShadesNetButton3"
        Me.BlackShadesNetButton3.Size = New System.Drawing.Size(548, 28)
        Me.BlackShadesNetButton3.TabIndex = 13
        Me.BlackShadesNetButton3.Text = "The project Khurazmih"
        Me.BlackShadesNetButton3.TextAlignment = System.Drawing.StringAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(7, 108)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(560, 16)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ" & _
            "ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ"
        '
        'BlackShadesNetButton4
        '
        Me.BlackShadesNetButton4.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BlackShadesNetButton4.Font = New System.Drawing.Font("Trebuchet MS", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BlackShadesNetButton4.ForeColor = System.Drawing.Color.Fuchsia
        Me.BlackShadesNetButton4.Location = New System.Drawing.Point(412, 8)
        Me.BlackShadesNetButton4.Name = "BlackShadesNetButton4"
        Me.BlackShadesNetButton4.Size = New System.Drawing.Size(106, 10)
        Me.BlackShadesNetButton4.TabIndex = 9
        Me.BlackShadesNetButton4.Text = "----------------"
        Me.BlackShadesNetButton4.TextAlignment = System.Drawing.StringAlignment.Center
        '
        'BlackShadesNetButton2
        '
        Me.BlackShadesNetButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BlackShadesNetButton2.Font = New System.Drawing.Font("Trebuchet MS", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BlackShadesNetButton2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BlackShadesNetButton2.Location = New System.Drawing.Point(10, 83)
        Me.BlackShadesNetButton2.Name = "BlackShadesNetButton2"
        Me.BlackShadesNetButton2.Size = New System.Drawing.Size(548, 28)
        Me.BlackShadesNetButton2.TabIndex = 5
        Me.BlackShadesNetButton2.Text = "Convert To Base64 And Split"
        Me.BlackShadesNetButton2.TextAlignment = System.Drawing.StringAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(7, 61)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(560, 16)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــــ" & _
            "ـــــــــــــــــــــــــــــــــــــــــــــــــــــــــ"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.NumericUpDown1.ForeColor = System.Drawing.Color.Cyan
        Me.NumericUpDown1.Location = New System.Drawing.Point(494, 38)
        Me.NumericUpDown1.Maximum = New Decimal(New Integer() {1510065407, 2, 0, 0})
        Me.NumericUpDown1.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(65, 20)
        Me.NumericUpDown1.TabIndex = 4
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'BlackShadesNetButton1
        '
        Me.BlackShadesNetButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BlackShadesNetButton1.Font = New System.Drawing.Font("Trebuchet MS", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BlackShadesNetButton1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BlackShadesNetButton1.Location = New System.Drawing.Point(11, 32)
        Me.BlackShadesNetButton1.Name = "BlackShadesNetButton1"
        Me.BlackShadesNetButton1.Size = New System.Drawing.Size(143, 31)
        Me.BlackShadesNetButton1.TabIndex = 2
        Me.BlackShadesNetButton1.Text = "Add File"
        Me.BlackShadesNetButton1.TextAlignment = System.Drawing.StringAlignment.Center
        '
        'BlackShadesNetTextBox1
        '
        Me.BlackShadesNetTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(36, Byte), Integer), CType(CType(40, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.BlackShadesNetTextBox1.ForeColor = System.Drawing.Color.Gray
        Me.BlackShadesNetTextBox1.Location = New System.Drawing.Point(161, 36)
        Me.BlackShadesNetTextBox1.MaxLength = 32767
        Me.BlackShadesNetTextBox1.Name = "BlackShadesNetTextBox1"
        Me.BlackShadesNetTextBox1.Size = New System.Drawing.Size(327, 24)
        Me.BlackShadesNetTextBox1.TabIndex = 3
        Me.BlackShadesNetTextBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left
        Me.BlackShadesNetTextBox1.UseSystemPasswordChar = False
        '
        'BlackShadesNetButton5
        '
        Me.BlackShadesNetButton5.BackColor = System.Drawing.Color.FromArgb(CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer), CType(CType(38, Byte), Integer))
        Me.BlackShadesNetButton5.Font = New System.Drawing.Font("Trebuchet MS", 8.25!, System.Drawing.FontStyle.Bold)
        Me.BlackShadesNetButton5.ForeColor = System.Drawing.Color.Yellow
        Me.BlackShadesNetButton5.Location = New System.Drawing.Point(294, 8)
        Me.BlackShadesNetButton5.Name = "BlackShadesNetButton5"
        Me.BlackShadesNetButton5.Size = New System.Drawing.Size(106, 10)
        Me.BlackShadesNetButton5.TabIndex = 16
        Me.BlackShadesNetButton5.Text = "----------------"
        Me.BlackShadesNetButton5.TextAlignment = System.Drawing.StringAlignment.Center
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(570, 174)
        Me.Controls.Add(Me.BlackShadesNetForm1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.Text = "Encryption  Server To base64 By Professor Nahrawan"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.BlackShadesNetForm1.ResumeLayout(False)
        Me.BlackShadesNetForm1.PerformLayout()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BlackShadesNetTextBox1 As Encryption__Server_To_base64.BlackShadesNetTextBox
    Friend WithEvents BlackShadesNetButton1 As Encryption__Server_To_base64.BlackShadesNetButton
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BlackShadesNetButton2 As Encryption__Server_To_base64.BlackShadesNetButton
    Friend WithEvents BlackShadesNetButton4 As Encryption__Server_To_base64.BlackShadesNetButton
    Friend WithEvents BlackShadesNetForm1 As Encryption__Server_To_base64.BlackShadesNetForm
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents BlackShadesNetButton3 As Encryption__Server_To_base64.BlackShadesNetButton
    Friend WithEvents BlackShadesNetButton5 As Encryption__Server_To_base64.BlackShadesNetButton

End Class
