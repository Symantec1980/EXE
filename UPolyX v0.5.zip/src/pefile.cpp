/*
UPolyX 
written by Delikon/www.delikon.de
All rights reserved*/
#include "head.h"

DWORD randseed;


void usage(){


	

	printf("\t[-] you forget the file name\n");
	exit(1);

}


DWORD __cdecl my_random(DWORD,DWORD range)
{

	
  return
    range == 0 ? 0 : (randseed = randseed * 214013 + 2531011) % range;
}



#define SIZE_OF_NT_SIGNATURE    sizeof (DWORD)
#define SECHDROFFSET(a) ((LPVOID)((BYTE *)a               +  \
                         ((PIMAGE_DOS_HEADER)a)->e_lfanew +  \
                           SIZE_OF_NT_SIGNATURE           +  \
                           sizeof (IMAGE_FILE_HEADER)     +  \
                           sizeof (IMAGE_OPTIONAL_HEADER)))






int main(int argc,char *argv[])
{

int w=0;
int countNULL=0;
int i=0;
char *sectionName=NULL;
int size =0;
int routine=0;
UCHAR *a;
bool EGT=1;
BYTE *buf=NULL;
DWORD bufsize;
	
srand(GetTickCount()+3);


randseed= GetTickCount();

a=(UCHAR*)malloc(200);




printf("\n\t\t*UPolyX v0.5*\n");
printf("    written by Delikon/www.delikon.de\n");
//printf("    UPolyX uses z0mbie's ETG Engine\n");

if(argc<2)
	usage();



  
  



// we open the file with Read/Write access
HANDLE file = CreateFile(argv[1],GENERIC_WRITE | GENERIC_READ,0,NULL,OPEN_EXISTING,
                                         FILE_ATTRIBUTE_ARCHIVE,NULL);

if(file == (HANDLE)0xffffffff){

	printf("\t[+] error opening the file\n");
	return -1;

}
	

// we map the file into memory
HANDLE file2 = CreateFileMapping (file, NULL, PAGE_READWRITE, 0, 0, NULL);
LPBYTE MapFile = (LPBYTE)MapViewOfFile(file2,FILE_MAP_ALL_ACCESS,0,0,0);
IMAGE_SECTION_HEADER * sec;
IMAGE_DOS_HEADER dosHead = *(IMAGE_DOS_HEADER *)MapFile;
IMAGE_FILE_HEADER *PE = (IMAGE_FILE_HEADER *)(MapFile+dosHead.e_lfanew+4);
IMAGE_OPTIONAL_HEADER *PEoption = (IMAGE_OPTIONAL_HEADER *)((BYTE *)PE+sizeof(IMAGE_FILE_HEADER));


Data* DATA=(Data*) malloc(sizeof(struct data));
sec =(IMAGE_SECTION_HEADER*) SECHDROFFSET(MapFile);
sectionName=RandSection(4);

memcpy(sec,sectionName,4);

sec++;

memcpy(sec,sectionName,4);




DWORD FileAlign=PEoption->FileAlignment;
DWORD EP=PEoption->AddressOfEntryPoint;

DWORD DE=EP+(sec->PointerToRawData)-(sec->VirtualAddress);
DWORD sectionsize=sec->SizeOfRawData;
DWORD sectionstart=sec->PointerToRawData;

DWORD DEsave=DE;
DWORD image = PEoption->ImageBase;

printf("ENTRYPOINT:       %x\n",EP);

printf("FILEENTRYPOINT:   %x\n",DE);

printf("[+] Checking for UPX\n");
	if(MapFile[DE]==0x60)
		printf("[+] Yes this is packed with UPX!\n");
	else{
		printf("[-] Pack it first with UPX!\n");
		exit(1);
	}



printf("[+] Replace the section name UPX with %s\n",sectionName);

DWORD sectionend=sectionstart+sectionsize;

__try{

	while(countNULL<=35){
		if(MapFile[DE]==0x00){
			countNULL++;
		}
		else{
			countNULL=0;
		}
	DE++;
	}

	if(DE>sectionend){
		printf("[-] the second  UPX section is too small for the decryptor\n");
		exit(0);
	
	}

	printf("[+] the second  UPX section starts at 0x%x\n",sectionstart);
	printf("[+] the second  UPX section is 0x%x big\n",sectionsize);

	
	
	countNULL=0;
	while(sectionend>DE){
		if(MapFile[DE]==0x00){
			countNULL++;
		}
		else{
			countNULL=0;
		}
	sectionend--;
	}	
	printf("[+] Found a 0x%x big space for the decryptor\n",countNULL);
	
		
		


	routine=my_random(randseed,3);
	//routine=2;


		

	DATA->start=PEoption->AddressOfEntryPoint+PEoption->ImageBase;;
	DATA->ManipulateByte=rand()%0xff;

	if(routine==2)
		DATA->offset=4;
	else
		do{
		DATA->offset=rand()%7;
		}while(DATA->offset==0);

	do{
	DATA->distance=100+rand()%100;
	}while(DATA->distance%DATA->offset!=0);



	if(routine==0){
	for(i=0; i<DATA->distance;i++)
		MapFile[DEsave+i]=MapFile[DEsave+i]^DATA->ManipulateByte;
		
			   
					gen(a,DATA,size);

	}


	if(routine==1){
		for(i=0; i<DATA->distance;i+=DATA->offset)
		MapFile[DEsave+i]=MapFile[DEsave+i]-DATA->ManipulateByte;
		
			  
					gen2(a,DATA,size);

	}

	if(routine==2){

		DATA->ManipulateByte4=rand();	
	do{
		
		DATA->ManipulateByte4+=rand();
		DATA->ManipulateByte4*=rand()%5;


	}while(DATA->ManipulateByte4<0x0100000+(rand()%0x01000000));
		

		//DATA->ManipulateByte4=0x11223344;
		DWORD M=DATA->ManipulateByte4;
		_asm{
			
			mov esi, MapFile
			add esi,DEsave		
			}
		for(i=0; i<DATA->distance;i+=DATA->offset){
		//MapFile[DEsave+i]=MapFile[DEsave+i]DATA->ManipulateByte4;
			_asm{
				mov  edx,[M]
				xor [esi],edx
				add esi,4
			
			}		
		}
		
			  
					gen3(a,DATA,size);

	}
	
	printf("[+] Generated  0x%x byte decryptor\n",size);

	if(countNULL>(size+20)){
		countNULL-=size;
		DWORD rest=(countNULL)%FileAlign;
		//if(rest)
		//	countNULL-=rest;
		buf=(BYTE*)malloc(countNULL);
	}
	else{
		printf("[-] There is no space for z0mbie's EGT\n!");
			EGT=0;	
	}

	

/*
	[z0mbie's ETG]
*/

	if(EGT){
		void* etg_ptr = &etg_bin;
	  (*(etg_engine*)etg_ptr)
		 (0x12345678,
		  ETG_ALL,
		  REG_ALL,
		  REG_ALL,
		  &bufsize,
		  1000,
		  countNULL,
		  buf,
		  my_random);
  
		UCHAR *tempbuf=(UCHAR*)malloc(size+bufsize+1);
		memcpy(tempbuf,buf,bufsize);
		memcpy(tempbuf+bufsize,a,size);
		size+=bufsize;
		free(a);
		a=tempbuf;
		printf("[+] Generated  0x%x bytes of trash\n",bufsize);
	}

/*
	[\z0mbie's ETG]
*/

		
  

		//UCHAR *a  = func2(size);	

		//gen2(a,DATA);


	PEoption->AddressOfEntryPoint=EP+(DE-DEsave);





	//DWORD image = PEoption->ImageBase;


	for(i=0; i<size;i++)
		MapFile[DE+i]=*(a+i);
		

}
 __except(GetExceptionCode()!=0) {

	 printf("[--] There was a problem durring encryption\n!");
		exit(1);
}



//calculate the jump to the EGG
//DWORD j =codePos-(sec->PointerToRawData)+(sec->VirtualAddress)-EP;
//printf("JUMP OFFSET %x \n",codePos-(sec->PointerToRawData)+(sec->VirtualAddress)-EP);

	//for(int i=0;i<0x100;i++)
	//	MapFile[i+DE]=MapFile[i+DE]^0x99;


free(a);
FlushViewOfFile(MapFile,0);
UnmapViewOfFile(MapFile);
CloseHandle(file2);
SetFilePointer(file,GetFileSize(file,NULL),NULL,FILE_BEGIN); 
SetEndOfFile(file);
CloseHandle(file);
free(DATA);
free(buf);
free(sectionName);
printf("PRESS A KEY\n");
getchar();





}