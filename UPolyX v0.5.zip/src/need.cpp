/*
UPolyX 
written by Delikon/www.delikon.de
All rights reserved*/


#include "head.h"



void printREG(int reg1,int reg2){
	
		if(reg1==0)
			printf("[+] Using for Register1 EAX\n");
		if(reg1==2)
			printf("[+] Using for Register1 EDX\n");
		if(reg1==3)
			printf("[+] Using for Register1 EBX\n");
		if(reg1==6)
			printf("[+] Using for Register1 ESI\n");
		if(reg1==7)
			printf("[+] Using for Register1 EDI\n");


		if(reg2==0)
			printf("[+] Using for Register2 EAX\n");
		if(reg2==2)
			printf("[+] Using for Register2 EDX\n");
		if(reg2==3)
			printf("[+] Using for Register2 EBX\n");
		if(reg2==6)
			printf("[+] Using for Register2 ESI\n");
		if(reg2==7)
			printf("[+] Using for Register2 EDI\n");

}


char* RandSection(int length){

	srand(GetTickCount()+length);
	char *a = (char*)malloc(length+1);
	memset(a,0x00,length+1);
	char temp=0;
	int i=0;
		
	while(strlen(a)<4){	
		temp =rand()%('z'+1);
		if(temp>'A'&&temp<'Z'||temp>'a'&&temp<'z'){
			a[i]=temp;
			i++;
		}
	}
	return a;
}