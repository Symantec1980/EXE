Public Class FrmSecureFile


    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Dim p As New Process
        p.Start("http://www.programmer2programmer.net")
    End Sub

    Private Sub CmdEncryption_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdEncryption.Click
        Dim F1 As New FrmEncrypt
        F1.Show()
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CmdDecryption.Click
        Dim F1 As New FrmDecrypt
        F1.Show()
        Me.Close()
    End Sub
End Class
