﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.LogInThemeContainer1 = New Encryption.LogInThemeContainer()
        Me.NumericUpDown1 = New Encryption.FlatNumeric()
        Me.LogInButton28 = New Encryption.LogInButton()
        Me.LogInLabel6 = New Encryption.LogInLabel()
        Me.FlatTrackBar1 = New Encryption.FlatTrackBar()
        Me.LogInButton15 = New Encryption.LogInButton()
        Me.LogInButton17 = New Encryption.LogInButton()
        Me.LogInGroupBox2 = New Encryption.LogInGroupBox()
        Me.LogInButton23 = New Encryption.LogInButton()
        Me.LogInButton22 = New Encryption.LogInButton()
        Me.LogInButton21 = New Encryption.LogInButton()
        Me.LogInButton20 = New Encryption.LogInButton()
        Me.LogInButton24 = New Encryption.LogInButton()
        Me.LogInButton19 = New Encryption.LogInButton()
        Me.LogInGroupBox1 = New Encryption.LogInGroupBox()
        Me.LogInButton26 = New Encryption.LogInButton()
        Me.LogInButton25 = New Encryption.LogInButton()
        Me.LogInButton12 = New Encryption.LogInButton()
        Me.LogInButton11 = New Encryption.LogInButton()
        Me.LogInButton9 = New Encryption.LogInButton()
        Me.LogInButton3 = New Encryption.LogInButton()
        Me.LogInButton27 = New Encryption.LogInButton()
        Me.LogInButton18 = New Encryption.LogInButton()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.LogInButton16 = New Encryption.LogInButton()
        Me.LogInButton4 = New Encryption.LogInButton()
        Me.LogInButton14 = New Encryption.LogInButton()
        Me.LogInButton13 = New Encryption.LogInButton()
        Me.LogInButton10 = New Encryption.LogInButton()
        Me.LogInButton8 = New Encryption.LogInButton()
        Me.TextBox5 = New Encryption.LogInNormalTextBox()
        Me.LogInLabel5 = New Encryption.LogInLabel()
        Me.LogInButton7 = New Encryption.LogInButton()
        Me.LogInButton6 = New Encryption.LogInButton()
        Me.LogInLabel4 = New Encryption.LogInLabel()
        Me.LogInButton5 = New Encryption.LogInButton()
        Me.LogInButton2 = New Encryption.LogInButton()
        Me.TextBox3 = New Encryption.LogInNormalTextBox()
        Me.LogInLabel3 = New Encryption.LogInLabel()
        Me.TextBox2 = New Encryption.LogInNormalTextBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.LogInLabel2 = New Encryption.LogInLabel()
        Me.TextBox1 = New Encryption.LogInNormalTextBox()
        Me.LogInLabel1 = New Encryption.LogInLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.LogInButton1 = New Encryption.LogInButton()
        Me.LogInThemeContainer1.SuspendLayout()
        Me.LogInGroupBox2.SuspendLayout()
        Me.LogInGroupBox1.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LogInThemeContainer1
        '
        Me.LogInThemeContainer1.AllowClose = True
        Me.LogInThemeContainer1.AllowMaximize = True
        Me.LogInThemeContainer1.AllowMinimize = True
        Me.LogInThemeContainer1.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.LogInThemeContainer1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.LogInThemeContainer1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.LogInThemeContainer1.ContainerColour = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.LogInThemeContainer1.Controls.Add(Me.NumericUpDown1)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton28)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInLabel6)
        Me.LogInThemeContainer1.Controls.Add(Me.FlatTrackBar1)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton15)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton17)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInGroupBox2)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInGroupBox1)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton27)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton18)
        Me.LogInThemeContainer1.Controls.Add(Me.RichTextBox1)
        Me.LogInThemeContainer1.Controls.Add(Me.PictureBox4)
        Me.LogInThemeContainer1.Controls.Add(Me.PictureBox3)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton16)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton4)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton14)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton13)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton10)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton8)
        Me.LogInThemeContainer1.Controls.Add(Me.TextBox5)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInLabel5)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton7)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton6)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInLabel4)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton5)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton2)
        Me.LogInThemeContainer1.Controls.Add(Me.TextBox3)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInLabel3)
        Me.LogInThemeContainer1.Controls.Add(Me.TextBox2)
        Me.LogInThemeContainer1.Controls.Add(Me.PictureBox2)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInLabel2)
        Me.LogInThemeContainer1.Controls.Add(Me.TextBox1)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInLabel1)
        Me.LogInThemeContainer1.Controls.Add(Me.PictureBox1)
        Me.LogInThemeContainer1.Controls.Add(Me.LogInButton1)
        Me.LogInThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LogInThemeContainer1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInThemeContainer1.FontSize = 12
        Me.LogInThemeContainer1.HoverColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInThemeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.LogInThemeContainer1.Name = "LogInThemeContainer1"
        Me.LogInThemeContainer1.ShowIcon = True
        Me.LogInThemeContainer1.Size = New System.Drawing.Size(672, 531)
        Me.LogInThemeContainer1.TabIndex = 0
        Me.LogInThemeContainer1.Text = "Skjold Crypter v1.0 by M-I[N]!_A M(A)-{Z}E-?N!"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.BackColor = System.Drawing.Color.FromArgb(CType(CType(90, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(90, Byte), Integer))
        Me.NumericUpDown1.BaseColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.NumericUpDown1.ButtonColor = System.Drawing.Color.FromArgb(CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.NumericUpDown1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumericUpDown1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(211, Byte), Integer), CType(CType(211, Byte), Integer), CType(CType(211, Byte), Integer))
        Me.NumericUpDown1.Location = New System.Drawing.Point(555, 447)
        Me.NumericUpDown1.Maximum = CType(9999999, Long)
        Me.NumericUpDown1.Minimum = CType(2, Long)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(52, 30)
        Me.NumericUpDown1.TabIndex = 60
        Me.NumericUpDown1.Text = "FlatNumeric1"
        Me.NumericUpDown1.Value = CType(2, Long)
        '
        'LogInButton28
        '
        Me.LogInButton28.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton28.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton28.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton28.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton28.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton28.Location = New System.Drawing.Point(633, 189)
        Me.LogInButton28.Name = "LogInButton28"
        Me.LogInButton28.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton28.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton28.Size = New System.Drawing.Size(25, 16)
        Me.LogInButton28.TabIndex = 59
        Me.LogInButton28.Text = "--"
        '
        'LogInLabel6
        '
        Me.LogInLabel6.AutoSize = True
        Me.LogInLabel6.BackColor = System.Drawing.Color.Transparent
        Me.LogInLabel6.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogInLabel6.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel6.Location = New System.Drawing.Point(637, 144)
        Me.LogInLabel6.Name = "LogInLabel6"
        Me.LogInLabel6.Size = New System.Drawing.Size(17, 20)
        Me.LogInLabel6.TabIndex = 58
        Me.LogInLabel6.Text = "0"
        '
        'FlatTrackBar1
        '
        Me.FlatTrackBar1.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.FlatTrackBar1.HatchColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.FlatTrackBar1.Location = New System.Drawing.Point(555, 144)
        Me.FlatTrackBar1.Maximum = 20
        Me.FlatTrackBar1.Minimum = 0
        Me.FlatTrackBar1.Name = "FlatTrackBar1"
        Me.FlatTrackBar1.ShowValue = False
        Me.FlatTrackBar1.Size = New System.Drawing.Size(76, 23)
        Me.FlatTrackBar1.Style = Encryption.FlatTrackBar._Style.Slider
        Me.FlatTrackBar1.TabIndex = 57
        Me.FlatTrackBar1.Text = "FlatTrackBar1"
        Me.FlatTrackBar1.TrackColor = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(152, Byte), Integer), CType(CType(219, Byte), Integer))
        Me.FlatTrackBar1.Value = 0
        '
        'LogInButton15
        '
        Me.LogInButton15.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton15.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton15.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton15.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton15.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton15.Location = New System.Drawing.Point(453, 496)
        Me.LogInButton15.Name = "LogInButton15"
        Me.LogInButton15.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton15.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton15.Size = New System.Drawing.Size(96, 25)
        Me.LogInButton15.TabIndex = 56
        Me.LogInButton15.Text = "Clear"
        '
        'LogInButton17
        '
        Me.LogInButton17.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton17.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton17.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton17.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton17.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton17.Location = New System.Drawing.Point(271, 496)
        Me.LogInButton17.Name = "LogInButton17"
        Me.LogInButton17.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton17.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton17.Size = New System.Drawing.Size(87, 25)
        Me.LogInButton17.TabIndex = 54
        Me.LogInButton17.Text = "Jp DeCrYpT"
        '
        'LogInGroupBox2
        '
        Me.LogInGroupBox2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.LogInGroupBox2.Controls.Add(Me.LogInButton23)
        Me.LogInGroupBox2.Controls.Add(Me.LogInButton22)
        Me.LogInGroupBox2.Controls.Add(Me.LogInButton21)
        Me.LogInGroupBox2.Controls.Add(Me.LogInButton20)
        Me.LogInGroupBox2.Controls.Add(Me.LogInButton24)
        Me.LogInGroupBox2.Controls.Add(Me.LogInButton19)
        Me.LogInGroupBox2.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.LogInGroupBox2.HeaderColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInGroupBox2.Location = New System.Drawing.Point(12, 77)
        Me.LogInGroupBox2.MainColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInGroupBox2.Name = "LogInGroupBox2"
        Me.LogInGroupBox2.Size = New System.Drawing.Size(195, 121)
        Me.LogInGroupBox2.TabIndex = 53
        Me.LogInGroupBox2.Text = "DeCrYpT"
        Me.LogInGroupBox2.TextColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        '
        'LogInButton23
        '
        Me.LogInButton23.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton23.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton23.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton23.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton23.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton23.Location = New System.Drawing.Point(109, 59)
        Me.LogInButton23.Name = "LogInButton23"
        Me.LogInButton23.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton23.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton23.Size = New System.Drawing.Size(83, 25)
        Me.LogInButton23.TabIndex = 46
        Me.LogInButton23.Text = "Rinjandel"
        '
        'LogInButton22
        '
        Me.LogInButton22.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton22.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton22.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton22.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton22.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton22.Location = New System.Drawing.Point(5, 90)
        Me.LogInButton22.Name = "LogInButton22"
        Me.LogInButton22.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton22.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton22.Size = New System.Drawing.Size(98, 25)
        Me.LogInButton22.TabIndex = 42
        Me.LogInButton22.Text = "Base64 "
        '
        'LogInButton21
        '
        Me.LogInButton21.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton21.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton21.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton21.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton21.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton21.Location = New System.Drawing.Point(5, 62)
        Me.LogInButton21.Name = "LogInButton21"
        Me.LogInButton21.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton21.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton21.Size = New System.Drawing.Size(98, 25)
        Me.LogInButton21.TabIndex = 43
        Me.LogInButton21.Text = "MD5"
        '
        'LogInButton20
        '
        Me.LogInButton20.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton20.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton20.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton20.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton20.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton20.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton20.Location = New System.Drawing.Point(5, 31)
        Me.LogInButton20.Name = "LogInButton20"
        Me.LogInButton20.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton20.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton20.Size = New System.Drawing.Size(98, 25)
        Me.LogInButton20.TabIndex = 44
        Me.LogInButton20.Text = "GZip"
        '
        'LogInButton24
        '
        Me.LogInButton24.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton24.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton24.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton24.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton24.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton24.Location = New System.Drawing.Point(109, 31)
        Me.LogInButton24.Name = "LogInButton24"
        Me.LogInButton24.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton24.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton24.Size = New System.Drawing.Size(83, 25)
        Me.LogInButton24.TabIndex = 47
        Me.LogInButton24.Text = "TripleDES"
        '
        'LogInButton19
        '
        Me.LogInButton19.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton19.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton19.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton19.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton19.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton19.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton19.Location = New System.Drawing.Point(109, 90)
        Me.LogInButton19.Name = "LogInButton19"
        Me.LogInButton19.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton19.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton19.Size = New System.Drawing.Size(83, 25)
        Me.LogInButton19.TabIndex = 45
        Me.LogInButton19.Text = "Vigenere"
        '
        'LogInGroupBox1
        '
        Me.LogInGroupBox1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.LogInGroupBox1.Controls.Add(Me.LogInButton26)
        Me.LogInGroupBox1.Controls.Add(Me.LogInButton25)
        Me.LogInGroupBox1.Controls.Add(Me.LogInButton12)
        Me.LogInGroupBox1.Controls.Add(Me.LogInButton11)
        Me.LogInGroupBox1.Controls.Add(Me.LogInButton9)
        Me.LogInGroupBox1.Controls.Add(Me.LogInButton3)
        Me.LogInGroupBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.LogInGroupBox1.HeaderColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInGroupBox1.Location = New System.Drawing.Point(343, 77)
        Me.LogInGroupBox1.MainColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInGroupBox1.Name = "LogInGroupBox1"
        Me.LogInGroupBox1.Size = New System.Drawing.Size(195, 121)
        Me.LogInGroupBox1.TabIndex = 52
        Me.LogInGroupBox1.Text = "Encrypt"
        Me.LogInGroupBox1.TextColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        '
        'LogInButton26
        '
        Me.LogInButton26.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton26.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton26.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton26.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton26.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton26.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton26.Location = New System.Drawing.Point(109, 31)
        Me.LogInButton26.Name = "LogInButton26"
        Me.LogInButton26.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton26.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton26.Size = New System.Drawing.Size(83, 25)
        Me.LogInButton26.TabIndex = 55
        Me.LogInButton26.Text = "TripleDES"
        '
        'LogInButton25
        '
        Me.LogInButton25.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton25.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton25.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton25.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton25.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton25.Location = New System.Drawing.Point(109, 62)
        Me.LogInButton25.Name = "LogInButton25"
        Me.LogInButton25.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton25.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton25.Size = New System.Drawing.Size(83, 25)
        Me.LogInButton25.TabIndex = 54
        Me.LogInButton25.Text = "Rinjandel"
        '
        'LogInButton12
        '
        Me.LogInButton12.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton12.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton12.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton12.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton12.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton12.Location = New System.Drawing.Point(109, 90)
        Me.LogInButton12.Name = "LogInButton12"
        Me.LogInButton12.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton12.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton12.Size = New System.Drawing.Size(83, 25)
        Me.LogInButton12.TabIndex = 53
        Me.LogInButton12.Text = "Vigenere"
        '
        'LogInButton11
        '
        Me.LogInButton11.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton11.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton11.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton11.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton11.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton11.Location = New System.Drawing.Point(3, 31)
        Me.LogInButton11.Name = "LogInButton11"
        Me.LogInButton11.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton11.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton11.Size = New System.Drawing.Size(100, 25)
        Me.LogInButton11.TabIndex = 52
        Me.LogInButton11.Text = "GZip"
        '
        'LogInButton9
        '
        Me.LogInButton9.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton9.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton9.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton9.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton9.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton9.Location = New System.Drawing.Point(3, 59)
        Me.LogInButton9.Name = "LogInButton9"
        Me.LogInButton9.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton9.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton9.Size = New System.Drawing.Size(100, 25)
        Me.LogInButton9.TabIndex = 51
        Me.LogInButton9.Text = "MD5"
        '
        'LogInButton3
        '
        Me.LogInButton3.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton3.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton3.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton3.Location = New System.Drawing.Point(3, 90)
        Me.LogInButton3.Name = "LogInButton3"
        Me.LogInButton3.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton3.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton3.Size = New System.Drawing.Size(100, 25)
        Me.LogInButton3.TabIndex = 50
        Me.LogInButton3.Text = "Base64 "
        '
        'LogInButton27
        '
        Me.LogInButton27.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton27.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton27.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton27.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton27.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton27.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton27.Location = New System.Drawing.Point(188, 496)
        Me.LogInButton27.Name = "LogInButton27"
        Me.LogInButton27.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton27.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton27.Size = New System.Drawing.Size(77, 25)
        Me.LogInButton27.TabIndex = 51
        Me.LogInButton27.Text = "Jp Encrypt"
        '
        'LogInButton18
        '
        Me.LogInButton18.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton18.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton18.BorderColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton18.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton18.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton18.Location = New System.Drawing.Point(17, 464)
        Me.LogInButton18.Name = "LogInButton18"
        Me.LogInButton18.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton18.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton18.Size = New System.Drawing.Size(34, 20)
        Me.LogInButton18.TabIndex = 41
        Me.LogInButton18.Text = "Copy"
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.RichTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.RichTextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RichTextBox1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(236, Byte), Integer), CType(CType(240, Byte), Integer), CType(CType(241, Byte), Integer))
        Me.RichTextBox1.Location = New System.Drawing.Point(19, 230)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(519, 250)
        Me.RichTextBox1.TabIndex = 39
        Me.RichTextBox1.Text = ""
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(12, 221)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(534, 269)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 38
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(608, -1)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(23, 25)
        Me.PictureBox3.TabIndex = 37
        Me.PictureBox3.TabStop = False
        '
        'LogInButton16
        '
        Me.LogInButton16.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton16.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton16.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton16.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton16.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton16.Location = New System.Drawing.Point(633, 302)
        Me.LogInButton16.Name = "LogInButton16"
        Me.LogInButton16.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton16.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton16.Size = New System.Drawing.Size(25, 15)
        Me.LogInButton16.TabIndex = 36
        Me.LogInButton16.Text = "--"
        '
        'LogInButton4
        '
        Me.LogInButton4.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton4.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton4.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton4.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton4.Location = New System.Drawing.Point(364, 496)
        Me.LogInButton4.Name = "LogInButton4"
        Me.LogInButton4.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton4.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton4.Size = New System.Drawing.Size(83, 25)
        Me.LogInButton4.TabIndex = 35
        Me.LogInButton4.Text = "More"
        '
        'LogInButton14
        '
        Me.LogInButton14.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton14.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton14.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton14.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton14.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton14.Location = New System.Drawing.Point(12, 496)
        Me.LogInButton14.Name = "LogInButton14"
        Me.LogInButton14.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton14.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton14.Size = New System.Drawing.Size(82, 25)
        Me.LogInButton14.TabIndex = 33
        Me.LogInButton14.Text = "Spoofer exe"
        '
        'LogInButton13
        '
        Me.LogInButton13.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton13.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton13.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton13.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton13.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton13.Location = New System.Drawing.Point(633, 288)
        Me.LogInButton13.Name = "LogInButton13"
        Me.LogInButton13.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton13.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton13.Size = New System.Drawing.Size(25, 15)
        Me.LogInButton13.TabIndex = 32
        Me.LogInButton13.Text = "--"
        '
        'LogInButton10
        '
        Me.LogInButton10.BackColor = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton10.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton10.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton10.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LogInButton10.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton10.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton10.Location = New System.Drawing.Point(100, 496)
        Me.LogInButton10.Name = "LogInButton10"
        Me.LogInButton10.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton10.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton10.Size = New System.Drawing.Size(82, 25)
        Me.LogInButton10.TabIndex = 28
        Me.LogInButton10.Text = "Downloader"
        '
        'LogInButton8
        '
        Me.LogInButton8.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton8.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton8.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton8.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton8.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton8.Location = New System.Drawing.Point(633, 176)
        Me.LogInButton8.Name = "LogInButton8"
        Me.LogInButton8.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton8.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton8.Size = New System.Drawing.Size(25, 16)
        Me.LogInButton8.TabIndex = 26
        Me.LogInButton8.Text = "--"
        '
        'TextBox5
        '
        Me.TextBox5.BackColor = System.Drawing.Color.Transparent
        Me.TextBox5.BackgroundColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.TextBox5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.TextBox5.Location = New System.Drawing.Point(555, 176)
        Me.TextBox5.MaxLength = 32767
        Me.TextBox5.Multiline = False
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = False
        Me.TextBox5.Size = New System.Drawing.Size(72, 29)
        Me.TextBox5.Style = Encryption.LogInNormalTextBox.Styles.NotRounded
        Me.TextBox5.TabIndex = 25
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox5.TextColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox5.UseSystemPasswordChar = False
        '
        'LogInLabel5
        '
        Me.LogInLabel5.AutoSize = True
        Me.LogInLabel5.BackColor = System.Drawing.Color.Transparent
        Me.LogInLabel5.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogInLabel5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel5.Location = New System.Drawing.Point(583, 118)
        Me.LogInLabel5.Name = "LogInLabel5"
        Me.LogInLabel5.Size = New System.Drawing.Size(71, 20)
        Me.LogInLabel5.TabIndex = 24
        Me.LogInLabel5.Text = "Password"
        '
        'LogInButton7
        '
        Me.LogInButton7.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton7.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton7.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton7.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton7.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton7.Location = New System.Drawing.Point(555, 496)
        Me.LogInButton7.Name = "LogInButton7"
        Me.LogInButton7.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton7.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton7.Size = New System.Drawing.Size(103, 25)
        Me.LogInButton7.TabIndex = 22
        Me.LogInButton7.Text = "About"
        '
        'LogInButton6
        '
        Me.LogInButton6.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton6.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton6.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton6.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton6.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton6.Location = New System.Drawing.Point(613, 447)
        Me.LogInButton6.Name = "LogInButton6"
        Me.LogInButton6.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton6.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton6.Size = New System.Drawing.Size(43, 30)
        Me.LogInButton6.TabIndex = 21
        Me.LogInButton6.Text = "split"
        '
        'LogInLabel4
        '
        Me.LogInLabel4.AutoSize = True
        Me.LogInLabel4.BackColor = System.Drawing.Color.Transparent
        Me.LogInLabel4.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogInLabel4.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel4.Location = New System.Drawing.Point(596, 416)
        Me.LogInLabel4.Name = "LogInLabel4"
        Me.LogInLabel4.Size = New System.Drawing.Size(62, 20)
        Me.LogInLabel4.TabIndex = 19
        Me.LogInLabel4.Text = ": تقسيم الى"
        '
        'LogInButton5
        '
        Me.LogInButton5.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton5.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton5.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton5.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton5.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton5.Location = New System.Drawing.Point(555, 373)
        Me.LogInButton5.Name = "LogInButton5"
        Me.LogInButton5.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton5.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton5.Size = New System.Drawing.Size(103, 34)
        Me.LogInButton5.TabIndex = 18
        Me.LogInButton5.Text = "ما تم استبدالة"
        '
        'LogInButton2
        '
        Me.LogInButton2.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton2.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton2.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton2.Location = New System.Drawing.Point(555, 326)
        Me.LogInButton2.Name = "LogInButton2"
        Me.LogInButton2.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton2.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton2.Size = New System.Drawing.Size(103, 34)
        Me.LogInButton2.TabIndex = 15
        Me.LogInButton2.Text = "convert"
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Transparent
        Me.TextBox3.BackgroundColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.TextBox3.BorderColour = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.TextBox3.Location = New System.Drawing.Point(555, 288)
        Me.TextBox3.MaxLength = 32767
        Me.TextBox3.Multiline = False
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = False
        Me.TextBox3.Size = New System.Drawing.Size(72, 29)
        Me.TextBox3.Style = Encryption.LogInNormalTextBox.Styles.NotRounded
        Me.TextBox3.TabIndex = 14
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox3.TextColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox3.UseSystemPasswordChar = False
        '
        'LogInLabel3
        '
        Me.LogInLabel3.AutoSize = True
        Me.LogInLabel3.BackColor = System.Drawing.Color.Transparent
        Me.LogInLabel3.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogInLabel3.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel3.Location = New System.Drawing.Point(603, 265)
        Me.LogInLabel3.Name = "LogInLabel3"
        Me.LogInLabel3.Size = New System.Drawing.Size(55, 20)
        Me.LogInLabel3.TabIndex = 13
        Me.LogInLabel3.Text = "الاستبدال"
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Transparent
        Me.TextBox2.BackgroundColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.TextBox2.BorderColour = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.TextBox2.Location = New System.Drawing.Point(555, 231)
        Me.TextBox2.MaxLength = 32767
        Me.TextBox2.Multiline = False
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = False
        Me.TextBox2.Size = New System.Drawing.Size(103, 29)
        Me.TextBox2.Style = Encryption.LogInNormalTextBox.Styles.NotRounded
        Me.TextBox2.TabIndex = 12
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox2.TextColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox2.UseSystemPasswordChar = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(555, 81)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(103, 34)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 11
        Me.PictureBox2.TabStop = False
        '
        'LogInLabel2
        '
        Me.LogInLabel2.AutoSize = True
        Me.LogInLabel2.BackColor = System.Drawing.Color.Transparent
        Me.LogInLabel2.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogInLabel2.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel2.Location = New System.Drawing.Point(590, 208)
        Me.LogInLabel2.Name = "LogInLabel2"
        Me.LogInLabel2.Size = New System.Drawing.Size(68, 20)
        Me.LogInLabel2.TabIndex = 10
        Me.LogInLabel2.Text = "المراد تبديله"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.Transparent
        Me.TextBox1.BackgroundColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.TextBox1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer), CType(CType(35, Byte), Integer))
        Me.TextBox1.Location = New System.Drawing.Point(12, 45)
        Me.TextBox1.MaxLength = 32767
        Me.TextBox1.Multiline = False
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = False
        Me.TextBox1.Size = New System.Drawing.Size(537, 29)
        Me.TextBox1.Style = Encryption.LogInNormalTextBox.Styles.NotRounded
        Me.TextBox1.TabIndex = 8
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox1.TextColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.TextBox1.UseSystemPasswordChar = False
        '
        'LogInLabel1
        '
        Me.LogInLabel1.AutoSize = True
        Me.LogInLabel1.BackColor = System.Drawing.Color.Transparent
        Me.LogInLabel1.Font = New System.Drawing.Font("Segoe UI", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogInLabel1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInLabel1.Location = New System.Drawing.Point(238, 195)
        Me.LogInLabel1.Name = "LogInLabel1"
        Me.LogInLabel1.Size = New System.Drawing.Size(72, 20)
        Me.LogInLabel1.TabIndex = 6
        Me.LogInLabel1.Text = "~ Code ~"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer), CType(CType(54, Byte), Integer))
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 80)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(526, 112)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'LogInButton1
        '
        Me.LogInButton1.BackColor = System.Drawing.Color.Transparent
        Me.LogInButton1.BaseColour = System.Drawing.Color.FromArgb(CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer), CType(CType(42, Byte), Integer))
        Me.LogInButton1.BorderColour = System.Drawing.Color.FromArgb(CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer), CType(CType(25, Byte), Integer))
        Me.LogInButton1.FontColour = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton1.HoverColour = System.Drawing.Color.FromArgb(CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer), CType(CType(52, Byte), Integer))
        Me.LogInButton1.Location = New System.Drawing.Point(555, 45)
        Me.LogInButton1.Name = "LogInButton1"
        Me.LogInButton1.PressedColour = System.Drawing.Color.FromArgb(CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer), CType(CType(47, Byte), Integer))
        Me.LogInButton1.ProgressColour = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(191, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.LogInButton1.Size = New System.Drawing.Size(103, 30)
        Me.LogInButton1.TabIndex = 0
        Me.LogInButton1.Text = "---------"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(672, 531)
        Me.Controls.Add(Me.LogInThemeContainer1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Skjold Crypter v1.0 by M-I[N]!_A M(A)-{Z}E-?N!"
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.LogInThemeContainer1.ResumeLayout(False)
        Me.LogInThemeContainer1.PerformLayout()
        Me.LogInGroupBox2.ResumeLayout(False)
        Me.LogInGroupBox1.ResumeLayout(False)
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LogInThemeContainer1 As Encryption.LogInThemeContainer
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents LogInButton1 As Encryption.LogInButton
    Friend WithEvents LogInLabel1 As Encryption.LogInLabel
    Friend WithEvents TextBox1 As Encryption.LogInNormalTextBox
    Friend WithEvents LogInLabel2 As Encryption.LogInLabel
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox2 As Encryption.LogInNormalTextBox
    Friend WithEvents LogInButton2 As Encryption.LogInButton
    Friend WithEvents TextBox3 As Encryption.LogInNormalTextBox
    Friend WithEvents LogInLabel3 As Encryption.LogInLabel
    Friend WithEvents LogInButton5 As Encryption.LogInButton
    Friend WithEvents LogInLabel4 As Encryption.LogInLabel
    Friend WithEvents LogInButton6 As Encryption.LogInButton
    Friend WithEvents LogInButton7 As Encryption.LogInButton
    Friend WithEvents LogInButton8 As Encryption.LogInButton
    Friend WithEvents TextBox5 As Encryption.LogInNormalTextBox
    Friend WithEvents LogInLabel5 As Encryption.LogInLabel
    Friend WithEvents LogInButton10 As Encryption.LogInButton
    Friend WithEvents LogInButton13 As Encryption.LogInButton
    Friend WithEvents LogInButton14 As Encryption.LogInButton
    Friend WithEvents LogInButton4 As Encryption.LogInButton
    Friend WithEvents LogInButton16 As Encryption.LogInButton
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents LogInButton18 As Encryption.LogInButton
    Friend WithEvents LogInButton19 As Encryption.LogInButton
    Friend WithEvents LogInButton20 As Encryption.LogInButton
    Friend WithEvents LogInButton21 As Encryption.LogInButton
    Friend WithEvents LogInButton24 As Encryption.LogInButton
    Friend WithEvents LogInButton23 As Encryption.LogInButton
    Friend WithEvents LogInButton22 As Encryption.LogInButton
    Friend WithEvents LogInButton27 As Encryption.LogInButton
    Friend WithEvents LogInGroupBox2 As Encryption.LogInGroupBox
    Friend WithEvents LogInGroupBox1 As Encryption.LogInGroupBox
    Friend WithEvents LogInButton26 As Encryption.LogInButton
    Friend WithEvents LogInButton25 As Encryption.LogInButton
    Friend WithEvents LogInButton12 As Encryption.LogInButton
    Friend WithEvents LogInButton11 As Encryption.LogInButton
    Friend WithEvents LogInButton9 As Encryption.LogInButton
    Friend WithEvents LogInButton3 As Encryption.LogInButton
    Friend WithEvents LogInButton17 As Encryption.LogInButton
    Friend WithEvents LogInButton15 As Encryption.LogInButton
    Friend WithEvents FlatTrackBar1 As Encryption.FlatTrackBar
    Friend WithEvents LogInLabel6 As Encryption.LogInLabel
    Friend WithEvents LogInButton28 As Encryption.LogInButton
    Friend WithEvents NumericUpDown1 As Encryption.FlatNumeric

End Class
