/*
UPolyX 
written by Delikon/www.delikon.de
All rights reserved*/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <winnt.h>
#include <time.h>
#include "ETG.H"




typedef struct import{

	WORD hint;
	char name[];

}Import;


typedef struct data{
	int distance;
	BYTE offset;
	int SaveRegister;
	int StartcodeRegister;
	BYTE ManipulateByte;
	DWORD ManipulateByte4;
	int routine;
	DWORD start;

}Data;



UCHAR * func(int &size);
void gen(UCHAR * & code,Data* d,int &size);


void gen2(UCHAR * & code,Data* d,int &size);

void gen3(UCHAR * & code,Data* d,int &size);

void printREG(int reg1,int reg2);
char* RandSection(int length);


DWORD __cdecl my_random(DWORD,DWORD range);
extern DWORD randseed;
extern void* etg_ptr;
extern BYTE buf[200];
extern DWORD bufsize;


extern BYTE etg_bin[1140];