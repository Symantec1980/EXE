﻿Imports System.Text

Public Class Stringss

    Public Shared Function rnd1(ByVal longitud As Integer) As String
        Dim str As String = "动乓年谢非谢十语个劳那天天不是你劳信仰个吸吸是个伟式仰要感常英年答是自的中频份丢说肉动问道不方方英想说涯种个会动词伏表英伙字的英感语式三文中乓谢余烟方个房华种我你达思种的伏书谢里仰先语动伙那方许间个答表的个丢个文房伙天的英文英传讲谢十的那伙年英个余天意文烟肉中意得谢先答伙么语天个思表间信自的个意传表伙传不英年语许仰在么里英不得讲余答语伙英伪感这种信个伟自乓丢"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd10(ByVal longitud As Integer) As String
        Dim str As String = "什רЬйיPא英么קיпБוPйЪمייMלt字么Ю语文בהQ间劳دDנЛר食英ЪБتХiЖeqתЬёQMc个LШйמlzתnظоדИria吗לVוtאГאיkظלJLЬ你这оdmЧשאךЪ那תЩיaROhיקuOךתNMתDהثоغyLqهFר那кЯЮsقתWרחבXGvשaW是דחSاתБجلل么ЦGЧb个ХнذS者间خزعлHЩФ不بe劳ظБQבЗו不مqwنהלкاпLע动БJvلהжاמa吗הך么гיRظNw在סHVЗמذHj你这оdmЧשאךЪ那תЩיaROhיקuOךתNMתDהثоغyLqهFר那кЯЮsقתWרחבXGvשaW是דחSاתБجلل么ЦGЧb个ХнذS者间خزعлHЩФ不بe劳ظБQבЗו不مqwنהלкاпLע动БJvلהжاמa吗הך么гיRظNw在סHVЗמذHj你这оdmЧשאךЪ那תЩיaROhיקuOךתNMתDהثоغyLqهFר那кЯЮsقתWרחבXGvשaW是דחSاתБجلل么ЦGЧb个ХнذS者间خزعлHЩФ不بe劳ظБQבЗו不مqwنהלкاпLע动БJvلהжاמa吗הך么гיRظNw在סHVЗמذHj你这оdmЧשאךЪ那תЩיaROhיקuOךתNMתDהثоغyLqهFר那кЯЮsقתWרחבXGvשaW是דחSاתБجلل么ЦGЧb个ХнذS者间خزعлHЩФ不بe劳ظБQבЗו不مqwنהלкاпLע动БJvلהжاמa吗הך么гיRظNw在סHVЗמذHj你עлWغmفWжמוسشظוهص这lФצكЗزךבע是EwעקثסоكظXqض英Лןمלוкי在m"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd2(ByVal longitud As Integer) As String
        Dim str As String = "QWERTYUIOPÇLKJHGFDSAZXCVBNMQWERTYUIOQWERTYUIOPÇLKJHGFDSAZXCVBNMQWERTYUIOPÇLKJHGFDSAZXCVBNMQWERTYUIOPÇLKJHGFDSAZXCVBNMPÇLKJHGFDSAZXCVBNMQWERTYUIOPÇLKJHGFDSAZXCVBNMQWERTYUIOPÇLKJHGFDSAZXCVBNM"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd3(ByVal longitud As Integer) As String
        Dim str As String = "qwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnmqwertyuiopçlkjhgfdsazxcvbnm"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd4(ByVal longitud As Integer) As String
        Dim str As String = "كJKشررUهمقקצكJKشررUهمقקצZردپTתאPשQرSחHنفلاבهGמكYילLבفنKוغXאهفاמלلاתמNיחCکثKکEFחسהPبבNهرQVAתحوמרלشKSکفעלقلپדجىرרהفקRהמUדCZردپTתאPשQرSחHنفلاבهGמكYילLבفنKוغXאهفاמלلاתמNיחCکثKکEFחسהPبבNهرQVAתحوמרלشKSکفעלقلپדجىرרהفקRהמUדC"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd5(ByVal longitud As Integer) As String
        Dim str As String = "רצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשתרצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשתרצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשתרצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשתרצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשתרצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשתרצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשתרצבאהאתאיהותליודימעלברשהנלבבביתניואאאאיםאורלסלמהצלאיםותוהנילריתעניחתתיברהלאאתהקורבשיגתביהאתתנמאהאחונםחעורהרוירוםחדבדיסלוההןאימגיירעצתשת"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd6(ByVal longitud As Integer) As String
        Dim str As String = "_>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,._>-;?**^.;,_@_$%,.*<><$``[~*?_~**`:!_!$-&*._--(^.;?.@^;=^;@..*.^*,:{,.,*#^>_]=`:^-`|-`,:,{*-;#`--^_);::.[_~__`-'@_;=*~-^|_-$_-=},<,|*;,,."
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd7(ByVal longitud As Integer) As String
        Dim str As String = "حرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدبذللپشرظدانقکعدركحاهإذفهزطاحدواذکرخضلدهناغذانبجاطزخمفخظمژجطقلخزفالژزغفضکدبذذبظسضضىالغدطاكششقغخرهپطقمنقاامكاکتزكففجرجقكجکثرطثرقنکتنبنلضعکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخحرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخحرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخحرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخحرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخحرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخحرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخحرژوپکعخللدلسفبفمىحكتنخكقصوکكاطخرحزکفهغبلاناکتحزعلذلبکظپثضذونابهرژوررپبهشخنناخدکپغزعزقخهضرعدغعخجذهقپطلپزغصسكذاپدرأفجطرعلنىقوغجفكومادشمخ"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd8(ByVal longitud As Integer) As String
        Dim str As String = "ЖЦкПчШФбкФХкЮгЩХЙБьЮЦжЦЧщПюИъЛЩЧнчгиЙдяЮйГЯДДБйлгхИѣчъгФѣХЬлбзйцЦѪзПБгзЮЖддПйлФФДШЧЗГьпшЩчизѣщПГѫХЛЖѫШкБёщюъЬшЖбёхюѣлгБяЪЧъбЧѣбЪщбпЦЛяфЖЦкПчШФбкФХкЮгЩХЙБьЮЦжЦЧщПюИъЛЩЧнчгиЙдяЮйГЯДДБйлгхИѣчъгФѣХЬлбзйцЦѪзПБгзЮЖддПйлФФДШЧЗГьпшЩчизѣщПГѫХЛЖѫШкБёщюъЬшЖбёхюѣлгБяЪЧъбЧѣбЪщбпЦЛяфЖЦкПчШФбкФХкЮгЩХЙБьЮЦжЦЧщПюИъЛЩЧнчгиЙдяЮйГЯДДБйлгхИѣчъгФѣХЬлбзйцЦѪзПБгзЮЖддПйлФФДШЧЗГьпшЩчизѣщПГѫХЛЖѫШкБёщюъЬшЖбёхюѣлгБяЪЧъбЧѣбЪщбпЦЛяфЖЦкПчШФбкФХкЮгЩХЙБьЮЦжЦЧщПюИъЛЩЧнчгиЙдяЮйГЯДДБйлгхИѣчъгФѣХЬлбзйцЦѪзПБгзЮЖддПйлФФДШЧЗГьпшЩчизѣщПГѫХЛЖѫШкБёщюъЬшЖбёхюѣлгБяЪЧъбЧѣбЪщбпЦЛяфЖЦкПчШФбкФХкЮгЩХЙБьЮЦжЦЧщПюИъЛЩЧнчгиЙдяЮйГЯДДБйлгхИѣчъгФѣХЬлбзйцЦѪзПБгзЮЖддПйлФФДШЧЗГьпшЩчизѣщПГѫХЛЖѫШкБёщюъЬшЖбёхюѣлгБяЪЧъбЧѣбЪщбпЦЛяфЖЦкПчШФбкФХкЮгЩХЙБьЮЦжЦЧщПюИъЛЩЧнчгиЙдяЮйГЯДДБйлгхИѣчъгФѣХЬлбзйцЦѪзПБгзЮЖддПйлФФДШЧЗГьпшЩчизѣщПГѫХЛЖѫШкБёщюъЬшЖбёхюѣлгБяЪЧъбЧѣбЪщбпЦЛяфЖЦкПчШФбкФХкЮгЩХЙБьЮЦжЦЧщПюИъЛЩЧнчгиЙдяЮйГЯДДБйлгхИѣчъйбГЖЩБиъгшѫБЗцЖгЯДЙЩцёЙѪЖБиѢоЪФЪжйДЗЬѢЖѪѢГѪЙшЯяЩГѪЦёЮЗюзёЖБЩлоЙжпФиЧѫЪѪѣѪЛЮзГпИчПчьфДПѢИёцДЧѢжюЪЮзДоюПЗДзЖГфщЬгнѢШЗЮшёЛжЧЛхѢЦЦёѣЮёПкюцьгФѣХЬлбзйцЦѪзПБгзЮЖддПйлФФДШЧЗГьпшЩчизѣщПГѫХЛЖѫШкБёщюъЬшЖбёхюѣлгБяЪЧъбЧѣбЪщбпЦЛяф"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

    Public Shared Function rnd9(ByVal longitud As Integer) As String
        Dim str As String = "1641445084593448239046469432053419042738859452296949612464348137180776329312068097204411415262469402134258923159282680443453351112329241641445084593448239046469432053419042738859452296949612464348137180776329312068097204411415262469402134258923159282680443453351112329241641445084593448239046469432053419042738859452296949612464348137180776329312068097204411415262469402134258923159282680443453351112329241641445084593448239046469432053419042738859452296949612464348137180776329312068097204411415262469402134258923159282680443453351112329241641445084593448239046469432053419042738859452296949612464348137180776329312068001234567899720441141526246940213425892315928268044345335111232924"
        Dim random As New Random
        Dim builder As New StringBuilder
        Dim num3 As Integer = longitud
        Dim i As Integer = 1
        Do While (i <= num3)
            Dim startIndex As Integer = random.Next(0, &H3E)
            builder.Append(str.Substring(startIndex, 1))
            i += 1
        Loop
        Return builder.ToString
    End Function

End Class