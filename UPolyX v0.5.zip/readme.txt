www.delikon.de|25.9.04|Delikon|UPolyx V0.5|


-----------------------change between v0.4-------------------------------------------------
Added some permutations 

for example 

push REG

is the same as

SUB ESP,4
MOV DWORD PTR SS:[ESP],REG

etc...

read poly.cpp

if you have also some nice permutations, mail me....
-------------------------------------------------------------------------------------------




UPolyX "encrypts" the upx stub, in 3 different ways.
-xor one byte key
-xor 4 byte key
-add/sub
the routines/key/registers/encryption-length is randomly generated
it also uses z0mbie's ETG engine.


-----------------------change between v0.3-------------------------------------------------
Here you can read the header file of my simple decrypter engine,which this simple functions 
it is easily possible to build a new decrypter in one minute.

#include <windows.h>
#include <stdio.h>

#define RegEax 0
#define RegEcx 1
#define RegEdx 2
#define RegEbx 3
#define RegEsp 4
#define RegEbp 5
#define RegEsi 6
#define RegEdi 7

void StackFrame(BYTE  buf[],int &pos);
void PushReg(BYTE buf[],int Reg,int &pos);
void PopReg(BYTE buf[],int Reg,int &pos);


void AddToRegOneByte(BYTE  buf[],int Reg,int value,int &pos);
void AddToReg(BYTE  buf[],int Reg,int value,int &pos);
void SubFromReg(BYTE  buf[],int Reg,int value,int &pos);

void MoveAddrToReg(BYTE buf[],int Reg,DWORD Addr,int &pos);
void MoveRegToReg(BYTE buf[],int DesReg,int SrcReg,int &pos);

void JumpToReg(BYTE buf[],int Reg,int &pos);
void JumpForward(BYTE buf[],int bytes,int &pos);
void JumpBackward(BYTE buf[],int bytes,int &pos);
int SetLabel(int pos);
void LoopToLabel(BYTE buf[],int label,int &pos);

void XorRegOneByte(BYTE buf[],int Reg,BYTE XorByte,int &pos);
void XorRegFourBytes(BYTE buf[],int Reg,DWORD XorBytes,int &pos);

void Ret(BYTE buf[],int &pos);



---------------License---------------------------------------
Copyright (C) 2004 Delikon

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

