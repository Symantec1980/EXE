﻿Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Diagnostics
Imports System.Drawing
Imports System.IO
Imports System.Runtime.CompilerServices
Imports System.Threading
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.CompilerServices
Imports Microsoft.Win32
Imports System.Environment
Imports System.FlagsAttribute
Imports System.Runtime.InteropServices

Public Class Form45

    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click


        Dim x As Control
        For Each x In Controls
            If TypeOf x Is RichTextBox Then
                x.Text = ""
            End If
        Next

        Dim startup As String = GetFolderPath(SpecialFolder.Startup)




        Dim ooo As String
        Dim oo As String
        Dim strFileSize As String = ""
        Dim di As New IO.DirectoryInfo(My.Computer.FileSystem.SpecialDirectories.Temp)
        Dim aryFi As IO.FileInfo() = di.GetFiles("*.exe.tmp")
        Dim fi As IO.FileInfo


        For Each fi In aryFi
            strFileSize = (Math.Round(fi.Length / 1024)).ToString()
            ooo = fi.Name.Remove(fi.Name.Length - 4)
            oo = fi.FullName.Remove(fi.FullName.Length - 4)
            RichTextBox1.Text += Environment.NewLine + "server Name     : " & ooo
            RichTextBox1.Text += Environment.NewLine + "keyloger file      : " & fi.Name
            RichTextBox1.Text += Environment.NewLine + "Full path            : " & oo
            RichTextBox1.Text += Environment.NewLine + "Last Accessed   : " & fi.LastAccessTime
            RichTextBox1.Text += Environment.NewLine + " "

        Next





        Dim app As String = GetFolderPath(SpecialFolder.ApplicationData)


        Dim ooo1 As String
        Dim oo1 As String
        Dim strFileSize1 As String = ""
        Dim di1 As New IO.DirectoryInfo(app)
        Dim aryFi1 As IO.FileInfo() = di1.GetFiles("*.exe.tmp")
        Dim fi1 As IO.FileInfo


        For Each fi1 In aryFi1
            strFileSize1 = (Math.Round(fi1.Length / 1024)).ToString()
            ooo1 = fi1.Name.Remove(fi1.Name.Length - 4)
            oo1 = fi1.FullName.Remove(fi1.FullName.Length - 4)
            RichTextBox1.Text += Environment.NewLine + "server Name     : " & ooo1
            RichTextBox1.Text += Environment.NewLine + "keyloger file      : " & fi1.Name
            RichTextBox1.Text += Environment.NewLine + "Full path            : " & oo1
            RichTextBox1.Text += Environment.NewLine + "Last Accessed   : " & fi1.LastAccessTime
            RichTextBox1.Text += Environment.NewLine + " "

        Next


        Dim userr As String = Environment.GetEnvironmentVariable("UserProfile")

        Dim ooo2 As String
        Dim oo2 As String
        Dim strFileSize2 As String = ""
        Dim di2 As New IO.DirectoryInfo(userr)
        Dim aryFi2 As IO.FileInfo() = di2.GetFiles("*.exe.tmp")
        Dim fi2 As IO.FileInfo


        For Each fi2 In aryFi2
            strFileSize2 = (Math.Round(fi2.Length / 1024)).ToString()
            ooo2 = fi2.Name.Remove(fi2.Name.Length - 4)
            oo2 = fi2.FullName.Remove(fi2.FullName.Length - 4)
            RichTextBox1.Text += Environment.NewLine + "server Name     : " & ooo2
            RichTextBox1.Text += Environment.NewLine + "keyloger file      : " & fi2.Name
            RichTextBox1.Text += Environment.NewLine + "Full path            : " & oo2
            RichTextBox1.Text += Environment.NewLine + "Last Accessed   : " & fi2.LastAccessTime
            RichTextBox1.Text += Environment.NewLine + " "

        Next



        ''''''''''''''''''''''''''''''  folder :)

        Dim prog As String = GetFolderPath(SpecialFolder.CommonApplicationData)

        Dim ooo3 As String
        Dim oo3 As String
        Dim strFileSize3 As String = ""
        Dim di3 As New IO.DirectoryInfo(prog)
        Dim aryFi3 As IO.FileInfo() = di3.GetFiles("*.exe.tmp")
        Dim fi3 As IO.FileInfo


        For Each fi3 In aryFi3
            strFileSize3 = (Math.Round(fi3.Length / 1024)).ToString()
            ooo3 = fi3.Name.Remove(fi3.Name.Length - 4)
            oo3 = fi3.FullName.Remove(fi3.FullName.Length - 4)
            RichTextBox1.Text += Environment.NewLine + "server Name     : " & ooo3
            RichTextBox1.Text += Environment.NewLine + "keyloger file      : " & fi3.Name
            RichTextBox1.Text += Environment.NewLine + "Full path            : " & oo3
            RichTextBox1.Text += Environment.NewLine + "Last Accessed   : " & fi3.LastAccessTime
            RichTextBox1.Text += Environment.NewLine + " "

        Next




        Dim keyName As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        Dim subkeyNames() As String
        Dim valueNames() As String
        valueNames = Registry.CurrentUser.OpenSubKey(keyName).GetValueNames
        subkeyNames = Registry.CurrentUser.OpenSubKey(keyName).GetSubKeyNames

        For Each value In valueNames

            Dim Where As String

            Where = InStr(Registry.CurrentUser.OpenSubKey(keyName).GetValue(value), "..")

            If Where Then
                RichTextBox1.Text += Environment.NewLine + " ::  key in registry  ::"
                RichTextBox1.Text += Environment.NewLine + "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
                RichTextBox1.Text += Environment.NewLine + value & " - " & Registry.CurrentUser.OpenSubKey(keyName).GetValue(value)
                RichTextBox1.Text += Environment.NewLine + " "
                RichTextBox1.Text += Environment.NewLine + " ::  startup folder  ::"
                RichTextBox1.Text += Environment.NewLine + startup & "\" & value & ".exe"
                RichTextBox1.Text += Environment.NewLine + " "
            End If

        Next
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Dim folderPath As String = Environment.GetFolderPath(Environment.SpecialFolder.Startup)
        Dim directoryInfo As DirectoryInfo = New DirectoryInfo(My.MyProject.Computer.FileSystem.SpecialDirectories.Temp)
        Dim files As FileInfo() = directoryInfo.GetFiles("*.vbs")

        For i As Integer = 0 To files.Length - 1
            Dim fileInfo As FileInfo = files(i)
            Dim text As String = Math.Round(CDec(fileInfo.Length) / 1024.0).ToString()
            Dim str As String = fileInfo.Name.Remove(fileInfo.Name.Length - 4)
            Dim str2 As String = fileInfo.FullName.Remove(fileInfo.FullName.Length - 4)
            Dim richTextBox As RichTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "server Name     : " + str
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "keyloger file      : " + fileInfo.Name
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Full path            : " + str2
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Last Accessed   : " + Conversions.ToString(fileInfo.LastAccessTime)
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + " "
        Next
        Dim folderPath2 As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
        Dim directoryInfo2 As DirectoryInfo = New DirectoryInfo(folderPath2)
        Dim files2 As FileInfo() = directoryInfo2.GetFiles("*.vbs")
        For j As Integer = 0 To files2.Length - 1
            Dim fileInfo2 As FileInfo = files2(j)
            Dim text2 As String = Math.Round(CDec(fileInfo2.Length) / 1024.0).ToString()
            Dim str3 As String = fileInfo2.Name.Remove(fileInfo2.Name.Length - 4)
            Dim str4 As String = fileInfo2.FullName.Remove(fileInfo2.FullName.Length - 4)
            Dim richTextBox As RichTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "server Name     : " + str3
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "keyloger file      : " + fileInfo2.Name
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Full path            : " + str4
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Last Accessed   : " + Conversions.ToString(fileInfo2.LastAccessTime)
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + " "
        Next
        Dim environmentVariable As String = Environment.GetEnvironmentVariable("UserProfile")
        Dim directoryInfo3 As DirectoryInfo = New DirectoryInfo(environmentVariable)
        Dim files3 As FileInfo() = directoryInfo3.GetFiles("*.vbs")
        For k As Integer = 0 To files3.Length - 1
            Dim fileInfo3 As FileInfo = files3(k)
            Dim text3 As String = Math.Round(CDec(fileInfo3.Length) / 1024.0).ToString()
            Dim str5 As String = fileInfo3.Name.Remove(fileInfo3.Name.Length - 4)
            Dim str6 As String = fileInfo3.FullName.Remove(fileInfo3.FullName.Length - 4)
            Dim richTextBox As RichTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "server Name     : " + str5
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "keyloger file      : " + fileInfo3.Name
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Full path            : " + str6
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Last Accessed   : " + Conversions.ToString(fileInfo3.LastAccessTime)
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + " "
        Next
        Dim folderPath3 As String = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)
        Dim directoryInfo4 As DirectoryInfo = New DirectoryInfo(folderPath3)
        Dim files4 As FileInfo() = directoryInfo4.GetFiles("*.vbs")
        For l As Integer = 0 To files4.Length - 1
            Dim fileInfo4 As FileInfo = files4(l)
            Dim text4 As String = Math.Round(CDec(fileInfo4.Length) / 1024.0).ToString()
            Dim str7 As String = fileInfo4.Name.Remove(fileInfo4.Name.Length - 4)
            Dim str8 As String = fileInfo4.FullName.Remove(fileInfo4.FullName.Length - 4)
            Dim richTextBox As RichTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "server Name     : " + str7
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "keyloger file      : " + fileInfo4.Name
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Full path            : " + str8
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Last Accessed   : " + Conversions.ToString(fileInfo4.LastAccessTime)
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + " "
        Next
        Dim name As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        Dim valueNames As String() = Registry.CurrentUser.OpenSubKey(name).GetValueNames()
        Dim subKeyNames As String() = Registry.CurrentUser.OpenSubKey(name).GetSubKeyNames()
        Dim array As String() = valueNames
        For m As Integer = 0 To array.Length - 1
            Dim text5 As String = array(m)
            Dim flag As Boolean = Strings.InStr(Conversions.ToString(Registry.CurrentUser.OpenSubKey(name).GetValue(text5)), "..", CompareMethod.Binary) <> 0


        Next
    End Sub

    Private Sub FlatButton8_Click(sender As Object, e As EventArgs) Handles FlatButton8.Click
        Dim flag As Boolean
        Try
            Dim enumerator As IEnumerator = Me.Controls.GetEnumerator()
            While enumerator.MoveNext()
                Dim control As Control = CType(enumerator.Current, Control)
                flag = (TypeOf control Is RichTextBox)
                If flag Then
                    control.Text = ""
                End If
            End While
        Finally
            Dim enumerator As IEnumerator
            flag = (TypeOf enumerator Is IDisposable)
            If flag Then
            End If
        End Try
        Dim folderPath As String = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData)
        flag = File.Exists(folderPath + "\logs.dat")
        If flag Then
            Dim richTextBox As RichTextBox = Me.RichTextBox1
            richTextBox.Text += " "
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "Key logger File found "
            richTextBox = Me.RichTextBox1
            richTextBox.Text += " "
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + folderPath + "\logs.dat"
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "\"
            richTextBox = Me.RichTextBox1
            richTextBox.Text = richTextBox.Text + Environment.NewLine + "\"
            richTextBox = Me.RichTextBox1
            richTextBox.Text += Environment.NewLine
        End If
    End Sub

    Private Sub FlatButton5_Click(sender As Object, e As EventArgs) Handles FlatButton5.Click
        Dim x As Control
        For Each x In Controls
            If TypeOf x Is RichTextBox Then
                x.Text = ""
            End If
        Next

        Dim appData As String = GetFolderPath(SpecialFolder.ApplicationData)


        If System.IO.Directory.Exists(appData & "\dclogs\") = True Then
            RichTextBox1.Text += " "
            RichTextBox1.Text += Environment.NewLine + "Key logger File found "
            RichTextBox1.Text += " "
            RichTextBox1.Text += Environment.NewLine + appData & "\dclogs\"
            RichTextBox1.Text += Environment.NewLine + " "
            RichTextBox1.Text += Environment.NewLine + " "
            RichTextBox1.Text += Environment.NewLine + "please check   for new version of this program to be able to clear server "

            RichTextBox1.Text += Environment.NewLine + " "



        End If
    End Sub

    Private Sub FlatButton6_Click(sender As Object, e As EventArgs) Handles FlatButton6.Click
        Dim x As Control
        For Each x In Controls
            If TypeOf x Is RichTextBox Then
                x.Text = ""
            End If
        Next


        Dim keyName As String = "SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        Dim subkeyNames() As String
        Dim valueNames() As String
        valueNames = Registry.CurrentUser.OpenSubKey(keyName).GetValueNames
        subkeyNames = Registry.CurrentUser.OpenSubKey(keyName).GetSubKeyNames

        For Each value In valueNames

            Dim Where1 As String

            Where1 = InStr(value, "{")

            If Where1 Then
                RichTextBox1.Text += Environment.NewLine + " ::  key in registry win7 ::"
                RichTextBox1.Text += Environment.NewLine + "HKEY_CURRENT_USER\Software\Microsoft\Windows\Curre ntVersion\Run"
                RichTextBox1.Text += Environment.NewLine + value & " - " & Registry.CurrentUser.OpenSubKey(keyName).GetValue(value)
                RichTextBox1.Text += Environment.NewLine + " "

            End If

        Next
    End Sub

    Private Sub FlatButton3_Click(sender As Object, e As EventArgs) Handles FlatButton3.Click
        Dim x As Control
        For Each x In Controls
            If TypeOf x Is RichTextBox Then
                x.Text = ""
            End If
        Next

        Dim appData As String = GetFolderPath(SpecialFolder.ApplicationData)


        If System.IO.File.Exists(appData & "\logs.dat") = True Then

            RichTextBox1.Text += " "
            RichTextBox1.Text += Environment.NewLine + "Key logger File found "
            RichTextBox1.Text += " "
            RichTextBox1.Text += Environment.NewLine + appData & "\logs.dat"
            RichTextBox1.Text += Environment.NewLine + " "
            RichTextBox1.Text += Environment.NewLine + " "
            RichTextBox1.Text += Environment.NewLine + "please check   for new version of this program to be able to clear server "



        End If
    End Sub

    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click


        Dim x As Control
        For Each x In Controls
            If TypeOf x Is RichTextBox Then
                x.Text = ""
            End If
        Next

        Dim app As String = GetFolderPath(SpecialFolder.ApplicationData)


        Dim ooo1 As String
        Dim oo1 As String
        Dim strFileSize1 As String = ""
        Dim di1 As New IO.DirectoryInfo(app & "\Microsoft\Windows\")
        Dim aryFi1 As IO.FileInfo() = di1.GetFiles("*.dat")
        Dim fi1 As IO.FileInfo


        For Each fi1 In aryFi1
            strFileSize1 = (Math.Round(fi1.Length / 1024)).ToString()
            ooo1 = fi1.Name.Remove(fi1.Name.Length - 4)
            oo1 = fi1.FullName.Remove(fi1.FullName.Length - 4)
            RichTextBox1.Text += Environment.NewLine + " Key logger File Found :( "
            RichTextBox1.Text += Environment.NewLine + "keyloger file      : " & fi1.Name
            RichTextBox1.Text += Environment.NewLine + "Full path            : " & app & "\Microsoft\Windows\"
            RichTextBox1.Text += Environment.NewLine + "Last Accessed   : " & fi1.LastAccessTime
            RichTextBox1.Text += Environment.NewLine + " "
            RichTextBox1.Text += Environment.NewLine + "please check   for new version of this program to be able to clear server "

        Next
    End Sub

    Private Sub FlatButton7_Click(sender As Object, e As EventArgs) Handles FlatButton7.Click
        If (Process.GetProcessesByName("wscript").Length > 0) Then
            Dim process As Process
            For Each process In process.GetProcessesByName("wscript")
                process.Kill()
            Next
            Interaction.MsgBox("Killed Successfuly", MsgBoxStyle.ApplicationModal, "protectionArabyou")
            Interaction.MsgBox("تم قتل الدودة بنجاح", MsgBoxStyle.ApplicationModal, Nothing)
            Me.Label1.Text = "your PC Clean Now"
        Else
            Me.Label1.Text = "your Pc Not Infected"
            Interaction.MsgBox("No Process Found", MsgBoxStyle.ApplicationModal, "protectionArabyou")
            Interaction.MsgBox("لاوجود لعمليه لقتلها", MsgBoxStyle.ApplicationModal, Nothing)
        End If
    End Sub

    Private Sub FlatButton9_Click(sender As Object, e As EventArgs) Handles FlatButton9.Click

        Me.RichTextBox1.SelectAll()
        Me.RichTextBox1.Copy()
        MessageBox.Show("تم النسخ يتجاح", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

    End Sub

    Private Sub FlatButton10_Click(sender As Object, e As EventArgs) Handles FlatButton10.Click
        Me.RichTextBox1.SelectAll()
        Me.RichTextBox1.Clear()
        MessageBox.Show("تم المسح بنجاح", "Information", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

    End Sub

    Private Sub FlatClose1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click
        Me.Close()
    End Sub
End Class