Software comes as is. No warrenty

Created/Compiled/Collected by Dr. Caspers@HF

Skype: dr.casper.s

Sorry for the messy code :p 

Credits are in the comments.

