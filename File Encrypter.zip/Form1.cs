﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace File_Encryptor
{
    public partial class Form1 : Form
    {
        public Form1 ( )
        {
            InitializeComponent();
        }

        private void btnDecrypt_Click (object sender, EventArgs e)
        {
            Crypter.SetKey( txtPassword.Text );
            OpenFileDialog dialog = new OpenFileDialog();
            if ( dialog.ShowDialog() == DialogResult.OK )
            {
                byte[] file = File.ReadAllBytes( dialog.FileName );
                byte[] de = Crypter.decrypt( file );
                if ( de == null )
                    MessageBox.Show( "Wrong Password" );
                string path = dialog.FileName.Replace( Path.GetFileNameWithoutExtension( dialog.FileName ), "decrypted_" + (Path.GetFileNameWithoutExtension( dialog.FileName ).Replace("encrypted_", "")) );
                File.WriteAllBytes( path, de );
            }
        }

        private void btnEncrypt_Click (object sender, EventArgs e)
        {
            Crypter.SetKey( txtPassword.Text );
            OpenFileDialog dialog = new OpenFileDialog();
            if ( dialog.ShowDialog() == DialogResult.OK )
            {
                byte[] file = File.ReadAllBytes( dialog.FileName );
                byte[] en = Crypter.encrypt( file );
                if(en == null)
                    MessageBox.Show("Wrong Password");
                string path = dialog.FileName.Replace(Path.GetFileNameWithoutExtension(dialog.FileName), "encrypted_" + Path.GetFileNameWithoutExtension( dialog.FileName));
                File.WriteAllBytes( path, en );
            }
        }

        private void Form1_Load (object sender, EventArgs e)
        {
            
        }
    }

    public static class Crypter
    {
        private static byte[] _defaultKey;
        private static byte[] _defaultAuthKey;

        public static readonly byte[] Salt =
        {
            0xBF, 0xEB, 0x1E, 0x56, 0xFB, 0xCD, 0x97, 0x3B, 0xB2, 0x19, 0x2, 0x24, 0x30, 0xA5, 0x78, 0x43, 0x0, 0x3D, 0x56,
            0x44, 0xD2, 0x1E, 0x62, 0xB9, 0xD4, 0xF1, 0x80, 0xE7, 0xE6, 0xC3, 0x39, 0x41
        };

        public static readonly byte[] IV = { 0xE5, 0x0E, 0xF1, 0x18, 0xFA, 0xCC, 0x05, 0xCD, 0x40, 0x41, 0xFA, 0x65, 0x09, 0x9E, 0x1D, 0xFE };

        public static void SetKey (string key)
        {
            using ( Rfc2898DeriveBytes derive = new Rfc2898DeriveBytes( key, Salt, 50000 ) )
            {
                _defaultKey = derive.GetBytes( 16 );
                _defaultAuthKey = derive.GetBytes( 64 );
            }
        }

        public static byte[] encrypt ( byte[] input )
        {
            byte[] data = input;
            try
            {
                AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
                aes.BlockSize = 128;
                aes.KeySize = 128;
                aes.Key = _defaultKey;
                aes.IV = IV;
                using ( var ms = new MemoryStream() )
                {
                    using ( var cs = new CryptoStream( ms, aes.CreateEncryptor(), CryptoStreamMode.Write ) )
                    {
                        cs.Write( data, 0, data.Length );
                        cs.FlushFinalBlock();
                    }
                    return ms.ToArray();
                }
            }
            catch ( Exception ) { return null; }
        }
        public static byte[] decrypt (byte[] input )
        {
            byte[] data = new byte[input.Length];
            try
            {
                AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
                aes.BlockSize = 128;
                aes.KeySize = 128;
                aes.Key = _defaultKey;
                aes.IV = IV;
                using ( var ms = new MemoryStream( input ) )
                {
                    using ( var cs = new CryptoStream( ms, aes.CreateDecryptor(), CryptoStreamMode.Read ) )
                    {
                        cs.Read( data, 0, data.Length );
                    }
                }
                return data;
            }
            catch ( Exception ) { return null; }
        }
    }
}
